const express = require("express");
const connectDB = require("./src/clients/MongoDbClient");
const elasticDB = require("./src/services/elasticService.js");
const cors = require("cors");
const app = express();
const http = require("http");
const port = process.env.PORT || 9000;
const s3Routes = require("./src/routes/s3Routes");
const userRoute = require("./src/routes/userRoute");
const healthRoutes = require("./src/routes/healthRoutes");
const searchRoutes = require("./src/routes/searchRoutes");
const chatService = require("./src/services/chatService");
const config = require("./src/config/env");
const swaggerUi = require('swagger-ui-express');
const path = require('path');
const fs = require('fs');
const { Server } = require("socket.io");
const server = http.createServer(app);
const environment = process.env.NODE_ENV || 'STAGE'; // Default to 'STAGE' if NODE_ENV is not set
const elasticEnabled = process.env.ELASTIC_ENABLED === 'true'
const corsConfig = config[environment].corsConfig;
 
// CORS configuration object
const corsOptions = {
  origin: corsConfig.origin,
  methods: corsConfig.methods,
  allowedHeaders: ["Content-Type", "Authorization"],
};
 
(async () => {
  try {
    await connectDB(); // Ensure DB connection is established before syncing with Elasticsearch
    if (elasticEnabled) { // Check if Elasticsearch feature flag is enabled
      await elasticDB.createElasticIndexIfNotExists();
      console.log('Elasticsearch index check completed.');
    } else {
      console.log('Elasticsearch feature is disabled.');
    }
  } catch (error) {
    console.error('Error connecting to databases:', error);
  }
})();

 
app.use(express.json());
app.use(cors(corsOptions));
 
// Load Swagger definition from JSON file
const swaggerDocument = JSON.parse(fs.readFileSync(path.join(__dirname, 'swagger.json'), 'utf8'));
 
// Set up Swagger UI
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
 
// S3 Routes
app.use("/api/s3", s3Routes);
 
// User Routes
app.use("/api/user", userRoute);
 
// Health-check Routes
app.use("/api", healthRoutes);
 
// Search on Elastic
app.use("/api/es", searchRoutes);

// AI Routes
app.use('/AI', userRoute);

//Socket Code 
const io = new Server(server, {
  cors: config[environment].corsConfig,
  allowEIO3: true
});


io.on("connection", (socket) => {
  console.log(`User Connected: ${socket.id}`);
  socket.on("join_room", (data) => {
    socket.join(data);
    socket.emit('joined_room'); 
    console.log(`User with ID: ${socket.id} joined room: ${data}`);
  });

  socket.on("send_message", async (data) => {
    console.log(data, '________MESSAGE SENT')
    const res = await chatService.saveChat(data);
    socket.to(data.room).emit("receive_message", { id: res.id, ...data});
  });

  socket.on("disconnect", () => {
    console.log( '________USER DSICONNECTED')
    console.log("User Disconnected", socket.id);
  });
});

server.listen(port, () => {
  console.log(`WebSocket running on port ${port}`);
});



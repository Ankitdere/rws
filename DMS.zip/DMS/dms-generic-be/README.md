# Document Management System (DMS)
<img src="./documentation/Firstsource_Logo.png"  alt="Piyush Patel">


The First Document Management System (FDMS) is designed to efficiently manage, organize, and control employee documents within an organization. FDMS provides a centralized repository where new joiner and employee documents such as Onboarding, Education, Previous Work Experience, National ID, and BGV reports are securely stored. With advanced search capabilities, admins can easily retrieve documents based on Employee ID, keywords, or content. The system enhances document security through role-based access controls, ensuring only authorized personnel can view, edit, or delete documents.

FDMS integrates with AWS S3 for scalable and secure storage. It supports document lifecycle management, from creation to archiving, and offers reporting features for document status and availability. Additionally, FDMS includes functionality for mass document downloads, audit logs for compliance, and regular backups with defined recovery procedures. The user interface is intuitive, responsive, and designed to work seamlessly across devices. FDMS aims to reduce paper usage, lower physical storage costs, and ensure compliance with organizational policies, making it a vital tool for HR and operations teams.

## Setup
> npm install --save

## Run
> npm start


## Whom to Talk ?

- piyush.patel@rws.com
- sneha.soni@rws.com
- nitin.joshi@rws.com
- ankit.dere@rws.com
- nishi.jain@rws.com
- dinsha.ahuja@rws.com

<img src="./documentation/ME.png" alt="Piyush Patel">
<img src="./documentation/sneha.png" alt="">
<img src="./documentation/nitin1.png" alt="">
<img src="./documentation/nitin1.png" alt="">
<img src="./documentation/nitin1.png" alt="">
<img src="./documentation/nitin1.png" alt="">
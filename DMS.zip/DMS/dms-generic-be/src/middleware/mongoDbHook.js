const { esClient } = require('../clients/ElasticSearchClient');
require('dotenv').config();

// Feature flag for Elasticsearch sync
const elasticEnabled = process.env.ELASTIC_ENABLED === 'true';

const mongoDbHook = (documentSchema) => {
    // Hook for saving or updating documents in Elasticsearch
    documentSchema.post('save', async function (doc) {
        if (!elasticEnabled) {
            console.log('Elasticsearch sync is disabled');
            return;
        }

        console.log('Insert or Update detected:', doc);

        const document = { ...doc._doc };
        delete document._id; // Elasticsearch doesn't need the _id field

        try {
            const insertElastic = await esClient.index({
                index: process.env.ELASTIC_INDEX || 'documents-index',
                id: doc._id.toString(),
                document,
            });
            console.log('Document indexed in Elasticsearch:', insertElastic);
        } catch (error) {
            console.error('Error indexing document:', error);
        }
    });

    // Hook for deleting documents from Elasticsearch
    documentSchema.post('remove', async function (doc) {
        if (!elasticEnabled) {
            console.log('Elasticsearch sync is disabled');
            return;
        }

        console.log('Delete detected:', doc._id);

        try {
            await esClient.delete({
                index: process.env.ELASTIC_INDEX || 'documents-index',
                id: doc._id.toString(),
            });
            console.log('Document deleted from Elasticsearch');
        } catch (error) {
            console.error('Error deleting document from Elasticsearch:', error);
        }
    });
};

module.exports = { mongoDbHook };

const Role = require("../models/Role");
const User = require("../models/User");
const s3Service = require("../services/s3Service");

const establishUser = async (request) => {
  console.log(request,'-request')
  const updatedUser = await User.findOneAndUpdate(
    { userName: request.userName },
    { role: request.role },
    { new: true }
  );

  if (!updatedUser) {
    const newUser = new User({
      userName: request?.userName,
      role: request?.role,
      profileImg:request?.profileImg,
      name:request?.name
    });
    await newUser.save();
  };

  return { message: "Sucess" };
};

const userList = async () => {
  const users = await User.find();
  const resArr = [];
  if (users) {
    users.forEach((user) => {
      const resObj = {};
      resObj.userName = user.userName;
      resObj.role = user.role;
      resObj.name = user.name;
      resObj.profileImg = user.profileImg;
      resArr.push(resObj);
    });
  }
  return resArr;
};

const getRolesDetails = async () => {
  const role = await Role.findOne();
  
  const resObj = {};
  resObj.User = role.User;
  resObj.Approver = role.Approver;
  resObj.Admin = role.Admin;
  
  return resObj;
};

const updateRoleDetails = async (request) => {
  const roles = await Role.findOne();
  if (roles) {
    const id = roles._id.toString();
    await Role.updateOne({ _id: id }, { $set: request });
  } else {
    const newRole = new Role({
      User: request.User,
      Approver: request.Approver,
      Admin: request.Admin,
    });
    await newRole.save();
  }
  return { message: "Roles updated successfully." };
};

const updateImage = async(req, file) => {
  const filePath = '/DumpImagesProfilePicturesHidden_XyzFrt123/';
  const fileUrl = await s3Service.uploadFile(file, filePath);
  const updatedUser = await User.findOneAndUpdate(
    { userName: req.email },
    { profileImg: fileUrl },
    { new: true }
  );

  return { message: "Profile Image uploaded successfully" };
}

module.exports = {
  establishUser,
  userList,
  getRolesDetails,
  updateRoleDetails,
  updateImage,
}
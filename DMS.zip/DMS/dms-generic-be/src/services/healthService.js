const getHealthStatus = () => {
    return {
        status: 'ok',
        message: 'Application is running',
        timestamp: new Date().toISOString()
    };
};

module.exports = {
    getHealthStatus
};

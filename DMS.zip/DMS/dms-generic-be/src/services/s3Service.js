const s3 = require("../clients/S3Client");
const moment = require("moment");
const axios = require("axios");
const pdfParse = require("pdf-parse");
const xlsx = require("xlsx");
const mammoth = require("mammoth");
const _ = require('underscore');
const path = require('path');
const fs = require('fs');
const userRequest = require("../models/UserRequest");
const Document = require("../models/Documents");
const User = require("../models/User")
const multimediaExtensions = require('../config/extensions');
const constant = require('../constants/constant');
const customlogService = require('../services/customlogService');
const aiController = require("../controller/aiController");
const customService = require("../services/customService");

const uploadFile = async (file, folderPath) => {
  // Remove leading and trailing slashes from the path
  const cleanedPath = folderPath.replace(/^\/+|\/+$/g, '');
  const key = cleanedPath ? `${cleanedPath}/${file.originalname}` : file.originalname;

  const params = {
    Bucket: process.env.S3_BUCKET_NAME,
    Key: key,
    Body: file.buffer,
    ContentType: file.mimetype,
    ACL: 'public-read'
  };

  try {
    const data = await s3.upload(params).promise();
    console.log(`File uploaded successfully. ${data.Location}`);
    return data.Location;
  } catch (err) {
    console.error("Error uploading file:", err.message);
    throw new Error("Failed to upload file");
  }
};

const listItems = async (folder) => {
  const params = {
    Bucket: process.env.S3_BUCKET_NAME,
    Prefix: folder,
    Delimiter: "/",
  };

  try {
    const data = await s3.listObjectsV2(params).promise();

    // List folders
    const folders = data.CommonPrefixes.map((prefix) => ({
      name: prefix.Prefix.split("/").filter(Boolean).pop(),
      extension: "folder",
    }));

    // List files
    const files = data.Contents.filter((item) => item.Size > 0).map((item) => ({
      name: item.Key.split("/").pop(),
      fileUrl: `https://${process.env.S3_BUCKET_NAME}.s3.amazonaws.com/${item.Key}`,
      extension: item.Key.split(".").pop(),
    }));
    return [...folders, ...files];
  } catch (err) {
    console.error("Error listing items:", err.message);
    throw new Error("Failed to list items");
  }
};

const createFolder = async (folderKey, author, date, email) => {
  const params = {
    Bucket: process.env.S3_BUCKET_NAME,
    Key: folderKey,
    Body: "",
    ContentType: "application/x-directory",
    Metadata: {
      author: author,
      date: date,
      email: email,
    },
  };

  try {
    const data = await s3.upload(params).promise();
    return data.Location;
  } catch (error) {
    console.error("Error creating folder in S3:", error.message);
    throw new Error("Failed to create folder");
  }
};
// Function to create a normalized folder key
const createFolderKey = (path, folderName, author, date, email) => {
  path = path.replace(/^\/+|\/+$/g, "");
  if (path) {
    return `${path}/${folderName}/`;
  } else {
    return `${folderName}/`;
  }
};

const downloadFile = async (filename) => {
  const params = {
    Bucket: process.env.S3_BUCKET_NAME,
    Key: filename,
  };
  return s3.getObject(params).promise();
};

const deleteFile = async (key, isFolder = false) => {
  const params = {
    Bucket: process.env.S3_BUCKET_NAME,
    Prefix: key,
  };

  try {
    if (isFolder && !key.endsWith('/')) {
      params.Prefix = `${key}/`;
    }
    const listedObjects = await s3.listObjectsV2(params).promise();

    if (listedObjects.Contents.length === 0) {
      console.log(`No files found under the path: ${key}`);
      return;
    }
    const deleteParams = {
      Bucket: process.env.S3_BUCKET_NAME,
      Delete: { Objects: [] },
    };

    listedObjects.Contents.forEach(({ Key }) => {
      deleteParams.Delete.Objects.push({ Key });
    });

    await s3.deleteObjects(deleteParams).promise();
    console.log(`Files deleted successfully under the path: ${key}`);
  } catch (err) {
    console.error("Error deleting files or folder:", err.message);
    throw new Error("Failed to delete files or folder");
  }
};

const getFileContent = async (fileurl) => {
  try {
    const response = await axios.get(fileurl, {
      responseType: "arraybuffer",
    });
    const buffer = Buffer.from(response.data);
    if (fileurl.endsWith(".pdf")) {
      const data = await pdfParse(buffer);
      return data.text;
    } else if (fileurl.endsWith(".txt")) {
      return buffer.toString("utf-8");
    } else if (
      fileurl.endsWith(".xlsx") ||
      fileurl.endsWith(".xls") ||
      fileurl.endsWith(".csv")
    ) {
      const workbook = xlsx.read(buffer, { type: "buffer" });
      const sheetName = workbook.SheetNames[0];
      const sheet = xlsx.utils.sheet_to_json(workbook.Sheets[sheetName], {
        header: 1,
      });
      return JSON.stringify(sheet);
    } else if (fileurl.endsWith(".docx")) {
      const { value } = await mammoth.extractRawText({ buffer });
      return value;
    } else {
      return "Unsupported file type";
    }
  } catch (error) {
    console.error("Error fetching file content:", error);
    return null;
  }
};

const getContentKeywords = async (fileContent) => {
  return new Promise(async (resolve, reject) => {
    if (!_.isEmpty(fileContent)) {
      const response = await fetch(`http://localhost:9000/AI/dmsBot?query='Generate me five Categories/keywords among these ${constant.categoriesGeneralKnown} from this content -: ${fileContent}'`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      }).then(response => response.json());

      // Regular expression to match the tags between ** **
      const regex = /\*\*(.*?)\*\*/g;

      // Extract the tags
      const matches = response.response.match(regex);

      // Clean up the matches by removing ** and join them into a comma-separated string
      const contentKeywords = matches ? matches.map(tag => tag.replace(/\*\*/g, '')).join(', ') : '';

      resolve(contentKeywords);
    }
    else {
      reject('Failed AI', response.statusText);
    }
  });
};

const uploadRequestedDocument = async (req, reqFile, folderPath, cleanedPath) => {
  const file = reqFile;
  const whereCond = {
    fileUrl: `${cleanedPath}/${file.originalname}`,
    requestType: 'upload',
    status: 1,
  };
  const requestData = await userRequest.findOne(whereCond);
  if (requestData) {
    return { message: "File upload request already exist" };    
  }
  const fileUrl = await uploadFile(file, folderPath);

  const newReq = new userRequest({
    fileUrl: `${cleanedPath}/${file.originalname}`,
    fileType: 'file',
    requestType: 'upload',
    author: req.author || "",
    date: req.date || new Date(),
    email: req.email || "",
    extension: reqFile.originalname.split(".").pop(),
    status: 1,
  });
  await newReq.save();

  const whereCond1 = { role: 'Approver' };
  const userData = await User.find(whereCond1);
  if (userData) {
    const userEmails = userData.map(user => user.userName);
    const subject = "Request for upload file";
    let body = `<p>Below file is requested for upload by ${req.author}. </p>`;
    body = body + `${cleanedPath}/${file.originalname}`;
    await customService.sendMail(userEmails, subject, body);
  }

  return { message: "File upload request saved successfully" };
};

const userRequestList = async () => {
  const whereCond = { status: 1 };
  const requestData = await userRequest.find(whereCond);
  const resArr = [];
  if (requestData) {
    requestData.forEach((req) => {
      const resObj = {};
      let fileName = req.fileUrl.split('/').pop();
      if (req.fileType === 'file') {
        fileName = fileName.split('.').slice(0, -1).join('.');
      }
      resObj.id = req._id.toString(),
      resObj.fileName = fileName,
      resObj.fileUrl = req.fileUrl,
      resObj.fileType = req.fileType,
      resObj.requestFor = req.requestType,
      resObj.author = req.author,
      resObj.date = req.date,
      resObj.email = req.email,
      resObj.extension = req.extension,
      resArr.push(resObj);
    });
  }
  return resArr;
};

const uploadToS3 = async (filePath) => {
  const fileDest = `uploads/${filePath}`;
  const fileContent = fs.readFileSync(fileDest);

  const params = {
    Bucket: process.env.S3_BUCKET_NAME,
    Key: filePath,
    Body: fileContent,
    ACL: 'public-read'
  };

  try {
    const data = await s3.upload(params).promise();
    console.log(`File uploaded successfully. ${data.Location}`);
    return data.Location;
  } catch (err) {
    console.error("Error uploading file:", err.message);
    throw new Error("Failed to upload file");
  }
}

const moveFileInS3 = async (destinationKey, sourceKey) => {
  try {
    const bucketName = process.env.S3_BUCKET_NAME;
    await s3
      .copyObject({
        Bucket: bucketName,
        CopySource: `${bucketName}/${sourceKey}`,
        Key: destinationKey,
        ACL: 'public-read',
      })
      .promise();

    await s3
      .deleteObject({
        Bucket: bucketName,
        Key: sourceKey,
      })
      .promise();

    return `${process.env.S3_GENERIC_BASE_URL}${destinationKey}`;
  } catch (error) {
    console.error('Error moving file:', error);
  }
};

const uploadS3Files = async (fileData, reqUsername, reqAuthor) => {
  const updateStatus = fileData.map((item) => ({
    ...item,
    uploaded: false,
    error: null
  }));
  if (fileData.length === 0) {
    return updateStatus;
  }

  const uploadPromises = fileData.map(async (file) => {
    const destinationPath = file.fileUrl;
    const destinationKey = destinationPath.replace(/^\/+|\/+$/g, '');
    const sourceKey = `dumpTempFiles/${destinationKey}`;
    
    const s3FileUrl = await moveFileInS3(destinationKey, sourceKey);
    const result = {
      ...file,
      fileUrl: s3FileUrl,
    }
    return result;
  });

  const s3Results = await Promise.all(uploadPromises);

  if (s3Results) {
    const userRequestData = s3Results.map(async (res) => {
      let contentKeywords;
      const whereCond = { _id: res.id };
      const requestData = await userRequest.findOne(whereCond);
      if (requestData) {
        const fileName = requestData.fileUrl.split('/').pop();

        const fileContent = await getFileContent(res.fileUrl);
        const extension = requestData.extension.toLowerCase();

        const multimediaExtension = [...multimediaExtensions.audio, ...multimediaExtensions.video, ...multimediaExtensions.image];

        if (!multimediaExtension.includes(extension)) {
          if (fileContent) {
            // Call Third Party API to fetch content keywords
            try {
              // contentKeywords = await getContentKeywords(fileContent);
              const query = `'Generate me five Categories/keywords among these ${constant.categoriesGeneralKnown} from this content -: ${fileContent}'`;

              const response = await aiController.generateAIResponse(query);
              // contentKeywords = await s3Service.getContentKeywords(fileContent);

              // Regular expression to match the tags between ** **
              const regex = /\*\*(.*?)\*\*/g;

              // Extract the tags
              const matches = response.match(regex);

              // Clean up the matches by removing ** and join them into a comma-separated string
              contentKeywords = matches ? matches.map(tag => tag.replace(/\*\*/g, '')).join(', ') : '';
            } catch (error) {
              console.error('Error AI:', error);
              return false;
            }
          }
        }

        const resObj = {};
        resObj.name = fileName;
        resObj.fileUrl = decodeURIComponent(res.fileUrl);
        resObj.author = requestData.author || "";
        resObj.date = requestData.date || new Date();
        resObj.email = requestData.email || "";
        resObj.extension = requestData.extension || "";
        resObj.keywords = contentKeywords || "";
        resObj.comment = res.comment || "";
        return resObj;
      }
    }).filter(item => item !== null && item !== undefined);

    const userReqData = await Promise.all(userRequestData);
    await Document.insertMany(userReqData);

    const ids = s3Results.map(item => item.id);

    const updateRequest = await userRequest.updateMany(
      { _id: { $in: ids } },
      { $set: { status: 2 } }
    );

    if (userReqData.length > 0) {
      for (const file of userReqData) {
        const logData = {
          name: reqAuthor,
          email: reqUsername,
          action: "approve request for upload file",
          path: file.fileUrl.replace(process.env.S3_GENERIC_BASE_URL, ''),
          fileUrl: file.fileUrl,
          comment: file.comment || "",
        };
        await customlogService.saveCustomlogs(logData);

        const toEmail = file.email;
        const subject = "Request for upload file status";
        let body = `<p>Request for upload file has been approved by ${reqAuthor}.`;
        if (file.comment) {
          body = body + `<p style="font-weight: 500; color: black;">${reqAuthor}: <span style="font-style: italic; color: #616161;">${file.comment}</span></p>`;
        }
        await customService.sendMail(toEmail, subject, body);
      }
    }

    return { message: "Files uploaded successfully" };
  }
  return { message: "Files not found" };
};

const updateUploadStatusIfRejected = async (fileData) => {
  const ids = fileData.map(item => item.id);

  const updateRequest = await userRequest.updateMany(
    { _id: { $in: ids } },
    { $set: { status: 3 } }
  );
  return { message: "Files rejected successfully" };
};

const addDeleteRequest = async (fileDetailsArray) => {
  try {
    // Validate input
    if (!Array.isArray(fileDetailsArray) || fileDetailsArray.length === 0) {
      throw new Error('Invalid input: fileDetailsArray should be a non-empty array');
    }

    // Insert multiple documents into the collection
    const result = await userRequest.insertMany(fileDetailsArray);
    return result;

  } catch (err) {
    console.error("Error saving file requests:", err.message);
    throw new Error("Error saving file requests:");
  }
};

const deleteS3Files = async (batchDeleteKeys) => {
  var updatePromises = [];
  var response = [];
  //Initialize delete status with false status
  const deleteStatus = batchDeleteKeys.map((item) => ({
    id: item.id,
    fileUrl: item.fileUrl,
    comment: item.comment ? item.comment : null,
    deleted: false,
    error: null
  }));

  if (batchDeleteKeys.length === 0) {
    return deleteStatus;
  }

  try {
    // Delete files from S3
    if (batchDeleteKeys.length > 0) {
      const deleteParams = {
        Bucket: process.env.S3_BUCKET_NAME,
        Delete: {
          Objects: batchDeleteKeys.map(fileUrl => ({ Key: fileUrl.fileUrl }))
        }
      };

      const deleteResponse = await s3.deleteObjects(deleteParams).promise();

      // Mark files as deleted or failed
      for (const { Key } of deleteResponse.Deleted) {
        const status = deleteStatus.find(status => status.fileUrl === Key);
        if (status) {
          //Update deleteStatus object
          status.deleted = true;

          //Update Status in "UserRequest" collection
          const updatePromise = userRequest.updateOne(
            { fileUrl: Key, status: 1 },
            { $set: { status: 2 } } // Update status to 2 for successful deletions
          ).exec().then(() => {
            response.push({ Key, message: 'Successfully updated status flag as approved in UserRequest' });
          }).catch(err => {
            response.push({ Key, message: `Failed to update status flag in UserRequest: ${err.message}` });
          });

          updatePromises.push(updatePromise);
        }
      };

      // Wait for all the update promises to complete
      await Promise.all(updatePromises);

      // Handle any errors in the deletion response
      if (deleteResponse.Errors.length > 0) {
        deleteResponse.Errors.forEach(({ Key, Code }) => {
          const status = deleteStatus.find(status => status.fileUrl === Key);
          if (status) {
            status.error = `Error deleting file: ${Code}`;
          }
        });
      }
    }
  } catch (error) {
    console.error('Error during S3 batch file deletion:', error);
    deleteStatus.forEach(status => status.error = 'Error during S3 deletion');
  }

  return deleteStatus;
};

const deleteS3Folders = async (folderPaths) => {
  var deleteStatus = [];
  var updatePromises = [];
  var response = [];

  for (const folderPath of folderPaths) {
    const listParams = {
      Bucket: process.env.S3_BUCKET_NAME,
      Prefix: folderPath.fileUrl
    };

    const userComment = folderPath.comment ? folderPath.comment : null;

    try {
      const listedObjects = await s3.listObjectsV2(listParams).promise();

      if (listedObjects.Contents.length > 0) {
        const deleteParams = {
          Bucket: process.env.S3_BUCKET_NAME,
          Delete: {
            Objects: listedObjects.Contents.map(({ Key }) => ({ Key }))
          }
        };

        //Delete S3 Folders
        const deleteResponse = await s3.deleteObjects(deleteParams).promise();

        // Mark files as deleted or failed
        deleteResponse.Deleted.forEach(({ Key }) => {
          deleteStatus.push({ fileUrl: Key, deleted: true, error: null, comment: userComment, id: folderPath.id });

          //Update Status in "UserRequest" collection
          const updatePromise = userRequest.updateOne(
            { fileUrl: folderPath.fileUrl, status: 1 },
            { $set: { status: 2 } } // Update status to 2 for successful deletions
          ).exec().then(() => {
            response.push({ fileUrl: folderPath.fileUrl, message: 'Successfully updated status flag as approved in UserRequest' });
          }).catch(err => {
            response.push({ fileUrl: folderPath.fileUrl, message: `Failed to update status in UserRequest: ${err.message}` });
          });

          updatePromises.push(updatePromise);
        });

        // Wait for all the update promises to complete
        await Promise.all(updatePromises);

        // Handle any errors in the deletion response
        if (deleteResponse.Errors.length > 0) {
          deleteResponse.Errors.forEach(({ Key, Code }) => {
            deleteStatus.push({ fileUrl: Key, deleted: false, error: `Error deleting file: ${Code}`, comment: userComment, id: folderPath.id });
          });
        }
      }
    } catch (error) {
      console.error('Error during S3 folder deletion:', error);
      deleteStatus.push({ fileUrl: folderPath.fileUrl, deleted: false, error: 'Error during S3 folder deletion', comment: userComment, id: folderPath.id });
    }
  }

  return deleteStatus;
};

const updateDeleteRequestStatus = async (deleteStatus) => {
  var response = [];
  var updatePromises = [];

  // Filter out only the items where deletion was successful
  const successfulDeletes = deleteStatus.filter(status => status.deleted);

  // Update Document collection for successfully deleted documents
  successfulDeletes.forEach(({ fileUrl, comment, id }) => {
    const updatePromise = Document.updateOne(
      { 
        fileUrl: { $regex: new RegExp(fileUrl.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i') },
        isDeleted: false,
      },
      { $set: { isDeleted: true } } // Set isDeleted to true for documents
    ).exec().then(() => {
      response.push({ fileUrl, message: 'Request for delete file has been approved', isDeleted: true, comment, id });
    }).catch(err => {
      response.push({ fileUrl, message: `Failed to update isDeleted flag in Document collection: ${err.message}`, comment, id });
    });

    updatePromises.push(updatePromise);
  });

  // Wait for all the update promises to complete
  await Promise.all(updatePromises);

  return response;
};

const updateDeleteStatusIfRejected = async (batchDeleteKeysToReject, folderPathsToReject) => {
  var response = [];
  var updatePromises = [];

  //Update Reject Status in "UserRequest" collection for Files
  batchDeleteKeysToReject.forEach((item) => {
    const userComment = item.comment ? item.comment : null;
    const updateFilePromise = userRequest.updateOne(
      { fileUrl: item.fileUrl, status: 1 },
      { $set: { status: 3 } } // Update status to 3 if approver rejects
    ).exec().then(() => {
      response.push({ fileUrl: item.fileUrl, message: 'Request for delete file has been rejected', isDeleted: false, comment: userComment, id: item.id });
    }).catch(err => {
      response.push({ fileUrl: item.fileUrl, message: `Failed to update Status flag in UserRequest collection: ${err.message}`, comment: userComment, id: item.id });
    });

    updatePromises.push(updateFilePromise);
  });

  //Update Reject Status in "UserRequest" collection for Folders
  folderPathsToReject.forEach((item) => {
    const userComment = item.comment ? item.comment : null;
    const updateFolderPromise = userRequest.updateOne(
      { fileUrl: item.fileUrl, status: 1 },
      { $set: { status: 3 } } // Update status to 3 if approver rejects
    ).exec().then(() => {
      response.push({ folderPath: item.fileUrl, message: 'Folder path marked as rejected in Database.', isDeleted: false, comment: userComment, id: item.id });
    }).catch(err => {
      response.push({ folderPath: item.fileUrl, message: `Failed to update status in UserRequest collection: ${err.message}`, comment: userComment, id: item.id });
    });

    updatePromises.push(updateFolderPromise);
  });

  // Wait for all the update promises to complete
  await Promise.all(updatePromises);

  return response;
};

module.exports = {
  uploadFile,
  createFolder,
  listItems,
  downloadFile,
  deleteFile,
  getFileContent,
  createFolderKey,
  getContentKeywords,
  uploadRequestedDocument,
  userRequestList,
  uploadS3Files,
  updateUploadStatusIfRejected,
  addDeleteRequest,
  deleteS3Files,
  deleteS3Folders,
  updateDeleteRequestStatus,
  updateDeleteStatusIfRejected,
};

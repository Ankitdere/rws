const Logs = require("../models/Logs");

const saveCustomlogs = async (req) => {
  const logData = new Logs({
    name: req.name,
    email: req.email,
    action: req.action,
    date: new Date(),
    path: req.path ? req.path : "",
    fileUrl: req.fileUrl ? req.fileUrl : "",
    comment: req.comment ? req.comment : "",
  });

  await logData.save();
};

const getLogs = async () => {
  const requestData = await Logs.find();
  const resArr = [];
  if (requestData) {
    requestData.forEach((req) => {
      const resObj = {};
      resObj.id = req._id.toString(),
      resObj.name = req.name,
      resObj.email = req.email,
      resObj.action = req.action,
      resObj.date = req.date,
      resObj.path = req.path,
      resObj.fileUrl = req.fileUrl,
      resObj.comment = req.comment ? req.comment : null,
      resArr.push(resObj);
    });
  }
  return resArr;
};

module.exports = {
  saveCustomlogs,
  getLogs,
}
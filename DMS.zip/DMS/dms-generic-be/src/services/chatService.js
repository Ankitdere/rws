const Chats = require("../models/Chats");

const saveChat = async (request) => {
  console.log(request, '_____________DB IN SAVE CHAT START')
  const newChat = new Chats({
    room: request?.room,
    author: request?.author,
    message:request?.message,
    email:request?.email,
    time:request?.time,
  });
  const result = await newChat.save();
  console.log(result, '_____________IF SAVED THEN THIS IS RESULT')
  return { message: "Chat saved", id: result._id.toString() };
};

const getChats = async () => {
  const chatsData = await Chats.find().sort({ time: 1 });
  const resArr = [];
  if (chatsData) {
    chatsData.forEach((chat) => {
      const resObj = {};
      resObj.id = chat._id.toString();
      resObj.room = chat.room;
      resObj.author = chat.author;
      resObj.message = chat.message;
      resObj.email = chat.email;
      resObj.time = chat.time;
      resArr.push(resObj);
    });
  }
  return resArr;
};

const deleteChat = async (req) => {
  const { id } = req;
  if (!id) {
    return res
      .status(400)
      .json({ message: "Missing required fields: id" });
  }
  const result = await Chats.deleteOne({ _id: id });

  if (result.deletedCount === 1) {
    return { message: `Successfully deleted chat with id: ${id}` };
  } else {
    return { message: `No chat found with id: ${id}` };
  }
}

module.exports = {
  saveChat,
  getChats,
  deleteChat,
}
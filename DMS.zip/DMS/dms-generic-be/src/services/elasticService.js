require('dotenv').config();
const Document = require("../models/Documents");
const documentSchema = Document.schema;
const { esClient } = require('../clients/ElasticSearchClient');
const esIndexName = process.env.ELASTIC_INDEX;
const path = require('path');

// Feature flag for Elasticsearch
const elasticEnabled = process.env.ELASTIC_ENABLED === 'true';

// Function to check if Elasticsearch index exists, and create if not
const createElasticIndexIfNotExists = async () => {
  if (!elasticEnabled) return; // Skip if Elasticsearch is disabled
  try {
    const indexExists = await esClient.indices.exists({ index: esIndexName });
    if (!indexExists) {
      await esClient.indices.create({
        index: esIndexName,
        body: {
          mappings: {
            properties: {
              fileUrl: { type: 'text' },
              extension: { type: 'keyword' },
              // Other mappings for your fields
            },
          },
        },
      });
      console.log(`Index ${esIndexName} created`);
    } else {
      console.log(`Index ${esIndexName} already exists`);
    }
  } catch (error) {
    console.error('Error checking/creating Elasticsearch index:', error);
  }
};

// Function to search documents in Elasticsearch
const searchElastic = async (params) => {
  if (!elasticEnabled) {
    return { message: "Elasticsearch functionality is disabled" };
  }

  try {
    const result = await esClient.search({
      index: esIndexName,
      body: {
        query: {
          query_string: {
            query: `${params}`, // Adjust as needed
            default_field: "*", // Search in all fields
          },
        },
      },
    });

    const fileDetails = result.hits.hits;
    let finalResult = [];

    if (Array.isArray(fileDetails) && fileDetails.length > 0) {
      let result =[]
      fileDetails.forEach((item) => {
        if(item && item._source){
        result.push(item._source)
      }
      });
      return result;
    } else {
      console.log('No documents found');
      return [];
    }
  } catch (error) {
    console.error('Error searching documents:', error);
    return { message: 'Error during search operation', error: error.message };
  }
};

// Helper function to get the file path
const getFilePath = (fileUrl) => {
  try {
    const url = new URL(fileUrl); // Use URL to parse the file URL
    const filePath = url.pathname; // Get the pathname from the URL
    return path.basename(filePath); // Use `path.basename` to get the file name
  } catch (error) {
    console.error('Invalid URL format:', error);
    return '';
  }
};

module.exports = {
  createElasticIndexIfNotExists,
  searchElastic,
};

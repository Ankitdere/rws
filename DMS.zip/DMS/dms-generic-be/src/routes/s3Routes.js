const express = require("express");
const router = express.Router();
const s3Controller = require("../controller/s3Controller");
const multer = require("multer");

const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

router.post("/upload", upload.single("file"), s3Controller.uploadDocument);

router.get("/list", s3Controller.listItems);
router.post("/create", s3Controller.createFolder);
router.delete("/delete", s3Controller.deleteDocument);
router.get("/content", s3Controller.getFileContentByUrl);
router.get("/download/:filename", s3Controller.downloadDocument);
router.post("/downloads",s3Controller.bulkDownloadDocument)
router.post("/uploadRequested", upload.single("file"), s3Controller.uploadRequestedDocument);
router.get("/userRequestList", s3Controller.userRequestList);
router.post("/userRequest", s3Controller.userRequest);
router.post("/delete/request", s3Controller.deleteRequest);
router.get("/Logs", s3Controller.getLogs);
router.get("/ExportLogs", s3Controller.exportLogs)

module.exports = router;

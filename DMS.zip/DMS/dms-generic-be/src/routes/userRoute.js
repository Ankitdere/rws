const express = require("express");
const router = express.Router();
const userController = require("../controller/userController");
const aiController = require("../controller/aiController")
const multer = require("multer");

const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

router.post("/establishUser", userController.establishUser);
router.get("/userList", userController.userList);
router.post("/updateImage", upload.single("file"), userController.updateImage);

router.post("/updateRoleDetails", userController.updateRoleDetails);
router.get("/getRolesDetails", userController.getRolesDetails);
router.get("/getChats", userController.getChats);
router.post("/deleteChat", userController.deleteChat);

router.get('/dmsBot', aiController.dmsAI);

module.exports = router;

const Express = require("express");
const router = Express.Router();
const searchController = require("../controller/searchController");

router.post("/search", searchController.searchList);
router.get("/health", searchController.healthController)

module.exports = router;

// config/extensions.js

// Define multimedia extensions for each type
const multimediaExtensions = {
    audio: ['mp3', 'wav', 'aac', 'flac', 'ogg', 'm4a', 'wma', 'alac', 'aiff', 'opus'],
    video: ['mp4', 'avi', 'mkv', 'mov', 'wmv', 'flv', 'webm', 'mpg', 'mpeg', '3gp', 'hevc'],
    image: ['jpeg', 'jpg', 'png', 'gif', 'bmp', 'tiff', 'tif', 'webp', 'heif', 'raw', 'svg'],
  };
  
  module.exports = multimediaExtensions;
  
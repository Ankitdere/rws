const config = {
    STAGE: {
        corsConfig: {
            origin: [
                "http://localhost:3000",
                "https://localhost:9200",
                "https://genericdms.wddemo.net",
            ],
            methods: ["GET", "PUT", "PATCH", "POST", "DELETE"],
        }
    },
    PROD: {
        corsConfig: {
            origin: [
                "http://localhost:3000",
                "https://localhost:9200",
                "https://genericdms.wddemo.net",
            ],
            methods: ["GET", "PUT", "PATCH", "POST", "DELETE"],
        }
    },
};

module.exports = config; 

const constant = {
    categoriesGeneralKnown : ["Reports", "Presentations", "Invoices", "Contracts", "Marketing Plans", "Research Papers", "User Manuals", "Financial Statements", "Project Plans", "Articles", "Policies", "Performance Reviews", "Training Materials", "Meeting Minutes", "Proposals"]
}

module.exports = constant;
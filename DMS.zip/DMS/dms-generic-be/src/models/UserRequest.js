const mongoose = require('mongoose');
 
const userRequestSchema = new mongoose.Schema({
    fileUrl: {
        type: String,
        required: true
    },
    fileType: {
        type: String,
        required: true
    },
    requestType: {
        type: String,
        required: true
    },
    author: {
        type: String,
        required: false
    },
    date: {
        type: Date,
        required: false
    },
    email: {
        type: String,
        required: false
    },
    extension: {
        type: String,
        required: false
    },
    status: {
        type: Number,
        required: true,
        default: 1
    }
});
 
const userRequest = mongoose.model('UserRequest', userRequestSchema);
 
module.exports = userRequest;
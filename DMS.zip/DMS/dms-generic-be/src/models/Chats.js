const mongoose = require('mongoose');

const chatSchema = new mongoose.Schema({
    room: {
        type: String,
        required: true
    },
    author: {
        type: String,
        required: true
    },
    message: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: false
    },
    time: {
        type: Date,
        required: true
    }
});

const Chat = mongoose.model('Chat', chatSchema);

module.exports = Chat;

const mongoose = require('mongoose');

const logsSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    action: {
        type: String,
        required: true
    },
    date: {
        type: Date,
        required: true
    },
    path: {
        type: String,
        required: false
    },
    fileUrl: {
        type: String,
        required: false
    },
    comment: {
        type: String,
        required: false
    }
});

const Logs = mongoose.model('Logs', logsSchema);

module.exports = Logs;

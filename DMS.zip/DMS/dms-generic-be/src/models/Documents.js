const mongoose = require('mongoose');
const { mongoDbHook } = require('../middleware/mongoDbHook'); // Import the decoupled MongoDB hook

const documentSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    fileUrl: {
        type: String,
        required: true
    },
    author: {
        type: String,
        required: false
    },
    date: {
        type: Date,
        required: true
    },
    email: {
        type: String,
        required: false
    },
    extension: {
        type: String,
        required: true
    },
    keywords: {
        type: String,
        required: false
    },
    isDeleted: {
        type: Boolean,
        default: false
    }
});

// Apply MongoDB hooks for Elasticsearch syncing
mongoDbHook(documentSchema);

const Document = mongoose.model('Document', documentSchema);

module.exports = Document;

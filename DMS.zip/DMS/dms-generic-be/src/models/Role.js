const mongoose = require('mongoose');

const roleSchema = new mongoose.Schema({
    User: {
        type: [String],
        required: false
    },
    Approver: {
        type: [String],
        required: false
    },
    Admin: {
        type: [String],
        required: false
    }
});

const Role = mongoose.model('Role', roleSchema);

module.exports = Role;

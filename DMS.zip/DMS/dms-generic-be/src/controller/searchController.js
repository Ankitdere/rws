const searchService = require("../services/elasticService.js");
const ecSearch = require("../clients/ElasticSearchClient.js");
require('dotenv').config();

// Feature flag for enabling/disabling Elasticsearch functionality
const elasticEnabled = process.env.ELASTIC_ENABLED === 'true';

const searchList = async (req, res) => {
  try {
    const { query } = req.body;
    if (!query) {
      return res
        .status(400)
        .json({ message: "Missing required fields: search query" });
    }

    // Check if Elasticsearch is enabled
    if (!elasticEnabled) {
      return res.status(503).json({ message: "Elasticsearch is currently disabled" });
    }

    const result = await searchService.searchElastic(query);
    res.status(200).json(result);
  } catch (error) {
    console.error("Error in search:", error);
    res.status(500).json({ message: "Internal Server Error during search" });
  }
};

const healthController = async (req, res) => {
  try {
    // Check if Elasticsearch is enabled
    if (!elasticEnabled) {
      return res.status(503).json({ message: "Elasticsearch is currently disabled" });
    }

    const healthStatus = await ecSearch.elasticConnect();
    res.status(200).json(healthStatus);
  } catch (error) {
    console.error("Error in health check:", error);
    res.status(500).json({ message: "Internal Server Error during health check" });
  }
};

module.exports = {
  searchList,
  healthController,
};

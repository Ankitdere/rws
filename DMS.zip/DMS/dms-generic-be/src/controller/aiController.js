const { GoogleGenerativeAI } = require("@google/generative-ai");
const dotenv = require('dotenv');

dotenv.config();

const handleError = (err, res) => {
    console.error(err);
    res.status(500).json({ message: 'Internal Server Error' });
};

const genAI = new GoogleGenerativeAI(process.env.GENERATIVE_AI_API_KEY);

async function generateAIResponse(query) {
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash-latest" });
    const result = await model.generateContent(query);
    const response = result.response;
    const text = response.text();
    return text;
}

const dmsAI = async (req, res) => {
    const { query } = req.query;
    if (!query) {
        return res.status(400).json({ message: 'Missing required field: query' });
    }
    try {
        const generatedResponse = await generateAIResponse(query);
        res.json({ response: generatedResponse });
    } catch (error) {
        handleError(error, res);
    }
};

module.exports = {
    dmsAI,
    generateAIResponse,
};

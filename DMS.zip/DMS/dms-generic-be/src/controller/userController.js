const userService = require("../services/userService");
const chatService = require("../services/chatService");

const establishUser = async (req, res) => {
  try {
    const request = req.body;
    if (!request.userName || !request.role) {
      return res
        .status(400)
        .json({ message: "Missing required fields: userName or role" });
    }

    const result = await userService.establishUser(request);

    res
      .status(200)
      .json(result);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const userList = async (req, res) => {
  try {
    const result = await userService.userList();
    res
      .status(200)
      .json(result);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
}

const getRolesDetails = async (req, res) => {
  try {
    const result = await userService.getRolesDetails();

    res
      .status(200)
      .json(result);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
}

const updateRoleDetails = async (req, res) => {
  try {
    const request = req.body;
    if (!request.User || !request.Approver || !request.Admin) {
      return res
        .status(400)
        .json({ message: "Missing required fields: User, Approver or Admin" });
    }

    const result = await userService.updateRoleDetails(request);

    res
      .status(200)
      .json(result);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const updateImage = async (req, res) => {
  try {
    const { email } = req.body;

    if (!req.file || !email) {
      return res
        .status(400)
        .json({ message: "Missing required fields: file or email" });
    }

    const result = await userService.updateImage(req.body, req.file);

    res
      .status(200)
      .json(result);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getChats = async (req, res) => {
  try {
    const result = await chatService.getChats();
    res
      .status(200)
      .json(result);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
}

const deleteChat = async (req, res) => {
  try {
    const result = await chatService.deleteChat(req.body);
    res
      .status(200)
      .json(result);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
}

module.exports = {
  establishUser,
  userList,
  getRolesDetails,
  updateRoleDetails,
  updateImage,
  getChats,
  deleteChat,
}
const s3 = require("../clients/S3Client");
const s3Service = require("../services/s3Service");
const Document = require("../models/Documents");
const userRequestModel = require("../models/UserRequest");
const multimediaExtensions = require('../config/extensions');
const JSZip = require("jszip")
const customlogService = require("../services/customlogService");
const aiController = require("../controller/aiController");
// const userRequest = require("../models/userRequest");
const constant = require('../constants/constant');
const customService = require("../services/customService");
const User = require("../models/User");

const uploadDocument = async (req, res) => {
  try {
    const { path } = req.body;

    if (!req.file || !path) {
      return res
        .status(400)
        .json({ message: "Missing required fields: file or path" });
    }

    const fileUrl = await s3Service.uploadFile(req.file, path);
    const fileContent = await s3Service.getFileContent(fileUrl);
    const extension = fileUrl.split('.').pop().toLowerCase();

    const multimediaExtension = [...multimediaExtensions.audio, ...multimediaExtensions.video, ...multimediaExtensions.image];
    var contentKeywords;

    if (!multimediaExtension.includes(extension)) {
      if (fileContent) {
        // Call Third Party API to fetch content keywords
        try {
          const query = `'Generate me five Categories/keywords among these ${constant.categoriesGeneralKnown} from this content -: ${fileContent}'`;

          const response = await aiController.generateAIResponse(query);
          // contentKeywords = await s3Service.getContentKeywords(fileContent);

          // Regular expression to match the tags between ** **
          const regex = /\*\*(.*?)\*\*/g;

          // Extract the tags
          const matches = response.match(regex);

          // Clean up the matches by removing ** and join them into a comma-separated string
          contentKeywords = matches ? matches.map(tag => tag.replace(/\*\*/g, '')).join(', ') : '';
        } catch (error) {
          console.error('Error AI:', error);
          return false;
        }
      }
    }
    const newDocument = new Document({
      name: req.file.originalname,
      fileUrl: decodeURIComponent(fileUrl),
      author: req.body.author || "",
      date: req.body.date || new Date(),
      email: req.body.email || "",
      extension: req.file.originalname.split(".").pop(),
      keywords: contentKeywords || "",
    });

    await newDocument.save();

    res
      .status(200)
      .json({ message: "File uploaded successfully", url: decodeURIComponent(fileUrl) });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const listItems = async (req, res) => {
  try {
    const { geo, year, month, empId, keyword } = req.query;

    let folder = '';
    if (geo) folder += `${geo}/`;
    if (year) folder += `${year}/`;
    if (month) folder += `${month}/`;
    if (empId) folder += `${empId}/`;

    const folderLength = folder !== '' ? folder.split('/').length : 1;

    const whereCond = { fileUrl: { $regex: folder }, isDeleted: false };
    if (keyword) {
      whereCond.keywords = { $regex: keyword };
    }
    const documents = await Document.find(whereCond);
    const response = [];
    for (const item of documents) {
      const path = item.fileUrl.replace(process.env.S3_GENERIC_BASE_URL, '');
      const pathLength = path.split('/').length;
      const whereCond = {
        fileUrl: path,
        requestType: 'delete',
        status: 1,
      };

      const requestData = await userRequestModel.findOne(whereCond);
      let request = "";
      if (requestData) {
        request = {
          action: requestData.requestType,
          name: requestData.author,
          email: requestData.email,
          date: requestData.date
        };
      }

      if (item.extension === "folder") {
        if (pathLength === folderLength + 1) {
          response.push({
            name: item.name,
            fileUrl: item.fileUrl,
            author: item ? item.author : "",
            date: item ? item.date : "",
            email: item ? item.email : "",
            extension: item.extension,
            keywords: (item && item.keywords) ? item.keywords.split(',').map(value => value.trim()) : [],
            request: request,
          });
        }
      } else {
        if (pathLength === folderLength) {
          response.push({
            name: item.name,
            fileUrl: item.fileUrl,
            author: item ? item.author : "",
            date: item ? item.date : "",
            email: item ? item.email : "",
            extension: item.extension,
            keywords: (item && item.keywords) ? item.keywords.split(',').map(value => value.trim()) : [],
            request: request,
          });
        }
      }
    };

    res.status(200).json(response);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: error.message });
  }
};

const createFolder = async (req, res) => {
  const { folderName, path, author, date, email } = req.body;
  if (typeof folderName !== "string" || typeof path !== "string") {
    return res
      .status(400)
      .json({ message: "Folder name and path must be strings" });
  }
  if (!folderName) {
    return res.status(400).json({ message: "Folder name is required" });
  }
  try {
    const folderKey = s3Service.createFolderKey(path, folderName, author, date, email);
    const folderUrl = await s3Service.createFolder(folderKey, author, date, email);

    const newDocument = new Document({
      name: folderName,
      fileUrl: decodeURIComponent(folderUrl),
      author: author || "",
      date: date || new Date(),
      email: email || "",
      extension: "folder",
      keywords: "",
    });

    await newDocument.save();

    const logData = {
      name: author || "",
      email: email || "",
      action: "Folder created successfully",
      path: path,
      fileUrl: folderUrl,
    };
    await customlogService.saveCustomlogs(logData);

    res.status(200).json({ message: "Folder created successfully", folderKey });
  } catch (error) {
    const logData = {
      name: author || "",
      email: email || "",
      action: "Error creating folder",
      path: path,
      fileUrl: "",
    };
    await customlogService.saveCustomlogs(logData);
    console.error("Error creating folder:", error.message);
    res.status(500).json({ message: "Failed to create folder" });
  }
};

const downloadDocument = async (req, res) => {
  try {
    const file = await s3Service.downloadFile(req.params.filename);
    res.attachment(req.params.filename).send(file.Body);
  } catch (error) {
    console.error("Error downloading file:", error);
    res.status(404).json({ message: "File Not Found" });
  }
};

const deleteDocument = async (req, res) => {
  try {
    const filesToDelete = req.body;

    if (!Array.isArray(filesToDelete) || filesToDelete.length === 0) {
      return res.status(400).json({ message: "Request body should be a non-empty array" });
    }

    const deletePromises = filesToDelete.map(file => {
      const { fileName, path } = file;

      if (!fileName || !path) {
        throw new Error("Missing required fields: fileName or path");
      }

      // Clean the path and handle root-level deletions
      const cleanedPath = path === "/" ? "" : path.replace(/^\/+|\/+$/g, '');
      const key = cleanedPath ? `${cleanedPath}/${fileName}` : `${fileName}`;

      const isFolder = !fileName.includes('.');

      return s3Service.deleteFile(key, isFolder);
    });
    await Promise.all(deletePromises);

    res.status(200).json({ message: "Files deleted successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: error.message });
  }
};

const getFileContentByUrl = async (req, res) => {
  const { fileurl } = req.query;
  if (!fileurl) {
    return res.status(400).json({ error: "File URL is required" });
  }
  try {
    const fileContent = await s3Service.getFileContent(fileurl);
    if (!fileContent) {
      return res
        .status(404)
        .json({ error: "File not found or content could not be retrieved" });
    }
    res.json({ "content": fileContent });
  } catch (error) {
    console.error("Error in getFileContentByUrl:", error);
    res
      .status(500)
      .json({ error: "An error occurred while fetching the file content" });
  }
};

const uploadRequestedDocument = async (req, res) => {
  try {
    const filePath = req.body.path;

    if (!req.file || !filePath) {
      return res
        .status(400)
        .json({ message: "Missing required fields: file or path" });
    }

    const cleanedPath = filePath === "/" ? "" : filePath.replace(/^\/+|\/+$/g, '');
    const folderPath = cleanedPath ? `dumpTempFiles/${cleanedPath}` : `dumpTempFiles/`;

    const result = await s3Service.uploadRequestedDocument(req.body, req.file, folderPath, cleanedPath);

    const logData = {
      name: req.body.author || "",
      email: req.body.email || "",
      action: result ? result.message : "",
      path: cleanedPath,
      fileUrl: `${cleanedPath}/${req.file.originalname}`
    };
    await customlogService.saveCustomlogs(logData);

    res
      .status(200)
      .json(result);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const userRequestList = async (req, res) => {
  try {
    const result = await s3Service.userRequestList();

    res
      .status(200)
      .json(result);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const userRequest = async (req, res) => {
  try {
    const fileRequests = req.body.requestData;
    const { username, author } = req.body;

    if (!username || !author || !fileRequests) {
      throw new Error("Missing required fields: username or author or requestData");
    }

    if (!Array.isArray(fileRequests) || fileRequests.length === 0) {
      return res.status(400).json({ message: "requestData should be a non-empty array" });
    }

    const batchUpload = [];
    const batchUploadToReject = [];

    // Arrays to hold objects to be deleted from S3 and updates for MongoDB
    const batchDeleteKeys = [];
    const folderPaths = new Set(); // To handle approve marked folders
    const batchDeleteKeysToReject = [];
    const folderPathsToReject = new Set(); // To handle reject marked folders
    var fileDeleteStatus = []; //To handle file delete status
    var folderDeleteStatus = []; //To handle folder delete status
    var approveResponse = [];
    var rejectResponse = [];

    for (const request of fileRequests) {
      const { fileType, fileUrl, requestType, requestFor } = request;

      if (!fileType || !fileUrl || !requestType || !requestFor) {
        throw new Error("Missing required fields: fileType or fileUrl or requestType or requestFor");
      }

      if (requestFor === 'upload') {
        if (requestType === "approve") {
          batchUpload.push(request);
        } else if (requestType == "reject") {
          batchUploadToReject.push(request);
        }
      } else if (requestFor === 'delete') {
        // Prepare for batch deletion
        if (fileType == 'file' && requestType == "approve") {
          batchDeleteKeys.push(request);
        } else if (fileType == 'folder' && requestType == "approve") {
          folderPaths.add(request);
        } else if (fileType == 'file' && requestType == "reject") {
          batchDeleteKeysToReject.push(request);
        } else if (fileType == 'folder' && requestType == "reject") {
          folderPathsToReject.add(request);
        }
      }
    }

    if (batchUpload.length > 0) {
      await s3Service.uploadS3Files(batchUpload, username, author);
    }

    if (batchUploadToReject.length > 0) {
      const fileUrls = batchUploadToReject.map(item => `dumpTempFiles/${item.fileUrl}`);
      await s3Service.deleteS3Files(fileUrls); // Remove temp files

      await s3Service.updateUploadStatusIfRejected(batchUploadToReject);
      for (const file of batchUploadToReject) {
        const logData = {
          name: author || "",
          email: username || "",
          action: "reject request for upload file",
          path: file.fileUrl,
          fileUrl: file.fileUrl,
          comment: file.comment || "",
        };
        await customlogService.saveCustomlogs(logData);

        const whereCond = { _id: file.id };
        const requestData = await userRequestModel.findOne(whereCond);
        if (requestData) {
          const toEmail = requestData.email;
          const subject = "Request for upload file status";
          let body = `<p>Request for upload file has been rejected by ${username || author}.`;
          if (file.comment) {
            body = body + `<p style="font-weight: 500; color: black;">${username || author}: <span style="font-style: italic; color: #616161;">${file.comment}</span></p>`;
          }
          await customService.sendMail(toEmail, subject, body);
        }
      }
    }

    //Delete Files from S3 and update UserRequest collection (Approve Case)
    if (batchDeleteKeys.length > 0) {
      fileDeleteStatus = await s3Service.deleteS3Files(batchDeleteKeys);
    }

    //Delete Folders from S3 and update UserRequest collection (Approve Case)
    if (folderPaths.size != 0) {
      folderDeleteStatus = await s3Service.deleteS3Folders(folderPaths);
    }

    //Delete Status of S3 Files and Folders
    const combinedDeleteStatus = [...fileDeleteStatus, ...folderDeleteStatus];

    //Update Documents Collections based on deletion status of(files and folders)
    approveResponse = await s3Service.updateDeleteRequestStatus(combinedDeleteStatus);

    //Reject Case
    if (batchDeleteKeysToReject.length > 0 || folderPathsToReject.size != 0) {
      rejectResponse = await s3Service.updateDeleteStatusIfRejected(batchDeleteKeysToReject, folderPathsToReject);
    }

    const response = [...approveResponse, ...rejectResponse];
    if (response.length > 0) {
      for (const res of response) {
        const logData = {
          name: author || "",
          email: username || "",
          action: res.message,
          path: res.fileUrl ? res.fileUrl : res.folderPath,
          fileUrl: res.fileUrl ? res.fileUrl : res.folderPath,
          comment: res.comment || "",
        };
        await customlogService.saveCustomlogs(logData);

        const whereCond = { _id: res.id };
        const requestData = await userRequestModel.findOne(whereCond);
        if (requestData) {
          const toEmail = requestData.email;
          const subject = "Request for delete file status";
          let body = `<p>${res.message} by ${author}. </p>`;
          if (res.comment) {
            body = body + `<p style="font-weight: 500; color: black;">${author}: <span style="font-style: italic; color: #616161;">${res.comment}</span></p>`;
          }
          await customService.sendMail(toEmail, subject, body);
        }
      }
    }

    res
      .status(200)
      .json({ message: 'File requests processed and database updated successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const deleteRequest = async (req, res) => {
  try {
    const fileDetailsArray = [];
    const filesToDelete = req.body.requestData;
    const { username, author } = req.body;
    const existRequest = [];

    if (!username || !author || !filesToDelete) {
      throw new Error("Missing required fields: username or author or requestData");
    }

    if (!Array.isArray(filesToDelete) || filesToDelete.length === 0) {
      return res.status(400).json({ message: "Request body should be a non-empty array" });
    }

    for (const file of filesToDelete) {
      const { fileName, path } = file;

      if (!fileName || !path) {
        throw new Error("Missing required fields: fileName or path");
      }

      // Clean the path and update deletedRequested status
      const cleanedPath = path === "/" ? "" : path.replace(/^\/+|\/+$/g, '');
      const key = cleanedPath ? `${cleanedPath}/${fileName}` : `${fileName}`;

      // Determine if the item is a folder or file
      const isFolder = !fileName.includes('.'); // If there is no dot, it's considered a folder
      const fileType = isFolder ? 'folder' : 'file';

      const whereCond = {
        fileUrl: `${cleanedPath}/${file.fileName}`,
        requestType: 'delete',
        status: 1,
      };

      const requestData = await userRequestModel.findOne(whereCond);

      if (requestData) {
        existRequest.push({
          fileUrl: key,
          fileType,
          requestType: 'delete',
          author: author,
          email: username,
          date: new Date(),
          extension: isFolder ? 'folder' : fileName.split(".").pop(),
          status: 1,
        });
      } else {
        // Create an object with filePath and fileType and push it to the array
        // Status:1 , admin requested superadmin
        fileDetailsArray.push({
          fileUrl: key,
          fileType,
          requestType: 'delete',
          author: author,
          email: username,
          date: new Date(),
          extension: isFolder ? 'folder' : fileName.split(".").pop(),
          status: 1,
        });
      }
    };

    //Save request in new collection "UserRequest"
    if (fileDetailsArray.length > 0) {
      await s3Service.addDeleteRequest(fileDetailsArray);
      let i = 1;
      let fileList = '';
      for (const file of fileDetailsArray) {
        const logData = {
          name: author || "",
          email: username || "",
          action: "request for delete",
          path: file.fileUrl,
          fileUrl: file.fileUrl,
        };
        await customlogService.saveCustomlogs(logData);
        // fileList = `${fileList} <p>${i}) ${process.env.WEB_URL}/${encodeURI(file.fileUrl)}</p>`;  it was working of below dones work try this --- piyush.patel@rws.com 
        const newUrl = file.fileUrl.substring(0, file.fileUrl.lastIndexOf('/'));
        fileList = `<ul>${fileList} <li><a href="${process.env.WEB_URL}/${encodeURI(newUrl)}" style="font-weight: 500;" >${process.env.WEB_URL}/${encodeURI(file.fileUrl)}</a></li></ul>`;
        i++;
      }

      const whereCond = { role: 'Approver' };
      const requestData = await User.find(whereCond);
      if (requestData) {
        const userEmails = requestData.map(user => user.userName);
        const subject = "Request for delete files";
        let body = `<p>Below files are requested for delete by ${author}. </p>`;
        body = body + `${fileList}`;
        await customService.sendMail(userEmails, subject, body);
      }
    }

    if (existRequest.length > 0) {
      for (const file of existRequest) {
        const logData = {
          name: author || "",
          email: username || "",
          action: "File delete request already exist",
          path: file.fileUrl,
          fileUrl: file.fileUrl,
        };
        await customlogService.saveCustomlogs(logData);
      }
    }

    if (fileDetailsArray.length > 0) {
      res.status(200).json({ message: 'Delete requests saved successfully' });
    } else {
      res.status(200).json({ message: 'File delete request already exist' });
    }
  } catch (error) {
    console.error('Error saving delete requests:', error);
    res.status(500).json({ message: 'Error saving delete requests', error: error.message });
  }
};

/**
 * Add an S3 folder and its contents to the zip file recursively.
 * 
 * @param {string} folderPath - The S3 folder path to add to the zip.
 * @param {object} zip - The JSZip instance to which files and folders are added.
 * @param {string} parentFolder - The parent folder path within the zip.
 */
const addFolderToZip = async (folderPath, zip, parentFolder = '') => {
  const listParams = {
    Bucket: process.env.S3_BUCKET_NAME,
    Prefix: folderPath.endsWith('/') ? folderPath : `${folderPath}/`, // Ensure folderPath ends with '/'
  };

  try {
    const data = await s3.listObjectsV2(listParams).promise();
    const files = data.Contents;

    if (!files || files.length === 0) {
      console.log(`No files found in folder: ${folderPath}`);
      return;
    }

    for (const file of files) {
      const relativePath = file.Key.replace(listParams.Prefix, '').replace(/^\/+/, ''); // Remove folder path prefix and any leading slashes

      if (relativePath === '') {
        // Skip the root folder itself
        continue;
      }

      const fullPathInZip = `${parentFolder}${relativePath}`.replace(/^\/+/, ''); // Ensure no leading slashes in the full path

      if (file.Key.endsWith('/')) {
        // Handle folder (recursively add its contents)
        const nestedFolderName = `${parentFolder}${relativePath}`.replace(/^\/+/, '').replace(/\/+$/, ''); // No leading/trailing slashes
        console.log(`Adding folder: ${nestedFolderName}`);
        zip.folder(nestedFolderName); // Add folder to the ZIP
        await addFolderToZip(file.Key, zip, `${nestedFolderName}/`); // Recurse into the folder
      } else {
        // Handle file
        console.log(`Adding file: ${fullPathInZip}`);
        try {
          const fileContent = await s3.getObject({ Bucket: listParams.Bucket, Key: file.Key }).promise();
          zip.file(fullPathInZip, fileContent.Body); // Add file content to the ZIP
        } catch (fileError) {
          console.error(`Error retrieving file ${file.Key}:`, fileError);
        }
      }
    }
  } catch (error) {
    console.error('Error adding folder to zip:', error);
    throw error;
  }
};

// Example usage in bulk download function
const bulkDownloadDocument = async (req, res) => {
  const files = req.body; // Expecting an array of file objects
  console.log("Request body:", JSON.stringify(files, null, 2)); // Log request body for better debugging

  if (!Array.isArray(files) || files.length === 0) {
    return res.status(400).json({ message: 'Invalid input' });
  }

  try {
    const zip = new JSZip();
    let hasFolder = false; // Flag to check if any folder is present

    for (const file of files) {
      const { fileName, path, type } = file;
      const fullPath = path ? `${path}/${fileName}` : fileName; // Handle case where path is empty

      console.log(`Processing file or folder: ${JSON.stringify(file, null, 2)}`);

      if (type === 'file') {
        try {
          const fileContent = await s3.getObject({ Bucket: process.env.S3_BUCKET_NAME, Key: fullPath }).promise();
          // Use only the file name for the zip entry
          console.log(`Adding file to zip: ${fileName}`);
          zip.file(fileName, fileContent.Body); // Directly add the file by its name
        } catch (fileError) {
          console.error(`Error adding file to zip: ${fileName}`, fileError);
        }
      } else if (type === 'folder') {
        hasFolder = true; // Set flag to true if a folder is present
        // Handle folders recursively
        const folderPath = path === "" ? `${fileName}` : `${path}/${fileName}`;
        console.log(`Adding folder and its contents to zip: ${folderPath}`);
        await addFolderToZip(folderPath, zip, `${fileName}/`); // Ensure each folder is added under its own root
      }
    }

    // Generate the zip and send it in response
    const zipContent = await zip.generateAsync({ type: 'nodebuffer' });
    console.log('ZIP content generated successfully');

    // Set the zip file name based on whether only files are selected
    const zipFileName = hasFolder ? 'files_with_folders.zip' : 'files_only.zip';

    res.setHeader('Content-Disposition', `attachment; filename="${zipFileName}"`);
    res.setHeader('Content-Type', 'application/zip');
    return res.send(zipContent);

  } catch (error) {
    console.error('Error handling files or folders:', error);
    return res.status(404).json({ message: 'One or more files/folders not found' });
  }
};



const getLogs = async (req, res) => {
  try {
    const result = await customlogService.getLogs();

    res
      .status(200)
      .json(result);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
const exportLogs = async (req, res) => {
  try {
    const logs = await customlogService.getLogs();
    const csvData = convertToCSV(logs);
    res.setHeader('Content-Disposition', 'attachment; filename="logs.csv"');
    res.setHeader('Content-Type', 'text/csv');
    res.status(200).send(csvData);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const convertToCSV = (logs) => {
  const header = Object.keys(logs[0]).join(',') + '\n';
  const rows = logs.map(log => Object.values(log).join(',')).join('\n');
  return header + rows;
};


module.exports = {
  uploadDocument,
  listItems,
  downloadDocument,
  deleteDocument,
  getFileContentByUrl,
  createFolder,
  uploadRequestedDocument,
  userRequestList,
  userRequest,
  deleteRequest,
  bulkDownloadDocument,
  getLogs,
  exportLogs
};

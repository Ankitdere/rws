const healthService = require('../services/healthService');

const getHealth = (req, res) => {
    try {
        const healthStatus = healthService.getHealthStatus();
        res.status(200).json(healthStatus);
    } catch (error) {
        console.error("Error in health check:", error);
        res.status(500).json({ message: "Internal Server Error" });
    }
};

module.exports = {
    getHealth
};

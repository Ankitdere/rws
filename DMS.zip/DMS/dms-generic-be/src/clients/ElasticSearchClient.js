const { Client } = require("@elastic/elasticsearch");
require("dotenv").config();

const esNode = process.env.ELASTIC_URL;
const elasticEnabled = process.env.ELASTIC_ENABLED === 'true';

let esClient = null; // Declare the client variable

// Only initialize the Elasticsearch client if the feature flag is enabled
if (elasticEnabled) {
  esClient = new Client({
    node: esNode,
    auth: {
      username: process.env.ELASTIC_USER,
      password: process.env.ELASTIC_PASSWORD,
    },
    tls: {
      rejectUnauthorized: false, // Adjust based on your security needs
    },
  });
  console.log('Elasticsearch client initialized');
} else {
  console.log('Elasticsearch feature disabled, client not initialized');
}

// Function to connect to Elasticsearch (only if enabled)
async function elasticConnect() {
  try {
    if (!elasticEnabled) return null; // Return early if Elasticsearch is disabled
    const health = await esClient.cluster.health();
    console.log("Elasticsearch cluster health:", health);
    return health; // Return health status if successful
  } catch (error) {
    console.error("Elasticsearch connection error:", error);
    return null; // Return null if there is an error
  }
}

// Export the elasticConnect function and client (client can be null if not enabled)
module.exports = {
  elasticConnect,
  esClient, // Will be `null` if Elasticsearch is disabled
};

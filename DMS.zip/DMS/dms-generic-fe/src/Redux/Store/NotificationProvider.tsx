import React, { createContext, useContext, useState } from 'react';

interface Notification {
    title: string;
    submessage: string;
    duration: number;
    type: number;
    isActive: boolean;
}

const defaultNotification: Notification = {
    title: '',
    submessage: '',
    type: 1,
    duration: 2000,
    isActive: false,
};

const NotificationContext = createContext<{
    notification: Notification;
    openNotificationPopUp: (title: string, submessage: string, duration?: number, type?: number) => void; // type is now optional
}>({
    notification: defaultNotification,
    openNotificationPopUp: () => { },
});

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [notification, setNotification] = useState<Notification>(defaultNotification);

    const openNotificationPopUp = (title: string, submessage: string, duration: number = 2000, type: number = 1) => {
        setNotification({
            title,
            submessage,
            duration,
            type,
            isActive: true,
        });
        setTimeout(() => {
            setNotification(prev => ({ ...prev, isActive: false }));
        }, duration);
    };

    return (
        <NotificationContext.Provider value={{ notification, openNotificationPopUp }}>
            {children}
        </NotificationContext.Provider>
    );
};

export const useNotification = () => {
    return useContext(NotificationContext);
};

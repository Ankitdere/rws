import React, { createContext, useState, useEffect, useContext, ReactNode } from 'react';
import { typeDocs, Document } from '../../Constants/constants';
import { notification } from 'antd';
import { getClassNames } from '../../Constants/utils';

type EmailContextType = {
  email: string;
  setEmail: React.Dispatch<React.SetStateAction<string>>;
  searchTerm: string;
  setSearchTerm: React.Dispatch<React.SetStateAction<string>>;
  docs: Document[];
  setDocs: React.Dispatch<React.SetStateAction<Document[]>>;
  fullDocs: Document[];
  setFullDocs: React.Dispatch<React.SetStateAction<Document[]>>;
  viewMode: 'grid' | 'list';
  setViewMode: React.Dispatch<React.SetStateAction<'grid' | 'list'>>;
  refresh: boolean;
  setRefresh: React.Dispatch<React.SetStateAction<boolean>>;
  selectedKey: any;
  setSelectedKey: any;
  openNotification: (message: string, description: string, duration: number, IconComponent: React.ReactNode, type:string) => void;
  RecentSearches:any,
  setRecentSearches:any
};


const EmailContext = createContext<EmailContextType | undefined>(undefined);

export const DMSProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [email, setEmail] = useState(() => localStorage.getItem('email') || '');
  const [searchTerm, setSearchTerm] = useState('');
  const [docs, setDocs] = useState<Document[]>(typeDocs);
  const [fullDocs, setFullDocs] = useState<Document[]>(typeDocs);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list');
  const [refresh, setRefresh] = useState(false);
  const [selectedKey, setSelectedKey] = useState('1');
  const [RecentSearches, setRecentSearches] = useState(['']);
  const [api, contextHolder] = notification.useNotification();

  const openNotification = (message: string, description: string, duration: number, IconComponent: React.ReactNode, type: string) => {
    api.open({
      message,
      description,
      duration,
      icon: IconComponent,
      // showProgress:true,
      pauseOnHover: true,
      placement:'bottomRight',
      className: getClassNames(type),
    });
  };

  useEffect(() => {
    localStorage.setItem('email', email);
  }, [email]);

  const emailContextValue = {
    email,
    setEmail,
    searchTerm,
    setSearchTerm,
    docs,
    setDocs,
    fullDocs,
    setFullDocs,
    viewMode,
    setViewMode,
    refresh,
    setRefresh,
    selectedKey,
    setSelectedKey,
    openNotification,
    RecentSearches,
    setRecentSearches
  };

  return (
    <EmailContext.Provider value={emailContextValue}>
      {contextHolder}
      {children}
    </EmailContext.Provider>
  );
};

export const useDMSHooks = () => {
  const context = useContext(EmailContext);
  if (!context) {
    throw new Error('useDMSHooks must be used within a DMSProvider');
  }
  return context;
};

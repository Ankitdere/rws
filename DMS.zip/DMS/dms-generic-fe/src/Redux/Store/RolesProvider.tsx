import React, { createContext, useState, useContext, ReactNode, useEffect } from 'react';
import { getUserRoles } from '../../ServiceUtils/Services/api';

interface RolesContextType {
    selectedRoles: {
        User: string[];
        Approver: string[];
        Admin: string[];
    };
    setSelectedRoles: React.Dispatch<React.SetStateAction<{
        User: string[];
        Approver: string[];
        Admin: string[];
    }>>;
    role: string[];
    setRole: React.Dispatch<React.SetStateAction<string[]>>;
    currentuserRole: string;
    setCurrentUserRole: React.Dispatch<React.SetStateAction<string>>;
    userDetails: any;
    setUserDetails: any;
    allUsersData: any;
    setAllUsersData: any

}

const RolesContext = createContext<RolesContextType | undefined>(undefined);

export const RolesProvider = ({ children }: { children: ReactNode }) => {
    const [selectedRoles, setSelectedRoles] = useState<{ User: string[], Approver: string[], Admin: string[] }>({
        User: ["FileList", "FilePreview", "AISummary"],
        Approver: ["Approve", "Reject"],
        Admin: ["Upload", "Delete", "FilePreview", "FileList", "AISummary", "Download", "Logs", "Chat"]
    });
    const [role, setRole] = useState(['FileList'])
    const [currentuserRole, setCurrentUserRole] = useState<string>('')
    const [userDetails, setUserDetails] = useState()
    const [allUsersData, setAllUsersData] = useState()
    //roles keys are this const options = ["Upload", "Delete", "FileList", "FilePreview", "AISummary", "Approve", "Reject"];
    //if any one want to use please strictly use these only.
    const getAlldata = async () => {
        const Response = await getUserRoles();
        setAllUsersData(Response)
    }
    useEffect(() => {
        getAlldata()
    }, [])
    return (
        <RolesContext.Provider value={{ selectedRoles, setSelectedRoles, role, setRole, currentuserRole, setCurrentUserRole, userDetails, setUserDetails, allUsersData, setAllUsersData }}>
            {children}
        </RolesContext.Provider>
    );
};

export const useRoles = () => {
    const context = useContext(RolesContext);
    if (!context) {
        throw new Error('useRoles must be used within a RolesProvider');
    }
    return context;
};

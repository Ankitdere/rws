export const msalConfig = {
  auth: {
    clientId: process.env.REACT_APP_CLIENT_ID || "",
    authority: process.env.REACT_APP_AUTHORITY_URL || "",
    redirectUri: '/',
    postLogoutRedirectUri: '/',
    navigateToLoginRequestUrl: false
  },
  caches: {
    cacheLocation: 'sessionStorage',
    storeAuthStateInCookie: true
  }
};

export const loginRequest = {
  scopes: ['user.read']
}
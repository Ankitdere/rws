import ReactDOM from 'react-dom/client';
import './index.css';
import reportWebVitals from './reportWebVitals';
import { AuthenticationResult, PublicClientApplication } from '@azure/msal-browser';
import { msalConfig } from './Authentication/AzureAD/Config/config';
import App from './AuthenticatedLayer';
import { RolesProvider } from './Redux/Store/RolesProvider';
import HealthCheck from './Component/ErrorPage/HealthCheckErrorFallbackPage/HealthCheck';
import { useState } from 'react';
import ErrorFirewall from './ErrorBoundaries/ErrorBackUI/ErrorFirewall';
import { NotificationProvider } from './Redux/Store/NotificationProvider';
import NotificationPop from './Component/Modules/Notifications/Notification';

const RootComponent = () => {
  const [healthChecked, setHealthChecked] = useState(false);
  const handleProceed = () => {
    setHealthChecked(true);
  };

  return (
    <ErrorFirewall>
      <HealthCheck onProceed={handleProceed} />
      {healthChecked && <App instance={msalInstance} />}
    </ErrorFirewall>
  );
};

const msalInstance = new PublicClientApplication(msalConfig);

if (!msalInstance.getActiveAccount() && msalInstance.getAllAccounts().length > 0) {
  msalInstance.setActiveAccount(msalInstance.getAllAccounts()[0]);
}

msalInstance.addEventCallback((event) => {
  if (event.eventType === 'msal:loginSuccess' && (event.payload as AuthenticationResult).account) {
    const payload = event.payload as AuthenticationResult;
    msalInstance.setActiveAccount(payload.account);
  }
});

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

root.render(

  <RolesProvider>
    <NotificationProvider>
      <NotificationPop />
      <RootComponent />
    </NotificationProvider>
  </RolesProvider>
);

reportWebVitals();

import React from 'react';
import { ErrorBoundary as ReactErrorBoundary } from 'react-error-boundary';
import UIErrorResults from './ErrorUIResults/UIErrorResults';

interface ErrorFallbackProps {
  error: Error;
  resetErrorBoundary: () => void;
}

function ErrorFallback({ error, resetErrorBoundary }: ErrorFallbackProps) {
  return (
    <div role="alert">
      <UIErrorResults errorMessage={error.message} />
    </div>
  );
}

const ErrorFirewall: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <ReactErrorBoundary
      FallbackComponent={ErrorFallback}
      onReset={() => {}}
    >
      {children}
    </ReactErrorBoundary>
  );
};

export default ErrorFirewall;

import { Result, Button, Collapse } from 'antd'
import LOGO from '../../../Assets/DMS_Logo/Logo.png'
import { Fragment } from 'react/jsx-runtime'

export default function UIErrorResults({ errorMessage }: any) {
    return (
        <Fragment>
            <Result
                icon={<div className='flex justify-center p-2 mt-10'>
                    <img src={LOGO} alt={'Error'} className='h-[70px]' />
                </div>}
                title="Oops, Something went wrong"
                subTitle="We're currently performing maintenance. Please bear with us and check back shortly"
                extra={[
                    <Button type="dashed" key="console" href="mailto:dmsuser@genericdms.onmicrosoft.com">
                        Contact Administrator
                    </Button>,
                ]}
            />
            <Collapse
                className='border-2 border-adminNavbar font-semibold mx-5'
                size="small"
                items={[{ key: '1', label: 'Advanced Details (Developers Team)', children: <p>{errorMessage}</p> }]}
            />
        </Fragment>
    )
}

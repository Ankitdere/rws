export const getBaseUrl = () => {
  let url;
  switch (process.env.REACT_APP_ENV) {
    case 'production':
      url = process.env.REACT_APP_SERVICE_URL_PROD || '';
      break;
    case 'development':
    default:
      url = process.env.REACT_APP_SERVICE_URL_LOCAL || '';
  }

  return url;
}
export const getSocketURL = () => {
  let url;
  switch (process.env.REACT_APP_ENV) {
    case 'production':
      url = process.env.REACT_APP_SOCKET_URL_PROD || '';
      break;
    case 'development':
    default:
      url = process.env.REACT_APP_SOCKET_URL_LOCAL || '';
  }

  return url;
}

export const formatTimeAgo = (dateString: string): string => {
  const date = new Date(dateString);
  const now = new Date();
  const secondsAgo = Math.floor((now.getTime() - date.getTime()) / 1000);

  const intervals: { [key: string]: number } = {
    year: 31536000,
    month: 2592000,
    week: 604800,
    day: 86400,
    hour: 3600,
    minute: 60,
    second: 1,
  };

  for (let interval in intervals) {
    const time = Math.floor(secondsAgo / intervals[interval]);
    if (time >= 1) {
      return `${time} ${interval}${time > 1 ? "s" : ""} ago`;
    }
  }
  return "just now";
};

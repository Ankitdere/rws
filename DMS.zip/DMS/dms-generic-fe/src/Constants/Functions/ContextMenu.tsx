import { FolderOpenOutlined, DeleteOutlined, CheckOutlined, DownloadOutlined } from "@ant-design/icons";
import { MenuProps, Tag } from "antd";
import { Document } from "../constants";

export const getMenuItems = (item: Document, isDeleteAccess: boolean, isDownloadAccess: boolean): MenuProps['items'] => {
  const menuItems: MenuProps['items'] = [
    {
      label: 'Open',
      key: '1',
      icon: <FolderOpenOutlined />,
    },
    {
      label: 'Select',
      key: '3',
      icon: <CheckOutlined />,
    },
  ];

  if (isDeleteAccess) {
    menuItems.splice(1, 0, {
      label: 'Delete',
      key: '2',
      icon: <DeleteOutlined />,
    });
  }
  if (isDownloadAccess) {
    menuItems.splice(1, 0, {
      label: 'Download',
      key: '4',
      icon: <DownloadOutlined />,
    });
  }

  return menuItems;
};



export const formatActionMessage = (action: string): JSX.Element => {
  const lowerCasedAction = action.toLowerCase();
  console.log(lowerCasedAction, '_____')
  if (lowerCasedAction.includes("file url marked as rejected in database")) {
    return (
      <p className="flex flex-wrap gap-1">
        Request to <Tag color="red">Delete</Tag> has been <Tag color="red">Rejected</Tag>
      </p>
    );
  } else if (lowerCasedAction.includes("reject request for upload file")) {
    return (
      <p className="flex flex-wrap gap-1">
        Request to <Tag color="green">Upload</Tag> has been <Tag color="red">Rejected</Tag>
      </p>
    );
  } else if (lowerCasedAction.includes('request for delete file has been approved')) {
    return (
      <p className="flex flex-wrap gap-1">
        Request to  <Tag color="red">Delete</Tag> has been  <Tag color="green">Approved</Tag>
      </p>
    );
  } else if (lowerCasedAction.includes("request for delete")) {
    return (
      <p className="flex flex-wrap gap-1 mr-1">
        <Tag color="red">Delete</Tag> Request Raised
      </p>
    );
  } else if (lowerCasedAction.includes("approve request for upload file")) {
    return (
      <p className="flex flex-wrap gap-1">
        Request to <Tag color="green">Upload</Tag> has been <Tag color="green">Approved</Tag>
      </p>
    );
  } else if (lowerCasedAction.includes("file upload request saved successfully")) {
    return (
      <p className="flex flex-wrap gap-1 mr-1">
        <Tag color="green">Upload</Tag> Request Raised
      </p>
    );
  }else if (lowerCasedAction.includes("folder created successfully")) {
    return (
      <p className="flex flex-wrap gap-1 mr-1">
        <Tag color="orange">Folder</Tag> Created
      </p>
    );
  }
  return <p>{action}</p>;
};
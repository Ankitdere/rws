import { FolderOpenFilled } from '@ant-design/icons';
import PNG from '../../Assets/FileIcons/PNG.png';
import wordicon from '../../Assets/FileIcons/wordIcon.svg'
import adobe from '../../Assets/FileIcons/adobe.png'
import excel from '../../Assets/FileIcons/excel.png'
import zip from '../../Assets/FileIcons/zip.png'
import xml from '../../Assets/FileIcons/xml.png'
import download from '../../Assets/FileIcons/download.png'
import svg from '../../Assets/FileIcons/svg.svg'
import json from '../../Assets/FileIcons/json.png'
import videoFile from '../../Assets/FileIcons/videoFile.png'
import bat from '../../Assets/FileIcons/bat.png'
import powerpoint from '../../Assets/FileIcons/powerPoint.png'
import rdp from '../../Assets/FileIcons/rdp.png'
import html from '../../Assets/FileIcons/html.png'
import css from '../../Assets/FileIcons/css.png'

export const getIcon = (extension: string, height: string, name:string) => {
  switch (extension) {
    case 'docx':
      return (
        <img
          src={wordicon}
          alt="docx"
          className={`${height}`} loading="lazy"
        />
      );
    case 'pdf':
      return (
        <img
          src={adobe}
          alt="pdf"
          className={`${height}`} loading="lazy"
        />
      );
    case 'ppt':
    case 'pptx':
      return (
        <img
          src={powerpoint}
          className={`${height}`} loading="lazy"
          alt="pptx"
        />
      );
    case 'xlsx':
    case 'xls':
    case 'csv':
      return (
        <img
          src={excel}
          alt="excel"
          className={`${height}`} loading="lazy"
        />
      );
    case 'rar':
    case 'zip':
      return (
        <img
          src={zip}
          alt="zip"
          className={`${height}`} loading="lazy"
        />
      );
    case 'xml':
    case 'xsd':
      return (
        <img
          src={xml}
          alt="xml"
          className={`${height}`} loading="lazy"
        />
      );
    case 'exe':
    case 'msi':
      return (
        <img
          src={download}
          alt="exe"
          className={`${height}`} loading="lazy"
        />
      );
    case 'jpg':
    case 'bitmap':
    case 'jpeg':
    case 'png':
      return (
        <img
          src={PNG}
          alt="img"
          className={`${height}`} loading="lazy"
        />
      );
    case 'svg':
      return (
        <img
          src={svg}
          alt="img"
          className={`${height}`} loading="lazy"
        />
      );
    case 'rdp':
      return (
        <img
          src={rdp}
          alt="img"
          className={`${height}`} loading="lazy"
        />
      );
    case 'json':
      return (
        <img
          src={json}
          alt="img"
          className={`${height}`} loading="lazy"
        />
      );
    case 'mov':
    case 'wmv':
    case 'avi':
    case 'avchd':
    case 'flv':
    case 'mp4':
      return <img src={videoFile} alt='videp' className='h-14' />;
    case 'bat':
    case 'vbs':
      return <img src={bat} alt='bat' className={`${height}`} loading="lazy" />
    case 'html':
      return <img src={html} alt='bat' className={`${height}`} loading="lazy" />
    case 'css':
      return <img src={css} alt='bat' className={`${height}`} loading="lazy" />
    default:
      return <FolderOpenFilled className={`${height === 'h-4' ? 'text-[20px]' : 'text-[50px]'} text-[#FFB300]`} />;
  }
};
export const GetIconCustomHeight = (extension: string, height: string, name:string) => {
  switch (extension) {
    case 'docx':
      return (
        <img
          src={wordicon}
          alt="docx"
          className={`${height}`} loading="lazy"
        />
      );
    case 'pdf':
      return (
        <img
          src={adobe}
          alt="pdf"
          className={`${height}`} loading="lazy"
        />
      );
    case 'ppt':
    case 'pptx':
      return (
        <img
          src={powerpoint}
          className={`${height}`} loading="lazy"
          alt="pptx"
        />
      );
    case 'xlsx':
    case 'xls':
    case 'csv':
      return (
        <img
          src={excel}
          alt="excel"
          className={`${height}`} loading="lazy"
        />
      );
    case 'rar':
    case 'zip':
      return (
        <img
          src={zip}
          alt="zip"
          className={`${height}`} loading="lazy"
        />
      );
    case 'xml':
    case 'xsd':
      return (
        <img
          src={xml}
          alt="xml"
          className={`${height}`} loading="lazy"
        />
      );
    case 'exe':
    case 'msi':
      return (
        <img
          src={download}
          alt="exe"
          className={`${height}`} loading="lazy"
        />
      );
    case 'jpg':
    case 'bitmap':
    case 'jpeg':
    case 'png':
      return (
        <img
          src={PNG}
          alt="img"
          className={`${height}`} loading="lazy"
        />
      );
    case 'svg':
      return (
        <img
          src={svg}
          alt="img"
          className={`${height}`} loading="lazy"
        />
      );
    case 'rdp':
      return (
        <img
          src={rdp}
          alt="img"
          className={`${height}`} loading="lazy"
        />
      );
    case 'json':
      return (
        <img
          src={json}
          alt="img"
          className={`${height}`} loading="lazy"
        />
      );
    case 'mov':
    case 'wmv':
    case 'avi':
    case 'avchd':
    case 'flv':
    case 'mp4':
      return <img src={videoFile} alt='videp' className={`${height}`} />;
    case 'bat':
    case 'vbs':
      return <img src={bat} alt='bat' className={`${height}`} loading="lazy" />
    case 'html':
      return <img src={html} alt='bat' className={`${height}`} loading="lazy" />
    case 'css':
      return <img src={css} alt='bat' className={`${height}`} loading="lazy" />
    default:
      return <FolderOpenFilled className={`${height === 'h-4' ? 'text-[20px]' : `${height === 'h-6' ? 'text-[30px]': 'text-[50px]'}`}'} text-[#FFB300]`} />;
  }
};
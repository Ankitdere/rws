export function formatDate(dateString:any) {
    let date = new Date(dateString);
    let year = date.getFullYear();
    let month = ("0" + (date.getMonth() + 1)).slice(-2);
    let day = ("0" + date.getDate()).slice(-2);
    return `${year}-${month}-${day}`;
  }

  export function getExtensionCounts(documents: any[]){
    const extensionMap: { [key: string]: number } = {};

    documents.forEach(doc => {
        const ext = doc.extension.replace('.', ''); 
        if (extensionMap[ext]) {
            extensionMap[ext]++;
        } else {
            extensionMap[ext] = 1;
        }
    });

    const extensions = Object.keys(extensionMap);
    const counts = Object.values(extensionMap);

    return { extension: extensions, count: counts };
};
export const BGs = [
  '#2196F3',
  '#673AB7',
  '#E91E63',
  '#009688',
  '#FF9800',
  '#009688',
  '#607D8B',
  '#FF5722',
  '#80DEEA',
  '#CFD8DC',
]

export interface File {
  name: string;
  extension: string;
}
export type GroupedFiles = Record<string, string[]>;

export const setCurrentAccessSession = (currentuserRole: string, role: string[]) => {
  const sessionData = {
      currentUserRole: currentuserRole,
      accessPermissions: role
  };
  const sessionDataString = JSON.stringify(sessionData);
  sessionStorage.setItem('currentAccessSession', sessionDataString);
};


export const capitalizeFirstLetter = (text: string): string => {
  if (!text) return text; 
  return text.charAt(0).toUpperCase() + text.slice(1);
};

export const getClassNames = (type:string) => {
  switch (type) {
    case 'success':
      return 'text-[10px] shadow-md  rounded-lg border border-green-500';
    case 'error':
      return 'text-[10px] shadow-md  rounded-lg border border-red-500';
    case 'info':
      return 'text-[10px] shadow-md rounded-lg border border-blue-500';
    case 'warning':
      return 'text-[9px] shadow-md  rounded-lg border border-warning';
    default:
      return 'text-[9px] shadow-md rounded-lg border border-gray-500';
  }
};

export function formatMessageDate(date: Date) {
  const today = new Date();
  const yesterday = new Date();
  yesterday.setDate(today.getDate() - 1);
  if (date.toDateString() === today.toDateString()) {
      return 'Today';
  }
  else if (date.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
  }
  else {
      return date.toLocaleDateString(undefined, {
          year: 'numeric',
          month: 'long',
          day: 'numeric',
      });
  }
}

export const shouldShowDivider = (currentMessageTime: any, previousMessageTime: any) => {
    const currentDate = new Date(currentMessageTime).toDateString();
    const previousDate = new Date(previousMessageTime).toDateString();
    return currentDate !== previousDate;
};
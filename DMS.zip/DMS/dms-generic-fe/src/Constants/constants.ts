export const DOCUMENT_ROLES = ['FileList', 'FilePreview', 'AISummary', 'Upload', 'Delete'];
export const NOT_AUTHORIZED_MESSAGE = 'You are not authorized to access this resource. Please contact your administrator for assistance.';
export const HOMEPAGE_LOADER_TIP = 'Please wait while we are setting up things for you.'
export const NO_DOCUMENTS_FOUND_TIP = 'You can try to upload by pressing Alt + U'
export const NO_DOCUMENTS_FOUND = 'Sorry No documents found.'
export const SYSTEM_ADMIN_ACCESS_MANAGEMENT_SUB_HEADING = 'System Admin has the authority to manage user roles and permissions, including creating, updating, and deleting users, as well as modifying their assigned roles.'
export const LOGIN_SUBHEADING = 'Sign in to your account to access the document management system and seamlessly sync with others, offering a wide range of powerful features.'
export const LOGIN_HEADING = 'Sign In to Your Account'
export const PLACEHOLDER_IMG_USER = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR-0XNyHsHLLce8OKJb4nuUcW-uZ38tcUvsJeeDZb3UnxnBl4OHCK4NdSKRvwNcshp3Xkg&usqp=CAU'
export const ERROR_HEADER = 'Error'
export const OOPS_HEADER = 'Oops'
export const SUCCESS_HEADER = 'Success'
export const ERROR_MESSAGE_FILE_PATH = 'You dont have file list permission in order to navigate to excat path of this request'
export const ERROR_CORE_SERVICE_DESC = 'We are currently experiencing issues with the core services of GenericDMS. This may affect your ability to access documents, upload files, or perform other key actions.Please be assured that our development team is actively investigating the problem to restore services as quickly as possible. In the meantime, you may experience interruptions in service.For assistance, please reach out to the Backend Development Team or your system administrator. We appreciate your patience and apologize for any inconvenience this may cause'
export const CHATROOM_DESC = "This Chat room is for users to engage in real-time discussions about documents and projects within our Document Management System. This chat room enhances collaboration and communication among team members, providing a dedicated space for users to share insights, ask questions, and exchange ideas"
export const HELPER_TEXT = "This chat room enables real-time discussions about documents and , enhancing collaboration among team members"
export const CHAT_TOKEN = '7xTq9jFr3pGzK5wQ'
export interface Document {
  name: string;
  extension: string;
  author: string;
  email: string;
  date: string
  request: {
    action: any
    name: any
    email: any
    date: any
  }
}
export interface typeDataSource {
  name: string;
  extension: string;
  author: string;
  email: string;
  date: string;
  id: string;
  requestType: string;
  requestFor: any;
  fileUrl: string;
  fileType: string;
  fileName:string
}

export interface User {
  userName: string;
  role: string;
  name: string;
  profileImg: string;
}

export const typeDocs: Document[] = [
];
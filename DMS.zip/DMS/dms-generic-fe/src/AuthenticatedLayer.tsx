import React, { useEffect } from 'react';
import {
  AuthenticatedTemplate,
  MsalProvider,
  UnauthenticatedTemplate,
  useMsal,
} from '@azure/msal-react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import LoginProgress from './Component/Modules/Chunks/LoginProgress';
import { DMSProvider } from './Redux/Store/Provider';
import { loginRequest } from './Authentication/AzureAD/Config/config';
import LayoutAdmin from './Component/Layout/Layout';
import LayoutSystemAdmin from './Component/SystemAdmin/LayoutSystemAdmin.tsx/LayoutSystemAdmin';
import { useRoles } from './Redux/Store/RolesProvider';
import { getCurrentRoleOfferings, getUserRoles, MapNewUserApi } from './ServiceUtils/Services/api';
import { Spin } from 'antd';
import { LoadingOutlined } from '@ant-design/icons';
import { PLACEHOLDER_IMG_USER } from './Constants/constants';
import { setCurrentAccessSession } from './Constants/utils';
import { AppStatusHealthRegistration } from './Component/Firewall/HealthRegistration';

const AppContent: React.FC = () => {
  const { instance } = useMsal();
  const { currentuserRole, setCurrentUserRole } = useRoles();
  const { role, setRole, setUserDetails } = useRoles();
  const { setSelectedRoles } = useRoles();
  const activeAccount = instance.getActiveAccount();
  AppStatusHealthRegistration(activeAccount, currentuserRole, role)
  const handleRedirect = () => {
    instance
      .loginRedirect({ ...loginRequest, prompt: 'create' })
      .catch((err) => console.log(err));
  };

  setCurrentAccessSession(currentuserRole, role)
  const mapNewUser = async (username: string, role: string, activeAccountUsername: string) => {
    const currentMappedUsers = await getUserRoles();
    if (Array.isArray(currentMappedUsers)) {
      const user = currentMappedUsers?.find((user) => user?.userName === activeAccountUsername);

      if (user) {
        if (user.role !== currentuserRole) {
          setCurrentUserRole(user.role);
          setUserDetails(user);
        }
        return;
      }
    }

    try {
      await MapNewUserApi(username, role, true, activeAccount?.name || '', PLACEHOLDER_IMG_USER);
      if (role !== currentuserRole) {
        setCurrentUserRole(role);
      }
    } catch (error) {
      console.error('Error mapping new user:', error);
    }
  };

  const getCurrentRolesOffering = async () => {
    const response = await getCurrentRoleOfferings();
    setSelectedRoles(response);
    if (currentuserRole === 'Admin' && role !== response?.Admin) {
      setRole(response?.Admin);
    } else if (currentuserRole === 'Approver' && role !== response?.Approver) {
      setRole(response?.Approver);
    } else if (currentuserRole === 'User' && role !== response?.User) {
      setRole(response?.User);
    }
  };
  useEffect(() => {
    if (activeAccount) {
      mapNewUser(activeAccount?.username, 'User', activeAccount?.username);
    }
    // eslint-disable-next-line
  }, [activeAccount]);
  useEffect(() => {
    if (currentuserRole) {
      getCurrentRolesOffering();
    }
    // eslint-disable-next-line
  }, [currentuserRole]);
  const getLayoutComponent = () => {
    if (currentuserRole === 'System Admin') {
      return <LayoutSystemAdmin />;
    } else{
      return <LayoutAdmin />;
    }
  };

  return (
    <>
      <AuthenticatedTemplate>
        <Spin spinning={currentuserRole === ''} fullscreen tip="Please wait while we are setting up things for you." indicator={<LoadingOutlined className='text-white' />} />
        <DMSProvider>
          <BrowserRouter>
            <Routes>
              {['/', '/:geo', '/:geo/:year', '/:geo/:year/:month', '/:geo/:year/:month/:empId'].map((path) => (
                <Route key={path} path={path} element={getLayoutComponent()} />
              ))}
            </Routes>
          </BrowserRouter>
        </DMSProvider>
      </AuthenticatedTemplate>
      <UnauthenticatedTemplate>
        <LoginProgress handleLogin={handleRedirect} />
      </UnauthenticatedTemplate>
    </>
  );
};

interface AppProps {
  instance: any;
}

const App: React.FC<AppProps> = ({ instance }) => (
  <MsalProvider instance={instance}>
    <AppContent />
  </MsalProvider>
);

export default App;

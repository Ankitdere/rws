import AWS from '../../Assets/Svgs/aws.png'
export default function LogoAWS() {
  return (
    <img src={AWS} alt='AWS' className='h-6 flex flex-wrap' />
  )
}

import { Col, Card, Radio, Alert } from "antd";
import { useState } from "react";
import { storageOptions } from "./StorageOptions";

export default function ConfigureStorage() {
    const [selectedStorage, setSelectedStorage] = useState<string>("Amazon S3");
    const handleStorageSelect = (value: string) => {
        setSelectedStorage(value);
    };

    return (
        <div>
            <Alert message="Select your preferred storage system for managing and storing files within the DMS" type="info" showIcon  className="bg-none my-2"/>
            <div className="flex flex-wrap gap-4">
                {storageOptions.map((storage) => (
                    <Col span={10} key={storage.key} onClick={() => handleStorageSelect(storage.key)} className={`hover:cursor-pointer rounded-lg shadow-sm transition hover:scale-105 hover:z-5 hover:shadow-2xl hover:shadow-[#FCE4EC] animate-fade`}>
                        <Card title={storage.title} bordered={false}>
                            <p className="flex flex-wrap"><img alt={storage.title} src={storage.imageUrl} className="m-1 h-10" />{storage.description}</p>
                            <div className="mt-5 flex justify-between">
                                <Radio
                                    checked={selectedStorage === storage.key}
                                    onChange={() => handleStorageSelect(storage.key)}
                                />
                            </div>
                        </Card>
                    </Col>
                ))}
            </div>
        </div>
    );
}

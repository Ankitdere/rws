export const storageOptions = [
    {
        key: "Amazon S3",
        title: "Amazon S3",
        background:'#FF9900',
        imageUrl:'https://static-00.iconduck.com/assets.00/aws-color-icon-1024x614-w77sz7xw.png',
        description:
            "Amazon S3 (Simple Storage Service) is a scalable object storage service used for storing and retrieving any amount of data at any time. It's highly durable, offers flexible storage management, and provides features like access control, data encryption, and event notifications.",
    },
    {
        key: "Microsoft Azure",
        title: "Microsoft Azure Blob Storage",
        background:'#0039A9',
        imageUrl:'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Microsoft_Azure.svg/1200px-Microsoft_Azure.svg.png',
        description:
            "Azure Blob Storage is Microsoft's object storage solution for the cloud. Optimized for storing massive amounts of unstructured data, it is ideal for serving images, documents, video, and backup. Azure Blob also provides integration with other Azure services, supports lifecycle management, and offers access tiers for cost optimization.",
    },
    {
        key: "Google Cloud",
        title: "Google Cloud Storage",
        background:'#EA4335',
        imageUrl:'https://seeklogo.com/images/G/google-cloud-logo-ADE788217F-seeklogo.com.png',
        description:
            "Google Cloud Storage is a secure, scalable, and durable object storage service. It is designed for performance and reliability, providing features like regional and multi-regional storage, versioning, and lifecycle management. It integrates seamlessly with other Google Cloud services and supports a variety of access controls and encryption options.",
    },
];
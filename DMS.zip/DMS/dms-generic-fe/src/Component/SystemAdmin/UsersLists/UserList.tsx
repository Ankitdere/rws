import { Button, Divider, Select, Table, Input, Drawer, Avatar, Spin } from "antd";
import { LoadingOutlined, PlusOutlined, SearchOutlined } from "@ant-design/icons";
import Paragraph from "antd/es/typography/Paragraph";
import { useState, useEffect, Fragment } from "react";
import DrawerNew from "./DrawerNew";
import { SYSTEM_ADMIN_ACCESS_MANAGEMENT_SUB_HEADING } from "../../../Constants/constants";
import { getUserRoles, MapNewUserApi } from "../../../ServiceUtils/Services/api";


interface User {
  key: string;
  userName: string;
  role: string;
  name: string;
  profileImg: string;
}

export default function UserList() {
  const [users, setUsers] = useState<User[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<User[]>([]);
  const [searchText, setSearchText] = useState("");
  const [selectedRole, setSelectedRole] = useState("");
  const [tableStyle, setTableStyle] = useState({});
  const [loading, setLoading] = useState<boolean>(true);
  const [loadingRoles, setLoadingRoles] = useState<{ [key: string]: boolean }>({});

  const handleRoleChange = async (userName: string, role: string, name: string, profileImg: string) => {
    setLoadingRoles((prev) => ({ ...prev, [userName]: true }));

    try {
      await MapNewUserApi(userName, role, false, name, profileImg);
      await fetchUserRoles();
    } catch (error) {
      console.error("Error updating role:", error);
    } finally {
      setLoadingRoles((prev) => ({ ...prev, [userName]: false }));
    }
  };

  const fetchUserRoles = async () => {
    setLoading(true);
    const response = await getUserRoles();
    const fetchedUsers = response.map((user: any) => ({ ...user, key: user.userName }));
    setUsers(fetchedUsers);
    setFilteredUsers(fetchedUsers);
    setLoading(false);
  };

  const handleResize = () => {
    if (window.innerWidth < 512) {
      setTableStyle({ maxWidth: "180px", overflowX: "auto" });
    } else {
      setTableStyle({});
    }
  };

  useEffect(() => {
    handleResize();
    fetchUserRoles();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
    // eslint-disable-next-line
  }, []);

  const filterUsers = () => {
    let filtered = users;

    if (searchText) {
      filtered = filtered.filter(user =>
        user.userName.toLowerCase().includes(searchText.toLowerCase())
      );
    }

    if (selectedRole) {
      filtered = filtered.filter(user => user.role === selectedRole);
    }

    setFilteredUsers(filtered);
  };

  useEffect(() => {
    filterUsers();
    // eslint-disable-next-line
  }, [searchText, selectedRole]);

  const columns = [
    {
      title: <div className="flex flex-wrap gap-2">
        <p>Users</p>
        <p className="bg-blue-100 rounded-full px-2 text-blue-500">{users?.length}</p>
      </div>,
      dataIndex: "userName",
      key: "userName",
      render: (text: string, record: User) => (
        <div className="flex flex-wrap gap-2">
          <Avatar size={"small"} className="hover:cursor-pointer" src={record?.profileImg} />
          <p>{text || ''}</p>
        </div>
      ),
    },
    {
      title: "Role",
      dataIndex: "role",
      key: "role",
      render: (text: string, record: User) => (
        loadingRoles[record.userName] ? (
          <Spin indicator={<LoadingOutlined />} />
        ) : (
          <Select
            value={record?.role}
            onChange={(newRole) => handleRoleChange(record?.key, newRole, record?.name, record?.profileImg)}
            style={{ width: 120 }}
          >
            <Select.Option value="System Admin">System Admin</Select.Option>
            <Select.Option value="User">User</Select.Option>
            <Select.Option value="Admin">Admin</Select.Option>
            <Select.Option value="Approver">Approver</Select.Option>
          </Select>
        )
      ),
    }
  ];

  const [open, setOpen] = useState(false);

  const showDrawer = () => {
    setOpen(true);
  };

  const onClose = () => {
    setOpen(false);
  };

  return (
    <Fragment>
      <p className="text-[34px] mb-1 animate-fade">Assigned Roles</p>
      <Paragraph className="text-[15px] text-[#616161]">
        {SYSTEM_ADMIN_ACCESS_MANAGEMENT_SUB_HEADING}
      </Paragraph>
      <Divider />
      <div className="flex flex-wrap gap-4 justify-between py-2 px-2 my-1 rounded-lg bg-[#ECEFF1] px-auto mx-auto ">
        <div className="flex flex-wrap gap-4">
          <Input
            placeholder="Search User"
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            prefix={<SearchOutlined className="text-[#212121]" />}
            className="bg-white text-[#212121]"
            style={{ width: 200 }}
          />
          <Select
            placeholder="Filter by role"
            value={selectedRole}
            onChange={(value) => setSelectedRole(value)}
            style={{ width: 150 }}
          >
            <Select.Option value="">All Roles</Select.Option>
            <Select.Option value="System Admin">System Admin</Select.Option>
            <Select.Option value="User">User</Select.Option>
            <Select.Option value="Admin">Admin</Select.Option>
            <Select.Option value="Approver">Approver</Select.Option>
          </Select>
        </div>
        <Button
          icon={<PlusOutlined />}
          onClick={showDrawer}
          className="my-auto bg-rws text-white border-none hover:scale-105 hover:z-10 font-semibold"
        >
          Add New User
        </Button>
      </div>

      <div className="rounded-lg shadow-md animate-fade">
        <div className="rounded-tr-lg rounded-tl-lg text-white flex flex-wrap justify-between gap-4">
          <Drawer
            title="Add New User"
            placement={'right'}
            closable={false}
            onClose={onClose}
            open={open}
          >
            <DrawerNew />
          </Drawer>
        </div>
        {loading ? (
          <div className="flex justify-center items-center py-10">
            <Spin size="large" indicator={<LoadingOutlined />} />
          </div>
        ) : (
          <Table
            className="truncate"
            columns={columns}
            dataSource={filteredUsers}
            pagination={{ pageSize: 10,showSizeChanger:false}} 
            style={tableStyle}
          />
        )}
      </div>
    </Fragment>
  );
}

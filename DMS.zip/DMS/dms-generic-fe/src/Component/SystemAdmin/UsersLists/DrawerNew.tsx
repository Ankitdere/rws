import { useState } from 'react';
import { Button, Form, Input, Select, Space } from 'antd';
import { PLACEHOLDER_IMG_USER } from '../../../Constants/constants';
import { MapNewUserApi } from '../../../ServiceUtils/Services/api';

const { Option } = Select;

export default function DrawerNew() {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);

  const onFinish = async (values: any) => {
    const { name, username, role } = values;
    setLoading(true);
    try {
      await MapNewUserApi(username, role, true, name,PLACEHOLDER_IMG_USER);
    } catch (error) {
      console.log(error)
    } finally {
      setLoading(false);
    }
  };

  const onReset = () => {
    form.resetFields();
  };

  return (
    <Form
      form={form}
      name="create-user"
      onFinish={onFinish}
      style={{ maxWidth: 600 }}
    >
      <Form.Item
        name="name"
        label="Name"
        rules={[{ required: true, message: 'Please enter the name' }]}
      >
        <Input placeholder="Enter Name" type='name'/>
      </Form.Item>
      <Form.Item
        name="username"
        label="Username"
        rules={[{ required: true, message: 'Please enter the username' }]}
      >
        <Input placeholder="Enter username" type='email'/>
      </Form.Item>

      <Form.Item
        name="role"
        label="Role"
        rules={[{ required: true, message: 'Please select a role' }]}
      >
        <Select placeholder="Select a role">
          <Option value="System Admin">System Admin</Option>
          <Option value="User">User</Option>
          <Option value="Admin">Admin</Option>
          <Option value="Approver">Approver</Option>
        </Select>
      </Form.Item>

      <Form.Item>
        <Space>
          <Button className='bg-rws text-white font-semibold' htmlType="submit" loading={loading}>
            Create New User
          </Button>
          <Button htmlType="button" className='font-semibold' onClick={onReset}>
            Reset
          </Button>
        </Space>
      </Form.Item>
    </Form>
  );
}

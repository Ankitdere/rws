import { useDMSHooks } from '../../../Redux/Store/Provider';
import { useEffect } from 'react';
import { useMsal } from '@azure/msal-react';
import { CaretDownOutlined } from '@ant-design/icons';
import { Popover } from 'antd';
import UserDetails from '../../Navbar/UserPopoverContent/UserDetails';
import { useRoles } from '../../../Redux/Store/RolesProvider';

export const NavbarSystemAdmin = () => {
  const { email, setEmail } = useDMSHooks();
  const { instance } = useMsal();
  const {userDetails} = useRoles()
  const activeAccount = instance.getActiveAccount();
  
  useEffect(() => {
    setEmail(activeAccount?.username || '');
    //eslint-disable-next-line
  }, [email, activeAccount?.username]);


  return (
    <div className='bg-rws flex justify-end p-1'>
      <div className='flex flex-wrap'>
        <Popover content={<UserDetails ImageUrl={userDetails?.profileImg}/>} title={`Hi, ${activeAccount?.name}`} trigger="click">
          <div className={`flex gap-1 cursor-pointer mr-3 px-2 rounded-lg hover:shadow-lg`}>
            <div className={`rounded-md px-3 py-1 text-[12px] py-auto  font-semibold  my-auto bg-transparent text-white cursor-pointer `}>
              {activeAccount?.name}
            </div>
            <CaretDownOutlined className='text-white' />
          </div>
        </Popover>
      </div>
    </div>
  );
};


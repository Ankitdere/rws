import { Checkbox, Col, Divider, Button } from "antd";
import Paragraph from "antd/es/typography/Paragraph";
import { useRoles } from "../../../Redux/Store/RolesProvider";
import { updateRoles } from "../../../ServiceUtils/Services/api";

type RoleGroup = 'User' | 'Admin' | 'Approver';

export default function Roles() {
    const { selectedRoles, setSelectedRoles } = useRoles();
    const options = ["Upload", "Delete", "FileList", "FilePreview", "AISummary", "Approve", "Reject", "Download", "Logs", "Chat"];
    const dependentOptions = ["Upload", "Delete", "FilePreview", "AISummary", "Download"];

    const handleChange = (roleGroup: RoleGroup, checkedValues: any) => {
        if (!checkedValues.includes("FileList")) {
            checkedValues = checkedValues.filter((option: string) => !dependentOptions.includes(option));
        }
        setSelectedRoles((prevRoles) => ({
            ...prevRoles,
            [roleGroup]: checkedValues
        }));
    };

    const handleSubmit = async () => {
        await updateRoles(selectedRoles);
    };

    const isFileListSelected = (roleGroup: RoleGroup) => {
        return selectedRoles[roleGroup]?.includes("FileList");
    };

    return (
        <div className="p-3 border rounded-lg shadow-md animate-fade">
            <div className="flex flex-wrap gap-2">
                <div className="p-5 rounded-lg bg-[#FAFAFA]">
                    <Paragraph className='text-[20px] my-auto'>
                        User Roles
                    </Paragraph>
                    <Divider />
                    <Checkbox.Group
                        style={{ width: '100%' }}
                        className="flex flex-col"
                        value={selectedRoles.User}
                        onChange={(checkedValues) => handleChange('User', checkedValues)}
                    >
                        {options.map((option: string) => (
                            <Col key={option}>
                                <Checkbox 
                                    value={option} 
                                    className="p-1" 
                                    disabled={dependentOptions.includes(option) && !isFileListSelected('User')}
                                >
                                    {option}
                                </Checkbox>
                            </Col>
                        ))}
                    </Checkbox.Group>
                </div>

                <div className="p-5 rounded-lg bg-[#FAFAFA]">
                    <Paragraph className='text-[20px] my-auto'>
                        Admin Roles
                    </Paragraph>
                    <Divider />
                    <Checkbox.Group
                        style={{ width: '100%' }}
                        className="flex flex-col"
                        value={selectedRoles.Admin}
                        onChange={(checkedValues) => handleChange('Admin', checkedValues)}
                    >
                        {options.map((option: string) => (
                            <Col span={8} key={option}>
                                <Checkbox 
                                    value={option} 
                                    className="p-1" 
                                    disabled={dependentOptions.includes(option) && !isFileListSelected('Admin')}
                                >
                                    {option}
                                </Checkbox>
                            </Col>
                        ))}
                    </Checkbox.Group>
                </div>

                <div className="p-5 rounded-lg bg-[#FAFAFA]">
                    <Paragraph className='text-[20px] my-auto'>
                        Approver Roles
                    </Paragraph>
                    <Divider />
                    <Checkbox.Group
                        style={{ width: '100%' }}
                        className="flex flex-col"
                        value={selectedRoles.Approver}
                        onChange={(checkedValues) => handleChange('Approver', checkedValues)}
                    >
                        {options.map((option: string) => (
                            <Col span={8} key={option}>
                                <Checkbox 
                                    value={option} 
                                    className="p-1" 
                                    disabled={dependentOptions.includes(option) && !isFileListSelected('Approver')}
                                >
                                    {option}
                                </Checkbox>
                            </Col>
                        ))}
                    </Checkbox.Group>
                </div>
            </div>
            <div className="mt-2">
                <Button type="primary" onClick={handleSubmit} className="w-full bg-blue-500 text-white font-semibold">
                    Apply Changes
                </Button>
            </div>
        </div>
    );
}

import React, { useEffect, useState } from 'react';
import { Layout, Tabs, theme } from 'antd';
import { NavbarSystemAdmin } from '../Navbar/NavbarSystemAdmin';
import { items } from '../Tabs/TabsLayout';

const { Content } = Layout;

const LayoutSystemAdmin: React.FC = () => {
  const [selectedKey] = useState('1');
  const {
    token: { colorBgContainer, borderRadiusLG },
  } = theme.useToken();

  const onChange = (key: string) => { };

  useEffect(() => {

  }, [selectedKey])
  return (
    <Layout>
      <Layout>
        <NavbarSystemAdmin />
        <Content style={{ margin: '24px 16px 0' }}>
          <div
            style={{
              padding: 24,
              minHeight: 360,
              background: colorBgContainer,
              borderRadius: borderRadiusLG,
            }}
          >
            <Tabs defaultActiveKey="1" items={items} onChange={onChange} className='select-none border-none' />
          </div>
        </Content>
      </Layout>
    </Layout>
  );
};

export default LayoutSystemAdmin;

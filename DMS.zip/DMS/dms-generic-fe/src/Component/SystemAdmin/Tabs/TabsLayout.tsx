import { TabsProps } from "antd";
import Roles from "../AdminRoles/Roles";
import ConfigureStorage from "../ConfigureStorage/ConfigureStorage";
import UserList from "../UsersLists/UserList";
import { DatabaseOutlined, HistoryOutlined, PullRequestOutlined, SettingOutlined, UserOutlined } from "@ant-design/icons";
import LogsList from "../../Modules/Logs/TableList/LogsList";
import Approval from "../../Modules/Workflow/Approval";

export const items: TabsProps['items'] = [
  {
    key: '1',
    label: 'Assigned Roles',
    children: <UserList />,
    icon: <UserOutlined />
  },
  {
    key: '2',
    label: 'Access Management',
    children: <Roles />,
    icon: <SettingOutlined />
  },
  {
    key: '3',
    label: 'Storage Unit',
    children: <ConfigureStorage />,
    icon:<DatabaseOutlined/>
  },
  {
    key: '4',
    label: 'All DMS Events & Actions',
    children: <LogsList />,
    icon:<HistoryOutlined/>
  },
  {
    key: '5',
    label: 'Approve & Reject',
    children: <Approval />,
    icon:<PullRequestOutlined />
  },
];
import { useNotification } from '../../../Redux/Store/NotificationProvider';
import success from '../../../Assets/Svgs/success.svg';
import error from '../../../Assets/Svgs/error.svg';
import { useEffect, useRef } from 'react';
import beepSound from '../../../Assets/audio/beep.wav';

export default function NotificationPop() {
    const { notification } = useNotification();
    const audioRef = useRef(new Audio(beepSound));

    useEffect(() => {
        if (notification?.isActive) {
            audioRef.current.play();
        }
    }, [notification?.isActive]);

    return (
        <div className={`absolute top-[40px] left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-50 transition-all duration-700 ease-[cubic-bezier(0.32, 0.7, 0.22, 1.2)]`}>
            <div
                className={`min-h-12 p-2 rounded-full transition-all duration-700 ease-[cubic-bezier(0.32, 0.7, 0.22, 1.2)] ${notification.isActive ? `min-h-12 bg-[#263238] !backdrop-blur-xl shadow-2xl ${notification.type === 1 ? 'shadow-[#81C784]' : 'shadow-[#E57373]'}` : 'bg-transparent'}`}
                style={{ width: '330px !important' }}
            >
                <div className={`flex px-2 items-center justify-between gap-2 transition-all duration-700 ease-[cubic-bezier(0.32, 0.7, 0.22, 1.2)] ${notification.isActive ? 'opacity-100 blur-0 scale-100' : 'opacity-0 blur-lg scale-50 pointer-events-none'}`}>
                    <div className="flex items-center gap-2 my-auto">
                        <div className=''>
                            <img src={notification.type === 1 ? success : error} alt="Notification" className="h-8 rounded-full shadow-2xl" />
                        </div>
                        <div className="description shadow-2xl">
                            <div className="text-xs text-green-500">{notification.submessage}</div>
                            <div className="text-xs text-white">{notification.title}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

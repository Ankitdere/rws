import { useEffect, useState } from 'react';
import { AppstoreOutlined, DeleteOutlined, DownloadOutlined, LoadingOutlined, QuestionCircleOutlined, UnorderedListOutlined } from '@ant-design/icons';
import { Button, Divider, Dropdown, Menu, Popconfirm, Spin, Tooltip, Typography } from 'antd';
import { useDMSHooks } from '../../../Redux/Store/Provider';
import NoFiles from '../Chunks/NoFiles';
import { getIcon } from '../../../Constants/Functions/fileIcon';
import { CHAT_TOKEN, Document } from '../../../Constants/constants';
import { deleteFiles, downloadFiles, getDocuments } from '../../../ServiceUtils/Services/api';
import { useLocation, useNavigate } from 'react-router-dom';
import FilePreviewModal from '../Chunks/FilePreviewModal';
import { DMSFilePreview } from '../Chunks/ContextStoreFilePreview/ContextStoreModel';
import CreateModal from '../Chunks/CreateUpload/CreateModal';
import BreadCrumbs from '../Chunks/BreadCrumbs/BreadCrumbs';
import ListViewFragments from '../Chunks/ListViewFragments/ListView';
import { getMenuItems } from '../../../Constants/Functions/ContextMenu';
import { useRoles } from '../../../Redux/Store/RolesProvider';
import { useMsal } from '@azure/msal-react';
import UserInsightsActivity from '../Chunks/ListViewFragments/UserInsightsActivity.tsx/UserInsightsActivity';
import { formatTimeAgo } from '../../../Constants/Functions/function';
import { useNotification } from '../../../Redux/Store/NotificationProvider';

const { Paragraph } = Typography;

export default function Documents() {
    const navigate = useNavigate();
    const { role } = useRoles()
    const { instance } = useMsal()
    const {openNotificationPopUp} = useNotification()
    const activeAccount = instance.getActiveAccount();
    const location = useLocation();
    const { email, docs, setDocs, setFullDocs, viewMode, setViewMode, refresh } = useDMSHooks();
    const [loading, setLoading] = useState(false);
    const [DownloadLoading, setDownloadLoading] = useState(false);
    const [LoadingDocument, SetLoadingDocument] = useState(true);
    const [selectedDocs, setSelectedDocs] = useState<Document[]>([]);
    const [open, setOpen] = useState(false);
    const [currentDoc, setCurrentDoc] = useState<Document | null>(null);
  
    const fetchDocs = async (path: string) => {
        SetLoadingDocument(true)
        try {
            const docs = await getDocuments(path);
            setDocs(docs);
            setFullDocs(docs);
            SetLoadingDocument(false)
        } catch (error) {
            console.error('Failed to fetch documents:', error);
        } finally {
            SetLoadingDocument(false);
        }
    };

    useEffect(() => {
        if(location?.pathname?.includes(CHAT_TOKEN)){
            navigate('/', {replace:true})
        }
        setDocs([])
        setFullDocs([])
        setSelectedDocs([]);
        fetchDocs(location.pathname);
        // eslint-disable-next-line
    }, [email, location.pathname, open, refresh]);

    const handleDocClisck = (doc: Document) => {
        setSelectedDocs((prevSelectedDocs) =>
            prevSelectedDocs.includes(doc)
                ? prevSelectedDocs.filter((item) => item !== doc)
                : [...prevSelectedDocs, doc]
        );
    };

    const handleDeleteSelected = async (docsToDelete: Document[] = selectedDocs) => {
        setLoading(true);
        try {
            const filesToDelete = docsToDelete.map((doc) => ({
                fileName: doc.name,
                path: location.pathname,
            }));

            const deleteResponse = await deleteFiles(filesToDelete, activeAccount?.username || '', activeAccount?.name || '');

            if (deleteResponse) {
                openNotificationPopUp("Deletion request submitted successfully.", "File Deletion", 3000, 1);
                // openNotification(
                //     'File Deletion Request Submitted',
                //     'Your request for deleting the selected file(s) has been submitted successfully.',
                //     2,
                //     <DeleteOutlined className='text-green-500' />,
                //     'success'
                // );
                setDocs((prevDocs) => prevDocs.filter((doc) => !docsToDelete.includes(doc)));
                setFullDocs((prevDocs) => prevDocs.filter((doc) => !docsToDelete.includes(doc)));
                setSelectedDocs([]);
            } else {
                openNotificationPopUp("Failed to initiate the file deletion request", "File Deletion failed", 3000, 2);
                // openNotification(
                //     'File Deletion Failed',
                //     'Failed to initiate the file deletion request. Please try again.',
                //     2,
                //     <DeleteOutlined className='text-red-500' />,
                //     'error'
                // );
                console.error('Failed to initiate the file deletion request!');
            }
        } catch (error) {
            // openNotification(
            //     'File Deletion Failed',
            //     'An error occurred while attempting to delete the file(s). Please try again.',
            //     2,
            //     <DeleteOutlined className='text-red-500' />,
            //     'error'
            // );
            openNotificationPopUp("Failed to initiate the file deletion request", "File Deletion failed", 3000, 2);
            console.error('Failed to initiate the file deletion request!', error);
        } finally {
            setLoading(false);
        }
    };

    const handleDownloadSelected = async (docsToDownload: Document[] = selectedDocs) => {
        setDownloadLoading(true)
        try {
            if (docsToDownload.length > 0) {
                const path = location.pathname.startsWith('/') ? location.pathname.slice(1) : location.pathname;
                const filesToDownload = docsToDownload.map(doc => ({
                    fileName: doc.name,
                    path: path,
                     type:doc.extension === "folder" ? "folder" : "file"
                }));
    
                const response = await downloadFiles(filesToDownload);
                if (response) {
                    openNotificationPopUp("Your file has been downloaded successfully.", "Download Successful", 3000, 1);
                    // openNotification('Download Successful', 'Your file has been downloaded successfully.', 2, <DownloadOutlined className='text-green-500' />, 'success')
                } else {
                    openNotificationPopUp("An error occurred while downloading the file. Please try again.", "Download Failed", 3000, 2);
                    // openNotification('Download Failed', 'An error occurred while downloading the file. Please try again.', 2, <DownloadOutlined className='text-red-500' />, 'error');
                }
                setDownloadLoading(false)
            } else {
                openNotificationPopUp("Please select at least one file to download.", "Oops", 3000, 2);
                // openNotification('Oops', 'Please select at least one file to download.', 2, <DownloadOutlined className='text-red-500' />, 'warning');
            }
        } catch (error) {
            openNotificationPopUp(`System Error ${error}.`, "Download Failed'", 3000, 2);
            // openNotification('Download Failed', `System Error ${error}.`, 2, <DownloadOutlined className='text-red-500' />, 'error');
            setDownloadLoading(false)
        }finally {
            setLoading(false);
            setDownloadLoading(false)
        }
    };


    const toggleViewMode = () => {
        setViewMode((prevMode) => (prevMode === 'grid' ? 'list' : 'grid'));
    };

    const handleNextTab = (item: Document) => {
        SetLoadingDocument(true);
        setDocs([]);
        setFullDocs([]);
        if (item.extension === 'folder') {
            setDocs([]);
            setFullDocs([]);
            navigate(item.name);
            SetLoadingDocument(true);
        } else {
            setCurrentDoc(item);
            setOpen(true);
        }
    };

    const handleMenuClick = (key: string, item: Document) => {
        if (key === '1') {
            handleNextTab(item);
        } else if (key === '2') {
            handleDeleteSelected([item]);
        } else if (key === '3') {
            handleDocClisck(item);
        } else if (key === '4') {
            handleDownloadSelected([item])
        }
    };
    return (
        <div className='animate-fade'>
            <BreadCrumbs />
            <div>
                <div className='flex flex-wrap' style={{ justifyContent: 'space-between' }}>
                    <div className='flex flex-wrap gap-2'>
                        <div className=''>
                            <Paragraph className='text-[24px] my-auto select-none'>
                                {'Your Files'}
                            </Paragraph>
                            {docs?.length > 0 ? null : (
                                <>
                                    {docs?.length === 0 ? null : (
                                        <Spin className='my-auto' indicator={<LoadingOutlined spin />} />
                                    )}
                                </>
                            )}
                        </div>
                        <div className='my-auto flex'>
                            {selectedDocs?.length > 1 && role?.includes('Delete') && (
                                <p className='bg-[#2196F3] rounded-full text-[10px] my-auto p-2 px-3 text-white font-bold'>
                                    {selectedDocs?.length}
                                </p>
                            )}
                            {selectedDocs?.length > 1 && role?.includes('Delete') && (
                                    <Popconfirm
                                        title="Delete"
                                        description="Are you sure to delete these files?"
                                        onConfirm={() => handleDeleteSelected(selectedDocs)}
                                        okText="Yes"
                                        icon={<QuestionCircleOutlined style={{ color: 'red' }} />}
                                        cancelText="No"
                                    >
                                        <Button  className='ml-3 text-[#212121] hover:border-red-300 hover:shadow-md hover:shadow-red-30 font-semibold bg-white hover:text-red-500' loading={loading} icon={<DeleteOutlined />}>
                                            Delete All
                                        </Button>
                                    </Popconfirm>
                            )}
                            {selectedDocs?.length > 1 && role?.includes('Download') && (
                                    <Button 
                                    className='ml-3 text-[#212121] hover:border-green-300 hover:shadow-md hover:shadow-green-30 font-semibold bg-white hover:text-green-500' loading={DownloadLoading}
                                        onClick={() => handleDownloadSelected(selectedDocs)}
                                        icon={<DownloadOutlined />}
                                    >
                                        Download All
                                    </Button>
                            )}
                        </div>
                    </div>
                    <div className='Search&GridList'>
                        <div className='flex flex-wrap my-auto'>
                            <CreateModal />
                            <Button onClick={toggleViewMode} icon={viewMode === 'grid' ? <UnorderedListOutlined /> : <AppstoreOutlined />}>
                                {viewMode === 'grid' ? 'List View' : 'Grid View'}
                            </Button>
                        </div>
                    </div>
                </div>
            </div>
            <Divider />
            {docs?.length > 0 ? (
                viewMode === 'grid' ? (
                    <div className={'grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-3 gap-4'}>
                        {docs?.map((item, index) => (
                            <Dropdown key={index} overlay={<Menu items={getMenuItems(item, role?.includes('Delete'), role?.includes('Download'))} onClick={({ key }) => handleMenuClick(key, item)} />} trigger={['contextMenu']}>
                                <div
                                    key={index}
                                    className={`border p-2 rounded-lg select-none cursor-pointer ${viewMode === 'grid' ? (selectedDocs?.includes(item) ? 'border-2 border-[#2196F3]' : '') : ''
                                        } ${viewMode === 'grid' ? 'hover:scale-13 transition hover:z-50' : ''} animate-fade`}
                                    onClick={() => handleDocClisck(item)}
                                    onDoubleClick={() => handleNextTab(item)}
                                >
                                    {getIcon(item.extension, 'h-12', item?.name)}
                                    {/* @ts-ignore */}
                                    <p className={`flex flex-wrap gap-1font-semibold mt-2 ${viewMode === 'list' ? 'text-sm' : 'text-xs'} truncate hover:whitespace-normal hover:overflow-visible hover:truncate select-none`}>
                                        {item?.name} {item?.request && 
                                        <Tooltip title={<p>Delete Request is raised for this by <UserInsightsActivity record={item?.request}/> - {formatTimeAgo(item?.request?.date)}</p>} overlayClassName='text-[12px] rounded-lg font-semibold  bg-white' color='white' overlayInnerStyle={{ color: 'black' }} placement='bottomLeft'>

                                        <p className='bg-red-500 h-2 ml-1 w-2 my-auto rounded-full'></p>
                                        </Tooltip>}
                                    </p>
                                </div>
                            </Dropdown>
                        ))}
                    </div>
                ) : (
                    <ListViewFragments
                        docs={docs}
                        handleMenuClick={handleMenuClick}
                        selectedDocs={selectedDocs}
                        setSelectedDocs={setSelectedDocs}
                        handleDeleteSelected={handleDeleteSelected}
                        handleDownloadSelected={handleDownloadSelected}
                        setDocs={setDocs}
                        setFullDocs={setFullDocs}
                        viewMode="list"
                        handleNextTab={handleNextTab}
                    />
                )
            ) : (
                <>{LoadingDocument ? <div className='mt-5'><Spin indicator={<LoadingOutlined spin />}></Spin></div> : <NoFiles />}</>
            )}
            {currentDoc && (
                <DMSFilePreview>
                    <FilePreviewModal item={currentDoc} open={open} setOpen={setOpen} />
                </DMSFilePreview>
            )}
        </div>
    );
}

import { UserOutlined } from "@ant-design/icons";
import { Avatar } from "antd";

export default function UserInfo() {
    return (
        <div>
            <div className='flex justify-center mt-4'>
                <Avatar size={64} icon={<UserOutlined />} />
            </div>
            <div className='flex justify-center mt-5'>
                <p>User</p>
            </div>
        </div>
    )
}

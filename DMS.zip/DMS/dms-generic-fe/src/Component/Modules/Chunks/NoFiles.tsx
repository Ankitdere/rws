import { FileUnknownTwoTone } from '@ant-design/icons'
import { NO_DOCUMENTS_FOUND, NO_DOCUMENTS_FOUND_TIP } from '../../../Constants/constants'

export default function NoFiles() {
    return (
        <div className='flex justify-center my-10'>
            <div className='text-center'>
                <FileUnknownTwoTone className='text-[52px] my-5' />
                <div>{NO_DOCUMENTS_FOUND}</div>
                <div >{NO_DOCUMENTS_FOUND_TIP}</div>
            </div>
        </div>
    )
}

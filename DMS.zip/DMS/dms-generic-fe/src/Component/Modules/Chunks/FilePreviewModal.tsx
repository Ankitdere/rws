import { Modal, Tabs, TabsProps, Tooltip } from "antd";
import ChatBox from "./AI/ChatBox";
import { useState, useEffect, Fragment } from "react";
import FileDetails from "./Details/FileDetails";
import { getTextContentDocument } from "../../../ServiceUtils/Services/api";
import { useDMSHookFilePreview } from "./ContextStoreFilePreview/ContextStoreModel";
import { EyeOutlined, RobotOutlined } from "@ant-design/icons";
import { useRoles } from "../../../Redux/Store/RolesProvider";
import AccessWarning from "./AccessWarnings/AccessWarning";
import { NOT_AUTHORIZED_MESSAGE } from "../../../Constants/constants";

export default function FilePreviewModal({ item, open, setOpen }: { item: any, open: boolean, setOpen: (open: boolean) => void }) {
    const [fileUrlValid, setFileUrlValid] = useState<boolean | null>(null);
    const { setDocContentText } = useDMSHookFilePreview();
    const { setAiResponse } = useDMSHookFilePreview();
    const { role, currentuserRole } = useRoles();
    const fetchTextContent = async (url: any) => {
        const textContent = await getTextContentDocument(url);
        setDocContentText(textContent);
    };

    useEffect(() => {
        if (item?.fileUrl) {
            fetch(item.fileUrl)
                .then(response => {
                    if (response.ok) {
                        setFileUrlValid(true);
                    } else {
                        setFileUrlValid(false);
                    }
                })
                .catch(() => setFileUrlValid(false));
        }
        fetchTextContent(item?.fileUrl);
        //eslint-disable-next-line
    }, [item?.fileUrl]);

    const getPreviewUrl = (url: string, extension: string) => {
        const supportedExtensions = ['xlsx', 'csv', 'docx'];
        if (supportedExtensions.includes(extension)) {
            return `https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(url)}`;
        }
        return url;
    };

    const fileExtension = item?.fileUrl?.split('.').pop().toLowerCase();
    const unsupportedExtensions = ['jpg', 'png', 'jpeg', 'mp3', 'mp4', 'avi', 'mov'];

    const onChange = (key: string) => {
        console.log(key);
    };

    const items: TabsProps['items'] = [
        {
            key: '1',
            label: <Tooltip title={role?.includes('FilePreview') ? "" : NOT_AUTHORIZED_MESSAGE}>
                      <span>Preview</span>
                   </Tooltip>,
            disabled: !role?.includes('FilePreview'),
            icon: <EyeOutlined />,
            children: <div className="rounded-lg m-1">
                {role?.includes('FilePreview') ? <iframe
                    src={fileUrlValid !== null ? getPreviewUrl(item.fileUrl, fileExtension) : ''}
                    width="100%"
                    height="500px"
                    title={item?.name}
                ></iframe> : <AccessWarning CurrentUserRole={currentuserRole} Message="Preview File" />}
            </div>,
        },
        {
            key: '2',
            label: <Tooltip title="View the file details">
                      <span>File Details</span>
                   </Tooltip>,
            children: <FileDetails item={item} />,
        },
        ...(unsupportedExtensions.includes(fileExtension) ? [] : [{
            key: '3',
            label: <Tooltip title={role?.includes('AISummary') ? "" : NOT_AUTHORIZED_MESSAGE}>
                      <span>AI Summary</span>
                   </Tooltip>,
            icon: <RobotOutlined />,
            disabled: !role?.includes('AISummary'),
            children: <Fragment>
                {role?.includes('AISummary') ? <ChatBox item={item} /> : <AccessWarning CurrentUserRole={currentuserRole} Message="View Summary using AI" />}
            </Fragment>,
        }]),
    ];

    const handleCancel = () => {
        setOpen(false);
        setAiResponse('');
    };

    return (
        <Modal
            title={item?.name}
            closeIcon
            centered
            open={open}
            cancelButtonProps={{ style: { display: "none" } }}
            onCancel={handleCancel}
            width={800}
            okButtonProps={{ style: { display: "none" } }}
        >
            <div className="">
                <Tabs defaultActiveKey="1" items={items} onChange={onChange} />
            </div>
        </Modal>
    );
}

import { Button } from 'antd'
import LOGO from '../../../Assets/DMS_Logo/Logo.png'
import { LoginOutlined } from '@ant-design/icons'
import Title from 'antd/es/typography/Title'
import { LOGIN_HEADING, LOGIN_SUBHEADING } from '../../../Constants/constants'

export default function LoginProgress({ handleLogin }: { handleLogin: () => void }) {
  return (
    <div className='m-10 flex justify-center'>
      <div >
        <div className='flex justify-center max-w-[300px]'>
          <div>
            <img alt="logo" src={LOGO} className='my-2'/>
            <Title level={2} >{LOGIN_HEADING}</Title>
            <p>{LOGIN_SUBHEADING}</p>
          </div>
        </div>
        <div className='flex gap-2 mt-4'>
          <Button
            onClick={handleLogin}
            className="w-full flex items-center justify-center space-x-2 bg-[#0078d4] hover:bg-[#106ebe] text-white"
          >
            <LoginOutlined className="w-5 h-5 my-auto py-auto" />
            <span>Sign in with Azure AD</span>
          </Button>
        </div>
      </div>
    </div>
  )
}

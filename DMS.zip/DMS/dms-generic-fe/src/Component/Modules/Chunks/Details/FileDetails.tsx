import { Descriptions, DescriptionsProps } from "antd";

export default function FileDetails({ item }: { item: any }) {

    const items: DescriptionsProps['items'] = [
        {
            key: '1',
            label: 'File name',
            children: `${item?.name}`,
        },
        {
            key: '2',
            label: 'Author',
            children: `${item?.author}`,
        },
        {
            key: '3',
            label: 'User Email',
            children: `${item?.email}`,
        },
        {
            key: '4',
            label: 'Date',
            children: `${item?.date}`,
        }
    ];

    return (
        <div>
            <Descriptions title="" column={1} items={items} />
        </div>
    )
}

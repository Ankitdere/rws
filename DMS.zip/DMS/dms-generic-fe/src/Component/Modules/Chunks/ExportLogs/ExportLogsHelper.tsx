import React, { useState } from 'react';
import { Button } from 'antd';
import { ExportOutlined } from '@ant-design/icons';
import { notification } from 'antd';
import { ExportLogs } from '../../../../ServiceUtils/Services/api';
import { getClassNames } from '../../../../Constants/utils';

export default function ExportLogsHelper() {
    const [loading, setLoading] = useState(false);

    const handleExportLogs = async () => {
        setLoading(true);
        try {
            await ExportLogs();
            notification.success({
                icon: <ExportOutlined className="text-green-500" />,
                message: "Logs Exported Successfully",
                description: `The log export process has completed successfully, and the logs are now available for download. If you have any questions or require further assistance, please don't hesitate to reach out to our support team.`,
                className: getClassNames('success'),
                placement: 'bottomRight',
            });
        } catch (error) {
            notification.error({
                icon: <ExportOutlined className="text-red-500" />,
                message: "Error During Log Export",
                description: `An issue occurred while attempting to export the logs. Please check your internet connection or try again later. If the issue persists, contact support for assistance with the log export process.`,
                className: getClassNames('error'),
                placement: 'bottomRight',
            });
        } finally {
            setLoading(false);
        }
    };


    return (
        <div>
            <Button
                type="primary"
                icon={<ExportOutlined />}
                onClick={handleExportLogs}
                loading={loading}
                className="bg-rws text-white font-semibold"
            >
                Export Logs
            </Button>
        </div>
    );
}

import { Alert, Button } from "antd";
import TextArea from "antd/es/input/TextArea";
import Paragraph from "antd/es/typography/Paragraph";
import { useState, useEffect } from "react";
import { createFolder } from "../../../../../ServiceUtils/Services/api";
import { useDMSHooks } from "../../../../../Redux/Store/Provider";
import { useMsal } from "@azure/msal-react";
import { ERROR_HEADER, SUCCESS_HEADER } from "../../../../../Constants/constants";
import { FileOutlined } from "@ant-design/icons";

export default function FolderModelChildren({ path, cancel }: { path: string; cancel: () => void }) {
    const { docs, refresh, setRefresh } = useDMSHooks();
    const { instance } = useMsal();
    const [folderName, setFolderName] = useState('');
    const [loading, setLoading] = useState(false);
    const [nameExists, setNameExists] = useState(false);
    const activeAccount = instance.getActiveAccount();
    const { email , openNotification} = useDMSHooks();
    const author = activeAccount?.name || "Unknown";
    const date = new Date().toISOString();

    useEffect(() => {
        const exists = docs?.some(doc => doc.name.toLowerCase() === folderName.toLowerCase());
        setNameExists(exists);
    }, [folderName, docs]);

    const handleCreateFolder = async () => {
        setLoading(true);
        const response = await createFolder(folderName, path, author, date, email);
        setLoading(false);

        if (!response || response.status === 500 || response.status === 404) {
            openNotification(ERROR_HEADER, `Error while creating ${folderName || 'Folder'} in ${path || 'Here'}`, 2, <FileOutlined className="text-red-500"/>, 'error')
        } else {
            openNotification(SUCCESS_HEADER, `Succesfully created ${folderName || 'Folder'} in ${path || 'Here'}`, 2, <FileOutlined className="text-green-500"/>, 'success')
            cancel();
            setRefresh(!refresh);
        }
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === 'Enter' && !e.shiftKey && !nameExists && folderName.trim()) {
            e.preventDefault();
            handleCreateFolder();
        }
    };

    return (
        <div>
            <div className="flex mt-5 gap-2">
                <TextArea
                    placeholder="Folder Name"
                    className="my-auto"
                    autoSize
                    autoFocus
                    value={folderName}
                    onChange={(e) => {
                        const value = e.target.value;
                        if (value === "" || value.charAt(0) !== " ") {
                            setFolderName(value);
                        }
                    }}
                    onKeyDown={handleKeyDown}
                />

                <Button onClick={handleCreateFolder} loading={loading} disabled={nameExists || !folderName.trim()}>
                    Create
                </Button>
            </div>
            {nameExists && <Alert message="Name Already Exists, Please Provide a Unique Name" className="text-[12px] mt-2" type="info" />}
            <Paragraph className="flex flex-wrap font-bold mt-4">
                Current Directory - <p className="font-normal ml-2">{path}</p>
            </Paragraph>
        </div>
    );
}

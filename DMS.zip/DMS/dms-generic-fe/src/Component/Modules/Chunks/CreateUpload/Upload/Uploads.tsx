import React, { useState } from "react";
import { Button, Upload } from "antd";
import { ExclamationCircleOutlined, FileOutlined, InboxOutlined, UploadOutlined } from "@ant-design/icons";
import { useDMSHooks } from "../../../../../Redux/Store/Provider";
import { useMsal } from "@azure/msal-react";
import { uploadFile } from "../../../../../ServiceUtils/Services/api";
import { useLocation } from "react-router-dom";

const { Dragger } = Upload;

export default function Uploads({ closeModal }: { closeModal: () => void }) {
  const { instance } = useMsal();
  const { refresh, setRefresh, openNotification } = useDMSHooks();
  const location = useLocation();
  const activeAccount = instance.getActiveAccount();
  const [fileList, setFileList] = useState<any[]>([]);
  const { email } = useDMSHooks();
  const [loading, setLoading] = useState(false);

  const handleFileChange = (info: any) => {
    setFileList(info.fileList);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    if (!email) {
      openNotification(
        'Email is Missing',
        'Unable to process your request as the email is missing. Please log in again and try once more',
        2,
        <ExclamationCircleOutlined className="text-red-500"/>,
        'error'
      );
      setLoading(false);
      return;
    }

    if (fileList.length === 0) {
      openNotification(
        'Please select a File',
        'Unable to process your request please select a file and again and try once more',
        2,
        <FileOutlined className="text-red-500"/>,
        'error'
      );
      setLoading(false);
      return;
    }

    try {
      const author = activeAccount?.name || "Unknown";
      const date = new Date().toISOString();
      let allSuccess = true;

      for (let i = 0; i < fileList.length; i++) {
        const file = fileList[i].originFileObj;
        try {
          await uploadFile(file, author, date, email, location.pathname);
          openNotification(
            'Request Submitted Successfully',
            'Your request has been successfully submitted to the Approver. Once approved, your file will be uploaded to the specified path.',
            2,
            <UploadOutlined className="text-green-500"/>,
            'success'
          );
          
        } catch (error) {
          allSuccess = false;
          openNotification(
            'Request Failed',
            'Your request has failed to register. Please try again.',
            2,
            <UploadOutlined className="text-red-500"/>,
            'error'
          );
          
        }
      }

      if (allSuccess) {
        if(fileList?.length > 1){
          openNotification(
            'All Files Upload Request Submitted Successfully',
            'Your request has been successfully submitted to the Approver. Once approved, your files will be uploaded to the specified path.',
            2,
            <UploadOutlined className="text-green-500"/>,
            'success'
          );
        }
      } else {
        openNotification(
          'Request Failed for Some files',
          'Your request has failed to register. Please try again.',
          2,
          <UploadOutlined className="text-red-500"/>,
          'error'
        );
      }

      setRefresh(!refresh);
      setFileList([]);
      closeModal();
    } catch (error) {
      openNotification(
        'Network Error',
        'Your request has failed to register. Please try again.',
        2,
        <UploadOutlined className="text-red-500"/>,
        'error'
      );
    } finally {
      setLoading(false);
      setRefresh(!refresh);
    }
  };

  return (
    <>
      <form onSubmit={handleSubmit}>
        <div>
          <Dragger
            multiple
            fileList={fileList}
            onChange={handleFileChange}
            beforeUpload={() => false}
            style={{ marginBottom: "16px" }}
          >
            <p className="ant-upload-drag-icon">
              <InboxOutlined />
            </p>
            <p className="ant-upload-text">
              Click or drag file to this area to upload
            </p>
            <p className="ant-upload-hint">
              Support for a single or bulk upload. Strictly prohibited from
              uploading suspicious data.
            </p>
          </Dragger>
          <div className="flex justify-center">
            {fileList.length > 0 && (
              <Button
                type="primary"
                className="bg-[#1677FF] mt-5"
                htmlType="submit"
                loading={loading}
              >
                Submit
              </Button>
            )}
          </div>
        </div>
      </form>
    </>
  );
}

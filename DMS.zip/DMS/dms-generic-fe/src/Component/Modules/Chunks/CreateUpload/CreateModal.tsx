import { CloudSyncOutlined, PlusOutlined } from "@ant-design/icons";
import { Button, Popover, Modal, Tooltip } from "antd";
import { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import FolderModelChildren from "./Folder/FolderModelChildren";
import Uploads from "./Upload/Uploads";
import { useDMSHooks } from "../../../../Redux/Store/Provider";
import { useRoles } from "../../../../Redux/Store/RolesProvider";

export default function CreateModal() {
    const location = useLocation();
    const {role} = useRoles()
    const {setViewMode} = useDMSHooks()
    const [isCreateFolderModalVisible, setCreateFolderModalVisible] = useState(false);
    const [isUploadFileModalVisible, setUploadFileModalVisible] = useState(false);
    const [isPopoverVisible, setPopoverVisible] = useState(false);

    useEffect(() => {
        const handleKeyDown = (event: any) => {
            if (event.altKey && event.key === 'n') {
                showCreateFolderModal();
            } else if (event.altKey && event.key === 'u') {
                showUploadFileModal();
            }else if (event.altKey && event.key === 'l') {
                setViewMode('list')
            }else if (event.altKey && event.key === 'g') {
                setViewMode('grid')
            }
        };

        window.addEventListener('keydown', handleKeyDown);

        return () => {
            window.removeEventListener('keydown', handleKeyDown);
        };
        // eslint-disable-next-line
    }, [role]);

    const showCreateFolderModal = () => {
        setCreateFolderModalVisible(true);
        setPopoverVisible(false);
    };

    const showUploadFileModal = () => {
        setUploadFileModalVisible(true);
        setPopoverVisible(false);
    };

    const handleCancel = () => {
        setCreateFolderModalVisible(false);
        setUploadFileModalVisible(false);
    };

    const content = (
        <div className="flex flex-col gap-2">
            <Tooltip title={location?.pathname?.split('/')?.length >= 5 ? `You can't create Folder here you can only put up your documents here` : 'Alt + N'}>
                <Button icon={<PlusOutlined />} onClick={showCreateFolderModal} disabled={location?.pathname?.split('/')?.length >= 5 } >
                    Create Folder
                </Button>
            </Tooltip>
            <Tooltip title={!role?.includes('Upload') ? 'You dont have permission to Upload, Try to Contact Administrator' : 'Alt + U'}>
                <Button icon={<CloudSyncOutlined />} onClick={showUploadFileModal} disabled={!role?.includes('Upload')}>
                    Upload File
                </Button>
            </Tooltip>
        </div>
    );

    return (
        <>
            <Popover
                content={content}
                title="Create or Upload"
                trigger="click"
                open={isPopoverVisible}
                onOpenChange={setPopoverVisible}
                className="mr-2"
            >
                <Button icon={<PlusOutlined />}>Create</Button>
            </Popover>
            <Modal
                title="Create Folder"
                open={isCreateFolderModalVisible}
                okButtonProps={{ style: { display: "none" } }}
                onCancel={handleCancel}
                cancelButtonProps={{ style: { display: "none" } }}
            >
                <FolderModelChildren path={location.pathname} cancel={handleCancel} />
            </Modal>

            <Modal
                title="Upload File"
                open={isUploadFileModalVisible}
                okButtonProps={{ style: { display: "none" } }}
                onCancel={handleCancel}
                cancelButtonProps={{ style: { display: "none" } }}
            >
                <Uploads closeModal={handleCancel} />
            </Modal>
        </>
    );
}

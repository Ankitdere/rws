import { Popover } from 'antd';
import {  MessageTwoTone } from '@ant-design/icons';

export default function CommentBallon({ comment }: any) {
    const content = (
        <div>
            <p className='flex flex-wrap gap-1'><strong>Comment:</strong><p className='	font-style: italic'>{comment}</p></p>
        </div>
    );

    return (
        <Popover content={content} trigger="hover">
            <div className="flex items-center">
                <MessageTwoTone className='cursor-pointer hover:scale-110 hover:z-50 transition ml-1 ' />
            </div>
        </Popover>
    );
}

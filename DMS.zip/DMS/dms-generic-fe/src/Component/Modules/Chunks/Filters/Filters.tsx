import React, { useState, useEffect } from 'react';
import { Checkbox, Spin, Collapse } from 'antd';
import { FilterOutlined, LoadingOutlined } from '@ant-design/icons';
import { useDMSHooks } from '../../../../Redux/Store/Provider';

const { Panel } = Collapse;

const FilterTags: React.FC = () => {
  const { setDocs, fullDocs } = useDMSHooks();
  const [selectedKeywords, setSelectedKeywords] = useState<string[]>([]);
  const [allKeywords, setAllKeywords] = useState<string[]>([]);

  useEffect(() => {
    const keywordsSet = new Set<string>();
    fullDocs.forEach(doc => {
      (doc as any).keywords.forEach((keyword: string) => keywordsSet.add(keyword));
    });
    setAllKeywords(Array.from(keywordsSet));
  }, [fullDocs]);

  const handleCheckboxChange = (keyword: string, checked: boolean) => {
    setSelectedKeywords(prevSelectedKeywords => {
      const updatedKeywords = checked
        ? [...prevSelectedKeywords, keyword]
        : prevSelectedKeywords.filter(k => k !== keyword);

      const filteredDocs = fullDocs.filter(doc =>
        (doc as any).keywords.some((kw: string) => updatedKeywords.includes(kw))
      );

      setDocs(filteredDocs.length > 0 ? filteredDocs : fullDocs);
      return updatedKeywords;
    });
  };

  return (
    <Collapse defaultActiveKey={['1']} className="mt-1 mx-3" size='small' expandIcon={() => <FilterOutlined  />} >
      <Panel header="Categories" key="1">
        {allKeywords.length > 0 ? (
          <div className="animate-fade max-h-[400px] overflow-auto p-1  bg-white rounded-lg custom-scrollbar">
            {allKeywords.map((keyword) => (
              <div key={keyword} className="flex items-center mb-2 max-w-[200px]">
                <Checkbox
                  checked={selectedKeywords.includes(keyword)}
                  onChange={(e) => handleCheckboxChange(keyword, e.target.checked)}
                  className="w-full rounded-full"
                >
                  <span className="whitespace-normal break-words text-[12px] text-[#424242]">
                    {keyword?.replaceAll(':','')}
                  </span>
                </Checkbox>
              </div>
            ))}
          </div>
        ) : (
          <Spin indicator={<LoadingOutlined />} size="small" />
        )}
      </Panel>
    </Collapse>
  );
};

export default FilterTags;

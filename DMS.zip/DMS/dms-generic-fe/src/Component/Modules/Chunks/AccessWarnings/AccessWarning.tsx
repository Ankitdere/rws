import { Alert } from 'antd';
import React from 'react';
interface AccessWarningProps {
  CurrentUserRole: string;
  Message: string;
}
const AccessWarning: React.FC<AccessWarningProps> = ({ CurrentUserRole, Message }) => {
  return (
    <Alert message={`Sorry ${CurrentUserRole} do not have Permission to ${Message}, Please Contact your Administrator in Order to Access.`} type="info" showIcon />
  );
};

export default AccessWarning;

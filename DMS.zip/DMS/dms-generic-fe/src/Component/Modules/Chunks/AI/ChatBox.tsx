import { Spin } from "antd";
// import TextArea from "antd/es/input/TextArea";
import { useEffect } from "react";
import { useDMSHookFilePreview } from "../ContextStoreFilePreview/ContextStoreModel";
import { getAIResponse } from "../../../../ServiceUtils/Services/api";
import { LoadingOutlined } from "@ant-design/icons";

export default function ChatBox({ item }: { item: any }) {
    const { DocContentText } = useDMSHookFilePreview();
    const { AiResponse, setAiResponse } = useDMSHookFilePreview();

    // const [inputValue, setInputValue] = useState<string>("");
    // const { loading, setLoading } = useDMSHookFilePreview();
    const FetchSummary = async () => {
        const Res = await getAIResponse(DocContentText);
        setAiResponse(Res.response);
    }
    useEffect(() => {
        FetchSummary()
        // eslint-disable-next-line
    }, [DocContentText]);

    // const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    //     setInputValue(e.target.value);
    // };

    // const handleAskAiClick = async () => {
    //     if (inputValue.trim() !== "") {
    //         setLoading(true);
    //         try {
    //             const Res = await getAIResponse(inputValue, DocContentText);
    //             setAiResponse(Res.response);
    //         } catch (error) {
    //             console.error("Error asking AI:", error);
    //         } finally {
    //             setLoading(false);
    //         }
    //     }
    // };

    // const handleKeyPress = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    //     if (e.key === "Enter" && !e.shiftKey) {
    //         e.preventDefault();
    //         handleAskAiClick();
    //     }
    // };

    return (
        <div className="shadow-md shadow-[#FCE4EC] border border-[#9C27B0] p-2 m-1 p-2 rounded-lg mt-5">
            <div className="messages">
                {AiResponse === '' ? (
                    <div className="flex justify-center my-5">
                        <Spin tip="Loading AI response..." indicator={<LoadingOutlined />} />
                    </div>
                ) : (
                    <div
                        style={{ overflowY: "auto", maxHeight: "250px" }}
                        className="p-2 font-semibold rounded-lg"
                    >
                        {AiResponse?.replace(/\* \*\*/g, '').replaceAll("**", "").replaceAll("#", "")}
                    </div>
                )}
            </div>
            {/* <div className="mb-1 mt-5">
                <div className="input-container">
                    <TextArea
                        className="custom-textarea py-auto"
                        placeholder={`Ask Anything about ${item.name}`}
                        autoSize={{ minRows: 2, maxRows: 6 }}
                        value={inputValue}
                        onChange={handleInputChange}
                        onKeyPress={handleKeyPress}
                    />
                    <Button
                        className="input-button"
                        onClick={handleAskAiClick}
                        loading={loading}
                    >
                        Ask AI
                    </Button>
                </div>
            </div> */}
        </div>
    );
}

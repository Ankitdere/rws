import React, { useEffect, useState } from 'react';
import { Button, Checkbox, Dropdown, Menu, Popconfirm, Table, Tag, Tooltip } from 'antd';
import { DeleteOutlined, DownloadOutlined, ExportOutlined } from '@ant-design/icons';
import { Document } from '../../../../Constants/constants';
import { getIcon } from '../../../../Constants/Functions/fileIcon';
import { getMenuItems } from '../../../../Constants/Functions/ContextMenu';
import UserInsightsActivity from './UserInsightsActivity.tsx/UserInsightsActivity';
import { formatTimeAgo } from '../../../../Constants/Functions/function';
import { useRoles } from '../../../../Redux/Store/RolesProvider';

interface ListViewFragmentsProps {
  docs: Document[];
  selectedDocs: Document[];
  setSelectedDocs: React.Dispatch<React.SetStateAction<Document[]>>;
  handleDeleteSelected: (docsToDelete?: Document[]) => Promise<void>;
  handleDownloadSelected: (docsToDownload?: Document[]) => Promise<void>;
  setDocs: React.Dispatch<React.SetStateAction<Document[]>>;
  setFullDocs: React.Dispatch<React.SetStateAction<Document[]>>;
  viewMode: string;
  handleNextTab: (item: Document) => void;
  handleMenuClick: (key: string, item: Document) => void;
}

const ListViewFragments: React.FC<ListViewFragmentsProps> = ({
  docs,
  selectedDocs,
  setSelectedDocs,
  handleDeleteSelected,
  handleDownloadSelected,
  viewMode,
  handleNextTab,
  handleMenuClick,
}) => {
  const [isSmallScreen, setIsSmallScreen] = useState(false);
  const { role, userDetails } = useRoles()

  const [sortOrder, setSortOrder] = useState<'ascend' | 'descend' | null>(null);
  const handleSort = (order: 'ascend' | 'descend' | null) => {
    setSortOrder(order);
  };
  useEffect(() => {
    const handleResize = () => {
      setIsSmallScreen(window.innerWidth < 880);
    };
    handleResize();
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [isSmallScreen]);

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedDocs(docs);
    } else {
      setSelectedDocs([]);
    }
  };

  const handleSelectDoc = (checked: boolean, doc: Document) => {
    if (checked) {
      setSelectedDocs((prevSelectedDocs) => [...prevSelectedDocs, doc]);
    } else {
      setSelectedDocs((prevSelectedDocs) => prevSelectedDocs.filter((item) => item !== doc));
    }
  };

  const columns = [
    {
      title: (
        <Checkbox
          className='outline-none'
          checked={selectedDocs?.length === docs.length}
          indeterminate={selectedDocs?.length > 0 && selectedDocs?.length < docs?.length}
          onChange={(e) => handleSelectAll(e.target.checked)}
        />
      ),
      dataIndex: 'select',
      key: 'select',
      render: (_: any, record: Document) => (
        <Checkbox
          className='outline-none'
          checked={selectedDocs?.includes(record)}
          onChange={(e) => handleSelectDoc(e.target.checked, record)}
        />
      ),
    },
    {
      title: 'File Name',
      dataIndex: 'name',
      key: 'name',
      render: (text: string, record: Document) => (
        <Dropdown
          overlay={
            <Menu
              items={getMenuItems(record, role?.includes('Delete'), role?.includes('Download'))}
              onClick={({ key }) => handleMenuClick(key, record)}
            />
          }
          trigger={['contextMenu']}
        >
          <div className='flex flex-wrap gap-3 hover:cursor-pointer' onClick={() => handleSelectDoc(!selectedDocs?.includes(record), record)}
            onDoubleClick={() => handleNextTab(record)}>
            {getIcon(record?.extension, 'h-4', record?.name)}
            <div
              className={`cursor-pointer ${selectedDocs?.includes(record) && viewMode === 'grid' ? 'border-2 border-[#2196F3]' : ''
                } select-none`}
            >
              <span className='select-none flex'>{text}{record?.request && <p className='bg-red-500 h-2 ml-1 w-2 my-auto rounded-full'></p>}</span>
            </div>
          </div>
        </Dropdown>
      ),
    },
    {
      title: (
        <div className='select-none'>
          Modified
        </div>
      ),
      dataIndex: 'modified',
      key: 'modified',
      sorter: (a: Document, b: Document) => new Date(a.date).getTime() - new Date(b.date).getTime(),
      sortOrder: sortOrder,
      onHeaderCell: () => ({
        onClick: () => {
          const newSortOrder = sortOrder === 'ascend' ? 'descend' : 'ascend';
          handleSort(newSortOrder);
        },
      }),
      render: (_: any, record: Document) => (
        <div className='flex flex-wrap items-center gap-2'>
          <span>{record?.date ? formatTimeAgo(record?.date) : "Unknown"}</span>
        </div>
      ),
    },
    {
      title: 'Activity',
      key: 'activity',
      render: (_: any, record: Document) => (
        <div className='flex flex-wrap items-center gap-2 select-none'>
          <UserInsightsActivity record={record} />
          {record?.request ? (
            <div className='flex flex-col flex-wrap gap-1'>
              <span>Modified by {record?.author === userDetails?.name ? "You" : record?.author || 'Unknown'}</span>
            <span className='flex flex-wrap gap-1'>
            <Tag color={record?.request?.action === 'delete' ? 'red' : 'blue'}>
            {`${record?.request?.action?.charAt(0).toUpperCase()}${record?.request?.action?.slice(1)}`}
            </Tag> Request raised by <UserInsightsActivity record={record?.request} /> - {formatTimeAgo(record?.request?.date)}
            </span>
            </div>
          ) : (
            <span>Modified by {record?.author === userDetails?.name ? "You" : record?.author || 'Unknown'}</span>
          )}
        </div>
      ),
    },
    {
      title: 'Type',
      dataIndex: 'extension',
      key: 'extension',
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_: any, record: Document) => (
        <div className="flex flex-wrap">

          <Tooltip title="Open">
            <Button
              className='border-none mx-auto outline-none'
              icon={<ExportOutlined />}
              onClick={() => handleNextTab(record)}
            />
          </Tooltip>
          {role?.includes('Delete') && <Tooltip title="Raise Delete Request">
            <Popconfirm
              title="Raise Delete Request"
              description="Your Request will be sent to Approver"
              onConfirm={async () => {
                await handleDeleteSelected([record]);
              }}
              okText="Yes"
              cancelText="No"
            >
              <Button icon={<DeleteOutlined />} className='text-red-500 border-none mx-auto outline-none' />
            </Popconfirm>
          </Tooltip>}
          {role?.includes('Download') &&
            <Tooltip title="Download">
              <Button
                icon={<DownloadOutlined />}
                className='text-green-500 border-none mx-auto outline-none'
                onClick={() => handleDownloadSelected([record])}
              />
            </Tooltip>
          }
        </div>
      ),
    },
  ];

  return (
    <Table
      columns={columns}
      dataSource={docs}
      rowKey="name"
      pagination={false}
      showHeader={viewMode === 'list'}
      scroll={isSmallScreen ? { x: 'auto' } : undefined}
    />
  );
};

export default ListViewFragments;

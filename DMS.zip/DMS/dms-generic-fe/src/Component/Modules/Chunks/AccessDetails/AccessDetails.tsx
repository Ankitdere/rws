export default function AccessDetails({ role }: any) {
    return (
        <div>
            <p className="text-[12px] font-semibold">Access Granted</p>
            {role && role?.map((item: any) => {
                return (
                    <ul>
                        <li className="text-[12px]">{item}</li>
                    </ul>
                )
            })}
        </div>
    )
}

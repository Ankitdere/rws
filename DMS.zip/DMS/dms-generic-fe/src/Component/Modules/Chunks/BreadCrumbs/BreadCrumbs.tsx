import { HomeOutlined } from "@ant-design/icons";
import { Breadcrumb } from "antd";
import { useLocation, Link } from "react-router-dom";

export default function BreadCrumbs() {
  const location = useLocation();
  const pathSnippets = location?.pathname?.split('/')?.filter(i => i);
  const LastIndex = pathSnippets.length - 1;

  const breadcrumbItems = pathSnippets?.map((snippet, index) => {
    const url = `/${pathSnippets.slice(0, index + 1).join('/')}`;
    const decodedSnippet = decodeURIComponent(snippet).replace('%20', '');
    const isSecondLast = index === LastIndex;
    const linkStyle = isSecondLast ? { fontWeight: '600', color:"#212121" } : {};

    return {
      title: (
        <Link to={url} style={linkStyle}>
          {decodedSnippet}
        </Link>
      ),
    };
  });

  const items = [
    {
      title: (
        <Link to="/">
          <HomeOutlined />
        </Link>
      ),
    },
    ...breadcrumbItems,
  ];

  return (
    <Breadcrumb className="mb-2" items={items} />
  );
}

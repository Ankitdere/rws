import { ReloadOutlined } from "@ant-design/icons";
import { useDMSHooks } from "../../../../Redux/Store/Provider";
import { useState } from "react";

export default function Refresh() {
    const { refresh, setRefresh } = useDMSHooks();
    const [rotate, setRotate] = useState(false);

    const handleRefreshClick = () => {
        setRefresh(!refresh);
        setRotate(true);
        setTimeout(() => setRotate(false), 1000); 
    };

    return (
        <div
            className={`my-auto flex flex-wrap gap-2 cursor-pointer hover:scale-110 hover:z-10 mx-2 ${rotate ? 'rotate' : ''}`}
            onClick={handleRefreshClick}
        >
            <ReloadOutlined className="text-grey-700" />
        </div>
    );
}

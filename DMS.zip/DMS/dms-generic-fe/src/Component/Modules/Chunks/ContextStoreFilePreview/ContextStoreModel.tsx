import React, { createContext, useState, useEffect, useContext, ReactNode } from 'react';

type DMSFilePreviewContextType = {
  AiResponse: string;
  setAiResponse: React.Dispatch<React.SetStateAction<string>>;
  DocContentText: string;
  setDocContentText: React.Dispatch<React.SetStateAction<string>>;
  loading: boolean;
  setLoading: React.Dispatch<React.SetStateAction<boolean>>;
};

const DMSFilePreviewContext = createContext<DMSFilePreviewContextType | undefined>(undefined);

export const DMSFilePreview: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [AiResponse, setAiResponse] = useState('');
  const [DocContentText, setDocContentText] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
  }, []);

  const ContextValue = {
    AiResponse,
    setAiResponse,
    DocContentText,
    setDocContentText,
    loading,
    setLoading
  };

  return (
    <DMSFilePreviewContext.Provider value={ContextValue}>
      {children}
    </DMSFilePreviewContext.Provider>
  );
};

export const useDMSHookFilePreview = () => {
  const context = useContext(DMSFilePreviewContext);
  if (!context) {
    throw new Error('useDMSHooks must be used within a DMSFilePreview');
  }
  return context;
};

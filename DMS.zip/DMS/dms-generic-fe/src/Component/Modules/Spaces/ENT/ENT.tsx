export default function ENT() {
  return (
    <div>ENT</div>
  )
}

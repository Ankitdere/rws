import { useEffect, useState } from 'react';
import { Table, Checkbox, Select, Button, Tooltip, Tag, Divider, Dropdown, Menu, Popconfirm, Modal } from 'antd';
import { CheckOutlined, CloseOutlined, UploadOutlined, DownOutlined } from '@ant-design/icons';
import { ExecuteRequest, FetchApprovalPendingList } from '../../../ServiceUtils/Services/api';
import { typeDataSource } from '../../../Constants/constants';
import { formatTimeAgo } from '../../../Constants/Functions/function';
import UserInsightsActivity from '../Chunks/ListViewFragments/UserInsightsActivity.tsx/UserInsightsActivity';
import PathTree from './PathTree/PathTree';
import { capitalizeFirstLetter } from '../../../Constants/utils';
import { useMsal } from '@azure/msal-react';
import { useNavigate } from 'react-router-dom';
import TextArea from 'antd/es/input/TextArea';
import { useNotification } from '../../../Redux/Store/NotificationProvider';

const { Option } = Select;

export default function Approval() {
  const [selectedRowKeys, setSelectedRowKeys] = useState<string[]>([]);
  const [dataSource, setDataSource] = useState<typeDataSource[]>([]);
  const [filteredDataSource, setFilteredDataSource] = useState<typeDataSource[]>([]);
  const [selectedFilter, setSelectedFilter] = useState<string>('all');
  const [selectedAuthors, setSelectedAuthors] = useState<Set<string>>(new Set());
  const [authors, setAuthors] = useState<string[]>([]);
  const { instance } = useMsal();
  const activeAccount = instance.getActiveAccount();
  const [isSmallScreen, setIsSmallScreen] = useState(false);
  const [sortOrder, setSortOrder] = useState<'ascend' | 'descend' | null>(null);
  const [loading, setLoading] = useState(true);
  const [approveLoading, setApproveLoading] = useState<string | null>(null);
  const [rejectLoading, setRejectLoading] = useState<string | null>(null);
  const [approveAllLoading, setApproveAllLoading] = useState(false);
  const [rejectAllLoading, setRejectAllLoading] = useState(false);
  const [isApproveModalVisible, setIsApproveModalVisible] = useState(false);
  const [isRejectModalVisible, setIsRejectModalVisible] = useState(false);
  const [comments, setComments] = useState('');
  const navigate = useNavigate();
  const { openNotificationPopUp } = useNotification()
  useEffect(() => {
    navigate('/', { replace: false });
  }, [navigate]);

  const handleSort = (order: 'ascend' | 'descend' | null) => {
    setSortOrder(order);
  };

  useEffect(() => {
    const handleResize = () => {
      setIsSmallScreen(window.innerWidth < 880);
    };
    handleResize();
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [isSmallScreen]);

  const FetchData = async () => {
    setLoading(true);
    try {
      const ListResponse: typeDataSource[] = await FetchApprovalPendingList();
      const data = Array.isArray(ListResponse) ? ListResponse : [];

      setDataSource(data);
      setFilteredDataSource(data);

      const uniqueAuthors = Array.from(new Set(data.map(item => item.author || ''))).sort();
      setAuthors(uniqueAuthors);
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    FetchData();
  }, []);

  useEffect(() => {
    setFilteredDataSource(dataSource?.filter(item => {
      const typeMatch = selectedFilter === 'all' || item.requestType === selectedFilter;
      const authorMatch = selectedAuthors.size === 0 || selectedAuthors.has(item.author || '');
      return typeMatch && authorMatch;
    }));
  }, [selectedFilter, selectedAuthors, dataSource]);

  const handleSelectChange = (value: string) => {
    setSelectedFilter(value);
  };

  const handleAuthorChange = (author: string, checked: boolean) => {
    setSelectedAuthors(prev => {
      const newSet = new Set(prev);
      if (checked) {
        newSet.add(author);
      } else {
        newSet.delete(author);
      }
      return newSet;
    });
  };

  const handleApprove = async (key: typeDataSource, comment: string) => {
    setApproveLoading(key.id);
    try {
      const response = await ExecuteRequest(
        'approve',
        key?.requestFor || 'upload',
        key?.fileUrl || '',
        key?.fileType || '',
        key?.id || '',
        activeAccount?.name || '',
        activeAccount?.username || '',
        comment || ''
      );
      if (response) {
        await FetchData()
        openNotificationPopUp(response, "Approved", 3000, 1);
      }
    } catch (error) {
      openNotificationPopUp("Please try again later.", "Failed to execute request", 3000, 2);
      console.error('Approval failed:', error);
    } finally {
      setApproveLoading(null);
      // openNotificationPopUp(response, "Success", 3000, 1);
    }
  };

  const handleReject = async (key: typeDataSource, comments: string) => {
    setRejectLoading(key.id);
    try {
      const response = await ExecuteRequest(
        'reject',
        key?.requestFor || 'upload',
        key?.fileUrl || '',
        key?.fileType || '',
        key?.id || '',
        activeAccount?.name || '',
        activeAccount?.username || '',
        comments || ''
      );
      if (response) {
        await FetchData()
        openNotificationPopUp(response, "Rejected", 3000, 1);
      }
    } catch (error) {
      openNotificationPopUp("Please try again later.", "Failed to execute request", 3000, 2);
      console.error('Rejection failed:', error);
    } finally {
      setRejectLoading(null);
    }
  };

  const columns = [
    {
      title: (
        <Checkbox
          indeterminate={selectedRowKeys.length > 0 && selectedRowKeys.length < filteredDataSource.length}
          checked={selectedRowKeys.length === filteredDataSource.length}
          onChange={(e) => {
            const { checked } = e.target;
            if (checked) {
              setSelectedRowKeys(filteredDataSource.map(record => record.id));
            } else {
              setSelectedRowKeys([]);
            }
          }}
        />
      ),
      key: 'select',
      render: (_: any, record: typeDataSource) => (
        <Checkbox
          checked={selectedRowKeys.includes(record.id)}
          onChange={(e) => {
            const { checked } = e.target;
            setSelectedRowKeys(prevKeys =>
              checked ? [...prevKeys, record.id] : prevKeys.filter(key => key !== record.id)
            );
          }}
        />
      ),
    },
    {
      title: 'File Name',
      dataIndex: 'fileName',
      key: 'fileName',
      render: (text: string) => (
        <Tooltip title={text} overlayClassName='text-[12px] rounded-lg font-semibold border border-rws bg-white' color='white' overlayInnerStyle={{ color: 'black' }} arrow={false}>
          <div
            style={{
              maxWidth: '120px',
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              cursor: 'pointer'
            }}
          >
            {text}
          </div>
        </Tooltip>
      ),
    },
    {
      title: 'Path',
      dataIndex: 'fileUrl',
      key: 'fileUrl',
      render: (record: typeDataSource) => (
        <PathTree record={record} />
      ),
    },
    {
      title: 'Activity',
      dataIndex: 'date',
      key: 'date',
      sorter: (a: typeDataSource, b: typeDataSource) => new Date(a.date).getTime() - new Date(b.date).getTime(),
      sortOrder: sortOrder,
      onHeaderCell: () => ({
        onClick: () => {
          const newSortOrder = sortOrder === 'ascend' ? 'descend' : 'ascend';
          handleSort(newSortOrder);
        },
      }),
      render: (_: any, record: typeDataSource) => (
        <div className='flex flex-wrap gap-1'>
          <span>Request raised by</span>
          <UserInsightsActivity record={record} /> <p className='font-semibold'>{record?.author}</p>
          - <p className='font-style: italic'>{record?.date ? formatTimeAgo(record?.date) : 'Unknown'}</p>
        </div>
      ),
    },
    {
      title: 'Type',
      dataIndex: 'requestFor',
      key: 'requestFor',
      render: (text: string) => (
        <Tag icon={<UploadOutlined />} color={text === "upload" ? 'green-inverse' : 'red-inverse'} className="font-semibold">
          {capitalizeFirstLetter(text)}
        </Tag>
      ),
    },
    ...(selectedRowKeys.length === 1 || selectedRowKeys.length === 0
      ? [
        {
          title: 'Action',
          key: 'action',
          render: (_: any, record: typeDataSource) => (
            <div className='flex flex-wrap gap-2 animate-fade'>
              <Popconfirm
                title="Approve"
                description={(
                  <div>
                    <TextArea
                      rows={3}
                      placeholder="Add any comments (optional)"
                      value={comments}
                      onChange={(e) => setComments(e.target.value)}
                    />
                  </div>
                )}
                onConfirm={async () => {
                  handleApprove(record, comments);
                }}
                okText="Yes"
                cancelText="No"
              >
                <Button
                  icon={<CheckOutlined />}
                  loading={approveLoading === record.id}
                >
                  Approve
                </Button>
              </Popconfirm>
              <Popconfirm
                title="Reject"
                description={(
                  <div>
                    <TextArea
                      rows={3}
                      placeholder="Add any comments (optional)"
                      value={comments}
                      onChange={(e) => setComments(e.target.value)}
                    />
                  </div>
                )}
                onConfirm={async () => {
                  handleReject(record, comments)
                }}
                okText="Yes"
                cancelText="No"
              >
                <Button
                  icon={<CloseOutlined />}
                  loading={rejectLoading === record.id}
                >
                  Reject
                </Button>
              </Popconfirm>
            </div>
          ),
        },
      ]
      : []),
  ];

  const handleApproveAll = async () => {
    setApproveAllLoading(true);
    for (const key of selectedRowKeys) {
      const record = dataSource?.find(item => item.id === key);
      if (record) {
        await handleApprove(record, comments);
      }
    }
    setApproveAllLoading(false);
    setIsApproveModalVisible(false)
  };

  const handleRejectAll = async () => {
    setRejectAllLoading(true);
    for (const key of selectedRowKeys) {
      const record = dataSource?.find(item => item.id === key);
      if (record) {
        await handleReject(record, comments);
      }
    }
    setRejectAllLoading(false);
    setIsRejectModalVisible(false)
  };


  const authorMenu = (
    <Menu>
      {authors.map(author => (
        <Menu.Item key={author}>
          <Checkbox
            checked={selectedAuthors.has(author)}
            onChange={(e) => handleAuthorChange(author, e.target.checked)}
          >
            {author}
          </Checkbox>
        </Menu.Item>
      ))}
    </Menu>
  );
  return (
    <div>
      <div className='flex flex-wrap justify-between'>
        <div className='flex flex-wrap gap-3 '>
          <p className='font-semibold my-auto'>Filters</p>
          <Select
            className='my-auto'
            onChange={handleSelectChange}
            value={selectedFilter}
          >
            <Option key="all" value="all">
              Request Type (All)
            </Option>
            <Option key="upload" value="upload">
              Upload
            </Option>
            <Option key="delete" value="delete">
              Delete
            </Option>
          </Select>
          <Dropdown
            // eslint-disable-next-line
            overlay={authorMenu} trigger={['click']}>
            <Button>
              Authors <DownOutlined /> {Array.from(selectedAuthors).map(author => <Tag key={author} color="blue" className='mr-0'>{author}</Tag>)}
            </Button>
          </Dropdown>
        </div>
        {selectedRowKeys.length > 1 && (
          <div className='flex flex-wrap gap-3 animate-fade'>
            <Button onClick={() => setIsApproveModalVisible(true)} className='hover:border hover:border-green-300 hover:shadow-md shadow-green-100 font-semibold bg-white hover:text-green-500'>
              Approve Selected
            </Button>
            <Button onClick={() => setIsRejectModalVisible(true)} loading={rejectAllLoading} className='hover:border hover:border-red-300 hover:shadow-md shadow-red-100 font-semibold bg-white hover:text-red-500'>
              Reject Selected
            </Button>
          </div>
        )}
        <Modal title="Approve" open={isApproveModalVisible} onOk={handleApproveAll} onCancel={() => setIsApproveModalVisible(false)} loading={approveAllLoading}>
          <TextArea
            rows={3}
            placeholder="Add any comments (optional)"
            value={comments}
            className='mb-3'
            onChange={(e) => setComments(e.target.value)}
          />
          {selectedRowKeys?.map((key) => {
            const record = dataSource?.find(item => item.id === key);
            const getTagColor = (requestFor: string) => {
              return requestFor.toLowerCase() === 'delete' ? 'red' : 'green';
            };

            const capitalizeFirstLetter = (string: string) => {
              return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
            };
            return (
              record &&
              <div className='px-2 flex flex-wrap gap-2 py-1'>
                <Tag key={key} color={getTagColor(record?.requestFor)}>
                  {capitalizeFirstLetter(record?.requestFor)}
                </Tag>
                <p key={key}>{record?.fileName}</p>
              </div>
            );
          })}
        </Modal>
        <Modal title="Reject" open={isRejectModalVisible} onOk={handleRejectAll} onCancel={() => setIsRejectModalVisible(false)} loading={rejectAllLoading}>
          <TextArea
            rows={3}
            placeholder="Add any comments (optional)"
            value={comments}
            className='mb-3'
            onChange={(e) => setComments(e.target.value)}
          />
          {selectedRowKeys?.map((key) => {
            const record = dataSource?.find(item => item.id === key);
            const getTagColor = (requestFor: string) => {
              return requestFor.toLowerCase() === 'delete' ? 'red' : 'green';
            };

            const capitalizeFirstLetter = (string: string) => {
              return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
            };
            return (
              record &&
              <div className='px-2 flex flex-wrap gap-2 py-1'>
                <Tag key={key} color={getTagColor(record?.requestFor)}>
                  {capitalizeFirstLetter(record?.requestFor)}
                </Tag>
                <p key={key}>{record?.fileName}</p>
              </div>
            );
          })}
        </Modal>
      </div>
      <Divider />
      <Table
        rowKey="id"
        dataSource={filteredDataSource}
        columns={columns}
        loading={loading}
        pagination={false}
        scroll={isSmallScreen ? { x: 'auto' } : undefined}
      />
    </div>
  );
}

import { Popover, Tag } from "antd";
import ContentTree from "./Tree/ContentTree";

export default function PathTree({ record }: { record: any }) {
    const content = (
        <ContentTree record={record} />
    );
    return (
        <Popover content={content}>
            <Tag color="processing" className="cursor-pointer animate-fade flex flex-wrap my-auto">
            / {record?.split('/')[record?.split('/')?.length - 2]?.replaceAll("%20"," ") || 'Root'}
            </Tag>
        </Popover>
    );
};


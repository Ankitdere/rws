import { getIcon } from "../../../../../Constants/Functions/fileIcon";
import { useRoles } from "../../../../../Redux/Store/RolesProvider";
import { useDMSHooks } from "../../../../../Redux/Store/Provider";
import { ERROR_HEADER, ERROR_MESSAGE_FILE_PATH } from "../../../../../Constants/constants";
import { FileOutlined } from "@ant-design/icons";

export default function ContentTree({ record }: { record: any }) {
  const records = record?.split('/');
  const { role } = useRoles()
  const { openNotification } = useDMSHooks()
  const handleNavigation = (index: number) => {
    if (role?.includes("FileList")) {
      const pathToNavigate = records.slice(0, index + 1).join('/');
      window.location.href = pathToNavigate;
    } else {
      openNotification(ERROR_HEADER, ERROR_MESSAGE_FILE_PATH, 3, <FileOutlined className="text-red-500" />, 'error')
    }
  };

  return (
    <div>
      <ul className="list-none pl-0">
        {records?.slice(0, records?.length - 1).map((folder: any, index: any) => (
          <li
            key={index}
            className="flex items-center hover:scale-110 transition hover:z-10 cursor-pointer"
            style={{ marginLeft: `${index * 2}rem` }}
            onClick={() => handleNavigation(index)}
          >
            <span className="flex items-center cursor-pointer">
              {index > 0 && (
                <span
                  className="w-2.5 h-2.5 border-l border-dotted border-black border-b ml-2 mr-2 animate-bounce"
                />
              )}
              {getIcon(folder, 'h-4', record?.name)}
            </span>
            <span className="ml-2 cursor-pointer" onClick={() => handleNavigation(index)}>
              {folder?.replaceAll("%20", " ")}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

import { useState, useEffect } from 'react';
import { Table, Button, Tag, Divider, Dropdown, Menu, Checkbox, DatePicker } from 'antd';
import { DownOutlined, EyeFilled, SyncOutlined } from '@ant-design/icons';
import UserInsightsActivity from '../../Chunks/ListViewFragments/UserInsightsActivity.tsx/UserInsightsActivity';
import { formatTimeAgo } from '../../../../Constants/Functions/function';
import PathTree from '../../Workflow/PathTree/PathTree';
import { useRoles } from '../../../../Redux/Store/RolesProvider';
import moment, { Moment } from 'moment';
import LogoAWS from '../../../../Assets/Svgs/LogoAWS';
import { FetchLogsEvent } from '../../../../ServiceUtils/Services/api';
import { formatActionMessage } from '../../../../Constants/Functions/ContextMenu';
import CommentBallon from '../../Chunks/CommentBallon/CommentBallon';
import ExportLogsHelper from '../../Chunks/ExportLogs/ExportLogsHelper';

const { RangePicker } = DatePicker;

interface LogData {
    id: string;
    name: string;
    email: string;
    action: string;
    date: string;
    path: string;
    fileUrl: string;
    comment:string;
}

export default function LogsList() {
    const [dataSource, setDataSource] = useState<LogData[]>([]);
    const [loading, setLoading] = useState(true);
    const { userDetails } = useRoles();
    const [isSmallScreen, setIsSmallScreen] = useState(false);
    const [sortOrder, setSortOrder] = useState<'ascend' | 'descend' | null>('descend');
    const [selectedAuthors, setSelectedAuthors] = useState<Set<string>>(new Set());
    const [dateRange, setDateRange] = useState<[Moment | null, Moment | null] | null>(null);
    const [startDate, setStartDate] = useState<string>('');
    const [endDate, setEndDate] = useState<string>('');
    const [isRefreshing, setIsRefreshing] = useState(false);

    const handleSort = (order: 'ascend' | 'descend' | null) => {
        setSortOrder(order);
    };
    useEffect(() => {
        const handleResize = () => {
            setIsSmallScreen(window.innerWidth < 880);
        };
        handleResize();
        window.addEventListener('resize', handleResize);

        return () => {
            window.removeEventListener('resize', handleResize);
        };
    }, [isSmallScreen]);

    const handleAuthorChange = (author: string, checked: boolean) => {
        const newSelectedAuthors = new Set(selectedAuthors);
        if (checked) {
            newSelectedAuthors.add(author);
        } else {
            newSelectedAuthors.delete(author);
        }
        setSelectedAuthors(newSelectedAuthors);
    };

    const authors = Array.from(new Set(dataSource?.map(log => log.name)));

    const filteredDataSource = dataSource.filter(log => {
        const logDate = moment(log.date);
        const isAuthorSelected = selectedAuthors.size === 0 || selectedAuthors.has(log.name);
        const isInDateRange = dateRange
            ? (!dateRange[0] || logDate.isAfter(dateRange[0])) && (!dateRange[1] || logDate.isBefore(dateRange[1]))
            : true;

        return isAuthorSelected && isInDateRange;
    });
    const fetchLogs = async () => {
        setLoading(true);
        setIsRefreshing(true);
        const ListResponse: LogData[] = await FetchLogsEvent();
        const logs = Array.isArray(ListResponse) ? ListResponse : [];
        setDataSource(logs);
        setLoading(false);
        setIsRefreshing(false);
    };
    useEffect(() => {
        fetchLogs();
        const intervalId = setInterval(fetchLogs, 20000);
        return () => clearInterval(intervalId);
    }, []);

    const columns = [
        {
            title: 'Activity',
            dataIndex: 'name',
            key: 'name',
            render: (_: any, record: LogData) => (
                <div className='flex flex-wrap items-center gap-2 select-none animate-fade'>
                    <span className='my-auto flex flex-wrap gap-1'>
                        <p className='my-auto flex flex-wrap '>{formatActionMessage(record?.action || '')} by</p>
                        <p className='my-auto ml-1'><UserInsightsActivity record={record} /></p>
                        <p className='my-auto'>{record?.name === userDetails?.name ? "You" : record?.name || 'Unknown'}</p>
                        {record?.comment && <CommentBallon comment={record?.comment || ''}/>}
                    </span>
                </div>
            ),
        },
        {
            title: 'Date',
            dataIndex: 'date',
            key: 'date',
            sorter: (a: LogData, b: LogData) => new Date(a.date).getTime() - new Date(b.date).getTime(),
            sortOrder: sortOrder,
            onHeaderCell: () => ({
                onClick: () => {
                    const newSortOrder = sortOrder === 'ascend' ? 'descend' : 'ascend';
                    handleSort(newSortOrder);
                },
            }),
            render: (_: any, record: LogData) => (
                <div className='flex flex-wrap items-center gap-2 animate-fade'>
                    <span>{record?.date ? formatTimeAgo(record?.date) : "Unknown"}</span>
                </div>
            ),
        },
        {
            title: 'Path',
            dataIndex: 'path',
            key: 'path',
            render: (record: LogData) => (
                <PathTree record={record} />
            ),
        },
        {
            title: 'Source',
            dataIndex: 'fileUrl',
            key: 'source',
            render: (fileUrl: string) => {
                const isAws = fileUrl?.includes("amazonaws") || fileUrl?.includes("s3");
                return (
                    <Tag color={isAws ? 'orange' : 'magenta'} className='animate-fade'>
                        {isAws ? <LogoAWS /> : 'Other'}
                    </Tag>
                );
            },
        },
        {
            title: 'Preview',
            dataIndex: 'fileUrl',
            key: 'fileUrl',
            render: (fileUrl: string) => {
                const isAws = fileUrl?.includes("amazonaws");

                return isAws ? (
                    <a href={fileUrl} target="_blank" rel="noopener noreferrer" className='mx-auto text-center animate-fade'>
                        <EyeFilled />
                    </a>
                ) : (
                    <EyeFilled className="text-gray-400 cursor-not-allowed" />
                );
            },
        },
    ];

    const authorMenu = (
        <Menu>
            {authors.map(author => (
                <Menu.Item key={author}>
                    <Checkbox
                        checked={selectedAuthors.has(author)}
                        onChange={(e) => handleAuthorChange(author, e.target.checked)}
                    >
                        {author}
                    </Checkbox>
                </Menu.Item>
            ))}
        </Menu>
    );

    useEffect(() => {
        if (dateRange && dateRange[0] && dateRange[1]) {
            const startDate = dateRange[0].format('DD MMMM YYYY');
            const endDate = dateRange[1].format('DD MMMM YYYY');
            setStartDate(startDate)
            setEndDate(endDate)
        } else {
            setStartDate('')
            setEndDate('')
        }
    }, [dateRange]);

    return (
        <div>
            <div className='flex flex-wrap justify-between border  shadow-md p-2 rounded-md'>
                <div className='flex flex-wrap justify-start'>
                    {isRefreshing ? (
                        <div className="flex flex-wrap gap-2 py-1">
                            <SyncOutlined spin className='text-[#9E9E9E]'/>
                            <p className="text-[#9E9E9E] font-semibold">Updating Logs</p>
                        </div>
                    ) : (
                        <>
                            <p className='mx-4 my-auto font-semibold'>Filters</p>
                            <Dropdown overlay={authorMenu} trigger={['click']} className='outline-none'>
                                <Button className='border-none'>
                                    Users {Array.from(selectedAuthors).map(author => <Tag key={author} color="blue" className='mr-0'>{author}</Tag>)}
                                    <DownOutlined />
                                </Button>
                            </Dropdown>
                            <RangePicker
                                onChange={(dates) => {
                                    if (dates && dates?.length === 2) {
                                        //@ts-ignore
                                        setDateRange([moment(dates[0].toISOString()), moment(dates[1].toISOString())]);
                                    } else {
                                        setDateRange(null);
                                    }
                                }}
                                className='ml-3 border-none'
                            />
                        </>
                    )}
                </div>
                <ExportLogsHelper/>
                {startDate && <p className='ml-3 my-auto flex flex-wrap'><Tag color='geekblue'>{startDate}</Tag> to <Tag color='geekblue' className='ml-2'>{endDate}</Tag></p>}
            </div>
            <Divider />
            <Table
                rowKey="id"
                dataSource={filteredDataSource}
                columns={columns}
                loading={loading}
                pagination={{ pageSize: 10,showSizeChanger:false}} 
                scroll={isSmallScreen ? { x: 'auto' } : undefined}
                className='shadow-md border'
            />
        </div>
    );
}

export default function Loader({ state }: any) {
    return (
        <>
            {state &&
                <div className="flex flex-wrap justify-center">
                    <div>
                        <div className="message-loader-2 mx-auto">
                            <div className="loader-bar-2"></div>
                            <div className="loader-bar-2"></div>
                            <div className="loader-bar-2"></div>
                        </div>
                        <p className="mx-auto text-xs text-[#B0BEC5]">Loading Chats</p>
                    </div>
                </div>
            }
        </>
    )
}

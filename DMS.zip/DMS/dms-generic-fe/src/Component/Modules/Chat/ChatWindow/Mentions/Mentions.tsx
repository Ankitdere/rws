import { MailOutlined, PhoneOutlined } from "@ant-design/icons";
import {  Divider, Popover, Tooltip } from "antd";
import { formatTimeAgo } from "../../../../../Constants/Functions/function";
import { useEffect, useState, useCallback } from "react";
import { useRoles } from "../../../../../Redux/Store/RolesProvider";

interface UserInsightsActivityProps {
    record: any;
}

interface userDetailsType {
    userName?: string;
    role?: string;
    name?: string;
    profileImg?: string;
}

const Mentions: React.FC<UserInsightsActivityProps> = ({ record }) => {
    const lastModified = record?.date ? formatTimeAgo(record?.date) : "";
    const {userDetails} = useRoles()
    const [userDetailsCurrent, setUserDetails] = useState<userDetailsType>({});
    const { allUsersData } = useRoles();
    const getUserDetails = useCallback((email: string) => {
        try {
            if (allUsersData && Array.isArray(allUsersData)) {
                const foundUserDetails = allUsersData?.find((user: any) => user.userName === email);
                if (foundUserDetails && foundUserDetails !== userDetails) {
                    setUserDetails(foundUserDetails);
                }
            }
        } catch (error) {
            console.error("Error fetching user details:", error);
        }
    }, [allUsersData, userDetails]);
console.log(record, '----')
    useEffect(() => {
        if (record?.email && allUsersData) {
            getUserDetails(record?.email);
        }
    }, [record?.email, allUsersData, getUserDetails]);

    const content = (
        <div>
            <div className="flex flex-wrap">
                {(userDetailsCurrent?.profileImg || record?.profileImg) && (
                    <img
                        src={userDetailsCurrent?.profileImg || record?.profileImg}
                        alt={record?.author}
                        className="h-10 rounded-full my-2"
                    />
                )}
                <Divider type="vertical" className="h-[99%]" dashed />
                <div className="my-auto">
                    <p className="font-semibold text-[13px]">{userDetails?.name === record?.author ? 'You' : record?.author || userDetails?.name === record?.name ? 'You' : record?.name || ''}</p>
                    {(userDetailsCurrent?.role || record?.role ) && <p className="text-[12px]">{record?.role || userDetailsCurrent?.role || ''}</p>}
                    {lastModified && <div className="flex flex-wrap gap-2">
                        <p className="text-[12px] font-semibold">Last Modified:</p>
                        <p className="text-[12px]">{lastModified}</p>
                    </div>}
                </div>
            </div>
            <div className="p-1 px-2 bg-[#ECEFF1] rounded-md my-1 shadow-lg">
                <p className="font-semibold text-[11px] mb-1">Contact</p>
                <Tooltip title={`Click here to Mail ${record?.author || record?.name || ''}`} overlayClassName="text-[10px]">
                    <a
                        className="text-blue-500 text-[12px] font-semibold hover:cursor-pointer"
                        href={`mailto:${record?.email}`}
                    >
                        <MailOutlined /> {record?.email || record?.userName}
                    </a>
                </Tooltip>
                <p className="flex flex-wrap gap-1"><PhoneOutlined className="text-[#616161] text-[11px]"/><p className="text-[#616161] font-semibold text-[11px]">+91 XXXXXXXXX</p></p>
            </div>
        </div>
    );


    return (
        <Popover content={content} overlayClassName="shadow-sm">
           <p className="font-semibold text-rws px-1 bg-white rounded-full">@{record?.name || ''}</p>
        </Popover>
    );
};

export default Mentions;

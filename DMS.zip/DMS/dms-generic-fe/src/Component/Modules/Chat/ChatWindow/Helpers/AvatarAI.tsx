import { Popover, Avatar } from 'antd';
import LOGORWS from '../../../../../Assets/RWS_Logo/RWS.L-f2a2bc55.png'

export default function AvatarAI() {
    const content = (
        <div className="flex flex-wrap">
            <div>
                <p className="font-semibold text-[13px]">{'DMS BOT'}</p>
                <div>
                    <p className="text-[12px]"> Hello there! I'm your friendly DMS BOT</p>
                    <p className="text-[12px]">here to assist you with anything you need.</p>
                </div>
            </div>
        </div>
    );

    return (
        <Popover content={content} className='my-auto'>
            <Avatar
                size={"small"}
                className="hover:cursor-pointer shadow-md"
                src={LOGORWS}
            />
        </Popover>
    )
}
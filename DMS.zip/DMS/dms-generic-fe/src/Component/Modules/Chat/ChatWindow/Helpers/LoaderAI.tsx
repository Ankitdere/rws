export default function LoaderAI() {
    return (<div className="flex flex-wrap justify-center">
        <div>
            <div className="base">
                <div className="circ circ-1"></div>
                <div className="circ circ-2"></div>
                <div className="circ circ-3"></div>
                <div className="circ circ-4"></div>
                <div className="circ circ-5"></div>
                <div className="circ circ-6"></div>
                <div className="circ circ-7"></div>
                <div className="circ circ-8"></div>
                <div className="circ circ-9"></div>
                <div className="circ circ-10"></div>
                <div className="circ circ-11"></div>
                <div className="circ circ-12"></div>
                <div className="circ circ-13"></div>
                <div className="circ circ-14"></div>
                <div className="circ circ-15"></div>
            </div>
        </div>
    </div>
    )
}

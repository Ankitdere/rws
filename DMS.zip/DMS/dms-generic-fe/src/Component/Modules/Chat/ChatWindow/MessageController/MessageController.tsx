import { DeleteOutlined, EditOutlined, EllipsisOutlined } from '@ant-design/icons'
import { Dropdown, MenuProps } from 'antd'

export default function MessageController({ handleDeleteMessage, id }: any) {
    const items: MenuProps['items'] = [
        {
            label: 'Test 1',
            key: '1',
            disabled:true,
        },
        {
            label: 'Test 2',
            disabled:true,
            key: '1',
        },
    ];
    return (
        <div className='flex flex-wrap gap-2'>
            <DeleteOutlined className='text-red-500 hover:scale-110 hover:z-50 transition text-[16px]' onClick={(e) => handleDeleteMessage(id)} />
            <EditOutlined onClick={() => alert('Edit')} className='hover:scale-110 hover:z-50 transition text-[16px] text-[#424242]'/>
            <Dropdown menu={{ items }}>
                <EllipsisOutlined  className='hover:bg-grey-100 cursor-pointer hover:scale-110 hover:z-50 transition text-[16px] text-[#424242]'/>
            </Dropdown>
        </div>
    )
}

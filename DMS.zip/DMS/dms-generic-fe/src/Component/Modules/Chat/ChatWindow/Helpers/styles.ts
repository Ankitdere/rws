export const DMSBOT_STYLE = 'text-xs text-[#90A4AE] bg-[#E3F2FD] font-semibold border border-blue-500 rounded-lg'
export const GENERIC_CHAT_MESSAGE = 'flex gap-1 message font-[400] shadow-sm px-2 p-1 rounded-full text-[#616161] cursor-pointer'
export const OVERLAY_TOOLTIP = 'text-[12px] rounded-lg font-semibold bg-white'
export const FORMAT_TIME = 'text-xs text-[#BDBDBD] my-auto'
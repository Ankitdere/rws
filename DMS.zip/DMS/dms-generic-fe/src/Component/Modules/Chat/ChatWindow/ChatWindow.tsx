import { useEffect, useRef, useState } from 'react';
import { Input, Tooltip, message as AntMessage, Divider } from 'antd';
import { useRoles } from '../../../../Redux/Store/RolesProvider';
import UserAvatars from './Helpers/UserAvatars';
import { CHAT_TOKEN, CHATROOM_DESC, HELPER_TEXT, User } from '../../../../Constants/constants';
import io from 'socket.io-client';
import UserInsightsActivity from '../../Chunks/ListViewFragments/UserInsightsActivity.tsx/UserInsightsActivity';
import { formatTimeAgo, getBaseUrl } from '../../../../Constants/Functions/function';
import Loader from './Helpers/Loader';
import { DeleteMessages, fetchChatFromDB, getAIOverview } from '../../../../ServiceUtils/Services/api';
import AvatarAI from './Helpers/AvatarAI';
import LoaderAI from './Helpers/LoaderAI';
import MessageController from './MessageController/MessageController';
import Mentions from './Mentions/Mentions';
import { DMSBOT_STYLE, FORMAT_TIME, GENERIC_CHAT_MESSAGE, OVERLAY_TOOLTIP } from './Helpers/styles';
import { formatMessageDate, shouldShowDivider } from '../../../../Constants/utils';

const socket = io(getBaseUrl(), {
    transports: ['websocket'],
    rejectUnauthorized: false
});

export default function ChatWindow() {
    const divRef = useRef<HTMLDivElement>(null);
    const [message, setMessage] = useState('');
    const [LoadingChats, setLoadingChats] = useState(false)
    const [LoadingAI, startLoading] = useState(false)
    const [BotOption, setBotOption] = useState(false)
    const [messageList, setMessageList] = useState<any[]>([]);
    const { allUsersData } = useRoles() as { allUsersData: User[] };
    const { userDetails } = useRoles();
    const room = CHAT_TOKEN;
    const [isShadow, setIsShadow] = useState(false);
    const handleSend = async () => {
        if (message !== '') {
            const messageData = {
                room: room,
                author: userDetails?.name,
                message: message,
                email: userDetails?.userName,
                time: new Date().toISOString(),
            };
            if (message.startsWith('/bot')) {
                startLoading(true)
                const filteredMessages = messageList?.filter(msg => msg?.author !== "dmsBot")?.map(({ author, message }) => ({ author, message }));
                const resultString = JSON.stringify(filteredMessages);
                try {
                    const response = await getAIOverview(resultString);

                    const aiMessageData = {
                        room: room,
                        author: 'dmsBot',
                        message: response.response || 'No response from Bot',
                        email: 'dmsBot',
                        time: new Date().toISOString(),
                    };
                    startLoading(false)
                    setMessageList((list) => [...list, aiMessageData]);
                    setMessage('');
                    setBotOption(false)
                } catch (error) {
                    console.error('Error calling AI overview:', error);
                    AntMessage.error('Failed to get AI response. Please try again.');
                    setBotOption(false)
                }
            } else {
                await socket.emit('send_message', messageData);
                setMessageList((list) => [...list, messageData]);
                setMessage('');
                setBotOption(false)
            }
        }
    };

    const handleKeyPress = (event: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (event.key === 'Enter' && !event.shiftKey) {
            handleSend();
            setIsShadow(true);
            setTimeout(() => setIsShadow(false), 200);
            event.preventDefault();
        }
    };
    const handleOnChange = (e: string) => {
        if (e.startsWith('/')) {
            setBotOption(true)
        } else {
            setBotOption(false)
        }
        setMessage(e)
    };

    const fetchChats = async () => {
        setLoadingChats(true)
        try {
            const fetchedMessages = await fetchChatFromDB();
            if (Array.isArray(fetchedMessages)) {
                console.log(fetchedMessages, '_______DB FETHCED')
                setMessageList((currentList) => [...fetchedMessages, ...currentList]);
            } else {
                console.error('Fetched messages are not an array:', fetchedMessages);
            }
            setLoadingChats(false)
        } catch (error) {
            console.error('Error fetching chat messages:', error);
            setLoadingChats(false)
            AntMessage.error('Failed to fetch chats. Please try again.');
        }
    };
    useEffect(() => {
        fetchChats()
        socket.emit('join_room', room);
        socket.on('receive_message', (data) => {
            console.log(data, '_______RECEIVED')
            setMessageList((list) => [...list, data]);
        });
        return () => {
            socket.off('receive_message');
        };
    }, [room]);
    const handleDeleteMessage = async (id: string) => {
        let response = await DeleteMessages(id);
        if (response) {
            setMessageList((prevMessages) => prevMessages?.filter((message) => message?.id !== id));
        }
    };
    const formatMessage = (message: String) => {
        const regex = /(@\w+)/g;

        return message.split(regex).map((part, index) => {
            if (regex.test(part)) {
                const mentionedName = part.replace('@', '').toLowerCase();

                const matchedUser = allUsersData?.find(user => user.name.toLowerCase() === mentionedName);
                if (matchedUser) {
                    return (
                        <span key={index} className='hover:shadow-md rounded-full'>
                            <Mentions record={matchedUser} />
                        </span>
                    );
                } else {
                    return (
                        <span key={index} className="font-semibold text-rws">
                            {part}
                        </span>
                    );
                }
            }
            return part;
        });
    };
    useEffect(() => {
        if (divRef.current) {
            divRef.current.scrollTop = divRef.current.scrollHeight;
        }
    }, [messageList]);

    return (
        <div className="flex flex-col justify-between w-full border rounded-lg min-h-[500px]">
            <div className='flex flex-wrap p-2 justify-between bg-rws rounded-tl-lg rounded-tr-lg rounded-b-none'>
                <Tooltip title={CHATROOM_DESC} overlayClassName='text-[12px] rounded-lg font-semibold border border-rws bg-white' color='white' overlayInnerStyle={{ color: 'black' }} placement='bottomLeft'>
                    <h2 className="text-lg text-white ml-1 font-semibold select-none">Generic DMS Room (Q&A)</h2>
                </Tooltip>
                <div className='flex flex-wrap gap-1'>
                    <UserAvatars allUsersData={allUsersData} />
                </div>
            </div>
                <div ref={divRef} className="flex-grow p-4 overflow-auto max-h-[400px]" >
                    <Loader state={LoadingChats} />
                    {messageList?.map((messageContent, index) => {
                        const isSameDay = index > 0 && !shouldShowDivider(messageContent?.time, messageList[index - 1]?.time);
                        return (
                            <div key={index}>
                                {!isSameDay && (
                                    <Divider className='text-[12px] text-[#424242]'>
                                        {formatMessageDate(new Date(messageContent?.time))}
                                    </Divider>
                                )}
                                <div
                                    className={`flex flex-wrap gap-1 animate-fade ${userDetails?.name === messageContent?.author ? 'justify-end' : 'justify-start'}`}
                                    key={index}
                                >
                                    {userDetails?.name === messageContent?.author && <span className="text-xs text-[#BDBDBD] my-auto">{formatTimeAgo(messageContent?.time)}</span>}
                                    {messageContent?.author === 'dmsBot' && <AvatarAI />}
                                    <div className={`m-2 max-w-[70%] flex flex-wrap gap-1 `}>
                                        {userDetails?.name !== messageContent?.author &&
                                            <>
                                                {messageContent?.author === 'dmsBot' ? null : <div className='my-auto'>
                                                    <UserInsightsActivity record={messageContent} />
                                                </div>}
                                            </>
                                        }
                                        {userDetails?.name === messageContent?.author ?
                                            <Tooltip title={<MessageController handleDeleteMessage={handleDeleteMessage} id={messageContent?.id || ''} />} overlayClassName={OVERLAY_TOOLTIP} color='white' arrow={false} >
                                                <p className={`${GENERIC_CHAT_MESSAGE} ${userDetails?.name === messageContent?.author ? "bg-[#EEEEEE] self-end" : `${messageContent?.author === 'dmsBot' ? DMSBOT_STYLE : 'bg-gray-300 self-start'}`} `}>
                                                    {messageContent?.author === 'dmsBot'
                                                        ? formatMessage(messageContent?.message?.replace(/\*/g, ""))
                                                        : formatMessage(messageContent?.message)}
                                                </p>
                                            </Tooltip>
                                            :
                                            <p className={`message font-[400] px-2 p-1 ${userDetails?.name === messageContent?.author ? "bg-[#EEEEEE] self-end" : `${messageContent?.author === 'dmsBot' ? DMSBOT_STYLE : 'bg-[#EEEEEE] self-start'}`} rounded-full text-[#616161] cursor-pointer flex gap-1`}>
                                                {messageContent?.author === 'dmsBot' ? messageContent?.message?.replace(/\*/g, "") : formatMessage(messageContent?.message)}
                                            </p>
                                        }
                                        {userDetails?.name !== messageContent?.author && <span className={FORMAT_TIME}>{formatTimeAgo(messageContent?.time)}</span>}
                                    </div>
                                    {userDetails?.name === messageContent?.author && (
                                        <div className='my-auto'>
                                            <UserInsightsActivity record={messageContent} />
                                        </div>
                                    )}
                                </div>
                            </div>)
                    })}

                    {LoadingAI && <LoaderAI />}
                </div>
            <div className="flex justify-center p-3">
                <div className='mx-[70px] w-full'>
                    <Input.TextArea
                        value={message}
                        onChange={(e) => handleOnChange(e.target.value)}
                        placeholder="Type your message here..."
                        rows={1}
                        className={`p-2 border ${BotOption && 'border-[#EC407A] shadow-lg shadow-[#FCE4EC]'} outline-none shadow-md rounded-full resize-none px-5 ${isShadow ? 'scale-90 z-10 transition' : ''} ${BotOption ? "text-[#EC407A]" : "text-[#424242]"}`}
                        autoSize={{ minRows: 1, maxRows: 5 }}
                        onKeyPress={handleKeyPress}
                    />
                    <p className={`flex justify-center ${BotOption ? "text-[#EC407A]" : "text-[#B0BEC5]"} text-xs pt-2`}>{BotOption ? "Type /Bot to bring Bot in conversation" : HELPER_TEXT}</p>
                </div>
            </div>
        </div>
    );
}

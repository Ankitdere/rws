import { Avatar, Tooltip } from "antd";

export default function UserAvatars({ allUsersData }: any) {
    return (
        <Avatar.Group
            size={24}
            max={{
                count: 2,
                style: { color: '#f56a00', backgroundColor: '#fde3cf' },
            }}
            className='cursor-pointer'
        >
            {allUsersData?.filter((user: any) => user?.role !== "System Admin")?.map((user: any) => (
                <Tooltip key={user?.userName} title={user?.name} placement="top">
                    <Avatar src={user?.profileImg} className='cursor-pointer' />
                </Tooltip>
            ))}
        </Avatar.Group>
    )
}

import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import ChatWindow from "./ChatWindow/ChatWindow";
import { CHAT_TOKEN } from "../../../Constants/constants";

export default function ChatsDMS() {
    const navigate = useNavigate();

    useEffect(() => {
        navigate(`/${CHAT_TOKEN}`, { replace: false });
    }, [navigate]);
    return (
        <ChatWindow/>
    )
}

import { SearchOutlined } from '@ant-design/icons';
import { Input } from 'antd';
import React, { useEffect, useState } from 'react';
// import { AdvancedSearch } from '../../ServiceUtils/Services/api';
import BottomGutter from './RecentSearches/BottomGutter';
import { useDMSHooks } from '../../Redux/Store/Provider';

interface SearchBarProps {
  placeholder?: string;
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onSearch?: (value: string) => void;
}

const SearchBar: React.FC<SearchBarProps> = ({ placeholder, value = '' , onChange, onSearch }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [open , setOpen] = useState(false)
  const [results, setSearchResults] = useState([]);
  useEffect(()=>{
    if(value?.length > 0){
      setOpen(true)
    }else{
      setOpen(false)
    }
  },[value])

  const { RecentSearches, setRecentSearches } = useDMSHooks()
  const handleSearch = () => {
    if (onSearch && value) {
      onSearch(value);
    }
    if (value && !RecentSearches.includes(value)) {
      setRecentSearches((prev: string[]) => [...prev, value]);
    }
  };
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };
  const handleInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputValue = e.target.value;
    if (onChange) onChange(e);
    if (inputValue.length > 0) {
      setIsLoading(true);
      try {
        // const response = await AdvancedSearch(inputValue);
        // setSearchResults(response.data);
      } catch (error) {
        console.error('Error fetching results:', error);
      } finally {
        setIsLoading(false);
      }
    } else {
      setSearchResults([]);
    }
  };

  return (
    <div className="relative">
      <Input
        type="text"
        placeholder={placeholder || 'Search...'}
        value={value}
        spellCheck={false}
        onKeyDown={handleKeyDown}
        prefix={<SearchOutlined className="text-[#212121]" />}
        onChange={handleInputChange}
        className="w-full rounded-full pl-4 pr-10 py-1 text-[13px] text-[#212121] shadow-md bg-white "
        style={{ width: 200 }}
      />

      {open  && (
        <div className="absolute z-10 w-full mt-1 p-2 bg-white border border-gray-300 rounded-md shadow-lg max-h-80 overflow-y-auto">
          <BottomGutter isLoading={isLoading} results={results} onSearch={onSearch} value={value} setOpen={setOpen} />
        </div>
      )}

      <button
        onClick={handleSearch}
        className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-500"
        aria-label="Search"
      ></button>
    </div>
  );
};

export default SearchBar;

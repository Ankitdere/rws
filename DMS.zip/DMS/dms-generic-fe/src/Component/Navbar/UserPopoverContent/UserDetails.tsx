import { LogoutOutlined, EditOutlined } from "@ant-design/icons";
import { useMsal } from "@azure/msal-react";
import { Button, Avatar, Tooltip, Upload, message } from "antd";
import { useState } from "react";
import { updateImage } from "../../../ServiceUtils/Services/api";


export default function UserDetails({ ImageUrl }: any) {
    const { instance } = useMsal();
    const activeAccount = instance.getActiveAccount();
    const [profileImageUrl, setProfileImageUrl] = useState(ImageUrl);
    const [isHovered, setIsHovered] = useState(false); 

    const handleLogout = async () => {
        try {
            await instance.logoutPopup({ postLogoutRedirectUri: "/" });
            localStorage.clear();
            sessionStorage.clear();
            message.success("Successfully logged out and cleared cache!");
        } catch (error) {
            message.error("Logout failed!");
            console.error("Logout error: ", error);
        }
    };
    
    const handleImageUpload = async (file: any) => {
        const formData = new FormData();
        formData.append("file", file);
        formData.append("email", activeAccount?.username || "");

        try {
            await updateImage(formData);
            const reader = new FileReader();
            reader.onloadend = () => {
                setProfileImageUrl(reader.result as string);
                message.success("Profile image updated!");
            };
            reader.readAsDataURL(file);
        } catch (error) {
            message.error("Failed to update profile image!");
            console.error("Image upload error: ", error);
        }

        return false; // Prevent default upload behavior
    };

    return (
        <div>
            <div className="my-1">
                <Tooltip title="Change Image" mouseEnterDelay={0.5}>
                    <div
                        className="relative cursor-pointer w-[36px]"
                        onMouseEnter={() => setIsHovered(true)}
                        onMouseLeave={() => setIsHovered(false)}
                    >
                        <Avatar src={profileImageUrl} size={36} />
                        {isHovered && (
                            <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 rounded-full">
                                <EditOutlined className="text-white" />
                            </div>
                        )}
                        <Upload
                            showUploadList={false}
                            beforeUpload={handleImageUpload}
                            accept="image/*"
                        >
                            <div className="absolute inset-0"></div>
                        </Upload>
                    </div>
                </Tooltip>
                <p className="text-[12px] mt-2">{activeAccount?.username}</p>
            </div>
            <Button
                type="primary"
                size="small"
                className="my-1"
                icon={<LogoutOutlined />}
                onClick={handleLogout}
                href="/"
            >
                Logout
            </Button>
        </div>
    );
}

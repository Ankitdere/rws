import { Divider } from "antd";
import { User } from "../../../Constants/constants";
import { useRoles } from "../../../Redux/Store/RolesProvider";
import UserInsightsActivity from "../../Modules/Chunks/ListViewFragments/UserInsightsActivity.tsx/UserInsightsActivity";

export default function People({ value }: any) {
    const { allUsersData } = useRoles() as { allUsersData: User[] };
    const filteredUsers = allUsersData.filter((user) =>
        user.userName.toLowerCase().includes(value.toLowerCase())
    );

    return (
        <div>
            {filteredUsers?.length > 0 && <>
                <Divider className="!my-[7px]" />
                <p className='text-[#90A4AE] text-[12px] mb-2 font-semibold'>People</p>
                <div className='ml-1 flex gap-2 my-4'>
                    {filteredUsers?.map((user) => (
                        <UserInsightsActivity record={user}/>
                    ))}
                </div>
            </>
            }
        </div>
    );
}

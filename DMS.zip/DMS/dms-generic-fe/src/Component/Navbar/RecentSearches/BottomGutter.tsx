import { Divider } from "antd";
import People from "../PeopleTab/People";
import RecentHistory from "./History/RecentHistory";
import Files from "./FilesSeaches.tsx/Files";

export default function BottomGutter({ isLoading, results, onSearch, value , setOpen}: any) {
    return (
        <div>
            <Files isLoading={isLoading} results={results} onSearch={onSearch} value={value} setOpen={setOpen}/>
            <People value={value} />
            <Divider className="!my-[7px]" />
            <p className='text-[#90A4AE] text-[12px] mb-2 font-semibold'>Recent Search</p>
            <RecentHistory />
        </div>
    )
}

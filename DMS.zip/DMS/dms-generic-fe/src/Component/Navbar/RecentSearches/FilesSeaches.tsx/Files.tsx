import { LoadingOutlined } from '@ant-design/icons';
import { Spin } from 'antd';
import { GetIconCustomHeight } from '../../../../Constants/Functions/fileIcon';
import { formatTimeAgo } from '../../../../Constants/Functions/function';
import PathBread from './PathBread';
import { useNavigate } from 'react-router-dom';
import { useDMSHooks } from '../../../../Redux/Store/Provider';

export default function Files({ isLoading, results, onSearch, value, setOpen }: any) {
    const navigate = useNavigate()
    const { setSearchTerm } = useDMSHooks()
    return (
        <div className='mb-4'>
            <p className='text-[#90A4AE] text-[12px] mb-2 font-semibold'>Files</p>
            {isLoading ? (
                <div className="flex justify-center p-2">
                    <Spin indicator={<LoadingOutlined className="text-gray-500" />} />
                </div>
            ) : (
                <>
                    {results?.length > 0 ?
                        results?.map((suggestion: any, index: any) => (
                            <div
                                key={index}
                                className="p-2 cursor-pointer hover:bg-gray-100 flex rounded-lg"
                                onClick={() => {
                                    const url = suggestion?.fileUrl?.replace(/^https?:\/\/[^/]+/, '');
                                    const lastSlashIndex = url?.lastIndexOf('/');
                                    const directoryPath = url?.substring(0, lastSlashIndex);
                                    navigate(directoryPath, { replace: true });
                                    setOpen(false);
                                    setSearchTerm(value);                                    
                                }}
                            >
                                <div className='my-auto'>
                                    {GetIconCustomHeight(suggestion?.extension, 'h-5', suggestion?.name)}
                                </div>
                                <div className='ml-2 w-full'>
                                    <p className='text-[11px] font-semibold'>{suggestion?.name}</p>
                                    <p className='text-[10px] text-[#78909C]'>Uploaded by - {suggestion?.author} - {formatTimeAgo(suggestion?.date)}</p>
                                    <PathBread path={suggestion?.fileUrl} />
                                </div>
                            </div>
                        )) : <p className='text-[#B0BEC5] text-xs mb-2 mt-3'>No Results found for "{value}"</p>}
                </>
            )}
        </div>
    )
}

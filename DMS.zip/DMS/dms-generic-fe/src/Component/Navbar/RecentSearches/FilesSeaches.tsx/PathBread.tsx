import React from 'react';
import { Breadcrumb } from 'antd';

interface PathBreadProps {
    path: string;
}

const PathBread: React.FC<PathBreadProps> = ({ path }) => {
    const pathParts = path?.replace(/^https?:\/\/[^/]+/, '')?.split('/')?.filter(Boolean);

    return (
        <Breadcrumb className='text-[10px] rounded-sm mt-[2px]'>
            {pathParts?.slice(0, pathParts?.length - 1)?.map((part, index) => (
                <p key={index} className='font-semibold'>
                    {part} {"/"}
                </p>
            ))}
        </Breadcrumb>
    );
};

export default PathBread;

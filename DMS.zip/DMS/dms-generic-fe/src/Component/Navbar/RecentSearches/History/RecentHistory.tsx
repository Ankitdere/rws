import { useEffect } from "react";
import { useDMSHooks } from "../../../../Redux/Store/Provider";
import { HistoryOutlined } from "@ant-design/icons";

export default function RecentHistory() {
    const { RecentSearches } = useDMSHooks();
    useEffect(() => {
    }, [RecentSearches]);
    return (
        <div>
            {RecentSearches && RecentSearches.length > 1 ? (
                <div>
                    {RecentSearches?.slice(1,RecentSearches?.length)?.map((item:any, index:any) => (
                        <div key={index} className="flex items-center my-1">
                            <HistoryOutlined className="ml-1 text-[#90A4AE]" />
                            <p className="ml-2  text-xs text-[#90A4AE]">{item}</p>
                        </div>
                    ))}
                </div>
            ) : (
                <p className="text-[#B0BEC5] text-xs mb-2">No recent searches found</p>
            )}
        </div>
    );
}

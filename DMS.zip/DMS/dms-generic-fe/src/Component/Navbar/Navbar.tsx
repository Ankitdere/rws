import { useDMSHooks } from '../../Redux/Store/Provider';
import { useEffect } from 'react';
import { DownOutlined } from '@ant-design/icons';
import { Popover, Tag, Tooltip } from 'antd';
import UserDetails from './UserPopoverContent/UserDetails';
import { useMsal } from '@azure/msal-react';
import Refresh from '../Modules/Chunks/Refresh/Refresh';
import { useLocation } from 'react-router-dom';
import SearchBar from './SearchBar';
import LogoImage from '../../Assets/DMS_Logo/Logo.png'
import { useRoles } from '../../Redux/Store/RolesProvider';
import AccessDetails from '../Modules/Chunks/AccessDetails/AccessDetails';

export const Navbar = () => {
  const { instance } = useMsal();
  const { currentuserRole, userDetails, role } = useRoles()
  const activeAccount = instance.getActiveAccount();
  const { setEmail } = useDMSHooks();
  const { searchTerm, setSearchTerm } = useDMSHooks();
  // const { fullDocs } = useDMSHooks();
  // const { setDocs } = useDMSHooks();
  const location = useLocation();

  useEffect(() => {
    if (activeAccount?.username) {
      setEmail(activeAccount.username);
    }
    //eslint-disable-next-line
  }, [activeAccount, location]);

  const onSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;
    setSearchTerm(value);
    // if (Array.isArray(fullDocs)) {
    //   const filteredDocs = fullDocs.filter(doc =>
    //     doc.name.toLowerCase().includes(value.toLowerCase())
    //   );
    //   setDocs(filteredDocs);
    // }
  };

  return (
    <div className='bg-adminNavbar flex items-center p-2 z-10' style={{ width: '100%' }}>
      <a href='/'>
      <img
        src={LogoImage}
        alt="Logo"
        className="h-8 w-8 mr-2 ml-6"
      />
      </a>
      <div className='flex justify-center items-center flex-grow mx-3'>
        {currentuserRole === "Admin" &&
          <>
            <div className='w-full max-w-lg'>
              <SearchBar
                placeholder={`Search files in ${location.pathname.split('/').filter(Boolean).length > 0 ? location.pathname.split('/').filter(Boolean).pop()?.replaceAll('7xTq9jFr3pGzK5wQ','DMS').replaceAll('%20',' ') : 'Home'}`}
                value={searchTerm}
                onChange={onSearchChange}
              />
            </div>
            <Refresh /></>
        }
      </div>
      <div className='flex flex-wrap items-center'>
        <Tooltip title={<AccessDetails role={role} />}>
          <Tag color={`${currentuserRole === "Admin" ? '#3F51B5' : `#009688`}`}>{currentuserRole}</Tag>
        </Tooltip>
        <Popover content={<UserDetails ImageUrl={userDetails?.profileImg} />} title={`Hi, ${activeAccount?.name || 'User'}`} trigger="click">
          <div className={`flex flex-wrap items-center gap-2 cursor-pointer mr-3 px-2 rounded-lg `}>
            {userDetails?.profileImg ? (
              <Tooltip title={`You are a ${currentuserRole || ''}`} overlayClassName="text-[10px]">
                <img
                  src={userDetails?.profileImg}
                  alt="Profile"
                  className="w-6 h-6 rounded-full shadow-sm hover:shadow-rws hover:scale-110 hover:custor-pointer transition"
                />
              </Tooltip>
            ) : (
              <div className="w-6 h-6 flex items-center justify-center rounded-full border border-gray-300">
                {userDetails?.profileImg}
              </div>
            )}

            <div className={`rounded-md px-1 py-1 text-[12px] font-semibold py-auto my-auto bg-transparent text-black cursor-pointer select-none`}>
              {activeAccount?.name || 'Guest'}
            </div>
            <DownOutlined className='text-blue text-[10px] my-auto' />
          </div>
        </Popover>
      </div>
    </div>
  );
};

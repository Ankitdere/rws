import React from 'react';
import { Navigate } from 'react-router-dom';
import { useDMSHooks } from '../../Redux/Store/Provider';

interface Props {
  element: React.ReactElement; 
}

const ProtectedRoute: React.FC<Props> = ({ element }) => { 
  const { email } = useDMSHooks();

  if (email && email.includes('@')) {
    return element;
  } else {
    return <Navigate to="/" replace />;
  }
};

export default ProtectedRoute;

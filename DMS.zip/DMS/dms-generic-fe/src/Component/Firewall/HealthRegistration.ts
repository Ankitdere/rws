let hasLoggedAppStatus = false;

export const AppStatusHealthRegistration = (UserDetails: any, currentUserRole: any, role: string[]) => {
    if (UserDetails && currentUserRole && role?.length > 1 && !hasLoggedAppStatus) {
        const formattedRoles = role.map((r: string) => `• ${r}`).join('');
        console.log(`\n%cGeneric DMS`, 'color:white; background:transparent; font-size:1.5rem; padding:0.15rem 0.25rem; margin: 1rem auto; font-family: arial; border-radius: 4px;font-weight: bold; text-shadow: 1px 1px 1px black;');
        console.table({
            "Application Health": 'Ok',
            'Current User role': currentUserRole,
            'Access Rights': formattedRoles,
            'Email': UserDetails?.username,
            'Name': UserDetails?.name,
            'Token' : UserDetails?.idToken,
            'Time Stamp': new Date().getTime(),
            'OS': navigator['platform'],
            'Browser': navigator['appCodeName'],
            'Language': navigator['language'],
            
        });
        hasLoggedAppStatus = true; 
    }
};

import React, { Fragment, useEffect, useState } from 'react';
import { Divider, Layout, Menu, theme } from 'antd';
import Documents from '../Modules/DocumentsLandingPage/Documents';
import { Navbar } from '../Navbar/Navbar';
import RWS from "../../Assets/RWS_Logo/RWS.L-f2a2bc55.png"
import Approval from '../Modules/Workflow/Approval';
import { useRoles } from '../../Redux/Store/RolesProvider';
import { FileOutlined, FileSyncOutlined, FilterOutlined, PullRequestOutlined, WechatWorkOutlined } from '@ant-design/icons';
import { CHAT_TOKEN, DOCUMENT_ROLES } from '../../Constants/constants';
import FilterTags from '../Modules/Chunks/Filters/Filters';
import { useDMSHooks } from '../../Redux/Store/Provider';
import DTGSpace from '../Modules/Spaces/DTG/DTG';
import ENT from '../Modules/Spaces/ENT/ENT';
import LayoutLogs from './LayoutLogs';
import ChatsDMS from '../Modules/Chat/ChatsDms';
import { useLocation } from 'react-router-dom';

const { Content, Sider } = Layout;

const LayoutAdmin: React.FC = () => {
  const { role, currentuserRole } = useRoles();
  const { docs, selectedKey, setSelectedKey } = useDMSHooks();
  const [collapsed, setCollapsed] = useState(false);
  const [showFilterTags, setShowFilterTags] = useState(false);
  const [isSmallScreen, setIsSmallScreen] = useState(false);
  const location = useLocation();
  const {
    token: { colorBgContainer, borderRadiusLG },
  } = theme.useToken();

  const handleMenuClick = (key: string) => {
    setSelectedKey(key);
  };


  const showDocumentsTab = role?.some(r => DOCUMENT_ROLES?.includes(r));
  const menuItems = [
    ...(showDocumentsTab
      ? [
        {
          key: '1',
          icon: React.createElement(FileOutlined),
          label: 'Documents',
        },
      ]
      : []),
    ...(role?.includes('Approve') || role?.includes('Reject')
      ? [
        {
          key: '2',
          icon: React.createElement(PullRequestOutlined),
          label: 'Workflow',
        },
      ]
      : []),
    ...(role?.includes('Logs')
      ? [
        {
          key: '7',
          icon: React.createElement(FileSyncOutlined),
          label: 'Logs',
        },
      ]
      : []),
    ...(role?.includes('Chat')
      ? [
        {
          key: '8',
          icon: React.createElement(WechatWorkOutlined),
          label: 'Chat',
        },
      ]
      : []),
  ];
  const spaceItems = [
    ...(showDocumentsTab
      ? [
        {
          key: '5',
          icon: React.createElement(FileOutlined),
          label: 'DTG',
        },
        {
          key: '6',
          icon: React.createElement(FileOutlined),
          label: 'Enterprise',
        },
      ]
      : []),
  ];

  const renderContent = () => {
    switch (selectedKey) {
      case '1':
        return <Documents />;
      case '2':
        return <Approval />;
      case '5':
        return <DTGSpace />
      case '6':
        return <ENT />
      case '7':
        return <LayoutLogs />
      case '8':
        return <ChatsDMS />
      default:
        return <Documents />;
    }
  };
  useEffect(() => {
    if (currentuserRole === 'Approver' && selectedKey !== '2') {
      setSelectedKey('2');
    }
    if (location?.pathname?.includes(CHAT_TOKEN)) {
      setSelectedKey('8')
    }
    //eslint-disable-next-line
  }, [currentuserRole,]);

  const toggleSidebar = () => {
    if (isSmallScreen) {
      setCollapsed(!collapsed);
      setShowFilterTags(collapsed);
    };
  }

  return (
    <Fragment>
      <Layout style={{ minHeight: '100vh' }}>
        <Navbar />
        <Layout>
          <Sider
            collapsible={isSmallScreen}
            collapsed={collapsed}
            breakpoint="lg"
            collapsedWidth="50"
            onClick={toggleSidebar}
            onBreakpoint={(broken) => {
              if (broken) {
                setIsSmallScreen(true);
                setCollapsed(true);
                setShowFilterTags(false);
              } else {
                setIsSmallScreen(false);
                setCollapsed(false);
                setShowFilterTags(true);
              }
            }}
          >
            <Menu
              className='bg-[#ECEFF1] min-h-[100%]'
              mode='inline'
              theme='light'
              defaultSelectedKeys={['1']}
              selectedKeys={[selectedKey]}
            >
              {menuItems?.map((item) => (
                <Menu.Item
                  key={item.key}
                  icon={item.icon}
                  onClick={() => handleMenuClick(item.key)}
                  className={`${selectedKey === item.key ? 'bg-adminNavbar' : 'bg-transparent'} text-[#212121] rounded-md outline-none`}
                >
                  {item.label}
                </Menu.Item>

              ))}
              {showFilterTags && spaceItems && <Divider children={<p className='text-[14px] text-white'>Groups</p>} rootClassName='bg-rws' />}
              <>{spaceItems?.map((item: any) => (
                <Menu.Item
                  key={item.key}
                  disabled={true}
                  icon={<img src={RWS} alt={"rws"} className='h-4 w-4' />}
                  onClick={() => handleMenuClick(item.key)}
                  className={`${selectedKey === item.key ? 'bg-adminNavbar' : 'bg-transparent'} text-[#212121] rounded-md`}
                >
                  {item.label}
                </Menu.Item>
              ))}</>
              {docs && role?.includes('FileList') && selectedKey === '1' && (
                <>
                  {docs?.some(doc => (doc as any).keywords && (doc as any).keywords?.length > 0) && (
                    <>
                      {showFilterTags && <Divider children={<p className='text-[14px] text-white '>Actions</p>} rootClassName=' bg-[#3F51B5]' />}
                      <div className="hidden lg:block">
                        <FilterTags />
                      </div>
                      {!showFilterTags && (
                        <Menu.Item
                          className="block lg:hidden"
                          icon={<FilterOutlined />}
                          onClick={toggleSidebar}
                        />
                      )}
                      {showFilterTags && (
                        <div className="block lg:hidden">
                          <FilterTags />
                        </div>
                      )}
                    </>
                  )}
                </>
              )}
            </Menu>
          </Sider>
          <Layout style={{ padding: '0 24px 24px' }}>
            <Content style={{ margin: '24px 16px 0' }}>
              <div
                style={{
                  padding: 24,
                  minHeight: 360,
                  background: colorBgContainer,
                  borderRadius: borderRadiusLG,
                }}
              >
                {renderContent()}
              </div>
            </Content>
          </Layout>
        </Layout>
      </Layout>
    </Fragment>
  );
};

export default LayoutAdmin;

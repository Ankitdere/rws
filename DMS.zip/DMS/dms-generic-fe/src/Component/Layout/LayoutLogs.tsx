import { Fragment, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import LogsList from '../Modules/Logs/TableList/LogsList';

export default function LayoutLogs() {
    const navigate = useNavigate();

    useEffect(() => {
        navigate('/', { replace: false });
    }, [navigate]);

    return (
        <Fragment>
            <div className='flex flex-wrap gap-2'>
                <p className='text-[30px] font-semibold mb-3 text-[#424242]'>Logs</p>
                <div className='flex flex-col items-end justify-end mb-5'>
                <p className='px-2 rounded-md border border-green-500 text-green-500 font-semibold flex flex-wrap gap-1'>Realtime <p className='bg-green-500 h-2 w-2 my-auto animate-pulse rounded-full'></p></p>
                </div>
            </div>
            <LogsList />
        </Fragment>
    )
}

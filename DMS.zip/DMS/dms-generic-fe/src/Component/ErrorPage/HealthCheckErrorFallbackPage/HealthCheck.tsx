import { useState, useEffect } from "react";
import { checkHealth } from '../../../ServiceUtils/Services/api'
import { Result } from "antd";
import { ERROR_CORE_SERVICE_DESC } from "../../../Constants/constants";
import LogoHealthError from "./LogoHealthError/LogoHealthError";

const HealthCheck = ({ onProceed }: { onProceed: () => void }) => {
  const [isModalVisible, setIsModalVisible] = useState(false);
  useEffect(() => {
    const checkServiceHealth = async () => {
      const isHealthy = await checkHealth();
      if (!isHealthy) {
        setIsModalVisible(true);
      } else {
        onProceed();
      }
    };

    checkServiceHealth();
    // eslint-disable-next-line
  }, []);


  if (!isModalVisible) {
    return null;
  }

  return (
    <Result
      icon={<LogoHealthError/>}
      title="Core Services Failed"
      subTitle={<p className="font-[400]">{ERROR_CORE_SERVICE_DESC}</p>}
    />
  );

};

export default HealthCheck;

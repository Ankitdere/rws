import { SyncOutlined } from '@ant-design/icons'
import DMS from '../../../../Assets/DMS_Logo/LogoError.png'

export default function LogoHealthError() {
    return (
        <div className="flex justify-center">
            <img src={DMS} alt="LOGO" className='h-20 animate-pulse'/>
            <div className='flex flex-col justify-center'>
            <p className=' z-50 ml-[-90px]'><SyncOutlined className='text-red-500 text-[20px] mt-1' spin/></p>
            </div>
        </div>
    )
}

import { Alert } from 'antd'

export default function ErrorPage() {
  return (
    <a href='/'>
      <Alert message="You landed wrong please Click here to Go to Login" type="warning" />
    </a>
  )
}

import { message, notification } from "antd";
import { getBaseUrl } from "../../Constants/Functions/function";
import { capitalizeFirstLetter, getClassNames } from "../../Constants/utils";
import { UserOutlined } from "@ant-design/icons";

const buildPathQuery = (path: string): string => {
  const parts = path.split('/').filter(Boolean);
  const queries = ['geo', 'year', 'month', 'empId'];
  const queryParams = parts.map((part, index) => `${queries[index]}=${part}`).join('&');
  return queryParams ? `?${queryParams}` : '';
};

export const getDocuments = async (path: string) => {
  try {
    const fullPath = path === '/' ? '' : buildPathQuery(path);
    const response = await fetch(`${getBaseUrl()}/api/s3/list${fullPath}`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      console.error('Failed to fetch documents:', response.statusText);
      return false;
    }

    return await response.json();
  } catch (error) {
    console.error('Error fetching documents:', error);
    return false;
  }
};
export const getUserRoles = async () => {
  try {
    const response = await fetch(`${getBaseUrl()}/api/user/userList`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      console.error('Failed to fetch documents:', response.statusText);
      return false;
    }
    return await response.json();
  } catch (error) {
    console.error('Error fetching documents:', error);
    return false;
  }
};

export const getTextContentDocument = async (fileurl: string) => {
  try {
    const response = await fetch(`${getBaseUrl()}/api/s3/content?fileurl=${fileurl}`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      console.error('Failed to fetch content from a document:', response.statusText);
      return false;
    }
    let Content = await response.json()
    return await Content?.content;
  } catch (error) {
    console.error('Error fetching content:', error);
    return false;
  }
};
export const getAIResponse = async (DocContent: string) => {
  try {
    const response = await fetch(`${getBaseUrl()}/AI/dmsBot?query='Summarize this Content and give me summary -: ${DocContent}'`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      console.error('Failed AI', response.statusText);
      return false;
    }

    return await response.json();
  } catch (error) {
    console.error('Error AI:', error);
    return false;
  }
};
export const getAIOverview = async (Messages: string) => {
  try {
    const response = await fetch(`${getBaseUrl()}/AI/dmsBot?query='Be a part of Conversation and tell us something -: ${Messages}'`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      console.error('Failed AI', response.statusText);
      return false;
    }

    return await response.json();
  } catch (error) {
    console.error('Error AI:', error);
    return false;
  }
};


export const getLogs = async (email: any) => {
  try {
    const response = await fetch(`${getBaseUrl()}/getLogs`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ email })
    });

    if (response.status === 200) {
      const data = await response.json();
      return data;
    } else {
      return false;
    }
  } catch (error) {
    console.error('Error:', error);
    return false;
  }
};
export const fetchChatFromDB = async () => {
  try {
    const response = await fetch(`${getBaseUrl()}/api/user/getChats`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      },
    });

    if (response.status === 200) {
      const data = await response.json();
      return data;
    } else {
      return false;
    }
  } catch (error) {
    console.error('Error:', error);
    return false;
  }
};

export const deleteDocuments = async (email: string, files: string[]) => {
  try {
    const response = await fetch(`${getBaseUrl()}/deleteFiles`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, files }),
    });

    if (!response.ok) {
      throw new Error('Failed to delete documents');
    }

    return await response.json();
  } catch (error) {
    console.error('Error deleting documents:', error);
    throw error;
  }
};
export const DeleteMessages = async (id:any) => {
  try {
    const response = await fetch(`${getBaseUrl()}/api/user/deleteChat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ id }),
    });

    if (!response.ok) {
      return false
    }

    return true
  } catch (error) {
    console.error('Error deleting documents:', error);
    throw error;
  }
};

export const updateImage = async (formData: FormData) => {
  try {
    const response = await fetch(`${getBaseUrl()}/api/user/updateImage`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error('Failed to update image');
    }

    return await response.json();
  } catch (error) {
    console.error('Error updating image:', error);
    throw error;
  }
};


export const downloadFile = async (email: string, fileName: string) => {
  try {
    const response = await fetch(`${getBaseUrl()}/downloadFile`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, fileName }),
    });

    if (!response.ok) {
      throw new Error('Failed to download file');
    }

    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    return url;
  } catch (error) {
    console.error('Error downloading file:', error);
    throw error;
  }
};


export const getCurrentRoleOfferings = async () => {
  try {
    const response = await fetch(`${getBaseUrl()}/api/user/getRolesDetails`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    });
    if (response.status === 200) {
      const data = await response.json();
      return data;
    } else {
      return false;
    }
  } catch (error) {
    console.error('Error:', error);
    return false;
  }
};

export const FetchApprovalPendingList = async () => {
  try {
    const response = await fetch(`${getBaseUrl()}/api/s3/userRequestList`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    });
    if (response.status === 200) {
      const data = await response.json();
      return data;
    } else {
      message.error('Failed to fetch Pending Approvals')
      return false;
    }
  } catch (error) {
    message.error('Failed to fetch Pending Approvals')
    console.error('Error:', error);
    return false;
  }
};
export const FetchLogsEvent = async () => {
  try {
    const response = await fetch(`${getBaseUrl()}/api/s3/Logs`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    });
    if (response.status === 200) {
      const data = await response.json();
      return data;
    } else {
      message.error('Failed to fetch Pending Approvals')
      return false;
    }
  } catch (error) {
    message.error('Failed to fetch Pending Approvals')
    console.error('Error:', error);
    return false;
  }
};

export const ExportLogs = async () => {
  try {
    const response = await fetch(`${getBaseUrl()}/api/s3/ExportLogs`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    });

    if (response.status === 200) {
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');

      a.style.display = 'none';
      a.href = url;
      a.download = 'logs.csv';

      document.body.appendChild(a);
      a.click();

      window.URL.revokeObjectURL(url);
      a.remove();
    } else {
      console.log('Failed to fetch logs');
    }
  } catch (error) {
    console.error('Error:', error);
  }
};


export const createFolder = async (folderName: string, path: string,
  author: string,
  date: string,
  email: string
) => {
  try {
    const response = await fetch(`${getBaseUrl()}/api/s3/create`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ folderName, path, author, date, email }),
    });

    if (!response.ok) {
      console.error('Failed to create folder:', response.statusText);
      return false;
    }

    return await response.json();
  } catch (error) {
    console.error('Error creating folder:', error);
    return false;
  }
};

export const updateRoles = async (role: any) => {
  try {
    const response = await fetch(`${getBaseUrl()}/api/user/updateRoleDetails`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(role),
    });

    if (!response.ok) {
      console.error('Failed to Update Roles Access:', response.statusText);
      message.error('Failed to Update Roles Access')
      return false;
    }
    notification.success({
      icon: <UserOutlined className="text-green-500"/>,
      message: "Got you !",
      description: `We have changed the Roles, will be effective from now on, Thank You `,
      className: getClassNames('success'),placement:'bottomRight',
    });
    return await response.json();
  } catch (error) {
    notification.error({
      icon: <UserOutlined className="text-red-500"/>,
      message: "Error",
      description: `please try again, something went wrong `,
      className: getClassNames('error'),placement:'bottomRight',
    });
    console.error('Error creating folder:', error);
    return false;
  }
};
export const MapNewUserApi = async (userName: string, role: string, isNewUser: boolean, name: string, profileImg: string) => {
  try {
    const response = await fetch(`${getBaseUrl()}/api/user/establishUser`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ userName, role, name, profileImg }),
    });

    if (!response.ok) {
      console.error('Failed to map user details:', response.statusText);
      message.error('Failed to map user details');
      return false;
    }

    isNewUser
      ? message.success(`Created New User - ${userName} and Role assigned - ${role}`)
      : message.success(`Role changed for ${userName} successfully`);

    return await response.json();
  } catch (error) {
    console.error('Error creating folder:', error);
    return false;
  }
};
export const ExecuteRequest = async (
  requestType: 'approve' | 'reject',
  requestFor: 'upload' | 'delete',
  fileUrl: string,
  fileType: string,
  id: string,
  author: string,
  username: string,
  comment:string
): Promise<any> => {
  try {
    const payload = {
      author,
      username,
      requestData: [
        {
          id,
          fileType,
          fileUrl,
          requestType,
          requestFor,
          comment
        },
      ],
    };

    const response = await fetch(`${getBaseUrl()}/api/s3/userRequest`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      console.error('Failed to execute request:', response.statusText);
      // notification.warning({
      //   icon: <ExceptionOutlined className="text-warning" />,
      //   message: "Failed to execute request",
      //   description: `Please try again later, maybe we have encountered with an error `,
      //   className: getClassNames('warning'),
      //   placement:'bottomRight',
      // });
      return false;
    }
    // notification.success({
    //   icon: <FileDoneOutlined className="text-green-500" />,
    //   message: capitalizeFirstLetter(requestType) || "",
    //   description: `You have ${capitalizeFirstLetter(requestType)} this Request to ${capitalizeFirstLetter(requestFor)}.`,
    //   className: getClassNames('success'),placement:'bottomRight',
    // })
    return `You have ${capitalizeFirstLetter(requestType)} this Request to ${capitalizeFirstLetter(requestFor)}.`;
  } catch (error) {
    console.error('Error executing request:', error);
    // notification.error({
    //   icon: <ExceptionOutlined className="text-red-500" />,
    //   message: "Failed to execute request",
    //   description: `Please try again later, maybe we have encountered with an error `,
    //   className: getClassNames('error'),placement:'bottomRight',
    // });
    return false;
  }
};



export const uploadFile = async (
  file: File,
  author: string,
  date: string,
  email: string,
  path: string
): Promise<any> => {
  try {
    const formData = new FormData();
    formData.append("file", file);
    formData.append("author", author);
    formData.append("date", date);
    formData.append("email", email);
    formData.append("path", path.replaceAll('%20', ' '));

    const response = await fetch(`${getBaseUrl()}/api/s3/uploadRequested`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error('Failed to upload file');
    }

    return await response.json();
  } catch (error) {
    console.error('Error uploading file:', error);
    throw error;
  }
};

export interface FileToDelete {
  fileName: string;
  path: string;
}

export const deleteFiles = async (filesToDelete: FileToDelete[], userName: string, name: string) => {
  try {
    const payload = {
      author: name,
      username: userName,
      requestData: filesToDelete.map(file => ({
        fileName: file.fileName,
        path: file.path,
      })),
    };

    const response = await fetch(`${getBaseUrl()}/api/s3/delete/request`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      console.error('Failed to delete files:', response.statusText);
      return false;
    }

    return await response.json();
  } catch (error) {
    console.error('Error deleting files:', error);
    return false;
  }
};

export interface FilesToDownload {
  fileName: string;
  path: string;
  type: string;
}

export const downloadFiles = async (filesToDownload: FilesToDownload[]) => {
  try {
    const payload = filesToDownload.map(file => ({
      fileName: file.fileName,
      path: file.path,
      type:file.type
    }));

    const response = await fetch(`${getBaseUrl()}/api/s3/downloads`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    })

    if (!response.ok) {
      console.error('Failed to download files:', response.statusText);
      return false
    }
    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', filesToDownload?.length > 1 ? 'SelectedFiles' : filesToDownload[0]?.fileName);
    document.body.appendChild(link);
    link.click();
    link.parentNode?.removeChild(link);
    return true
  } catch (error) {
    console.error('Error downloading files:', error);
    return false
  }
}
export const checkHealth = async () => {
  try {
    const response = await fetch(`${getBaseUrl()}/api/health`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    if (response.status === 200) {
      return true;
    } else {
      return false;
    }
  } catch (error) {
    console.error('Error checking health:', error);
    return false; 
  }
};

//Advanced Search
export const AdvancedSearch = async (query:string) => {
  try {
    const payload = {
      query: query
    };

    const response = await fetch(`${getBaseUrl()}/api/es/search`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      console.error('Failed to Crawl File:', response.statusText);
      return false;
    }

    return await response.json();
  } catch (error) {
    console.error('Error Crawling files:', error);
    return false;
  }
};







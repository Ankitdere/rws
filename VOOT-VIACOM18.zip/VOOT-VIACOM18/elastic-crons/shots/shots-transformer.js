/* eslint-disable prefer-destructuring */
/* eslint-disable max-len */
/* eslint-disable no-unused-vars */
const shots = require('../v3ResponseTypes').getResponseType('shots');

const maxSeason = 99999;
const maxEpisode = 99999;
const seasons = ['s0', 's1', 's2', 's3', 's4', 's5', 's6', 's7', 's8', 's9', 's00', 's01', 's02', 's03', 's04', 's05', 's06', 's07', 's08', 's09', 's10', 's11', 's12', 's13', 's14', 's15', 's16', 's17', 's18', 's19', 's20', 's21', 's22', 's23', 's24', 's25', 's26', 's27', 's28', 's29', 's30', 's31', 's32', 's33', 's34', 's35', 's36', 's37', 's38', 's39', 's40', 's41', 's42', 's43', 's44', 's45', 's46', 's47', 's48', 's49', 's50', 's51', 's52', 's53', 's54', 's55', 's56', 's57', 's58', 's59', 's60', 's61', 's62', 's63', 's64', 's65', 's66', 's67', 's68', 's69', 's70', 's71', 's72', 's73', 's74', 's75', 's76', 's77', 's78', 's79', 's80', 's81', 's82', 's83', 's84', 's85', 's86', 's87', 's88', 's89', 's90', 's91', 's92', 's93', 's94', 's95', 's96', 's97', 's98', 's99', 's100',
  'season0', 'season1', 'season2', 'season3', 'season4', 'season5', 'season6', 'season7', 'season8', 'season9', 'season00', 'season01', 'season02', 'season03', 'season04', 'season05', 'season06', 'season07', 'season08', 'season09', 'season10', 'season11', 'season12', 'season13', 'season14', 'season15', 'season16', 'season17', 'season18', 'season19', 'season20', 'season21', 'season22', 'season23', 'season24', 'season25', 'season26', 'season27', 'season28', 'season29', 'season30', 'season31', 'season32', 'season33', 'season34', 'season35', 'season36', 'season37', 'season38', 'season39', 'season40', 'season41', 'season42', 'season43', 'season44', 'season45', 'season46', 'season47', 'season48', 'season49', 'season50', 'season51', 'season52', 'season53', 'season54', 'season55', 'season56', 'season57', 'season58', 'season59', 'season60', 'season61', 'season62', 'season63', 'season64', 'season65', 'season66', 'season67', 'season68', 'season69', 'season70', 'season71', 'season72', 'season73', 'season74', 'season75', 'season76', 'season77', 'season78', 'season79', 'season80', 'season81', 'season82', 'season83', 'season84', 'season85', 'season86', 'season87', 'season88', 'season89', 'season90', 'season91', 'season92', 'season93', 'season94', 'season95', 'season96', 'season97', 'season98', 'season99', 'season100'];
const episodes = ['e0', 'e1', 'e2', 'e3', 'e4', 'e5', 'e6', 'e7', 'e8', 'e9', 'e00', 'e01', 'e02', 'e03', 'e04', 'e05', 'e06', 'e07', 'e08', 'e09', 'e10', 'e11', 'e12', 'e13', 'e14', 'e15', 'e16', 'e17', 'e18', 'e19', 'e20', 'e21', 'e22', 'e23', 'e24', 'e25', 'e26', 'e27', 'e28', 'e29', 'e30', 'e31', 'e32', 'e33', 'e34', 'e35', 'e36', 'e37', 'e38', 'e39', 'e40', 'e41', 'e42', 'e43', 'e44', 'e45', 'e46', 'e47', 'e48', 'e49', 'e50', 'e51', 'e52', 'e53', 'e54', 'e55', 'e56', 'e57', 'e58', 'e59', 'e60', 'e61', 'e62', 'e63', 'e64', 'e65', 'e66', 'e67', 'e68', 'e69', 'e70', 'e71', 'e72', 'e73', 'e74', 'e75', 'e76', 'e77', 'e78', 'e79', 'e80', 'e81', 'e82', 'e83', 'e84', 'e85', 'e86', 'e87', 'e88', 'e89', 'e90', 'e91', 'e92', 'e93', 'e94', 'e95', 'e96', 'e97', 'e98', 'e99', 'e100',
  'episode0', 'episode1', 'episode2', 'episode3', 'episode4', 'episode5', 'episode6', 'episode7', 'episode8', 'episode9', 'episode00', 'episode01', 'episode02', 'episode03', 'episode04', 'episode05', 'episode06', 'episode07', 'episode08', 'episode09', 'episode10', 'episode11', 'episode12', 'episode13', 'episode14', 'episode15', 'episode16', 'episode17', 'episode18', 'episode19', 'episode20', 'episode21', 'episode22', 'episode23', 'episode24', 'episode25', 'episode26', 'episode27', 'episode28', 'episode29', 'episode30', 'episode31', 'episode32', 'episode33', 'episode34', 'episode35', 'episode36', 'episode37', 'episode38', 'episode39', 'episode40', 'episode41', 'episode42', 'episode43', 'episode44', 'episode45', 'episode46', 'episode47', 'episode48', 'episode49', 'episode50', 'episode51', 'episode52', 'episode53', 'episode54', 'episode55', 'episode56', 'episode57', 'episode58', 'episode59', 'episode60', 'episode61', 'episode62', 'episode63', 'episode64', 'episode65', 'episode66', 'episode67', 'episode68', 'episode69', 'episode70', 'episode71', 'episode72', 'episode73', 'episode74', 'episode75', 'episode76', 'episode77', 'episode78', 'episode79', 'episode80', 'episode81', 'episode82', 'episode83', 'episode84', 'episode85', 'episode86', 'episode87', 'episode88', 'episode89', 'episode90', 'episode91', 'episode92', 'episode93', 'episode94', 'episode95', 'episode96', 'episode97', 'episode98', 'episode99', 'episode100'];
const extras = [...seasons, ...episodes];
module.exports = (obj, show) => {
  const meta = obj.meta || {};
  const details = obj.details || {};
  const stats = obj.stats || {};
  const resp = shots.transform(obj);
  const showId = resp.showId;
  const showName = resp.showName;
  const disabled = !!obj.disabled;
  let rankingType = 50;
  let episodeInt;
  let seasonInt;
  let showTitle;
  const keywords = meta.keywords || [];
  let extraKeywords;
  if (resp.episode && !Number.isNaN(resp.episode)) {
    episodeInt = parseFloat(resp.episode);
  }
  if (resp.season && !Number.isNaN(resp.season)) {
    seasonInt = parseFloat(resp.season);
  }
  if (details.mediaType === 'SHOTS' || details.mediaType === 'CONTAINER') {
    rankingType = 20;
  }
  delete resp.mediaVariants;
  return {
    ...resp,
    rankingType,
    keywords,
    availability: obj.availability,
    objectID: `${obj.id}`,
    disabled,
    episodeInt,
    seasonInt,
    showId,
    showName,
    showTitle,
    extraKeywords,
  };
};

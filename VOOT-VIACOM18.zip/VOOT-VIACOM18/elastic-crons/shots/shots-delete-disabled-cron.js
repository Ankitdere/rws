/* eslint-disable no-await-in-loop */
const log = require('logger-v18');
const sleep = require('util').promisify(setTimeout);
const elasticClient = require('../modules/elasticClient');
const storageClient = require('../modules/storageClient');
const algoliaClient = require('../modules/algoliaClient');
const recoClient = require('../modules/reco');

const { logger } = log;

exports.invoke = async () => {
  try {
    log.init({
      json: JSON.parse(process.env.logJson), service: 'shots-delete-disabled-cron', tags: ['crons'], level: process.env.logLevel,
    });
    logger.log('connecting to elastic search');
    await elasticClient.init();
    const { name } = process.env;
    const toTime = parseInt(new Date().getTime() / 1000, 10);
    let fromTime = (await storageClient.getCronConfig(name)).lastProcessedTime;
    // fromTime = 0;
    let keepGoing = true;
    while (keepGoing) {
      logger.log({
        fromTime,
        toTime,
        fromTimeStr: new Date(fromTime * 1000),
        toTimeStr: new Date(toTime * 1000),
      });

      /*
        Assets whose availability was changed cannot be differentiated from other assets which
        were revised and their availability starts in the future. This resulted in an avg of 30
        assets being deleted every hour (assets which dont even exist in algolia). This counts
        towards the budget of allowed operations per month in Algolia. It is easier to manually
        delete the one asset whose availability was changed in Algolia, than doing this via code.
        Thus, this is being removed from the logic below.
      */
      const disabledAssets = await elasticClient.getDisabledShotsInRange(fromTime, toTime);
      // const assetsAvailabilityChanged = await elasticClient.getAvailabilityChangedAssetsInRange(fromTime, toTime);
      const beyondEndDateAssets = await elasticClient.getShotsBeyondEndDate(fromTime, toTime);
      // const documents = [...disabledAssets, ...assetsAvailabilityChanged, ...beyondEndDateAssets];
      const documents = [...disabledAssets, ...beyondEndDateAssets];
      logger.log('disabledAssets total length', disabledAssets.length);
      // logger.log('assetsAvailabilityChanged total length', assetsAvailabilityChanged.length);
      // logger.log('assetsAvailabilityChanged', JSON.stringify(assetsAvailabilityChanged));
      logger.log('beyondEndDateAssets total length', beyondEndDateAssets.length);
      logger.log('beyondEndDateAssets', JSON.stringify(beyondEndDateAssets));

      if (documents.length <= 0) {
        logger.info('no documents to process, exiting');
        return {};
      }
      logger.info(`got total documents ${documents.length} deleting in algolia`);
      const assetIds = documents.map((item) => item.id);

      await algoliaClient.deleteDocuments(assetIds);
      const resp = await recoClient.updateDisabled(assetIds);

      logger.info('assets sent to reco for disabling', resp);
      logger.info('documents deleted from algolia');

      const { revised } = documents[documents.length - 1];
      await storageClient.updateLastProcessedTime(name, revised);
      fromTime = revised;
      keepGoing = documents.length === elasticClient.MAX_DOCUMENTS;
      if (keepGoing) {
        await sleep(2000);
      }
    }
  } catch (error) {
    logger.error('ERROR', Object.keys(error).length ? JSON.stringify(error) : error);
    // throw err;
  }
  return {};
};

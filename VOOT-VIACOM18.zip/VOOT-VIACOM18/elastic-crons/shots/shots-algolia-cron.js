/* eslint-disable no-await-in-loop */
const log = require('logger-v18');
const sleep = require('util').promisify(setTimeout);
const elasticClient = require('../modules/elasticClient');
const storageClient = require('../modules/storageClient');
const transformer = require('./shots-transformer');
const algoliaClient = require('../modules/algoliaClient');

const { logger } = log;

exports.invoke = async () => {
  try {
    log.init({
      json: JSON.parse(process.env.logJson), service: 'shots/algolia-cron', tags: ['crons'], level: process.env.logLevel,
    });
    logger.log('connecting to elastic search');
    await elasticClient.init();
    const { configFileName } = process.env;
    const toTime = parseInt(new Date().getTime() / 1000, 10);
    let fromTime = (await storageClient.getCronConfig(configFileName)).lastProcessedTime;
    // fromTime = 0;
    let keepGoing = true;
    while (keepGoing) {
      logger.log({
        fromTime,
        toTime,
        fromTimeStr: new Date(fromTime * 1000),
        toTimeStr: new Date(toTime * 1000),
      });

      const updatedDocuments = await elasticClient.getUpdatedShotsDocuments(fromTime, toTime);
      const recentlyPublished = await elasticClient.getRecentlyPublishedShotsDocuments(fromTime, toTime);
      const documents = [...updatedDocuments, ...recentlyPublished];
      logger.log('recentlyPublished total documents', recentlyPublished.length);
      logger.log('recentyPublished', JSON.stringify(recentlyPublished.map((asset) => asset.id)));
      logger.log('updated documents total length', updatedDocuments.length);

      if (documents.length <= 0) {
        logger.info('no documents to process, exiting');
        return;
      }

      logger.info(`got total documents ${documents.length} inserting in algolia`);
      const showList = await elasticClient.getShowDetailsMap(documents);

      // eslint-disable-next-line no-loop-func
      const assets = documents.map((obj) => {
        if (obj.meta) {
          if (obj.meta.showId) {
            return transformer(obj, showList[`${obj.meta.showId}`]);
          } if (obj.meta.series && obj.meta.series.showId) {
            return transformer(obj, showList[`${obj.meta.series.showId}`]);
          }
        }
        return transformer(obj);
      });
      await algoliaClient.saveDocuments(assets);
      logger.info('documents inserted in algolia');
      const { revised } = documents[documents.length - 1];
      await storageClient.updateLastProcessedTime(configFileName, revised);
      fromTime = revised;
      keepGoing = documents.length === elasticClient.MAX_DOCUMENTS;
      if (keepGoing) {
        await sleep(2000);
      }
    }
    return;
  } catch (error) {
    logger.error('ERROR', Object.keys(error).length ? JSON.stringify(error) : error);
    // throw err;
  }
};

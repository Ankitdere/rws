/* eslint-disable quote-props */
/* eslint-disable no-await-in-loop */
const log = require('logger-v18');
const moment = require('moment');
const elasticClient = require('../modules/elasticClient');
const emailTemplate = require('../emailTemplates/shots-stats');
const emailer = require('../modules/emailClient');

const { logger } = log;

exports.invoke = async (event) => {
  try {
    logger.log('Received event for handling :', event);
    log.init({
      json: JSON.parse(process.env.logJson), service: 'shots/stats', tags: ['crons'], level: process.env.logLevel,
    });
    logger.log('connecting to elastic search');
    await elasticClient.init();
    const date = moment().subtract(1, 'd').format('YYYY-MM-DD').toString(); // ISO format needed for moment() below
    logger.log(date);
    const startTs = moment(`${date}T00:00:01+05:30`).unix();
    logger.log(startTs);
    const endTs = moment(`${date}T23:59:59+05:30`).unix();
    logger.log(endTs);

    const statsMap = {
      getTotal: {
        label: 'Total Shots',
        esQuery: {
          query: {
            bool: {
              must: [
                {
                  match: {
                    'details.mediaType.keyword': 'SHOTS',
                  },
                },
              ],
            },
          },
          size: 0,
          track_total_hits: true,
          aggs: {
            source: {
              terms: {
                field: 'meta.video.source.keyword',
                size: 1000,
              },
            },
          },
        },
        count: 0,
        split: {}, // contains ngc,pgc - format "name:count"
      },
      getDisabled: {
        label: 'Total Disabled',
        esQuery: {
          query: {
            bool: {
              must: [
                {
                  match: {
                    'details.mediaType.keyword': 'SHOTS',
                  },
                },
                {
                  match: {
                    'disabled': true,
                  },
                },
              ],
            },
          },
          size: 0,
        },
        count: 0,
      },
      getIngested: {
        label: 'Newly Ingested',
        esQuery: {
          query: {
            bool: {
              must: [
                {
                  match: {
                    'details.mediaType.keyword': 'SHOTS',
                  },
                },
                {
                  range: {
                    ingested: {
                      gte: startTs,
                      lte: endTs,
                    },
                  },
                },
              ],
            },
          },
          size: 0,
        },
        count: 0,
      },
      getActive: {
        label: 'Total Active',
        esQuery: null,
        count: 0,
      },
    };

    // eslint-disable-next-line no-restricted-syntax
    for (const key in statsMap) {
      if (Object.hasOwnProperty.call(statsMap, key) && statsMap[key].esQuery) {
        const esResp = await elasticClient.getGeneric(statsMap[key].esQuery || '');
        statsMap[key].count = esResp.hits.total.value;
        if (esResp.aggregations) {
          esResp.aggregations.source.buckets.forEach((obj) => {
            statsMap[key].split[`${obj.key || 'EMPTY_FIELD'}`] = obj.doc_count;
          });
        }
      }
    }
    statsMap.getActive.count = statsMap.getTotal.count - statsMap.getDisabled.count;
    const html = emailTemplate.template(statsMap);
    logger.log('final email html', html);
    const date2 = moment().subtract(1, 'd').format('DD-MMM-YYYY');
    await emailer.sendShotsStatsEmail(html, date2);
  } catch (error) {
    logger.error('ERROR in shots stats', Object.keys(error).length ? JSON.stringify(error) : error);
  }
};

/* eslint-disable no-await-in-loop */
/* eslint-disable consistent-return */
const log = require('logger-v18');
const fs = require('fs');
const ISO6391 = require('iso-639-1');
const elasticClient = require('./modules/elasticClient');
const constant = require('./constant');

const { logger } = log;

const escapeMap = {
  '>': '&gt;',
  '<': '&lt;',
  "'": '&apos;',
  '"': '&quot;',
  '&': '&amp;',
};

const updateIndex = process.env.elasticLiveAssetsIndex;

function escape(string, ignore) {
  if (string === null || string === undefined) return;
  const ignoreData = (ignore || '').replace(/[^&"<>']/g, '');
  const pattern = '([&"<>\'])'.replace(new RegExp(`[${ignoreData}]`, 'g'), '');
  return string.replace(new RegExp(pattern, 'g'), (str, item) => escapeMap[item]);
}

function getDeepLink(obj) {
  const details = obj.details || {};
  const meta = obj.meta || {};
  const { jioVootBaseUrl } = constant;
  switch (details.mediaType) {
    case 'SHOW':
      return `${jioVootBaseUrl}details/show/${obj.id}`;
    case 'EPISODE':
    case 'CAC':
    case 'MOVIE':
    case 'LIVECHANNEL':
      return `${jioVootBaseUrl}playback/${obj.id}`;
    case 'CHANNEL':
      return `${jioVootBaseUrl}details/channel/${obj.id}`;
    case 'SERIES':
      return `${jioVootBaseUrl}details/show/${meta.showId}/season/${obj.id}`;
    default:
      return jioVootBaseUrl;
  }
}

function getDefaultLangugage(languages, profile = {}) {
  if (!languages || languages.length === 0) {
    return '';
  }
  const profileUrl = profile.url;
  if (languages.length === 1) {
    return languages[0];
  }
  if (profileUrl && profileUrl.indexOf('defaultAudioLang') > -1) {
    const start = profileUrl.indexOf('defaultAudioLang') + 17;
    const end = profileUrl.indexOf('/', start);
    return profileUrl.substring(start, end);
  }
  return languages[0];
}

function getXML(asset, type) {
  const details = asset.details || {};
  const { meta } = asset;
  const {
    synopsis,
    contributors,
    genres,
    releaseYear,
    languages,
  } = meta;
  const image = details.image['16x9'];
  const checkImageUrl = image.substring(image.indexOf('/') + 1);
  const imageUri = (checkImageUrl !== 'undefined') ? `http://v3img.voot.com/${details.image['16x9']}` : '';
  const offer = asset.details && ['PREMIUM', 'PREMIER'].includes(asset.details.marketType) ? 'SubscriptionOffer' : 'FreeOffer';
  const releaseYearTag = Number.isInteger(releaseYear) && releaseYear !== 0 ? `<ReleaseYear>${releaseYear}</ReleaseYear>` : '';
  const runtimeMinutes = (details.kalturaMedia && details.kalturaMedia.duration
    ? `<RuntimeMinutes>${Math.floor(details.kalturaMedia.duration / 60)}</RuntimeMinutes>` : '');
  const ftrdContributors = Array.isArray(contributors) ? contributors.filter((contributor) => contributor.length > 0 && contributor !== 'NA') : '';
  const creditsTag = Array.isArray(ftrdContributors) && ftrdContributors.length ? `
  <Credits>
    <CastMember>${ftrdContributors.map((contributor) => `
      <Name locale="en-IN">${escape(contributor)}</Name>`).join('')}
    </CastMember>
  </Credits>` : '';
  const defLanguage = (details.mediaVariants && details.mediaVariants.DASH_MOBILE
    ? getDefaultLangugage(languages, details.mediaVariants.DASH_MOBILE) : '');
  const langCode = defLanguage ? ISO6391.getCode(defLanguage) : 'hi-IN';
  const languageTag = langCode ? `<Language>${langCode}</Language>` : '';
  const audioLanguageTag = langCode ? `<AudioLanguage>${langCode}</AudioLanguage>` : '';

  return `<ID>${asset.id}_${type}</ID>
        <Title locale="en-IN">${escape(asset.meta.title.full)}</Title>
        <Offers>
          <${offer}>
            <Regions>${Object.keys(asset.availability.available).map((key) => `
              <Country>${key}</Country>`).join('')}
            </Regions>
            <LaunchDetails>
              ${audioLanguageTag}
              <LaunchId>${getDeepLink(asset)}?src=catalog</LaunchId>
            </LaunchDetails>
          </${offer}>
        </Offers>
        ${releaseYearTag}
        ${synopsis && synopsis.full ? `<Synopsis locale="en-IN">${escape(synopsis.full)}</Synopsis>` : ''}
        ${imageUri ? `<ImageUrl>${imageUri}</ImageUrl>` : ''}
        ${runtimeMinutes}
        ${creditsTag}
        ${languageTag}
        ${Array.isArray(genres) && genres.length ? `<Genres>${genres.map((genre) => `
          <Genre locale="en-IN">${escape(genre)}</Genre>`).join('')}
        </Genres>` : ''}`;
}

async function getAllSeriesForShow(_showId) {
  try {
    if (!_showId) {
      return [];
    }
    const showId = parseInt(_showId, 10);
    const res = await elasticClient.getClient().search({
      index: updateIndex,
      size: 1000,
      _source: [
        'id', 'name', 'details.marketType', 'meta.title.full', 'details.mediaType',
        'meta.genres', 'details.image', 'meta.synopsis.full', 'availability',
        'meta.showId', 'meta.season', 'meta.contributors', 'meta.releaseYear',
        'details.kalturaMedia.duration', 'meta.languages', 'details.mediaVariants.DASH_MOBILE',
      ],
      body: {
        query: {
          bool: {
            must: [
              {
                match: {
                  'details.mediaType.keyword': 'SERIES',
                },
              },
              {
                match: {
                  'meta.showId': showId,
                },
              },
            ],
          },
        },
        sort: [
          { 'meta.season': { order: 'asc' } },
        ],
      },
    });
    if (res.errors) {
      logger.error(`getAllShowsAndMovies elasticsearch response took:${res.took} errors:${res.errors} items.length:${res.items.length}`);
      if (res.items) {
        res.items.forEach((item) => {
          logger.warn(item.index.error);
        });
      }
      throw new Error(res.errors);
    }
    return res.hits.hits.map(({ _source }) => _source);
  } catch (error) {
    logger.info('Error in getAllSeriesForShow', error);
  }
}

async function getAssetXML(asset, showId) {
  try {
    switch (asset.details.mediaType) {
      case 'MOVIE':
        return `
          <Movie>
            ${getXML(asset, 'MOVIE')}
          </Movie>
          `;
      case 'SHOW': {
        // eslint-disable-next-line no-use-before-define
        const childrenShows = await getTVShowChildren(asset);
        if (!childrenShows || childrenShows === '' || childrenShows === null || typeof childrenShows === 'undefined') {
          return '';
        }
        return `
          <TvShow>
            ${getXML(asset, 'SHOW')}
          </TvShow>
          ${childrenShows}
          `;
      }
      case 'SERIES': {
        // eslint-disable-next-line no-use-before-define
        const childrenSeries = await getTVSeriesChildren(asset);
        if (!childrenSeries || childrenSeries === '' || childrenSeries === null || typeof childrenSeries === 'undefined') {
          return '';
        }
        return typeof asset.meta.season === 'number' ? `
          <TvSeason>
            ${getXML(asset, 'SERIES')}
            ${asset.meta.showId ? `<ShowID>${asset.meta.showId}_SHOW</ShowID>` : ''}
            <SeasonInShow>${asset.meta.season}</SeasonInShow>
          </TvSeason>
          ${childrenSeries}
          ` : '';
      }
      case 'EPISODE': {
        const show = asset.meta.series.showId || showId;
        return Number.isInteger(asset.meta.series.episode) ? `
          <TvEpisode>
            ${getXML(asset, 'EPISODE')}
            ${show ? `<ShowID>${show}_SHOW</ShowID>` : ''}
            <SeasonID>${asset.meta.series.id}_SERIES</SeasonID>
            <EpisodeInSeason>${(asset.meta.series.episode)}</EpisodeInSeason>
          </TvEpisode>
          ` : '';
      }
      default:
        return '';
    }
  } catch (error) {
    logger.info('Error in getAssetXML', error);
  }
}

async function getTVShowChildren(asset) {
  try {
    logger.log(`getting childrens for tvshow id:${asset.id}`);
    const series = await getAllSeriesForShow(asset.id);
    let result = '';
    // eslint-disable-next-line no-restricted-syntax
    for (const ser of series) {
      result += await getAssetXML(ser);
    }
    return result;
  } catch (error) {
    logger.log('Error in getTVShowChildren', error);
  }
}

async function xmlFormat(assets, fileName) {
  try {
    fs.writeFileSync(fileName, `<?xml version="1.0" encoding="utf-8"?>
  <Catalog xmlns="http://www.amazon.com/FireTv/2014-04-11/ingestion" version="FireTv-v1.3">
    <Partner>JIO</Partner>
    <Works>
    `);
    // eslint-disable-next-line no-restricted-syntax
    for (const [index, asset] of assets.entries()) {
      logger.info(`processing index:${index}  of total:${assets.length}`);
      const result = await getAssetXML(asset);
      fs.appendFileSync(fileName, result);
    }
    fs.appendFileSync(fileName, `
    </Works>
  </Catalog>`);
  } catch (error) {
    logger.info('Error in XML format function', error);
  }
}

async function getAllEpisodeForSeries(_seriesId) {
  try {
    if (!_seriesId) {
      return [];
    }
    const seriesId = parseInt(_seriesId, 10);
    let AllEpisodes = [];
    let res = await elasticClient.getClient().search({
      index: updateIndex,
      size: 1000,
      scroll: '15m',
      _source: [
        'id', 'name', 'details.marketType', 'meta.title.full', 'details.mediaType',
        'meta.genres', 'details.image', 'meta.synopsis.full', 'availability',
        'meta.series', 'meta.contributors', 'meta.releaseYear', 'details.kalturaMedia.duration',
        'meta.languages', 'details.mediaVariants.DASH_MOBILE',
      ],
      body: {
        query: {
          bool: {
            must: [
              {
                terms: {
                  'details.mediaType.keyword': ['EPISODE'],
                },
              },
              {
                match: {
                  'meta.series.id': seriesId,
                },
              },
            ],
          },
        },
        sort: [
          { 'meta.series.episode': { order: 'asc' } },
        ],
      },
    });
    if (res.errors) {
      logger.error(`getAllShowsAndMovies elasticsearch response took:${res.took} errors:${res.errors} items.length:${res.items.length}`);
      if (res.items) {
        res.items.forEach((item) => {
          logger.warn(item.index.error);
        });
      }
      throw new Error(res.errors);
    }
    AllEpisodes = AllEpisodes.concat(res.hits.hits);
    let keepGoing = (res.hits.hits.length === 1000);
    while (keepGoing) {
      logger.log(`SERIES:${seriesId} fetched ${AllEpisodes.length}`);
      // eslint-disable-next-line no-await-in-loop
      res = await elasticClient.getClient().scroll({
        // eslint-disable-next-line no-underscore-dangle
        scroll_id: res._scroll_id,
        scroll: '15m',
      });
      AllEpisodes = AllEpisodes.concat(res.hits.hits);
      keepGoing = (res.hits.hits.length === 1000);
    }
    // eslint-disable-next-line no-underscore-dangle
    await elasticClient.getClient().clearScroll({ scroll_id: res._scroll_id });
    return AllEpisodes.map(({ _source }) => _source);
  } catch (error) {
    logger.error('Error in fetching series data ::-', error);
  }
}

async function getTVSeriesChildren(asset) {
  try {
    logger.log(`getting childrens for tvseries id:${asset.id}`);
    const episodes = await getAllEpisodeForSeries(asset.id);
    logger.debug(`got childrens for tvseries id:${asset.id} length:${episodes.length}`);
    const { showId } = asset.meta;
    let result = '';
    // eslint-disable-next-line no-restricted-syntax
    for (const epi of episodes) {
      result += await getAssetXML(epi, showId);
    }
    return result;
  } catch (error) {
    logger.info('Error in getTVSeriesChildren', error);
  }
}

async function getAllShowsAndMovies(size = 5000) {
  try {
    const res = await elasticClient.getClient().search({
      index: updateIndex,
      size,
      body: {
        _source: {
          includes: ['id', 'name', 'details.marketType', 'meta.title.full', 'details.mediaType',
            'meta.genres', 'details.image', 'meta.synopsis.full', 'availability',
            'meta.contributors', 'meta.releaseYear', 'details.marketType',
            'details.kalturaMedia.duration', 'meta.languages', 'details.mediaVariants.DASH_MOBILE'],
        },
        query: {
          bool: {
            must: [
              {
                terms: {
                  'details.mediaType.keyword': ['SHOW', 'MOVIE'],
                },
              },
            ],
          },
        },
      },
    });
    if (res.errors) {
      logger.error(`getAllShowsAndMovies elasticsearch response took:${res.took} errors:${res.errors} items.length:${res.items.length}`);
      if (res.items) {
        res.items.forEach((item) => {
          logger.warn(item.index.error);
        });
      }
      throw new Error(res.errors);
    }
    return res.hits.hits.map(({ _source }) => _source);
  } catch (error) {
    logger.info('Error in getAllShowsAndMovies', error);
  }
}

module.exports = {
  getAllShowsAndMovies,
  xmlFormat,
};

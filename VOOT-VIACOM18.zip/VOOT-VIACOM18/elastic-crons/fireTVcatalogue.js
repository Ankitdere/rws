const log = require('logger-v18');
const s3Client = require('./modules/s3Client');
const storageClient = require('./modules/uploadToGcp');
const catalogueTemplate = require('./fireTvCatalogueTemplate');
const emailClient = require('./modules/emailClient');

// eslint-disable-next-line import/no-dynamic-require
const config = require(`./config.${process.env.envConfigKey}.json`);
const dateUtils = require('./utils/dateUtils');

const { logger } = log;

exports.invoke = async () => {
  try {
    logger.log('connecting to elastic search');
    const result = await catalogueTemplate.getAllShowsAndMovies();
    logger.info('got tvshows and movies, creating catalog xml');
    const fileName = dateUtils.getLastestDate();
    await catalogueTemplate.xmlFormat(result, fileName);
    logger.info('uploading catalog to amazon');
    await storageClient.uploadToGCP(fileName);
    await s3Client.uploadCatalog(fileName, process.env.catalogBucket, `catalogs/${fileName}`);
    const getfilePath = await storageClient.listFiles('amazon-catalogue/', 'partner-catalogue-dev');
    const getLastestFile = storageClient.getLatestFilePath(getfilePath);
    const fireTvCatalogueUrl = `${config.xmlBaseUrl}/${getLastestFile}`;
    logger.info('sucessfully uploaded on GCP bucket & amazon S3 bucket');
    await emailClient.sendAmazonFireTVCatalogueReport(fireTvCatalogueUrl);
    return;
  } catch (err) {
    logger.error('Error in invoke:-', err);
    await emailClient.sendAmazonFireTVCatalogueErrorReport(err.message);
    throw err;
  }
};

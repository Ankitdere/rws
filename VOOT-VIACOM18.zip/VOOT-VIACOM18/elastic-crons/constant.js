const jioVootBaseUrl = 'jiovootviacom18://jiovoot/';
const fileName = 'fireTV-catalogue.xml';

module.exports = {
  jioVootBaseUrl,
  fileName,
};

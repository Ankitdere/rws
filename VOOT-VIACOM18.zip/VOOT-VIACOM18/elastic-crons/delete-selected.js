/* eslint-disable no-await-in-loop */
const log = require('logger-v18');
const elasticClient = require('./modules/elasticClient');
const algoliaClient = require('./modules/algoliaClient');

const ids = [];
// const ids = require('./ids.json');

const { logger } = log;

exports.invoke = async (event) => {
  try {
    logger.log('Received event for handling :', event);
    log.init({
      json: JSON.parse(process.env.logJson), service: 'delete-disabled-elastic-cron', tags: ['crons'], level: process.env.logLevel,
    });
    logger.log('connecting to elastic search');
    await elasticClient.init();
    while (ids.length) {
      logger.log('remaining assets', ids.length);
      const batch = ids.splice(0, 500);
      if (batch.length <= 0) {
        logger.log('no documents to delete, exiting');
        return;
      }
      const assets = batch.map((id) => {
        const obj = {
          id,
          disabled: true,
        };
        return obj;
      });
      await elasticClient.bulkUpdate(assets);
      logger.info(`got total documents ${batch.length} deleting in algolia`);
      await algoliaClient.deleteDocuments(batch);
      logger.info('documents deleted from algolia');

      //   const { revised } = documents[documents.length - 1];
      //   await storageClient.updateLastProcessedTime(name, revised);
      //   fromTime = revised;
      //   keepGoing = documents.length === elasticClient.MAX_DOCUMENTS;
      //   if (keepGoing) {
      //     await sleep(2000);
      //   }
    }
    return;
  } catch (err) {
    logger.error('ERROR in cron', Object.keys(err).length ? JSON.stringify(err) : err);
    // throw err;
  }
};

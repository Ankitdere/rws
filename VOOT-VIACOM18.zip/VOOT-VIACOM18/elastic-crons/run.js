/**
 * this file is used to run all crons. this file parses process.env and
 * brings all variables in the execution environment based on the stage passed in deployment CD pipeline in azure devops.
 *
 * make sure - all crons have an "invoke" fn which triggers the business logic
 * make sure - all cron yaml in kustomize pass the "FN" variable which contains the exact js filename
 */

/* eslint-disable no-plusplus */
const dotenvJSON = require('dotenv-json-complex');

const env = process.env.NODE_ENV || 'jio';

dotenvJSON({ path: `./config.${env}.json` });
const { logger } = require('logger-v18');

const { FN: filename } = process.env;

try {
  logger.log('INVOKING', filename, ' with environment ', env);
  // eslint-disable-next-line import/no-dynamic-require, global-require
  const file = require(`./${filename}.js`);
  file.invoke();
} catch (err) {
  logger.error('ERROR in running cron', filename, Object.keys(err).length ? JSON.stringify(err) : err);
}

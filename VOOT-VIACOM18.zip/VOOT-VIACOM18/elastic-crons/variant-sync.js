/* eslint-disable radix */
/* eslint-disable no-plusplus */
/* eslint-disable no-await-in-loop */
/* eslint-disable no-restricted-syntax */
/* eslint-disable no-nested-ternary */
/* eslint-disable no-use-before-define */
const log = require('logger-v18');
const moment = require('moment');
const storageClient = require('./modules/storageClient');
// eslint-disable-next-line import/no-extraneous-dependencies

const { logger } = log;

function getNested(obj, ...args) {
  // eslint-disable-next-line no-shadow
  return args.reduce((obj, level) => obj && obj[level], obj);
}

// eslint-disable-next-line no-unused-vars
function get(obj, nestedIndex, defaultValue) {
  const value = getNested(obj, ...nestedIndex.split('.'));
  if (typeof value === 'undefined') {
    return defaultValue;
  // eslint-disable-next-line no-else-return
  } else {
    return value;
  }
}

async function getObject(key) {
  const resp = await storageClient.getFile(key, process.env.cmsBucketName);
  return resp;
}

async function putObject(key, body, options) {
  const resp = await storageClient.saveFile(key, body, options, process.env.cmsBucketName);
  return resp;
}

async function transformVariant(fromView, fromVariant, toView, toVariant) {
  logger.info('invoked transformVariant with from: ', fromView, fromVariant, ' and to: ', toView, toVariant);
  try {
    const fromViewContents = await getObject(
      `${fromView}/${fromVariant}.json`,
    );
    const toViewContents = await getObject(
      `${toView}/${toVariant}.json`,
    );
    if (fromViewContents && toViewContents) {
      toViewContents.variant = `${toVariant}`;
      toViewContents.updated = parseInt(new Date().getTime() / 1000);
      toViewContents.updatedBy = 'elastic-crons';
      toViewContents.trays = fromViewContents.trays || [];

      await putObject(
        `${toView}/${toVariant}.json`,
        toViewContents,
        { contentType: 'application/json' },
      );
    } else {
      logger.info('No contents returned');
    }
  } catch (err) {
    logger.error('ERROR in transformVariant - ', err.code || '', err.message || '');
    throw err;
  }
}

async function invoke() {
  try {
    log.init({
      json: process.env.logJson,
      service: 'variant-sync-cron',
      tags: ['crons'],
      level: process.env.logLevel,
    });
    logger.info(
      'Variant sync cron running on ',
      moment().utcOffset('+05:30').format('YYYY-MM-DD HH:MM:SS'),
    );

    const syncViews = [
      {
        from: 'platform/voot-common/views/sports/live',
        to: 'platform/voot-common/views/2128534/live',
        variants: [0, 1, 2, 3],
      },
      {
        from: 'platform/voot-common/views/shows/live',
        to: 'platform/voot-common/views/2128533/live',
        variants: [0, 1, 2, 3],
      },
      {
        from: 'platform/voot-common/views/premium/live',
        to: 'platform/voot-common/views/2128532/live',
        variants: [0, 1, 2, 3],
      },
      {
        from: 'platform/voot-common/views/movies/live',
        to: 'platform/voot-common/views/2128531/live',
        variants: [0, 1, 2, 3],
      },
    ];

    for (let i = 0; i < syncViews.length; i += 1) {
      const variants = syncViews[i].variants || [];
      for (let j = 0; j < variants.length; j += 1) {
        await transformVariant(syncViews[i].from, variants[j], syncViews[i].to, variants[j]);
      }
    }
  } catch (error) {
    logger.error('ERROR in variant sync cron - ', Object.keys(error).length ? JSON.stringify(error) : error);
    // throw err;
  }
}

module.exports = {
  invoke,
};

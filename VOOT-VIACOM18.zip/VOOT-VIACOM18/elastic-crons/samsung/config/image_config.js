const config = {
  image16x9: {
    width: 1920,
    height: 1080,
  },
  image4x3: {
    width: 1440,
    height: 1080,
  },
  image1x1: {
    width: 1200,
    height: 1200,
  },
  image2x3: {
    width: 720,
    height: 1080,
  },
  image3x4: {
    width: 1200,
    height: 1600,
  },
};

module.exports = config;

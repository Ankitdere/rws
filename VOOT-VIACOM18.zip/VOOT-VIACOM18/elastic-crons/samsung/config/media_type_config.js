const MediaTypes = {
  SAMP2XYV8YTKZB8W: [
    'CAC',
    'EPISODE',
    'MOVIE',
    'SERIES',
    'SHOW',
    'LIVECHANNEL',
  ],
};

module.exports = MediaTypes;

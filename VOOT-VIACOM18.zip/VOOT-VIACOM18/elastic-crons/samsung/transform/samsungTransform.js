const moment = require('moment');
const { getDeepLink, getTizenV2Deeplink, getTizenV3Deeplink } = require('../../v3ResponseTypes/deepLinkGenerator');
const utils = require('../../v3ResponseTypes/responseTypes/utils');
const config = require('../config/image_config');
const imageConfig = require('../../v3ResponseTypes/const.json');

const baseUrl = imageConfig.imageCDN;
function imageFormatSamsung(assetImages) {
  const images = [];
  // eslint-disable-next-line no-restricted-syntax
  for (const key in assetImages) {
    // eslint-disable-next-line no-prototype-builtins
    if (config.hasOwnProperty(key) && assetImages[key] && !assetImages[key].includes('undefined')) {
      images.push(
        {
          url: `${baseUrl}${assetImages[key]}`.replaceAll(' ', '%20'),
          width: config[key].width,
          height: config[key].height,
          type: 'iconic',
        },
      );
    }
  }
  const unique = [...new Map(images.map((image) => [image.url, image])).values()];
  return unique;
}

const dateFormatterForAvalability = (newDate) => moment(newDate * 1000).format('YYYY-MM-DD HH:mm:ss');

const transform = (obj, playback, show = {}) => {
  const meta = obj.meta || {};
  const details = obj.details || {};
  const availability = obj.availability || {};
  let showId = '';
  let seasonName = '';
  let seasonId = '';
  let episode = '';
  let season = '';
  let name = '';
  let showName = '';
  let sampledCount = '';
  let assetRef = '';
  name = obj.name;

  const showDetails = show.details || {};
  const showMeta = show.meta || {};
  let showImages = {};
  if (show.details && show.details.image) {
    showImages = utils.getImages(showDetails, showMeta);
  }
  const samsungTransformData = { programs: [{}] };
  samsungTransformData.programs[0].program_id = String(obj.id);
  samsungTransformData.programs[0].type = details.mediaType.toLowerCase();
  if (details.mediaType === 'EPISODE' || details.mediaType === 'CAC' || details.mediaType === 'LIVECHANNEL') {
    if (meta.series && meta.series.showId && meta.series.showName) {
      showId = `${meta.series.showId || ''}`;
      showName = `${meta.series.showName || ''}`;
    }
    if (show.name) {
      showName = `${show.name || ''}`;
    }
    if (meta.series) {
      seasonName = `${meta.series.name || ''}`;
      seasonId = `${meta.series.id || ''}`;
      episode = `${meta.series.episode || ''}`;
      season = `${meta.series.season || ''}`;
    }

    if (seasonName) name = seasonName;
    if (showName) name = showName;
    samsungTransformData.programs[0].series_info = {
      show_id: showId,
      season_id: seasonId,
      season_number: Number(season),
      episode_number: Number(episode),
    };
  } else if (details.mediaType === 'SERIES' || details.mediaType === 'SEASON') {
    showId = `${meta.showId || ''}`;
    showName = `${meta.showName || ''}`;
    if (show.name) {
      showName = `${show.name || ''}`;
    }
    seasonName = `${obj.name || ''}`;
    seasonId = `${obj.id || ''}`;
    season = `${meta.season || ''}`;
    samsungTransformData.programs[0].series_info = {
      show_id: showId,
      season_number: season,
    };
  } else if (details.mediaType === 'SHOW') {
    if (meta.sampledCount) {
      sampledCount = parseInt(meta.sampledCount, 10);
    }
    if (Number.isNaN(meta.sampledCount)) {
      sampledCount = 0;
    }
    if (meta.assetRef) {
      assetRef = meta.assetRef;
    }
  } else if (details.mediaType === 'CUSTOM') {
    if (meta.assetRef) {
      assetRef = meta.assetRef;
    }
    if (meta && meta.series && meta.series.showId) {
      showId = `${meta.series.showId || ''}`;
      showName = `${meta.series.showName || ''}`;
      if (show.name) {
        showName = `${show.name || ''}`;
      }
      seasonName = `${meta.series.name || ''}`;
      seasonId = `${meta.series.id || ''}`;
      episode = `${meta.series.episode || ''}`;
      season = `${meta.series.season || ''}`;

      if (seasonName) name = seasonName;
      if (showName) name = showName;
    }
  }
  console.log('asset and samplecount', assetRef, sampledCount, name);
  let telecastDate = obj.telecasted;
  if (!telecastDate && obj.created) {
    telecastDate = new Date((obj.created + (-330 * 60)) * 1000).toISOString().split('T')[0].replace(/-/g, '');
  }

  let { releaseYear } = meta;
  if (releaseYear) {
    releaseYear = parseInt(releaseYear, 10);
  }
  if ((!releaseYear || Number.isNaN(releaseYear)) && obj.created) {
    releaseYear = parseInt(`${telecastDate}`.substring(0, 4), 10);
  }

  samsungTransformData.programs[0].genres = meta.genres;

  if (details.mediaType === 'MOVIE') samsungTransformData.programs[0].release_date = String(releaseYear);

  let assetImages = {};
  if (details.image) {
    assetImages = utils.getImages(details, meta);

    if (showImages.imageUri) {
      assetImages.showImage = showImages.imageUri;
    }
    if (details.mediaType === 'SHOW') {
      assetImages.showImage = assetImages.imageUri;
    }
    if (details.mediaType === 'MOVIE') {
      assetImages.showImage = assetImages.imageUri;
    }
  }

  samsungTransformData.programs[0].images = imageFormatSamsung(assetImages);
  let shortTitle = meta.title ? meta.title.short : '';
  const fullTitle = meta.title ? meta.title.full : '';
  if (!shortTitle) {
    shortTitle = fullTitle;
  }
  samsungTransformData.programs[0].titles = [{
    title: fullTitle,
    language: 'en',
    type: 'main',
  }];
  let uploadTime;
  let endTime;
  if (availability && availability.available && availability.available.IN) {
    if (availability.available.IN.from) {
      uploadTime = dateFormatterForAvalability(availability.available.IN.from);
    }
    if (availability.available.IN.to) {
      endTime = dateFormatterForAvalability(availability.available.IN.to);
    }
  }
  const assetMarketType = details.marketType || 'STANDARD';
  const showMarketType = (Object.keys(show).length === 0 && show.constructor === Object) ? assetMarketType : showDetails.marketType;
  const deeplinkUrl = getDeepLink(obj);
  samsungTransformData.programs[0].playback_items = [{
    license: showMarketType === 'STANDARD' ? 'subscription' : 'free',
    quality: 'HD',
    available_ending: endTime || '',
    available_starting: uploadTime || '',
    country_code: 'IN',
    deeplink_payload: deeplinkUrl, // we'll change
    tizenV2DeepLink: getTizenV2Deeplink(obj),
    tizenV3DeepLink: getTizenV3Deeplink(obj),
  }];
  // return samsungTransformData
  return samsungTransformData.programs[0];
};

module.exports = { transform };

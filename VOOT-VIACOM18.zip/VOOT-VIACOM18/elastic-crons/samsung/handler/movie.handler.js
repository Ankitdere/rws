const elasticClient = require('../../modules/elasticClient');

const source = ['id', 'name', 'details.mediaType', 'details.image3x4', 'meta.releaseYear', 'meta.genres',
  'details.marketType', 'meta.title.full', 'availability.available', 'details.image', 'meta.synopsis.full'];
const movieHandler = async () => {
  const movies = await elasticClient.getMovies(source);
  const assets = await elasticClient.getTransformSamsungAssets(movies);
  return assets;
};

module.exports = { movieHandler };

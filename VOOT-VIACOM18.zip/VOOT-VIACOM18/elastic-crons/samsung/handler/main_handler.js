const moment = require('moment');
const fs = require('fs');
const { movieHandler } = require('./movie.handler');
const { showHandler } = require('./show_handler');
const { episodeHandler } = require('./episode_handler');
const { liveChannelHandler } = require('./live_channel_handler');
const MediaTypes = require('../config/media_type_config');

async function handler(partnerKey) {
  try {
    const totalAssets = [];
    const mediaType = MediaTypes[partnerKey];// can take from alias
    // eslint-disable-next-line no-plusplus
    for (let index = 0; index < mediaType.length; index++) {
      const type = mediaType[index];
      if (type === 'MOVIE') {
        // eslint-disable-next-line no-await-in-loop
        totalAssets.push(...(await movieHandler()));
      }
      if (type === 'EPISODE') {
        // eslint-disable-next-line no-await-in-loop
        totalAssets.push(...(await episodeHandler(type)));
      }
      // if (type === "CAC") {
      //     total_assets.push(...(await episodeHandler(type)))
      // }
      // if (type === "SERIES") {
      //     total_assets.push(...(await seriesHandler(type)))
      // }
      if (type === 'SHOW') {
        // eslint-disable-next-line no-await-in-loop
        totalAssets.push(...(await showHandler()));
      }
      if (type === 'LIVECHANNEL') {
        // eslint-disable-next-line no-await-in-loop
        totalAssets.push(...(await liveChannelHandler()));
      }
    }
    const fileName = moment().format('YYYYMMDD_HHMMSS');
    const dir = 'samsung/assets';
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(`samsung/assets/${fileName}.json`, JSON.stringify({ programs: totalAssets }), { encoding: 'utf-8' });
    return { success: true, fileName: `${fileName}.json` };
  } catch (error) {
    console.log(error);
    throw error;
  }
}

module.exports = { handler };

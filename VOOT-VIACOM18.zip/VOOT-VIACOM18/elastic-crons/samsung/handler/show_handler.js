const elasticClient = require('../../modules/elasticClient');

const logger = require('../../modules/logger');

const source = ['id', 'revised', 'name', 'details.image3x4', 'details.mediaType', 'details.duration',
  'details.marketType', 'meta.series', 'meta.title.full', 'availability', 'details.kalturaMedia',
  'details.image', 'meta.synopsis.full', 'meta.contributors', 'meta.movieDirector'];

async function showHandler() {
  logger.log('handling show sitemap');
  const shows = await elasticClient.getShows(source);
  const assets = await elasticClient.getTransformSamsungAssets(shows);
  return assets;
}

module.exports = {
  showHandler,
};

const elasticClient = require('../../modules/elasticClient');
const logger = require('../../modules/logger');

const source = ['id', 'revised', 'name', 'details.mediaType', 'details.image3x4', 'details.duration',
  'details.marketType', 'meta.series', 'meta.title.full', 'availability.available', 'details.kalturaMedia',
  'details.image', 'meta.synopsis.full', 'meta.contributors', 'meta.movieDirector', 'meta.releaseYear',
  'meta.genres'];

async function generateEpisodeFeeds(show, mediaType) {
  const showId = `${show.id}`;
  let allEpisode = [];
  let allAssets = [];
  let keepGoing = true;
  let from = 0;
  let res;
  while (keepGoing) {
    logger.log(`showId:${showId} fetched ${allEpisode.length}`);
    if (mediaType === 'CAC') {
      // eslint-disable-next-line no-await-in-loop
      res = await elasticClient.getCAC(showId, from, source);
    } else if (mediaType === 'EPISODE') {
      // eslint-disable-next-line no-await-in-loop
      res = await elasticClient.getEpisodes(showId, from, source);
    }
    // eslint-disable-next-line no-await-in-loop
    const assets = await elasticClient.getTransformSamsungAssets(res);
    allEpisode = allEpisode.concat(res);
    allAssets = allAssets.concat(assets);
    keepGoing = (res.length === elasticClient.MAX_DOCUMENTS);
    if (keepGoing) {
      from = allEpisode[allEpisode.length - 1].id;
    }
  }
  return allAssets;
}

async function episodeHandler(mediaType) {
  logger.log('handling episode sitemap');
  const shows = await elasticClient.getShows(source);
  logger.info(`got shows from elasticsearch length:${shows.length}`);
  const urlObjects = [];
  // eslint-disable-next-line no-restricted-syntax
  for (const show of shows) {
    // eslint-disable-next-line no-await-in-loop
    const episodes = await generateEpisodeFeeds(show, mediaType);
    urlObjects.push(...episodes);
    logger.log(`urlObjects length:${urlObjects.length}`);
  }
  return urlObjects;
}

module.exports = {
  episodeHandler,
};

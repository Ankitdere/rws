const elasticClient = require('../../modules/elasticClient');

const source = ['id', 'revised', 'name', 'details.mediaType', 'details.image3x4',
  'details.duration', 'details.marketType', 'meta.series', 'meta.title.full',
  'availability.available', 'details.kalturaMedia', 'details.image',
  'meta.synopsis.full', 'meta.contributors', 'meta.movieDirector', 'meta.releaseYear', 'meta.genres'];
const liveChannelHandler = async () => {
  const liveChannels = await elasticClient.getLiveChannels(source);
  const assets = await elasticClient.getTransformSamsungAssets(liveChannels);
  return assets;
};

module.exports = { liveChannelHandler };

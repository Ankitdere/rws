const elasticClient = require('../../modules/elasticClient');

const logger = require('../../modules/logger');

const source = ['id', 'name', 'meta', 'details.mediaType', 'details.image3x4', 'meta.releaseYear',
  'meta.genres', 'details.marketType', 'meta.title.full', 'availability.available', 'details.image',
  'meta.synopsis.full'];

async function seriesHandler() {
  logger.log('handling show sitemap');
  const series = await elasticClient.getSeries(source);
  const assets = await elasticClient.getTransformSamsungAssets(series);
  return assets;
}

module.exports = {
  seriesHandler,
};

// partner will be name of partner
// type will be feed or etc.
// subtype will be movie, shows, series
const dotenvJSON = require('dotenv-json-complex');

const env = process.env.NODE_ENV || 'jio';
dotenvJSON({ path: `./config.${env}.json` });
const { handler } = require('./handler/main_handler');
const logger = require('../modules/logger');
const { uploadToGCP } = require('./services/storage.service');
const { compressFile } = require('./services/gzip.service');

const getHandler = async (partner, type, partnerKey = '') => {
  switch (partner) {
    case 'SAMSUNG': {
      switch (type) {
        case 'FEED': {
          // eslint-disable-next-line no-return-await
          return await handler(partnerKey);
        }
        default: {
          console.log('will check after');
          return () => { };
        }
      }
    }
    default: {
      console.log('will check after');
      return () => { };
    }
  }
};

async function invoke() {
  try {
    const partner = process.env.PARTNER_NAME || 'SAMSUNG';
    const partnerKey = process.env.PARTNER_KEY || 'SAMP2XYV8YTKZB8W';
    const type = process.env.TYPE || 'FEED';
    const handlerRes = await getHandler(partner, type, partnerKey);
    if (handlerRes.success) {
      compressFile(`samsung/assets/${handlerRes.fileName}`).on('finish', async () => {
        console.log(`Successfully compressed the file at ${handlerRes.fileName}`);
        const uploadResponse = await uploadToGCP(`${handlerRes.fileName}.gz`);
        console.log('uploadResponse', uploadResponse);
        console.log('storage bucket upload status success');
      }).on('error', (err) => {
        throw new Error('Unable to upload', err);
      });
    } else {
      throw new Error('Something went Wrong!!!!!!!!');
    }
  } catch (err) {
    logger.error(err);
  }
}

module.exports = {
  invoke,
};

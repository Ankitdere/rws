const { createReadStream, createWriteStream } = require('fs');
const { createGzip } = require('zlib');

const compressFile = (filePath) => {
  const stream = createReadStream(filePath);
  return stream
    .pipe(createGzip())
    .pipe(createWriteStream(`${filePath}.gz`));
};

module.exports = { compressFile };

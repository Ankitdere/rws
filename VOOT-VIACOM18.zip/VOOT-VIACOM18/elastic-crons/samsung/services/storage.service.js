const { Storage } = require('@google-cloud/storage');

const storage = new Storage({ keyFilename: 'google-cloud-key.json' });

const uploadToGCP = async (fileName) => {
  // eslint-disable-next-line no-useless-catch
  try {
    const localPath = `samsung/assets/${fileName}`;
    const bucketName = process.env.samsungBucketName || 'partner-catalogue-dev';
    const path = process.env.samsungCatlogPath || 'samsung-catalog';
    const response = await storage.bucket(bucketName).upload(localPath, { gzip: true, destination: `${path}/${fileName}` });
    return response;
  } catch (error) {
    throw error;
  }
};
module.exports = { uploadToGCP };

const { Parser } = require('json2csv');
const log = require('logger-v18');
// eslint-disable-next-line import/no-unresolved
const dotenvJSON = require('dotenv-json');
const storageClient = require('./modules/storageClient');
const cassandraClient = require('./modules/cassandraClient');

const env = process.env.NODE_ENV || 'jiouat';
// eslint-disable-next-line import/no-dynamic-require
dotenvJSON({ path: `./config.${env}.json` });

const { logger } = log;

// returns date in YYYY-MM-DD format
function getYesterdayDate() {
  const yesterdayDate = new Date();
  yesterdayDate.setDate(yesterdayDate.getDate() - 1);
  const offset = 330;// India offset
  const date = new Date(yesterdayDate.getTime() + (offset * 60 * 1000));
  // eslint-disable-next-line prefer-destructuring
  return date.toISOString().split('T')[0];
}

exports.invoke = async () => {
  try {
    const date = getYesterdayDate();
    logger.info(`generating playback report for ${date}`);
    const prefix = 'reports/playback/';
    let key = `${prefix}${date}.csv`;
    const fileExist = await storageClient.doesFileExist(key, process.env.cmsBucketName);
    if (fileExist) {
      logger.info('report file not found in GCS, exiting');
      return;
    }
    let history = [];
    history = await cassandraClient.getRecords(date);
    if (!history || history.length === 0) {
      logger.info('no history found, exiting');
      return;
    }
    const CHUNK_SIZE = 500000;
    const colOrder = [
      {
        label: 'Partner',
        value: 'partner',
      },
      {
        label: 'Media ID',
        value: 'mediaid_requested',
      },
      {
        label: 'Partner ID',
        value: 'partnerid',
      },
      {
        label: 'Partner',
        value: 'partner',
      },
      {
        label: 'Status',
        value: 'status',
      },
      {
        label: 'Timestamp',
        value: 'epoch',
      },
    ];
    const opts = { fields: colOrder };
    const json2csvParser = new Parser(opts);
    for (let i = 0; i < history.length; i += CHUNK_SIZE) {
      const records = history.slice(i, i + CHUNK_SIZE);
      const csv = json2csvParser.parse(records);
      if (i !== 0) {
        key = `${prefix}${date}-${i}.csv`;
      }
      // eslint-disable-next-line no-await-in-loop
      await storageClient.saveFileRaw(key, csv, process.env.cmsBucketName);
    }
  } catch (err) {
    logger.error('ERROR in generating playback report', err);
  }
};

const log = require('logger-v18');
const handlers = require('./handlers');
const feedHandlers = require('./feedHandlers');
const { googleFeedJiositemap } = require('../template');

const { logger } = log;

function getHandler(type, sitemapType) {
  switch (sitemapType) {
    case 'FEED': {
      switch (type) {
        case 'MOVIE':
          return feedHandlers.movieHandler;
        case 'SHOW':
          return feedHandlers.showHandler;
        case 'EPISODE':
          return feedHandlers.episodeHandler;
        case 'SITEMAP':
          return feedHandlers.sitemapHandler;
        default:
          return () => {};
      }
    }
    default: {
      switch (type) {
        case 'MOVIE':
          return handlers.movieHandler;
        case 'SHOW':
          return handlers.showHandler;
        case 'VIDEO':
          return handlers.videoHandler;
        case 'NEWS':
          return handlers.newsHandler;
        case 'CHANNEL':
          return handlers.channelHandler;
        case 'SITEMAP':
          return handlers.sitemapHandler;
        default:
          return () => {};
      }
    }
  }
}

async function invoke() {
  try {
    logger.log('start googleTV');
    // eslint-disable-next-line no-plusplus
    for (let i = 0; i < googleFeedJiositemap.type.length; i++) {
      const type = googleFeedJiositemap.type[i];
      const { priority, changefreq, sitemapType } = googleFeedJiositemap;
      const handler = getHandler(type, sitemapType);
      if (!handler) {
        throw new Error('Type not supported');
      }
      // eslint-disable-next-line no-await-in-loop
      await handler.handle({ priority, changefreq });
    }
  } catch (err) {
    logger.error(err);
  }
}

module.exports = {
  invoke,
};

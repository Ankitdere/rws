/* eslint-disable global-require */
module.exports = {
  movieHandler: require('./movieHandler'),
  showHandler: require('./showHandler'),
  videoHandler: require('./videoHandler'),
  newsHandler: require('./newsHandler'),
  channelHandler: require('./channelHandler'),
  sitemapHandler: require('./sitemapHandler'),
};

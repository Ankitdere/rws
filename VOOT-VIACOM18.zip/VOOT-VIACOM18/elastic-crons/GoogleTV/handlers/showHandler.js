/* eslint-disable no-await-in-loop */
const log = require('logger-v18');
const elasticClient = require('../../modules/elasticClient');
const storageClient = require('../../modules/uploadToGcp');
const helper = require('../../modules/helper');

const { logger } = log;

async function generateEpisodeCACSiteMap({ show, priority, changefreq }, showAsset) {
  const showId = show.id;
  logger.log(`handling generateEpisodeCACSiteMap showId:${showId}`);
  let AllEpisode = [];
  let AllAssets = [];
  let keepGoing = true;
  let from = 0;
  while (keepGoing) {
    logger.log(`showId:${showId} fetched ${AllEpisode.length}`);
    const res = await elasticClient.getEpisodeCAC(showId, from);
    const assets = await elasticClient.getTransformedAssets(res);
    AllEpisode = AllEpisode.concat(res);
    AllAssets = AllAssets.concat(assets);
    keepGoing = (res.length === elasticClient.MAX_DOCUMENTS);
    if (keepGoing) {
      from = AllEpisode[AllEpisode.length - 1].id;
    }
  }
  logger.log(`showId:${showId} All episode length:${AllEpisode.length}`);
  const urlObjects = AllEpisode.map(
    (episode, index) => helper.generateUrlNode(episode, priority, changefreq, false, false, AllAssets[index]),
  );
  urlObjects.unshift(helper.generateUrlNode(show, priority, changefreq, false, false, showAsset));
  logger.log(`urlObjects length:${urlObjects.length}`);
  const obj = {
    '@': {
      xmlns: 'http://www.sitemaps.org/schemas/sitemap/0.9',
      'xmlns:xsi': 'https://www.w3.org/2001/XMLSchema-instance',
      'xsi:schemaLocation': 'http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/siteindex.xsd',
    },
    url: urlObjects,
  };
  await storageClient.uploadXML('urlset', obj, `sitemap/shows-${showId}.xml`);
}

async function handle({ priority, changefreq }) {
  logger.log('handling movie sitemap');
  const shows = await elasticClient.getShows();
  const showAssets = await elasticClient.getTransformedAssets(shows);
  logger.info(`got shows from elasticsearch length:${shows.length}`);
  const urlObjects = shows.map((show) => helper.generateSiteMapNode(show));
  logger.log(`urlObjects length:${urlObjects.length}`);
  const obj = {
    '@': {
      xmlns: 'http://www.sitemaps.org/schemas/sitemap/0.9',
      'xmlns:xsi': 'https://www.w3.org/2001/XMLSchema-instance',
      'xsi:schemaLocation': 'http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd',
    },
    sitemap: urlObjects,
  };
  await storageClient.uploadXML('sitemapindex', obj, 'sitemap/shows.xml');
  await Promise.all(shows.map((show, index) => generateEpisodeCACSiteMap({
    show, priority, changefreq,
  }, showAssets[index])));
}

module.exports = {
  handle,
};

const log = require('logger-v18');
const sitemap = require('../sitemap.json');
const sitemapIndex = require('../sitemap-index.json');
const storageClient = require('../../modules/uploadToGcp');

const { logger } = log;

// async function handle({ priority, changefreq }) {
async function handle() {
  logger.log('handling movie sitemap');
  const lastmod = new Date().toISOString();
  const urlObjects = sitemap.map((obj1) => ({ ...obj1, lastmod }));
  const obj = {
    '@': {
      xmlns: 'http://www.sitemaps.org/schemas/sitemap/0.9',
      'xmlns:xsi': 'https://www.w3.org/2001/XMLSchema-instance',
      'xsi:schemaLocation': 'http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/siteindex.xsd',
    },
    url: urlObjects,
  };
  await storageClient.uploadXML('urlset', obj, 'sitemap/sitemap.xml');
  const sitemapObj = sitemapIndex.map((obj1) => ({ ...obj1, lastmod }));
  const sitemapindexObj = {
    '@': {
      xmlns: 'http://www.sitemaps.org/schemas/sitemap/0.9',
      'xmlns:xsi': 'https://www.w3.org/2001/XMLSchema-instance',
      'xsi:schemaLocation': 'http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/siteindex.xsd',
    },
    sitemap: sitemapObj,
  };
  await storageClient.uploadXML('sitemapindex', sitemapindexObj, 'sitemap/sitemap-index.xml');
}

module.exports = {
  handle,
};

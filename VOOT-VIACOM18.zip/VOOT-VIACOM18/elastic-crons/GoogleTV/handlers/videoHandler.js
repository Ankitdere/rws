/* eslint-disable no-await-in-loop */
const log = require('logger-v18');
const elasticClient = require('../../modules/elasticClient');
const storageClient = require('../../modules/uploadToGcp');
const helper = require('../../modules/helper');

const { logger } = log;

async function handle() {
  logger.log('handling video sitemap');
  let total = 0;
  let keepGoing = true;
  let from = 0;
  const siteMapSize = 5000;
  let count = 1;
  while (keepGoing) {
    logger.log(`fetched ${total}`);
    const res = await elasticClient.getVideos(from, siteMapSize);
    const assets = await elasticClient.getTransformedAssets(res);
    const urlObjects = res.map(
      (video, index) => helper.generateVideoNode(video, assets[index]),
    );
    logger.log(`urlObjects length:${urlObjects.length}`);
    const obj = {
      '@': {
        xmlns: 'http://www.sitemaps.org/schemas/sitemap/0.9',
        'xmlns:video': 'http://www.google.com/schemas/sitemap-video/1.1',
      },
      url: urlObjects,
    };
    // eslint-disable-next-line no-await-in-loop
    await storageClient.uploadXML('urlset', obj, `video-sitemap/video-sitemap${count}.xml`);
    keepGoing = (res.length === siteMapSize);
    total += res.length;
    if (keepGoing) {
      from = res[res.length - 1].id;
      count += 1;
    }
  }
  const lastmod = new Date().toISOString();
  const urlObjects = Array(count).fill(0).map((obj, i) => ({
    lastmod,
    loc: `${process.env.baseUrl}/video-sitemap/video-sitemap${i + 1}.xml`,
  }));
  const obj = {
    '@': {
      xmlns: 'http://www.sitemaps.org/schemas/sitemap/0.9',
    },
    sitemap: urlObjects,
  };
  await storageClient.uploadXML('sitemapindex', obj, 'video-sitemap/video-sitemap.xml');
}

module.exports = {
  handle,
};

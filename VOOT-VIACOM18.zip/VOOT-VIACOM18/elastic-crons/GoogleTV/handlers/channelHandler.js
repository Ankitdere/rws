const log = require('logger-v18');
const elasticClient = require('../../modules/elasticClient');
const storageClient = require('../../modules/uploadToGcp');
const helper = require('../../modules/helper');

const { logger } = log;

async function handle({ priority, changefreq }) {
  logger.log('handling channels sitemap');
  const news = await elasticClient.getChannels();
  const assets = await elasticClient.getTransformedAssets(news);
  logger.info(`got news from elasticsearch length:${news.length}`);
  const urlObjects = news.map((movie, index) => helper.generateUrlNode(movie, priority, changefreq, true, false, assets[index]));
  logger.log(`urlObjects length:${urlObjects.length}`);
  const obj = {
    '@': {
      xmlns: 'http://www.sitemaps.org/schemas/sitemap/0.9',
      'xmlns:xsi': 'https://www.w3.org/2001/XMLSchema-instance',
      'xsi:schemaLocation': 'http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/siteindex.xsd',
    },
    url: urlObjects,
  };
  await storageClient.uploadXML('urlset', obj, 'sitemap/channels.xml');
}

module.exports = {
  handle,
};

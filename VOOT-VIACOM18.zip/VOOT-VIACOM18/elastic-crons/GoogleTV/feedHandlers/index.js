/* eslint-disable global-require */
module.exports = {
  movieHandler: require('./movieHandler'),
  showHandler: require('./showHandler'),
  episodeHandler: require('./episodeHandler'),
  sitemapHandler: require('./sitemapHandler'),
};

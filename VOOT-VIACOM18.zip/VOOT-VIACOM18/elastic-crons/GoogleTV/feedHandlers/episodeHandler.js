/* eslint-disable no-await-in-loop */
const log = require('logger-v18');
const elasticClient = require('../../modules/elasticClient');
const storageClient = require('../../modules/uploadToGcp');
const helper = require('../../modules/helper');

const { logger } = log;

const source = ['id', 'revised', 'name', 'details.mediaType', 'details.duration',
  'details.marketType', 'meta.series', 'meta.title.full', 'availability',
  'details.kalturaMedia', 'details.image', 'meta.synopsis.full',
  'meta.contributors', 'meta.movieDirector', 'details.image3x4', 'meta.releaseYear', 'meta.genres', 'meta'];
async function generateEpisodeFeeds(show) {
  const [showAsset] = await elasticClient.getTransformedAssets([show]);
  const showId = `${show.id}`;
  let AllEpisode = [];
  let AllAssets = [];
  let keepGoing = true;
  let from = 0;
  while (keepGoing) {
    logger.log(`showId:${showId} fetched ${AllEpisode.length}`);
    const res = await elasticClient.getEpisodes(showId, from, source);
    const assets = await elasticClient.getTransformedAssets(res);
    AllEpisode = AllEpisode.concat(res);
    AllAssets = AllAssets.concat(assets);
    keepGoing = (res.length === elasticClient.MAX_DOCUMENTS);
    if (keepGoing) {
      from = AllEpisode[AllEpisode.length - 1].id;
    }
  }
  logger.log(`showId:${showId} All episode length:${AllEpisode.length}`);
  const urlObjects = AllEpisode.map(
    (episode, index) => helper.generateEpisodeFeedNode(episode, show, AllAssets[index], showAsset),
  ).filter(Boolean);
  logger.log(`showId:${showId} urlObjects length:${urlObjects.length}`);
  return urlObjects;
}

async function handle() {
  logger.log('handling episode sitemap');
  const shows = await elasticClient.getShows(source);
  logger.info(`got shows from elasticsearch length:${shows.length}`);
  let urlObjects = [];
  let listCount = 1;
  // eslint-disable-next-line no-restricted-syntax
  for (const show of shows) {
    // eslint-disable-next-line no-await-in-loop
    const episodes = await generateEpisodeFeeds(show);
    urlObjects.push(...episodes);
    logger.log(`urlObjects length:${urlObjects.length}`);
    if (urlObjects.length > 0) {
      const obj = {
        '@context': 'http://schema.org',
        '@type': 'DataFeed',
        dateModified: new Date().toISOString(),
        dataFeedElement: urlObjects,
      };
      // eslint-disable-next-line no-await-in-loop
      await storageClient.uploadFile(obj, `feed/episodes-${listCount}.json`, 'partner-catalogue-dev', 'google-catalogue');
      listCount += 1;
      urlObjects = [];
    }
  }
  const obj = {
    '@context': 'http://schema.org',
    '@type': 'DataFeed',
    dateModified: new Date().toISOString(),
    dataFeedElement: urlObjects,
  };
  await storageClient.uploadFile(obj, `feed/episodes-${listCount}.json`, 'partner-catalogue-dev', 'google-catalogue');
}

module.exports = {
  handle,
};

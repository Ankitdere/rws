const log = require('logger-v18');
const elasticClient = require('../../modules/elasticClient');
const storageClient = require('../../modules/uploadToGcp');
const helper = require('../../modules/helper');

const { logger } = log;

const source = ['id', 'name', 'details.mediaType', 'details.image3x4', 'meta.releaseYear', 'meta.genres',
  'details.marketType', 'meta.title.full', 'availability.available', 'details.image', 'meta.synopsis.full', 'meta'];

async function handle() {
  logger.log('handling movie sitemaps');
  const movies = await elasticClient.getMovies(source);
  const assets = await elasticClient.getTransformedAssets(movies);

  console.info(`got movies from elasticsearch length:${movies.length}`);
  const urlObjects = movies.map((movie, index) => helper.generateMovieFeedNode(movie, assets[index])).filter(Boolean);
  logger.log(`urlObjects length:${urlObjects.length}`);
  const obj = {
    '@context': 'http://schema.org',
    '@type': 'DataFeed',
    dateModified: new Date().toISOString(),
    dataFeedElement: urlObjects,
  };
  await storageClient.uploadFile(obj, 'feed/movies.json', 'partner-catalogue-dev', 'google-catalogue');
}

module.exports = {
  handle,
};

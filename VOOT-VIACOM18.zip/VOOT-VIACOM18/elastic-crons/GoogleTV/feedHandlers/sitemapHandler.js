const log = require('logger-v18');
const storageClient = require('../../modules/uploadToGcp');
// eslint-disable-next-line import/no-dynamic-require
const config = require(`../../config.${process.env.envConfigKey}.json`);

const { logger } = log;

async function handle() {
  logger.log('handling feed sitemap');
  let urlObjects = await storageClient.listFiles('google-catalogue/feed/', 'partner-catalogue-dev');
  urlObjects = urlObjects.slice(1);
  const sitemapObj = urlObjects.map((obj1) => ({
    loc: `${config.xmlBaseUrl}/${obj1.filename}`,
    lastmod: new Date(obj1.createdDate).toISOString(),
  }));
  const sitemapindexObj = {
    '@': {
      xmlns: 'http://www.sitemaps.org/schemas/sitemap/0.9',
      'xmlns:xsi': 'https://www.w3.org/2001/XMLSchema-instance',
      'xsi:schemaLocation': 'http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/siteindex.xsd',
    },
    sitemap: sitemapObj,
  };
  await storageClient.uploadXML('sitemapindex', sitemapindexObj, 'watchFeed.xml', 'partner-catalogue-dev', 'google-catalogue');
}

module.exports = {
  handle,
};

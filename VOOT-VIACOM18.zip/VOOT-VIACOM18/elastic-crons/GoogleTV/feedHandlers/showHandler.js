const log = require('logger-v18');
const elasticClient = require('../../modules/elasticClient');
const storageClient = require('../../modules/uploadToGcp');
const helper = require('../../modules/helper');

const { logger } = log;

const source = ['id', 'revised', 'name', 'details.mediaType', 'details.duration',
  'details.marketType', 'meta.series', 'meta.title.full', 'availability',
  'details.kalturaMedia', 'details.image', 'meta.synopsis.full', 'meta.contributors',
  'meta.movieDirector', 'details.image3x4', 'meta.releaseYear', 'meta.genres', 'meta'];
async function handle() {
  logger.log('handling show sitemap');
  const shows = await elasticClient.getShows(source);
  const assets = await elasticClient.getTransformedAssets(shows);
  console.info(`got shows from elasticsearch length:${shows.length}`);
  const urlObjects = shows.map((show, index) => helper.generateShowFeedNode(show, assets[index])).filter(Boolean);
  console.log(`urlObjects length:${urlObjects.length}`);
  const obj = {
    '@context': 'http://schema.org',
    '@type': 'DataFeed',
    dateModified: new Date().toISOString(),
    dataFeedElement: urlObjects,
  };
  await storageClient.uploadFile(obj, 'feed/tvSeries.json', 'partner-catalogue-dev', 'google-catalogue');
}

module.exports = {
  handle,
};

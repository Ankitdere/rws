/* eslint-disable max-len */
/* eslint-disable func-names */
/* eslint-disable no-unused-vars */
const slugify = require('slugify');
const config = require('./const.json');

const vootBaseUrl = 'https://www.voot.com';
const jcBaseUrl = 'https://www.jiocinema.com';

const sbuMapping = {
  COB: 'Colors Bangla',
  COG: 'Colors Gujarati',
  COH: 'Colors Hindi',
  COI: 'Colors Infinity',
  COK: 'Colors Kannada',
  TEL: 'Colors Telugu',
  VOST: 'Voot Studio',
  CCP: 'Colors Cineplex',
  COM: 'Colors Marathi',
  COS: 'Colors SUPER',
  DAN: 'Dandelooo',
  DHX: 'DHX',
  DTH: 'Dream Theatre',
  ETO: 'Entertainment one',
  GRG: 'Green Gold',
  HBR: 'Hasbro',
  Hi5: 'Hi5',
  HITENT: 'Hit Entertainment',
  KAR: 'Karadi Tales',
  MIL: 'Millimages',
  MTV: 'MTV',
  MTVI: 'Pepsi MTV Indies',
  MTVMN: 'MTV International',
  NICK: 'Nickelodeon',
  STR: 'Strika Entertainment',
  TFC: 'The Film Company',
  TOON: 'Toonz Animation',
  Tur: 'Turner',
  VMP: 'Viacom18 Motion Pictures',
  VOOT: 'VOOT',
  VH1: 'Vh1',
  VORG: 'Voot Originals',
  VSO: 'Voot Select Originals',
  WAM: 'Wide Angle Media',
  MDT: 'MDT',
  MTVB: 'MTVB',
  YOB: 'Yoboho',
  BIG: 'Big Animation',
  AMD: 'Animaccord',
  BBC: 'BBC',
  END: 'Endemol',
  NLV: 'Nelvana',
  SQZ: 'Squeeze Studio',
  TAMIL: 'Colors Tamil',
  ZOD: 'Zodiak',
  MTL: 'Mattel',
  LEG: 'Lego',
  VIC: 'Vice',
  CN18: 'CNBC-TV18',
  CNN18: 'CNN-News18',
  CNAZ: 'CNBC Awaaz',
  CNBZ: 'CNBC-Bazaar',
  NEI: 'News18 India',
  NEB: 'News18 Bangla',
  NEM: 'News18 Marathi',
  NEG: 'News18 Gujarati',
  NET: 'News18 Tamil Nadu',
  NEK: 'News18 Kannada',
  NEP: 'News18 Punjabi',
  NEU: 'News18 Urdu',
  NEML: 'News18 Malayalam',
  NEBJ: 'News18 Bihar Jharkhand',
  NEMC: 'News18 MP Chhattisgarh',
  NERJ: 'News18 Rajasthan',
  NEUU: 'News18 UP Uttarakhand',
  NEAN: 'News18 Assam Northeast',
  NEHP: 'News18 Punjab Haryana Himachal',
  NEKL: 'News18 Kerala',
  NEL: 'News18 Lokmat',
  NEO: 'News18 Odia',
  FTP: 'Firstpost',
  ESP: 'Voot eSports',
};

function getSlugifiedString(temp = '') {
  return slugify(temp, {
    replacement: '-',
    remove: /[*+~.()'",!:@?]/g,
    lower: true,
  });
}

// eslint-disable-next-line no-extend-native
String.prototype.capitalize = function () {
  return this.replace(/(?:^|\s)\S/g, a => a.toUpperCase());
};

function getPageName(mediaType, fullTitle = '', genre, showTitle, season, episode) {
  if (mediaType === 'EPISODE' && genre !== 'NEWS') {
    return `Episode ${episode} - ${fullTitle}`.capitalize();
  }
  return fullTitle.capitalize();
}

function getImgAltTags(mediaType, fullTitle = '', SBU, genre, isPremium, episode) {
  switch (mediaType) {
    case 'SHOW':
      if (['VORG', 'VOST'].includes(SBU)) {
        return `Watch ${fullTitle} Web Series Online`;
      }
      return `Watch ${fullTitle} Online`;
    case 'EPISODE':
      if (isPremium) {
        return `Watch ${fullTitle} Online`;
      }
      switch (genre.toUpperCase()) {
        case 'NEWS':
          return `Watch ${fullTitle} Online`;
        default:
          return `Watch Episode ${episode} - ${fullTitle} Online`;
      }
    default:
      return `Watch ${fullTitle} Online`;
  }
}

function getTitle(mediaType, fullTitle = '', genre, showTitle, season, episode, isPremium, SBU, language, telecastDate, releaseYear) {
  switch (mediaType) {
    case 'SHOW':
      if (isPremium) {
        switch (SBU) {
          case 'VORG':
          case 'VOST':
            return `${fullTitle} | Watch ${genre} Web Series ${fullTitle} Full Episodes Online | JioCinema`;
          default:
            return `${fullTitle} | Watch ${genre} Series ${fullTitle} Full Episodes Online | JioCinema`;
        }
      } else {
        switch (genre.toUpperCase()) {
          case 'NEWS':
            return `${fullTitle} | Watch All the Top ${sbuMapping[SBU] || ''} ${language} TV Show Videos in HD Streaming Online`;
          case 'REALITY':
            return `${fullTitle} | Watch ${fullTitle} Show All Latest Seasons Full Episodes and Videos Online on JioCinema`;
          default:
            return `${fullTitle} | Watch ${fullTitle} Serial All Latest Seasons Full Episodes and Videos Online on JioCinema`;
        }
      }
    case 'EPISODE':
      if (isPremium) {
        switch (SBU) {
          case 'VORG':
          case 'VOST':
            return `Watch ${showTitle} Web Series Season ${season} Episode ${episode} Online`;
          default:
            return `Watch ${showTitle} Season ${season} Episode ${episode} telecasted on ${telecastDate} online`;
        }
      } else {
        switch (genre.toUpperCase()) {
          case 'NEWS':
            return `Watch ${fullTitle} News Video Telecasted on ${telecastDate} Online`;
          default:
            return `Watch ${showTitle} Season ${season} Episode ${episode} telecasted on ${telecastDate} online`;
        }
      }
    case 'LIVECHANNEL':
      return `${fullTitle.capitalize()} TV Channels Videos Live Streaming Online on JioCinema`;
    case 'MOVIE':
      return `${fullTitle} | Watch Full HD ${language} Movie ${fullTitle} ${releaseYear} Online`;
    case 'CAC':
      return `${fullTitle.capitalize()} - Date ${telecastDate} Online | JioCinema`;
    case 'CHANNEL':
      return `${fullTitle.capitalize()} - Watch HD Streaming TV Channels Online for free of the latest TV Shows, Videos & Movies | Viacom 18 Network TV Channel Serials on JioCinema`;
    case 'SERIES':
      return `${fullTitle.capitalize()} - Season ${(`0${season}`).slice(-2)} - Watch ${fullTitle.capitalize()} Season ${(`0${season}`).slice(-2)}, Latest Episodes HD Streaming Online on JioCinema`;
    default:
      return 'JioCinema - Watch Free Online TV Shows, Movies, Kids Shows HD Quality on JioCinema';
  }
}

function getDescription(mediaType, fullTitle = '', genre, showTitle, season, episode, isPremium, SBU, language, telecastDate, releaseYear, description) {
  switch (mediaType) {
    case 'SHOW':
      if (isPremium) {
        switch (SBU) {
          case 'VORG':
          case 'VOST':
            return `Watch All Episodes of JioCinema Originals TV Web series ${fullTitle} Online. ${description}. Get HD Streaming of all latest Episodes of ${fullTitle} schedule & video clips only on JioCinema.`;
          default:
            return `Watch All Episodes of ${fullTitle} Online. ${description}. Get HD Streaming of all latest Episodes of ${fullTitle} schedule & video clips only on JioCinema.`;
        }
      } else {
        switch (genre.toUpperCase()) {
          case 'NEWS':
            return `View All the Latest Episodes of our Popular ${language} News Show ${fullTitle} in HD Streaming Videos only on JioCinema. Get tuned with ${sbuMapping[SBU] || ''} ${language} TV 24*7 Top Headline news stories online. Watch Now!`;
          case 'REALITY':
            return `Watch All Seasons Episodes of ${sbuMapping[SBU] || ''} TV Show ${fullTitle} Online. Get schedule and best quality online streaming of all episodes, clips and videos of ${fullTitle} for free at JioCinema`;
          default:
            return `Watch All Seasons Episodes of ${sbuMapping[SBU] || ''} TV Serial ${fullTitle} Online. Get schedule and best quality online streaming of all episodes, clips and videos of ${fullTitle} for free at JioCinema`;
        }
      }
    case 'EPISODE':
      if (isPremium) {
        switch (SBU) {
          case 'VORG':
          case 'VOST':
            return `Watch Full Episode of ${genre} Web Series ${showTitle} Season ${season} Episode ${episode} - ${fullTitle} online. ${description}. Get Episode story & video clips of all webisodes of ${showTitle} ${releaseYear} Voot Originals TV Show only on JioCinema.`;
          default:
            return `Watch ${showTitle} Season ${season} Episode ${episode} - ${fullTitle} online. ${description}. Get Episode story & video clips of all Episodes of ${showTitle} ${releaseYear} ${sbuMapping[SBU] || ''} only on JioCinema.`;
        }
      } else {
        switch (genre.toUpperCase()) {
          case 'NEWS':
            return `Stay tuned to our ${sbuMapping[SBU] || ''} News Show ${showTitle} - ${fullTitle} broadcasted on ${telecastDate} Online only on JioCinema. Catch ${showTitle} all latest episodes & HD Video clips online. Watch Now!`;
          case 'REALITY':
            return `Watch ${showTitle} Season ${season} Episode ${episode} - ${fullTitle} online. ${description}. Get Episode story & video clips of all Episodes of ${showTitle} ${releaseYear} ${sbuMapping[SBU] || ''} TV show only on JioCinema`;
          default:
            return `Watch ${showTitle} Season ${season} Episode ${episode} - ${fullTitle} online. ${description}. Get Episode story & video clips of all Episodes of ${showTitle} ${releaseYear} ${sbuMapping[SBU] || ''} TV Serial only on JioCinema`;
        }
      }
    case 'LIVECHANNEL':
      return `Watch local, national, regional & worldwide Live news streaming of your favourite ${fullTitle.capitalize()} TV channels only on JioCinema. Get ${fullTitle.capitalize()}-India, Assam, Bangla, Lokmat, Jharkhand & Regional channels Breaking news videos on politics, sports, entertainment, lifestyle and much more Online.`;
    case 'MOVIE':
      return `${fullTitle} - ${description}. Browse through the complete list of best HD quality streaming ${language} full movies online only on JioCinema.`;
    case 'CAC':
      return `Watch ${fullTitle.capitalize()} All latest episodes live online on JioCinema. Get best quality online streaming of all Colors Hindi TV Show videos for free. Vote now for your favourite contestant.`;
    case 'CHANNEL':
      return `${fullTitle.capitalize()} - Browse through the list of All Viacom 18 Network TV Channels, Colors, MTV, Nick and many more on JioCinema.com. Best quality streaming of all popular TV serials, movies, vidoes & reality shows online.`;
    case 'SERIES':
      return `Watch ${showTitle ? showTitle.capitalize() : ''} All latest episodes live online on JioCinema. Get best quality online streaming of all Colors Hindi TV Show videos for free. Vote now for your favourite contestant.`;
    default:
      return 'JioCinema - Watch free online streaming of your favourite TV Shows, Movies, Kids Shows - Hindi, Tamil, Bengali, Kannada and more with Colors, MTV, NICK and many of your favourite channels in HD quality on, India’s leading online streaming platform.';
  }
}

function getImage(obj) {
  return config.imageCDN;
}

function getUrlStructure(mediaType, fullTitle = '', id, showTitle, showId, seasonId, season) {
  switch (mediaType) {
    case 'SHOW':
      return `${vootBaseUrl}/shows/${getSlugifiedString(fullTitle)}/${id}`;
    case 'EPISODE':
      return `${vootBaseUrl}/shows/${getSlugifiedString(showTitle)}/${season}/${seasonId}/${getSlugifiedString(fullTitle)}/${id}`;
    case 'LIVECHANNEL':
      return `${vootBaseUrl}/news/${getSlugifiedString(fullTitle)}-live/${id}`;
    case 'MOVIE':
      return `${vootBaseUrl}/movie/${getSlugifiedString(fullTitle)}/${id}`;
    case 'CAC':
      return `${vootBaseUrl}/shows/${getSlugifiedString(showTitle)}/${season}/${seasonId}/${getSlugifiedString(fullTitle)}/${id}`;
    case 'CHANNEL':
      return `${vootBaseUrl}/channels/${getSlugifiedString(fullTitle)}/${id}`;
    case 'SERIES':
      return `${vootBaseUrl}/shows/${getSlugifiedString(showTitle)}/${showId}?s${season}`;
    default:
      return vootBaseUrl;
  }
}

function getExtraKeywords(mediaType, fullTitle = '', genre, showTitle, season, episode, isPremium, SBU, language, telecastDate, releaseYear, description) {
  switch (mediaType) {
    case 'SHOW':
      if (isPremium) {
        switch (SBU) {
          case 'VORG':
          case 'VOST':
            return [fullTitle, `web series ${fullTitle}`, `web series ${fullTitle} HD streaming online`, `web show ${fullTitle} online`, `watch ${fullTitle} online`, `${genre} ${fullTitle}`, `${fullTitle} JioCinema Show`, 'JioCinema shows', 'JioCinema TV series'];
          default:
            return [fullTitle, `${fullTitle} all seasons`, `${fullTitle} ${sbuMapping[SBU] || ''} TV Show`, `${fullTitle} hd streaming`, `${fullTitle} HD streaming online`, `web show ${fullTitle} online`, `watch ${fullTitle} online`, `${genre} ${fullTitle}`, `${fullTitle} JioCinema Show`, 'JioCinema shows', 'JioCinema TV series'];
        }
      } else {
        switch (genre.toUpperCase()) {
          case 'NEWS':
            return [fullTitle, `${sbuMapping[SBU] || ''} news`, `${language} news`, 'TV news', `${fullTitle} episodes`, 'news shows videos', `${fullTitle} videos`];
          case 'REALITY':
            return [fullTitle, `${fullTitle} all seasons`, `${fullTitle} ${sbuMapping[SBU] || ''} TV Show`, `watch ${fullTitle}`, `watch ${fullTitle} online`, `${fullTitle} hd streaming`, `${fullTitle} free streaming`];
          default:
            return [fullTitle, `${fullTitle} all seasons`, `${fullTitle} ${sbuMapping[SBU] || ''} TV Serial`, `watch ${fullTitle}`, `watch ${fullTitle} online`, `${fullTitle} hd streaming`, `${fullTitle} free streaming`];
        }
      }
    case 'EPISODE':
      if (isPremium) {
        switch (SBU) {
          case 'VORG':
          case 'VOST':
            return [`Episode ${episode} - ${fullTitle}`, showTitle, `Web Series ${showTitle}`, `${showTitle} Season ${season} Episode ${episode}`, `${showTitle} webisode ${episode}`, fullTitle, `watch ${showTitle} Episode ${episode} online`, `watch ${showTitle} HD Streaming online`, `${showTitle} ${releaseYear}`, `${showTitle} video`];
          default:
            return [`${showTitle} ${episode}`, `${showTitle} ${telecastDate}`, `${fullTitle}`, `${showTitle}`, `${showTitle} ${season}`, `${showTitle} ${sbuMapping[SBU] || ''} TV Show`, `watch ${showTitle} Season ${season} Episode ${episode} online`, 'HD Streaming online'];
        }
      } else {
        switch (genre.toUpperCase()) {
          case 'NEWS':
            return [`${fullTitle}`, `${showTitle}`, `${sbuMapping[SBU] || ''} news`, `${language} news`, 'TV news', `${showTitle} episodes`, `${fullTitle} news shows videos`, `${showTitle} videos`, `${fullTitle} telecasted on ${telecastDate}`];
          case 'REALITY':
            return [`${showTitle} ${episode}`, `${showTitle} ${telecastDate}`, `${fullTitle}`, `${showTitle}`, `${showTitle} ${season}`, `${showTitle} ${sbuMapping[SBU] || ''} TV Show`, `watch ${showTitle} Season ${season} Episode ${episode} online`, 'HD Streaming online'];
          default:
            return [`${showTitle} ${episode}`, `${showTitle} ${telecastDate}`, `${fullTitle}`, `${showTitle}`, `${showTitle} ${season}`, `${showTitle} ${sbuMapping[SBU] || ''} TV Serial`, `watch ${showTitle} Season ${season} Episode ${episode} online`, 'HD Streaming online'];
        }
      }
    case 'MOVIE':
      return [fullTitle, `${fullTitle} ${releaseYear} Online`, `Watch ${language} Movie ${fullTitle} online`, `Watch ${fullTitle} ${releaseYear}`, `${fullTitle} HD Streaming Online`, `${fullTitle} videos`];
    default:
      return [];
  }
}

// if field doesn't exist then returning null to trigger the auto-generated functions
function getSeoFeilds(obj, field, seoTags) {
  if (obj && obj[field]) {
    const regEx = new RegExp(Object.keys(seoTags).join("|"), "gi");
    const res = obj[field].replace(regEx, function (match) { return seoTags[match] });
    return res;
  }
  return '';
}

/**
 * Extract and merge linear asset seo and show level linear seo
 * @param {Object} linearAssetSeo SEO Metadata of linear asset
 * @param {Object} showLinearSeo SEO Metadata of show page linear seo
 * @returns 
 */
function extractLiveChannelSeoMetadata(linearAssetSeo = {}, showLinearSeo = {}) {
  const extractedSeo = {};
  // Choose show level linear seo if asset level seo not available
  extractedSeo.imgTitle = linearAssetSeo.imgTitle ? linearAssetSeo.imgTitle : showLinearSeo.imgTitle;
  extractedSeo.focusKeywords = linearAssetSeo.focusKeywords ? linearAssetSeo.focusKeywords : showLinearSeo.focusKeywords;
  extractedSeo.imgAltTags = linearAssetSeo.imgAltTags ? linearAssetSeo.imgAltTags : showLinearSeo.imgAltTags;
  extractedSeo.description = linearAssetSeo.description ? linearAssetSeo.description : showLinearSeo.description;
  extractedSeo.page = linearAssetSeo.page ? linearAssetSeo.page : showLinearSeo.page;
  extractedSeo.title = linearAssetSeo.title ? linearAssetSeo.title : showLinearSeo.title;
  return extractedSeo;
}

function getNewUrlStructure(id, showName, fullTitle, seasonName, season, mediaType = '', seasonId = '', genres = [], options = { isPlayback: true }) {
  const defaultRoute = jcBaseUrl;
  if (!id || !mediaType) {
    return defaultRoute;
  }
  const showTitle = showName || seasonName || fullTitle || '';
  const seasonNo = season || seasonId || 1;
  const isSports = genres.includes('Sports');
  if (mediaType === 'MOVIE') {
    const { isPlayback } = options;
    if (isPlayback) {
      return `${defaultRoute}/movies/${getSlugifiedString(showTitle)}/${id}/watch`;
    }
    return `${defaultRoute}/movies/${getSlugifiedString(showTitle)}/${id}`;
  }
  if (mediaType === 'SHOW') {
    if (isSports) {
      return `${defaultRoute}/sports/${getSlugifiedString(fullTitle)}/${id}`;
    }
    return `${defaultRoute}/tv-shows/${getSlugifiedString(showTitle)}/${id}`;
  }
  if (mediaType === 'EPISODE') {
    if (isSports) {
      return `${defaultRoute}/sports/${getSlugifiedString(fullTitle)}/${id}`;
    }
    return `${defaultRoute}/tv-shows/${getSlugifiedString(showTitle)}/${seasonNo}/${getSlugifiedString(fullTitle)}/${id}`;
  }
  if (['CAC', 'LIVECHANNEL'].includes(mediaType)) {
    if (isSports) {
      return `${defaultRoute}/sports/${getSlugifiedString(fullTitle)}/${id}`;
    }
    return `${defaultRoute}/videos/${getSlugifiedString(fullTitle)}/${id}`;
  }
  return defaultRoute;
}

exports.getSEOMetaObject = (obj, show = {}) => {
  const meta = obj.meta || {};
  const details = obj.details || {};
  const showDetails = show.details || {};
  const showMeta = show.meta || {};
  const seo = meta.seo || {};
  const isPremium = (details.marketType === 'PREMIUM' || details.marketType === 'PREMIER');
  let isShowPremium = (showDetails.marketType === 'PREMIUM' || showDetails.marketType === 'PREMIER');
  const fullTitle = meta.title ? meta.title.full : obj.name;
  let showTitle = showMeta.title ? showMeta.title.full : show.name;
  const fullSynopsis = meta.synopsis ? meta.synopsis.full : '';
  const description = fullSynopsis.split('.')[0] || '';
  const genre = (Array.isArray(meta.genres) && meta.genres.length ? meta.genres[0] : '');
  const language = Array.isArray(meta.languages) && meta.languages.length ? meta.languages[0] : '';
  let episode = '';
  let season = '';
  let showId = '';
  let seasonId = '';
  const showSeo = showMeta.seo || {};
  if (['CAC', 'EPISODE'].includes(details.mediaType)) {
    episode = `${meta.series.episode || ''}`;
    season = `${meta.series.season || ''}`;
    showId = `${meta.series.showId || ''}`;
    seasonId = `${meta.series.id || ''}`;
    if (!showTitle) {
      showTitle = meta.series.name;
    }
    if (showSeo && showSeo.episode && ['EPISODE'].includes(details.mediaType)) {
      Object.assign(seo, showSeo.episode);
    }
    if (showSeo && showSeo.cac && ['CAC'].includes(details.mediaType)) {
      Object.assign(seo, showSeo.cac);
    }
  } else if (['SERIES'].includes(details.mediaType)) {
    season = `${meta.season || ''}`;
    showId = `${meta.showId || ''}`;
    isShowPremium = isPremium || isShowPremium;
  } else if (['SHOW'].includes(details.mediaType)) {
    isShowPremium = isPremium || isShowPremium;
  } else if(['LIVECHANNEL'].includes(details.mediaType)) {
    Object.assign(seo, extractLiveChannelSeoMetadata(seo, showSeo.linear));
  }
  const SBU = meta.SBU || '';
  let telecastDate = obj.telecasted || '';
  if (telecastDate) {
    telecastDate = `${telecastDate}`.replace(/(\d{4})(\d{2})(\d{2})/g, '$3-$2-$1');
  }
  if (!telecastDate && obj.created) {
    telecastDate = new Date((obj.created + (-330 * 60)) * 1000).toISOString().split('T')[0].split('-').reverse().join('-');
  }
  let { releaseYear } = meta;
  if (!releaseYear && obj.created) {
    releaseYear = parseInt(`${telecastDate}`.substr(-4), 10);
  }
  const seoTitle = getTitle(
    details.mediaType, fullTitle, genre, showTitle, season, episode, isShowPremium, SBU, language, telecastDate, releaseYear,
  );
  const seoDescription = getDescription(
    details.mediaType, fullTitle, genre, showTitle, season, episode, isShowPremium, SBU, language, telecastDate, releaseYear, description,
  );
  const extraKeywords = getExtraKeywords(
    details.mediaType, fullTitle, genre, showTitle, season, episode, isShowPremium, SBU, language, telecastDate, releaseYear, description,
  );
  const seoTags = {
    '<title>': fullTitle,
    '<description>': description,
    '<show name>': showTitle || '',
    '<telecast date>': telecastDate,
    '<season number>': season,
    '<episode number>': episode,
    '<sbu name>': sbuMapping[SBU],
    '<release year>': releaseYear
  }
  if(Array.isArray(seo.focusKeywords)){
    seo.focusKeywords = seo.focusKeywords.filter(word => word != '');
  }
  const seoFocusKeywords = Array.isArray(seo.focusKeywords) && seo.focusKeywords.length ? seo.focusKeywords : extraKeywords;
  const seoObject = {
    page: getSeoFeilds(seo, 'page', seoTags) || getPageName(details.mediaType, fullTitle, genre, showTitle, season, episode),
    title: getSeoFeilds(seo, 'title', seoTags) || seoTitle.capitalize(),
    urlStructure: seo.urlStructure || getUrlStructure(details.mediaType, fullTitle, obj.id, showTitle, showId, seasonId, season),
    urlStructureNew: seo.urlStructure || getNewUrlStructure(obj.id, showTitle, fullTitle, showTitle, season, details.mediaType, seasonId, genre),
    description: getSeoFeilds(seo, 'description', seoTags) || seoDescription.capitalize(),
    keywords: [...seoFocusKeywords, ...(meta.keywords || [])],
    ogTitle: getSeoFeilds(seo, 'title', seoTags) || seoTitle.capitalize(),
    ogDescription: getSeoFeilds(seo, 'description', seoTags) || seoDescription.capitalize(),
    ogImage: seo.ogImage || getImage(obj),
    imgTitle: getSeoFeilds(seo, 'imgTitle', seoTags) || fullTitle,
    imgAltTags: getSeoFeilds(seo, 'imgAltTags', seoTags) || getImgAltTags(details.mediaType, fullTitle, SBU, genre, isShowPremium, episode),
  };
  return seoObject;
};

exports.source = ['id', 'availability', 'details.mediaType', 'meta.type', 'meta.downloadable', 'meta.SBU', 'meta.languages'];

exports.transform = (obj) => {
  const meta = obj.meta || {};
  const details = obj.details || {};
  return {
    id: obj.id,
    mediaType: details.mediaType,
    mediaSubType: meta.type,
    downloadable: meta.downloadable === 'yes',
    SBU: meta.SBU,
    multiTrackAudioEnabled: (meta.languages && meta.languages.length > 1),
  };
};

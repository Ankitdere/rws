/* eslint-disable camelcase */
const seoMetaGenerator = require('./../seoMetaGenerator');
const deepLinkGenerator = require('../deepLinkGenerator');
const utils = require('./utils');

exports.source = ['id', 'updated', 'availability', 'revised', 'created', 'meta.assetRef', 'meta.isDAIEnabled', 'meta.daiAssetKey', 'meta.isDVREnabled', 'meta.isHLSEnabled', 'meta.type', 'meta.seo', 'details.externalId', 'details.kalturaMedia', 'details.image', 'meta.contentDescriptor', 'meta.releaseYear', 'telecasted', 'slug', 'details.mediaType', 'meta.series', 'meta.genres', 'meta.characters', 'meta.contributors', 'meta.showId', 'name', 'meta.season', 'meta.downloadable', 'meta.synopsis', 'meta.title', 'meta.languages', 'meta.SBU', 'meta.age', 'meta.intro', 'meta.credit', 'meta.recap', 'details.mediaVariants', 'details.marketType', 'meta.isPremium', 'meta.keywords', 'meta.onAir', 'details.jioMedia', 'meta.contentSubject', 'details', 'config'];

function getDefaultLangugage(languages, profile = {}) {
  if (!languages || languages.length === 0) {
    return '';
  }
  const profileUrl = profile.url;
  if (languages.length === 1) {
    return languages[0];
  }
  if (profileUrl && profileUrl.indexOf('defaultAudioLang') > -1) {
    const start = profileUrl.indexOf('defaultAudioLang') + 17;
    const end = profileUrl.indexOf('/', start);
    return profileUrl.substring(start, end);
  }
  return languages[0];
}

function getImages(details, meta) {
  const suffixes = [];
  suffixes['16x9'] = '_1280X720';
  suffixes['4x3'] = '_1024X768';
  suffixes['1x1'] = '_320X320';
  suffixes['2x3'] = "_850X1275";
  const images = {
    imageUri: '',
    image16x9: '',
    image4x3: '',
    image1x1: '',
    image2x3: '',
    showImage: '',
  };

  if (details.image && details.image.id && details.image.id.includes('kimg')) {
    images.imageUri = `${details.image.id + suffixes['16x9']}.${details.image.type}`;
    images.image16x9 = `${details.image.id + suffixes['16x9']}.${details.image.type}`;
    images.image4x3 = `${details.image.id + suffixes['4x3']}.${details.image.type}`;
    images.image1x1 = `${details.image.id + suffixes['1x1']}.${details.image.type}`;
    images.image2x3 = `${details.image.id + suffixes['2x3']}.${details.image.type}`;
  } else {
    images.imageUri = `${details.image.id}.${details.image.type}`;
    images.image16x9 = `${details.image.id}.${details.image.type}`;
    images.image4x3 = `${details.image.id}.${details.image.type}`;
    images.image1x1 = `${details.image.id}.${details.image.type}`;
    images.image2x3 = `${details.image.id}.${details.image.type}`;
  }

  if (meta.showId) {
    images.showImage = `v3Storage/showImages/${meta.showId}.jpg`;
  } else if (meta.series && meta.series.showId) {
    images.showImage = `v3Storage/showImages/${meta.series.showId}.jpg`;
  }

  return images;
}

exports.transform = (obj, playback, show = {}) => {
  const meta = obj.meta || {};
  const details = obj.details || {};
  const availability = obj.availability || {};
  let showId = '';
  let seasonName = '';
  let seasonId = '';
  let episode = '';
  let season = '';
  let assetRef = {};
  let name = '';
  let showName = '';
  let sampledCount = 0;
  name = obj.name;
  const contentSubject = meta.contentSubject || '';

  let pubmaticAdsEnabled = true;
  const isConfigKeyPresent = (obj && obj.config) || false;

  // there can be other keys present in config apart from pubmaticAdsEnabled
  if (isConfigKeyPresent && Object.keys(obj.config).includes('pubmaticAdsEnabled')) {
    // if pubmaticAdsEnabled key present then take whatever value is assigned
    pubmaticAdsEnabled = !!obj.config.pubmaticAdsEnabled;
  }


  const showDetails = show.details || {};
  const showMeta = show.meta || {};
  let showImages = {};
  if (show.details && show.details.image) {
    showImages = getImages(showDetails, showMeta);
  }

  if (details.mediaType === 'EPISODE' || details.mediaType === 'CAC') {
    showId = `${meta.series.showId || ''}`;
    showName = `${meta.series.showName || ''}`;
    if (show.name) {
      showName = `${show.name || ''}`;
    }
    seasonName = `${meta.series.name || ''}`;
    seasonId = `${meta.series.id || ''}`;
    episode = `${meta.series.episode || ''}`;
    season = `${meta.series.season || ''}`;

    if (seasonName) name = seasonName;
    if (showName) name = showName;
  } else if (details.mediaType === 'SERIES') {
    showId = `${meta.showId || ''}`;
    showName = `${meta.showName || ''}`;
    if (show.name) {
      showName = `${show.name || ''}`;
    }
    seasonName = `${obj.name || ''}`;
    seasonId = `${obj.id || ''}`;
    season = `${meta.season || ''}`;
  } else if (details.mediaType === 'SHOW') {
    sampledCount = `${meta.sampledCount || 0}`;
    if (meta.assetRef) {
      assetRef = meta.assetRef;
    }
  } else if (details.mediaType === 'CUSTOM') {
    if (meta.assetRef) {
      assetRef = meta.assetRef;
    }
  }
  let telecastDate = obj.telecasted || '';
  if (!telecastDate && obj.created) {
    telecastDate = new Date((obj.created + (-330 * 60)) * 1000).toISOString().split('T')[0].replace(/-/g, '');
  }

  let { releaseYear } = meta;
  if (!releaseYear && obj.created) {
    releaseYear = parseInt(`${telecastDate}`.substring(0, 4), 10);
  }
  const assetImages = getImages(details, meta);
  if (showImages.imageUri) {
    assetImages.showImage = showImages.imageUri;
  }
  if (details.mediaType === 'SHOW') {
    assetImages.showImage = assetImages.imageUri;
  }
  if (details.mediaType === 'MOVIE') {
    assetImages.showImage = assetImages.imageUri;
  }
  let seo = {};
  try {
    seo = seoMetaGenerator.getSEOMetaObject(obj, show);
  } catch (e) {
    console.error(e);
  }
  seo.ogImage += assetImages.imageUri;
  let shortTitle = meta.title ? meta.title.short : '';
  const fullTitle = meta.title ? meta.title.full : '';
  if (!shortTitle) {
    shortTitle = fullTitle;
  }
  details.mediaVariants = details.mediaVariants ? details.mediaVariants : {};
  let isPremium = (details.marketType === 'PREMIUM' || details.marketType === 'PREMIER');
  const isShowPremium = (showDetails.marketType === 'PREMIUM' || showDetails.marketType === 'PREMIER');

  if (!isPremium) {
    isPremium = !!meta.isPremium;
  }
  let badgeName = meta.badgeName ? meta.badgeName : '';
  let badgeType = meta.badgeType ? meta.badgeType : 0;
  if (isPremium) {
    badgeName = 'Select';
    badgeType = 1;
  }
  let introStart = 0, introEnd = 0, recapStart = 0, recapEnd = 0, creditStart = 0, creditEnd = 0;
  const intro = meta.intro || false;
  const recap = meta.recap || false;
  const credit = meta.credit || false;
  if (intro) {
    introStart = intro.start || 0;
    introEnd = intro.end || 0;
  }
  if (recap) {
    recapStart = recap.start || 0;
    recapEnd = recap.end || 0;
  }
  if (credit) {
    creditStart = credit.start || 0;
    creditEnd = credit.end || 0;
  }
  let playbackType;
  let jioMediaId;
  if (details.mediaType === 'JIOCHANNEL') {
    playbackType = 'DASH_LINEAR_JIO';
    if (details.jioMedia) {
      jioMediaId = details.jioMedia.id;
    }
  }
  let uploadTime;
  if (availability && availability.available && availability.available.IN.from) {
    uploadTime = availability.available.IN.from;
  }
  const assetMarketType = details.marketType || 'STANDARD'
  const showMarketType = showDetails.marketType || 'STANDARD';
  const deeplinkUrl = deepLinkGenerator.getDeepLink(obj);

  const ageMap = utils.getAgeMappings(meta.age);

  return {
    playbackType,
    id: `${obj.id}`,
    mediaType: details.mediaType,
    mediaSubType: meta.type,
    downloadable: meta.downloadable === 'yes',
    languages: meta.languages,
    defaultLanguage: getDefaultLangugage(meta.languages, details.mediaVariants.DASH_MOBILE),
    SBU: meta.SBU,
    multiTrackAudioEnabled: (meta.languages && meta.languages.length > 1),
    shortSynopsis: meta.synopsis ? meta.synopsis.short : '',
    fullSynopsis: meta.synopsis ? meta.synopsis.full : '',
    shortTitle,
    fullTitle,
    showId,
    showName,
    seasonId,
    seasonName,
    season,
    sampledCount,
    episode,
    genres: meta.genres,
    contributors: meta.contributors,
    characters: meta.characters,
    slug: seo.urlStructure,
    assetRef,
    telecastDate: `${telecastDate}`,
    releaseYear,
    contentDescriptor: meta.contentDescriptor,
    contentSubject,
    age: meta.age,
    ageNumeric: ageMap.numeric,
    ageNemonic: ageMap.nemonic,
    name,
    entryId: details.kalturaMedia ? details.kalturaMedia.entryId : '',
    duration: details.duration || 0,
    imageUri: assetImages.imageUri,
    image16x9: assetImages.image16x9,
    image4x3: assetImages.image4x3,
    image1x1: assetImages.image1x1,
    image2x3: assetImages.image2x3,
    showImage: assetImages.showImage,
    externalId: details.externalId,
    updated: obj.revised ? obj.revised : obj.updated,
    badgeName,
    badgeType,
    isPremium,
    isShowPremium,
    onAir: meta.onAir,
    seo,
    introStart,
    introEnd,
    recapStart,
    recapEnd,
    creditStart,
    creditEnd,
    deeplinkUrl,
    jioMediaId,
    isDAIEnabled: !!meta.isDAIEnabled,
    daiAssetKey: meta.daiAssetKey || '',
    isDVREnabled: !!meta.isDVREnabled,
    isHLSEnabled: !!meta.isHLSEnabled,
    uploadTime,
    assetMarketType,
    showMarketType,
    trailerId: `${meta.trailerId || ''}`,
    pubmaticAdsEnabled
  };
};

const common = require('./common');
const deepLinkGenerator = require('../deepLinkGenerator');
const config = require('../const.json');
const utils = require('./utils');

exports.source = undefined;

exports.transform = (obj, playback, show) => {
  const resp = common.transform(obj, playback, show);
  const meta = obj.meta || {};
  const details = obj.details || {};
  const partnerImages = utils.getPartnerImages(details, meta);
  const baseUrl = config.imageCDN;
  const imageUri = `${baseUrl}${partnerImages.imageUri}`;
  const image16x9 = `${baseUrl}${partnerImages.image16x9}`;
  const image4x3 = `${baseUrl}${partnerImages.image4x3}`;
  const image1x1 = `${baseUrl}${partnerImages.image1x1}`;
  const image2x3 = `${baseUrl}${partnerImages.image2x3}`;
  const image3x4 = partnerImages.image3x4 ? `${baseUrl}${partnerImages.image3x4}` : '';
  const image9x16 = partnerImages.image9x16 ? `${baseUrl}${partnerImages.image9x16}` : '';
  const showImage = partnerImages.showImage ? `${baseUrl}${partnerImages.showImage}` : '';

  let seriesImage = '';
  if (resp.seasonId) {
    seriesImage = `${baseUrl}v3Storage/showImages/${resp.seasonId}.jpg`;
  }
  resp.deeplinkUrl = deepLinkGenerator.getPartnerDeeplinkWithoutSource(obj);
  delete resp.seo;
  delete resp.imageUri2;
  return {
    ...resp,
    imageUri,
    image16x9,
    image4x3,
    image1x1,
    image2x3,
    image3x4,
    image9x16,
    showImage,
    seriesImage,
  };
};
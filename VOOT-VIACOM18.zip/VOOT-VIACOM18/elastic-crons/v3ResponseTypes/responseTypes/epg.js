/* eslint-disable no-param-reassign */
function getImages(details) {
  const suffixes = [];
  suffixes['16x9'] = '_1280X720';
  suffixes['4x3'] = '_1024X768';
  suffixes['1x1'] = '_320X320';
  suffixes['2x3'] = '_850X1275';
  const images = {
    imageUri: '',
    image16x9: '',
    image4x3: '',
    image1x1: '',
    image2x3: '',
  };

  if (details.image && details.image.id && details.image.id.includes('kimg')) {
    images.imageUri = `${details.image.id + suffixes['16x9']}.${details.image.type}`;
    images.image16x9 = `${details.image.id + suffixes['16x9']}.${details.image.type}`;
    images.image4x3 = `${details.image.id + suffixes['4x3']}.${details.image.type}`;
    images.image1x1 = `${details.image.id + suffixes['1x1']}.${details.image.type}`;
    images.image2x3 = `${details.image.id + suffixes['2x3']}.${details.image.type}`;
  } else {
    images.imageUri = `${details.image.id}.${details.image.type}`;
    images.image16x9 = `${details.image.id}.${details.image.type}`;
    images.image4x3 = `${details.image.id}.${details.image.type}`;
    images.image1x1 = `${details.image.id}.${details.image.type}`;
    images.image2x3 = `${details.image.id}.${details.image.type}`;
  }

  return {
    imageUri: images.imageUri,
  };
}

exports.transform = (obj, playbackType, channel = {}) => {
  const meta = obj.meta || {};
  const details = obj.details || {};
  const assetImages = getImages(details, meta);

  const channelDetails = channel.details || {};
  const channelMeta = channel.meta || {};
  let isPremium = (channelDetails.marketType === 'PREMIUM' || channelDetails.marketType === 'PREMIER');
  if (!isPremium) {
    isPremium = !!channelMeta.isPremium;
  }
  let badgeName = channelMeta.badgeName ? channelMeta.badgeName : '';
  let badgeType = channelMeta.badgeType ? channelMeta.badgeType : 0;
  if (isPremium) {
    badgeName = 'Select';
    badgeType = 1;
  }

  return {
    ...assetImages,
    channelId: obj.channelId,
    name: obj.name,
    fromTime: obj.time.from,
    toTime: obj.time.to,
    badgeName,
    badgeType,
    isPremium,
    SBU: channelMeta.SBU,
    programId: meta.programId,
    mediaType: channelDetails.mediaType,
  };
};

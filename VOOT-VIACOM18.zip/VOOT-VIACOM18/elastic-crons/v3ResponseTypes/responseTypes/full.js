/* eslint-disable no-param-reassign */
exports.source = ['meta.downloadable', 'meta.languages', 'meta.SBU', 'meta.synopsis.*', 'meta.title.*', 'meta.type', 'meta.characters', 'meta.releaseYear',
  'meta.subHeading.*', 'meta.series.*', 'meta.genres', 'meta.assetRef', 'meta.assetType', 'meta.contributors', 'meta.season', 'name', 'details.image', 'details.kalturaMedia',
  'details.externalId', 'details.mediaType', 'id', 'availability', 'slug', 'meta.age', 'meta.contentDescriptor', 'meta.videoFormat', 'ingested', 'created', 'updated', 'telecasted', 'meta.contentSubject', 'config'];

exports.transform = (obj) => {
  delete obj.availability;
  return obj;
};

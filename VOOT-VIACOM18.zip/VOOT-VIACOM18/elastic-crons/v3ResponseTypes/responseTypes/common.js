const seoMetaGenerator = require('../seoMetaGenerator');
const deepLinkGenerator = require('../deepLinkGenerator');
const shotsResponseType = require('./shots');
const utils = require('./utils');
const { getSportsInformation } = require('../sportsMetaData');
const { getKeyMomentsInfo } = require('../keyMoments');

exports.source = ['id', 'updated', 'availability', 'revised', 'created', 'meta.assetRef', 'meta.trailerId',
  'meta.isDAIEnabled', 'meta.daiAssetKey', 'meta.isDVREnabled', 'meta.isHLSEnabled', 'meta.type',
  'meta.seo', 'details.externalId', 'details.kalturaMedia', 'details.image', 'details.oneLink', 'meta.contentDescriptor',
  'meta.releaseYear', 'telecasted', 'slug', 'details.mediaType', 'meta.series', 'meta.genres',
  'meta.characters', 'meta.contributors', 'meta.showId', 'name', 'meta.season', 'meta.seasonDisplay', 'meta.downloadable',
  'meta.synopsis', 'meta.title', 'meta.languages', 'meta.SBU', 'meta.age', 'meta.intro', 'meta.credit',
  'meta.recap', 'details.mediaVariants', 'details.marketType', 'meta.isPremium', 'meta.keywords',
  'meta.onAir', 'details.jioMedia', 'meta.pwaAllowAnonymous', 'details.gracenote', 'meta.needsCameraAccess',
  'meta.contentSubject', 'details', 'config', 'details.mediaVariants', 'meta.sourceDeeplink', 'meta.hashtags',
  'meta.refShowId', 'meta.refSeriesId', 'meta.topic', 'stats', 'ingested', 'meta.subGenre', 'meta.sportsInformation',
  'meta.mediaDescription', 'meta.movieProducer', 'meta.movieDirector', 'meta.label', 'meta.cueTimes',
  'meta.assetsByLanguage', 'meta.gameSeriesId', 'meta.gameId', 'meta.gameWidgetLink', 'meta.isMatchCentreEnabled',
  'meta.isPublicOpinionEnabled', 'meta.isPlayAlongEnabled', 'meta.isWatchPartyEnabled', 'meta.line1', 'meta.line2', 'meta.line3',
  'meta.adsEnabled', 'meta.adDetails', 'meta.matchCentreLink', 'meta.publicOpinionLink', 'meta.playAlongLink',
  'meta.watchPartyLink', 'meta.isVirtualShow', 'meta.matchCentreActionType', 'meta.playAlongActionType',
  'meta.publicOpinionActionType', 'meta.watchPartyActionType', 'meta.matchCentreLabel', 'meta.watchPartyLabel',
  'meta.playAlongLabel', 'meta.publicOpinionLabel', 'meta.multiCamInfo', 'meta.labelText', 'meta.liveAdPlayMode',
  'meta.assetsByFeed', 'meta.cam360Info', 'meta.isConcurrencyDisplayed', 'meta.is4KSupported', 'meta.matchCentreIcon',
  'meta.publicOpinionIcon', 'meta.playAlongIcon', 'meta.watchPartyIcon', 'meta.audioType', 'meta.keyMomentsInfo', 'meta.advertiserName',
  'meta.matchNumber', 'meta.concurrencyData', 'details.multiAudioMeta'];

const subtitleLanguageMap = {
  'en': 'English',
  'hi': 'Hindi'
};

function getDefaultLangugage(languages, profile = {}) {
  if (!languages || languages.length === 0) {
    return '';
  }
  const profileUrl = profile.url;
  if (languages.length === 1) {
    return languages[0];
  }
  if (profileUrl && profileUrl.indexOf('defaultAudioLang') > -1) {
    const start = profileUrl.indexOf('defaultAudioLang') + 17;
    const end = profileUrl.indexOf('/', start);
    return profileUrl.substring(start, end);
  }
  return languages[0];
}

const mandatoryFixtureFields = ['id', 'mediaType', 'mediaSubType', 'SBU', 'shortSynopsis', 'fullSynopsis', 'shortTitle',
  'fullTitle', 'showId', 'showName', 'seasonId', 'seasonName', 'season', 'seasonDisplay', 'sampledCount',
  'episode', 'genres', 'age', 'name', 'ageNumeric', 'ageNemonic', 'showImage', 'updated', 'assetMarketType',
  'ingested', 'sportsInformation', 'assetRef', 'imageUri', 'image16x9', 'image4x3', 'image1x1', 'image2x3', 'image3x4',
  'image9x16', 'animation16x9', 'animationUri', 'line1', 'line2', 'line3', 'matchCardActions'];

function getFixtureResponse(resp) {
  Object.keys(resp).forEach((key) => {
    if (!mandatoryFixtureFields.includes(key)) {
      delete resp[key];
    }
  });
  return resp;
}

const OLD_ASSET_DATE = 1593561600;

/**
 * 
 * @param {{}} obj - The asset which needs to be transformed
 * @param {{}} playback 
 * @param {{}} show - The show to which this asset belongs
 * @param {string} imageSize - Aspect ratio of images to be returned
 * @param {{}} options - Collection for options that need to be passed (current and future)
 * @returns {{}} the transformed object
 * 
 * options object can be used to send across additional options without changing the method
 * signature.
 * It currently contains the following:
 * options = {
 *  validValues: {} - all valid values (including metadata management)
 * }
 */

exports.transform = (obj, playback, show = {}, imageSize = '16x9', options = {}, reqQuery = {}) => {
  const meta = obj.meta || {};
  const details = obj.details || {};
  const availability = obj.availability || {};
  const validValues = options.validValues || {};
  const carouselMeta = options.carouselMeta || {};
  const playableAsset = ['MOVIE', 'EPISODE', 'CAC', 'LIVECHANNEL'].includes(details.mediaType);
  const devicePlatformType = reqQuery.type || reqQuery.devicePlatformType;
  const isSportsAsset = meta.genres && Array.isArray(meta.genres) && meta.genres.some((genre) => genre.toLowerCase() === 'sports')

  let showId = '';
  let seasonName = '';
  let seasonId = '';
  let episode = '';
  let season = '';
  let seasonDisplay = '';
  let assetRef = {};
  let name = '';
  let showName = '';
  let sampledCount = 0;
  name = obj.name;
  const contentSubject = meta.contentSubject || '';

  let pubmaticAdsEnabled = true;
  const isConfigKeyPresent = (obj && obj.config) || false;

  // there can be other keys present in config apart from pubmaticAdsEnabled
  if (isConfigKeyPresent && Object.keys(obj.config).includes('pubmaticAdsEnabled')) {
    // if pubmaticAdsEnabled key present then take whatever value is assigned
    pubmaticAdsEnabled = !!obj.config.pubmaticAdsEnabled;
  }

  const showDetails = show.details || {};
  const showMeta = show.meta || {};
  let showImages = {};
  if (show.details && show.details.image) {
    showImages = utils.getImages(showDetails, showMeta);
  }
  let oldJioAsset = false;
  if (obj.ingested && obj.ingested < OLD_ASSET_DATE) {
    oldJioAsset = true;
  }
  if (obj.created && obj.created < OLD_ASSET_DATE) {
    oldJioAsset = true;
  }
  if (['EPISODE', 'CAC', 'LIVECHANNEL', 'PCCHANNEL'].includes(details.mediaType)) {
    if (!('series' in meta)) {
      meta.series = {};
    }
    showId = `${meta.series.showId || ''}`;
    showName = `${meta.series.showName || ''}`;
    if (show.name) {
      showName = `${show.name || ''}`;
    }
    seasonName = `${meta.series.name || ''}`;
    seasonId = `${meta.series.id || ''}`;
    episode = `${meta.series.episode || ''}`;
    season = `${meta.series.season || ''}`;
    seasonDisplay = `${meta.series.seasonDisplay || seasonName || ''}`;

    if (seasonName) name = seasonName;
    if (showName) name = showName;
  } else if (details.mediaType === 'SERIES') {
    showId = `${meta.showId || ''}`;
    showName = `${meta.showName || ''}`;
    if (show.name) {
      showName = `${show.name || ''}`;
    }
    seasonName = `${obj.name || ''}`;
    seasonId = `${obj.id || ''}`;
    season = `${meta.season || ''}`;
    seasonDisplay = `${meta.seasonDisplay || seasonName || ''}`;
  } else if (details.mediaType === 'SHOW') {
    if (meta.sampledCount) {
      sampledCount = parseInt(meta.sampledCount, 10);
    }
    if (Number.isNaN(meta.sampledCount)) {
      sampledCount = 0;
    }
    if (meta.assetRef) {
      assetRef = meta.assetRef;
    }
  } else if (details.mediaType === 'CUSTOM') {
    if (meta.assetRef) {
      assetRef = meta.assetRef;
    }
    if (meta && meta.series && meta.series.showId) {
      showId = `${meta.series.showId || ''}`;
      showName = `${meta.series.showName || ''}`;
      if (show.name) {
        showName = `${show.name || ''}`;
      }
      seasonName = `${meta.series.name || ''}`;
      seasonId = `${meta.series.id || ''}`;
      episode = `${meta.series.episode || ''}`;
      season = `${meta.series.season || ''}`;

      if (seasonName) name = seasonName;
      if (showName) name = showName;
    }
  } else if (details.mediaType === 'SHOTS') {
    if (!('series' in meta)) {
      meta.series = {};
    }
    showId = `${meta.series.showId || ''}`;
    showName = `${meta.series.showName || ''}`;
    if (show.name) {
      showName = `${show.name || ''}`;
    }
    seasonName = `${meta.series.name || ''}`;
    seasonId = `${meta.series.id || ''}`;
    episode = `${meta.series.episode || ''}`;
    season = `${meta.series.season || ''}`;
    seasonDisplay = `${meta.series.seasonDisplay || seasonName || ''}`;
  }

  if (meta.assetRef) {
    assetRef = meta.assetRef;
  }

  const profilesDetails = details.profilesDetails || [];
  const assetSubtitles = details.subtitles || [];
  const hasSubtitles = assetSubtitles.length > 0;
  let is1080PSupported = false;
  let isDolbySupported = false, subtitles = [];
  profilesDetails.forEach((profile) => {
    if (profile.TYPE === 'VIDEO') {
      const resolution = profile.RESOLUTION.split('x');
      if (resolution.length === 2) {
        const height = !isNaN(resolution[1]) ? parseInt(resolution[1], 10) : 0;
        const fullHD = 1080, fourK = 2160;
        // Some assets have heights greater than 1080 (for ex: 1088)
        if (height >= fullHD && height < fourK) {
          is1080PSupported = true;
        }
        // if (height >= fourK) {
        //   is4KSupported = true;
        // }
      }
    } else if (profile.TYPE === 'AUDIO') {
      if (profile.CHANNELS === 6) {
        isDolbySupported = true;
      }
    }
  });

  // Show 4K support
  let is4KSupported = meta.is4KSupported || false;

  // Show level dolby support flag is driven from publishing
  if (['SHOW'].includes(details.mediaType)) {
    if (('assetRef' in meta) && ('dolbySupported' in meta.assetRef)) {
      isDolbySupported = meta.assetRef.dolbySupported;
    }
  }

  assetSubtitles.forEach((subtitle) => {
    if (subtitle.toLowerCase() in subtitleLanguageMap) {
      subtitles.push(subtitleLanguageMap[subtitle.toLowerCase()]);
    }
  });

  let telecastDate = obj.telecasted || '';
  if (!telecastDate && obj.created) {
    telecastDate = new Date((obj.created + (-330 * 60)) * 1000).toISOString().split('T')[0].replace(/-/g, '');
  }

  let { releaseYear } = meta;
  if (releaseYear) {
    releaseYear = parseInt(releaseYear, 10);
  }
  if ((!releaseYear || Number.isNaN(releaseYear)) && obj.created) {
    releaseYear = parseInt(`${telecastDate}`.substring(0, 4), 10);
  }
  const assetImages = utils.getImages(details, meta, imageSize);
  if (showImages.imageUri) {
    assetImages.showImage = showImages.imageUri;
  }
  if (details.mediaType === 'SHOW') {
    assetImages.showImage = assetImages.imageUri;
  }
  if (details.mediaType === 'MOVIE') {
    assetImages.showImage = assetImages.imageUri;
  }
  let seo = {};
  try {
    seo = seoMetaGenerator.getSEOMetaObject(obj, show);
  } catch (e) {
    console.error(e);
  }
  seo.ogImage += assetImages.imageUri;
  let shortTitle = meta.title ? meta.title.short : '';
  const fullTitle = meta.title ? meta.title.full : '';
  if (!shortTitle) {
    shortTitle = fullTitle;
  }
  details.mediaVariants = details.mediaVariants ? details.mediaVariants : {};
  let isPremium = (details.marketType === 'PREMIUM' || details.marketType === 'PREMIER');
  const isShowPremium = (showDetails.marketType === 'PREMIUM' || showDetails.marketType === 'PREMIER');

  if (!isPremium) {
    isPremium = !!meta.isPremium;
  }
  let badgeName = meta.badgeName ? meta.badgeName : '';
  let badgeType = meta.badgeType ? meta.badgeType : 0;
  if (isPremium) {
    badgeName = 'Select';
    badgeType = 1;
  }
  const labelText = meta.labelText || '';

  let introStart = 0; let introEnd = 0; let recapStart = 0; let recapEnd = 0; let creditStart = 0; let
    creditEnd = 0;
  const intro = meta.intro || false;
  const recap = meta.recap || false;
  const credit = meta.credit || false;
  if (intro) {
    introStart = intro.start || 0;
    introEnd = intro.end || 0;
  }
  if (recap) {
    recapStart = recap.start || 0;
    recapEnd = recap.end || 0;
  }
  if (credit) {
    creditStart = credit.start || 0;
    creditEnd = credit.end || 0;
  }
  let jioMediaId;
  if (details.jioMedia && details.jioMedia.id) {
    jioMediaId = `${details.jioMedia.id}`;
  } else {
    jioMediaId = `${obj.id}`;
  }
  let uploadTime;
  if (availability && availability.available && availability.available.IN && availability.available.IN.from) {
    uploadTime = availability.available.IN.from;
  }
  const assetMarketType = details.marketType || 'STANDARD';
  const showMarketType = (Object.keys(show).length === 0 && show.constructor === Object) ? assetMarketType : showDetails.marketType;
  const deeplinkUrl = deepLinkGenerator.getDeepLink(obj);
  const oneLinkUrl = utils.get(details, 'oneLink.url', '');

  let graceNoteId = '';
  let graceNoteType = '';
  if (details.gracenote && details.gracenote.id) {
    graceNoteId = details.gracenote.id;
    graceNoteType = 'gracenote_gvd';
  }

  const ageMap = utils.getAgeMappings(meta.age);

  let shotsMeta = {};
  if (details.mediaType.toUpperCase() === 'SHOTS') shotsMeta = { ...shotsResponseType.shotsNewFields(obj) };
  if ((details.mediaType.toUpperCase() === 'CONTAINER' || details.mediaType.toUpperCase() === 'CATEGORY') && details.mediaSubType.toUpperCase() !== 'TRAY CONTAINER') {
    assetRef = {}
  }

  let sportsInformation = {};
  if (meta.genres && meta.genres.find((genre) => genre.toLowerCase() === 'sports')) {
    sportsInformation = getSportsInformation(obj, validValues);
  }

  const synopsis = {
    short: '',
    full: ''
  };
  if (meta.synopsis) {
    if (meta.synopsis.full) {
      synopsis.full = meta.synopsis.full;
    }
    if (meta.synopsis.short) {
      synopsis.short = meta.synopsis.short.substring(0, 170);
    } else {
      synopsis.short = synopsis.full.substring(0, 170);
    }
  }

  let isPartnerAsset = false, partnerName = '';
  if (utils.get(details, 'jioMedia.isPartnerAsset', '') === true) {
    isPartnerAsset = true;
    partnerName = utils.get(details, 'jioMedia.partnerName', '');
  }

  const label = meta.label || '';
  const logo = details.logo || '';

  const audioType = meta.audioType || '1';

  let multiCamInfo = {};
  if (details.mediaType === 'LIVECHANNEL') {
    const multiCamConfig = meta.multiCamInfo || {};
    if (!multiCamConfig.isMultiCamEnabled) {
      multiCamInfo = { enabled: false };
    } else {
      multiCamInfo = {
        enabled: multiCamConfig.isMultiCamEnabled,
        broadcastStart: multiCamConfig.broadcastStart,
        broadcastEnd: multiCamConfig.broadcastEnd,
        name: multiCamConfig.name,
        type: multiCamConfig.type,
        status: multiCamConfig.status,
        icon: multiCamConfig.icon
      };

      multiCamInfo.action = {
        type: multiCamConfig.actionType,
        meta: {
          uri: multiCamConfig.showUrl || ''
        }
      };

      const local_actions = ['PLAYER_SHEET'];

      if (local_actions.includes(multiCamInfo.action.type)) {
        multiCamInfo.action.meta.localActionType = multiCamInfo.action.type;
        multiCamInfo.action.type = 'LOCAL_ACTION';
      }
    }
  }

  let cam360Info = {};
  if (details.mediaType === 'LIVECHANNEL') {
    const cam360Config = meta.cam360Info || {};
    if (!cam360Config.isCamEnabled) {
      cam360Info = { enabled: false };
    } else {
      cam360Info = {
        enabled: cam360Config.isCamEnabled,
        broadcastStart: cam360Config.broadcastStart,
        broadcastEnd: cam360Config.broadcastEnd,
        name: cam360Config.name,
        type: cam360Config.type,
        status: cam360Config.status,
        icon: cam360Config.icon
      };

      cam360Info.action = {
        type: cam360Config.actionType,
        meta: {
          uri: cam360Config.webView || ''
        }
      };

      const local_actions = ['PLAYER_SHEET'];

      if (local_actions.includes(cam360Info.action.type)) {
        cam360Info.action.meta.localActionType = cam360Info.action.type;
        cam360Info.action.type = 'LOCAL_ACTION';
      }
    }
  }

  let keyMomentsInfo = {};
  if (details.mediaType === 'LIVECHANNEL') {
    const keyMomentsConfig = meta.keyMomentsInfo || {};
    if (!keyMomentsConfig.enabled) {
      keyMomentsInfo = { enabled: false };
    } else {
      keyMomentsInfo = {
        enabled: keyMomentsConfig.enabled,
        name: keyMomentsConfig.name,
      };

      keyMomentsInfo.action = {
        type: keyMomentsConfig.actionType || 'PLAYER_SHEET',
        meta: {
          uri: keyMomentsConfig.keyMomentsUrl || `key-moments/${obj.id}`
        }
      };

      const local_actions = ['PLAYER_SHEET'];

      if (local_actions.includes(keyMomentsInfo.action.type)) {
        keyMomentsInfo.action.meta.localActionType = keyMomentsInfo.action.type;
        keyMomentsInfo.action.type = 'LOCAL_ACTION';
      }
    }
  }

  let concurrencyInfo = {};
  if (details.mediaType === 'LIVECHANNEL' && meta.isConcurrencyDisplayed && meta.gameId) {
    concurrencyInfo = {
      enabled: meta.isConcurrencyDisplayed || false,
      url: process.env.concurrencyBaseUrl + meta.gameId + '.json' || '',
    };
  } else {
    concurrencyInfo = { enabled: false };
  }

  let adConfig = {};
  let adsEnabled = meta.adsEnabled;
  if (typeof adsEnabled === 'undefined') {
    adsEnabled = utils.get(validValues, 'globalConfig.adsEnabled', true);
  }

  if (adsEnabled && playableAsset && devicePlatformType) {
    const primaryProvider = utils.get(validValues, 'globalConfig.primaryAdsProvider', '');
    const globalAdDetails = utils.get(validValues, `ads.${primaryProvider}.${devicePlatformType}.instreamAds`, {});
    if (globalAdDetails.enabled) {
      const adDetails = utils.get(meta, `adDetails.${primaryProvider}.${devicePlatformType}`, {});
      const showAdDetails = utils.get(showMeta, `adDetails.${primaryProvider}.${devicePlatformType}`, {});

      adConfig = {
        primaryProvider,
      }

      let adBreakInterval = `${globalAdDetails.adBreakInterval || ''}`;
      try {
        if (adBreakInterval) {
          const components = adBreakInterval.split('.');
          const multipliers = [60, 1];
          let timeInMs = 0;
          components.forEach((component, index) => {
            timeInMs += component * multipliers[index];
          });
          if (timeInMs) {
            adBreakInterval = timeInMs * 1000;
          }
        }
      } catch (ex) {
        adBreakInterval = '';
      }

      adConfig[primaryProvider] = {
        prerollAdspotid: adDetails.preRoll || showAdDetails.preRoll || globalAdDetails.preRoll || '',
        midrollAdspotid: adDetails.CSAI_Midroll || showAdDetails.CSAI_Midroll || globalAdDetails.CSAI_Midroll || '',
        midrollAdspotid_ssai: adDetails.SSAI_Midroll || showAdDetails.SSAI_Midroll || globalAdDetails.SSAI_Midroll || '',
        defaultBitRate: globalAdDetails.defaultBitRate || '',
        adBreakInterval
      }

      if (['LIVECHANNEL'].includes(details.mediaType)) {
        let liveAdPlayMode = meta.liveAdPlayMode;
        if (typeof liveAdPlayMode === 'undefined') {
          liveAdPlayMode = utils.get(validValues, 'globalConfig.liveAdPlayMode', '2');
        }

        adConfig.liveAdPlayMode = Number(liveAdPlayMode);
      }
    }
  }

  if (!playableAsset) adsEnabled = false;

  let matchNumber = '';
  let advertiserName = [];
  if (['EPISODE', 'CAC', 'SHOW', 'SERIES', 'LIVECHANNEL', 'MOVIE'].includes(details.mediaType)) {
    advertiserName = meta.advertiserName;
  }

  if (meta.genres.includes('Sports')) {
    matchNumber = meta.matchNumber;
  }

  const mediaDescriptionMap = {
    '${full-title}': fullTitle,
    '${full-synopsis}': synopsis.full,
    '${characters}': meta.characters && meta.characters.join(','),
    '${genres}': meta.genres && meta.genres.join(','),
    '${contributors}': meta.contributors && meta.contributors.join(','),
    '${language}': meta.languages && meta.languages.join(','),
    '${sub-genres}': meta.subGenre && meta.subGenre.join(','),
    '${content-descriptor}': meta.contentDescriptor,
    '${content-subject}': meta.contentSubject,
    '${age}': meta.age,
    '${telecast-date}': telecastDate,
    '${show-name}': showName,
    '${sport}': sportsInformation.sport,
    '${competition-type}': sportsInformation.competitionType,
    '${event-type}': sportsInformation.eventType,
    '${tournament-name}': sportsInformation.tournament,
    '${winner}': sportsInformation.tournament,
    '${first-runnerUp}': sportsInformation.firstRunnerUp,
    '${second-runnerUp}': sportsInformation.secondRunnerUp,
    '${round/stage}': sportsInformation.round,
    '${venue-details}': sportsInformation.venueDetails,
    '${venue-location}': sportsInformation.venueLocation,
    '${venue-name}': sportsInformation.venueName,
    '${team-a-name}': sportsInformation.teamAName,
    '${team-b-name}': sportsInformation.teamBName,
    '${team-a-code}': sportsInformation.teamACode,
    '${team-b-code}': sportsInformation.teamBCode,
    '${all-participants}': sportsInformation.allParticipants && sportsInformation.allParticipants.join(','),
    '${team-a-participants}': sportsInformation.teamA && sportsInformation.teamA.join(','),
    '${team-b-participants}': sportsInformation.teamB && sportsInformation.teamB.join(','),
    '${team-a-score}': sportsInformation.scoreA,
    '${team-b-score}': sportsInformation.scoreB,
    '${season-number}': season,
    '${episode-number}': episode,
    '${release-year}': releaseYear,
    '${movie-directors}': meta.movieDirector && meta.movieDirector.join(','),
    '${movie-producers}': meta.movieProducer && meta.movieProducer.join(','),
    '${team-a-logo}': '${sportsInformation.teamALogo}',
    '${team-b-logo}': '${sportsInformation.teamBLogo}',
    '${logo}': '${logo}',
    '${eventSubStatus}': sportsInformation.eventSubStatus
  }

  let mediaDescription = synopsis.full;
  if (meta.mediaDescription) {
    try {
      mediaDescription = meta.mediaDescription.replace(/\$\{.*?\}/g, function (key) {
        const value = mediaDescriptionMap[`${key}`];
        if (!value) throw new Error
        return value;
      });
    }
    catch {
      mediaDescription = synopsis.full;
    }
  }

  ['line1', 'line2'].forEach(item => {
    if (carouselMeta[item]) {
      try {
        carouselMeta[item] = carouselMeta[item].replace(/\$\{.*?\}/g, function (key) {
          const value = mediaDescriptionMap[`${key}`];
          if (!value) throw new Error
          return value;
        });
      }
      catch {
        carouselMeta[item] = "";
      }
    }
  });

  const genreForTemplateDefaults = meta.genres.find((genre) => utils.get(validValues, `templateDefaults.${genre}`));
  const templateDefault = utils.get(validValues, `templateDefaults.${genreForTemplateDefaults}`)
    || utils.get(validValues, 'templateDefaults.ALL') || {};
  let line1 = meta.line1 || templateDefault.line1Default || '';
  let line2 = meta.line2 || templateDefault.line2Default || '';
  let line3 = meta.line3 || templateDefault.line3Default || '';
  [line1, line2, line3] = [line1, line2, line3].map(item => {
    if (item) {
      try {
        return item.replace(/\$\{.*?\}/g, function (key) {
          const value = mediaDescriptionMap[`${key}`];
          if (!value) throw new Error
          return value;
        });
      }
      catch {
        item = "";
      }
    }
    return item;
  });

  const cueTimes = [];
  (meta.cueTimes || []).forEach((cuePoint) => {
    try {
      if (cuePoint) {
        const components = cuePoint.split('.');
        const multipliers = [60, 1];
        let timeInMs = 0;
        components.forEach((component, index) => {
          timeInMs += component * multipliers[index];
        });
        if (timeInMs) {
          cueTimes.push(timeInMs * 1000);
        }
      }
    } catch (ex) { }
  });

  const viewMapping = {
    EPISODE: 'episode',
    MOVIE: 'movie',
    CAC: 'cac',
    LIVECHANNEL: 'live-channel',
    SHOW: 'show'
  };

  const buttonMapping = {
    0: 'NA',
    11: 'DOWNLOAD',
    12: 'SHARE',
    13: 'ADD',
    17: 'DOWNLOAD'
  };

  let route = '';
  if (details.mediaType in viewMapping) {
    route = `view/${viewMapping[details.mediaType]}/${obj.id}`;
  }

  const resp = {
    id: `${obj.id}`,
    mediaType: details.mediaType,
    mediaSubType: meta.type,
    downloadable: meta.downloadable === 'yes',
    languages: meta.languages,
    defaultLanguage: getDefaultLangugage(meta.languages, details.mediaVariants.DASH_MOBILE),
    SBU: meta.SBU,
    multiTrackAudioEnabled: (meta.languages && meta.languages.length > 1),
    shortSynopsis: synopsis.short,
    fullSynopsis: mediaDescription,
    shortTitle,
    fullTitle,
    line1,
    line2,
    line3,
    showId,
    showName,
    seasonId,
    seasonName,
    season,
    seasonDisplay,
    sampledCount,
    episode,
    genres: meta.genres,
    contributors: meta.contributors,
    characters: meta.characters,
    slug: seo.urlStructureNew,
    assetRef,
    telecastDate: `${telecastDate}`,
    releaseYear,
    contentDescriptor: meta.contentDescriptor,
    contentSubject,
    age: meta.age || ageMap.nemonic,
    ageNumeric: ageMap.numeric,
    ageNemonic: ageMap.nemonic,
    name,
    entryId: details.jioMedia && details.jioMedia.contentId ? details.jioMedia.contentId : '',
    duration: details.duration || 0,
    imageUri: assetImages.imageUri,
    imageUri2: assetImages.imageUri2,
    image16x9: assetImages.image16x9,
    image4x3: assetImages.image4x3,
    image1x1: assetImages.image1x1,
    image2x3: assetImages.image2x3,
    image3x4: assetImages.image3x4,
    image9x16: assetImages.image9x16,
    animation16x9: assetImages.animation16x9,
    animationUri: assetImages.animation16x9,
    showImage: assetImages.showImage,
    logo,
    externalId: details.externalId,
    updated: obj.revised ? obj.revised : obj.updated,
    badgeName,
    badgeType,
    labelText,
    isPremium,
    isShowPremium,
    onAir: meta.onAir,
    seo,
    introStart,
    introEnd,
    recapStart,
    recapEnd,
    creditStart,
    creditEnd,
    deeplinkUrl,
    shareUrl: oneLinkUrl,
    jioMediaId,
    isDAIEnabled: !!meta.isDAIEnabled,
    daiAssetKey: meta.daiAssetKey || '',
    isDVREnabled: !!meta.isDVREnabled,
    isHLSEnabled: !!meta.isHLSEnabled,
    uploadTime,
    assetMarketType,
    showMarketType: showMarketType || 'STANDARD',
    isPwaLoginDisabled: !!meta.pwaAllowAnonymous,
    needsCameraAccess: !!meta.needsCameraAccess,
    trailerId: `${meta.trailerId || ''}`,
    oldJioAsset,
    graceNoteId,
    graceNoteType,
    pubmaticAdsEnabled,
    is4KSupported,
    is1080PSupported,
    isDolbySupported,
    hasSubtitles,
    subtitles,
    ingested: obj.ingested || 0,
    ...shotsMeta,
    sportsInformation,
    isPartnerAsset,
    partnerName,
    label,
    audioType,
    carouselMeta,
    cueTimes,
    adsEnabled,
    adConfig,
    action: {
      type: 'ROUTE',
      meta: {
        uri: route,
        deeplinkUrl,
        route: deeplinkUrl.substring(deepLinkGenerator.constants.vootBaseUrl.length)
      }
    },
    isVirtualShow: meta.isVirtualShow || false,
    multiCamInfo,
    cam360Info,
    keyMomentsInfo,
    concurrencyInfo,
    advertiserName,
    matchNumber,
    multiAudioMeta: details.multiAudioMeta || []
  };

  if (meta.type.toUpperCase() == 'KEY MOMENTS' && details.mediaType.toUpperCase() == "CAC" && meta.genres && meta.genres.find((genre) => genre.toLowerCase() === 'sports')) {
    const keymomentsInfo = getKeyMomentsInfo(obj);
    Objects.keys(keymomentsInfo).forEach((key) => { resp[key] = keymomentsInfo[key] });
  }
  if (meta.type === 'BUTTON') {
    resp.action = {
      type: 'LOCAL_ACTION',
      meta: {
        localActionType: buttonMapping[utils.get(assetRef, 'buttonFunction', 0)]
      },
    }
  }
  if (meta.type === 'FIXTURE') {
    resp.matchCardActions = [
      {
        label: meta.scheduleLabel || 'SCHEDULE',
        enabled: meta.isScheduleEnabled,
        icon: meta.scheduleIcon || '',
        action: {
          type: meta.scheduleActionType || 'ROUTE',
          meta: {
            route: 'tournament',
            relativePath: `view/sports-season/${seasonId}`,
            selectedTabId: 'tab1',
          }
        }
      },
      {
        label: meta.tableLabel || 'TABLE',
        enabled: meta.isTableEnabled,
        icon: meta.tableIcon || '',
        action: {
          type: meta.tableActionType || 'ROUTE',
          meta: {
            route: 'tournament',
            relativePath: `view/sports-season/${seasonId}`,
            selectedTabId: 'tab2',
          }
        }
      }
    ];
    return getFixtureResponse(resp);
  }
  if (details.mediaType === 'LIVECHANNEL') {
    resp.assetsByLanguage = meta.assetsByLanguage;
    resp.assetsByFeed = meta.assetsByFeed || [];
    resp.gameSeriesId = meta.gameSeriesId;
    resp.gameId = meta.gameId;
    resp.gameWidgetLink = meta.gameWidgetLink;
    resp.matchActions = [];
    if (meta.isMatchCentreEnabled) {
      resp.matchActions.push({
        label: meta.matchCentreLabel,
        enabled: meta.isMatchCentreEnabled,
        icon: meta.matchCentreIcon || 'v3Storage/menu/jv/sports_cricket.png',
        action: {
          type: meta.matchCentreActionType,
          meta: {
            uri: meta.matchCentreLink || ''
          }
        }
      });
    }
    if (meta.isPublicOpinionEnabled) {
      resp.matchActions.push({
        label: meta.publicOpinionLabel,
        enabled: meta.isPublicOpinionEnabled,
        icon: meta.publicOpinionIcon || 'v3Storage/menu/jv/sports_chat.png',
        action: {
          type: meta.publicOpinionActionType,
          meta: {
            uri: meta.publicOpinionLink || ''
          }
        }
      });
    }
    if (meta.isPlayAlongEnabled) {
      resp.matchActions.push({
        label: meta.playAlongLabel,
        enabled: meta.isPlayAlongEnabled,
        icon: meta.playAlongIcon || 'v3Storage/menu/jv/sports_play_along.png',
        action: {
          type: meta.playAlongActionType,
          meta: {
            uri: meta.playAlongLink || ''
          }
        }
      });
    }
    if (meta.isWatchPartyEnabled) {
      resp.matchActions.push({
        label: meta.watchPartyLabel,
        enabled: meta.isWatchPartyEnabled,
        icon: meta.watchPartyIcon || 'v3Storage/menu/jv/sports_watch_party.png',
        action: {
          type: meta.watchPartyActionType,
          meta: {
            uri: meta.watchPartyLink || ''
          }
        }
      });
    }
    const local_actions = ['PLAYER_SHEET'];
    resp.matchActions.forEach((matchAction) => {
      if (local_actions.includes(matchAction.action.type)) {
        matchAction.action.meta.localActionType = matchAction.action.type;
        matchAction.action.type = 'LOCAL_ACTION';
      }
    });
  }

  if (details.mediaType === 'SERIES' && isSportsAsset) {
    resp.action = {
      type: 'DEEPLINK',
      meta: {
        deeplinkUrl: `jiovootviacom18://jiovoot/sports-season/${obj.id}/subtab/tab1`
      }
    }
  }

  return resp;
};

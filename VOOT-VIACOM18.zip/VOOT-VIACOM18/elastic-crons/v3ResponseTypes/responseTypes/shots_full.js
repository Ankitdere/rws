const common = require('./common');
const sourceDeeplinkGen = require('../shotsDeepLinkGenerator');
const utils = require('./utils');

/* eslint-disable camelcase */
exports.source = ['id', 'updated', 'availability', 'revised', 'created', 'meta.assetRef', 'meta.trailerId',
  'meta.isDAIEnabled', 'meta.daiAssetKey', 'meta.isDVREnabled', 'meta.isHLSEnabled', 'meta.type',
  'meta.seo', 'details.externalId', 'details.kalturaMedia', 'details.image', 'meta.contentDescriptor',
  'meta.releaseYear', 'telecasted', 'slug', 'details.mediaType', 'meta.series', 'meta.genres',
  'meta.characters', 'meta.contributors', 'meta.showId', 'name', 'meta.season', 'meta.downloadable',
  'meta.synopsis', 'meta.title', 'meta.languages', 'meta.SBU', 'meta.age', 'meta.intro', 'meta.credit',
  'meta.recap', 'details.mediaVariants', 'details.marketType', 'meta.isPremium', 'meta.keywords',
  'meta.onAir', 'details.jioMedia', 'meta.pwaAllowAnonymous', 'details.gracenote', 'meta.needsCameraAccess',
  'meta.contentSubject', 'details', 'config', 'details.mediaVariants', 'meta.sourceDeeplink', 'meta.hashtags',
  'meta.refShowId', 'meta.refSeriesId', 'meta.topic', 'stats', 'details.mediaVariants', 'meta.sourceDeeplink',
  'meta.hashtags', 'meta.refShowId', 'meta.refSeriesId', 'meta.topic', 'stats', 'ingested', 'meta.subGenre', 'meta.keywords',
  'meta.sourceDeeplink.mediaId', 'meta.sourceDeeplink.mediaType'];

exports.transform = (obj, playback, show = {}, imageSize = '16x9') => {
  const resp = common.transform(obj, playback, show = {}, imageSize = '16x9');
  const shotsFields = this.allShotsFields(obj);
  return {
    ...resp,
    ...shotsFields
  };
};

function transformArrayToStr(obj, nestedIndex, defaultValue = '-') {
  let value = utils.get(obj, nestedIndex, defaultValue);
  if (value === '-') return value;
  value = value.join(';') || '-';
  return value;
}

//for catalog report
exports.allShotsFields = (obj) => {
  let sourceDeeplinkUrl = sourceDeeplinkGen.getShotsSourceDeeplink(obj);
  if (sourceDeeplinkUrl === 'vootviacom18://voot/') sourceDeeplinkUrl = '-';
  return {
    sourceDeeplinkUrl,
    imageUri: utils.get(obj, 'details.image.9x16') || utils.get(obj, 'details.image.16x9') || '-',
    topic: utils.get(obj, 'meta.topic') || '-',
    trendHashtags: transformArrayToStr(obj, 'meta.hashtags.trend'),
    creativeHashtags: transformArrayToStr(obj, 'meta.hashtags.creative'),
    musicSource: utils.get(obj, 'meta.music.source', '-'),
    musicName: utils.get(obj, 'meta.music.name', '-'),
    musicLabel: utils.get(obj, 'meta.music.label', '-'),
    musicArtists: transformArrayToStr(obj, 'meta.music.artists'),
    videoSource: utils.get(obj, 'meta.video.source', '-'),
    videoCreator: utils.get(obj, 'meta.video.creator', '-'),
    videoAgency: utils.get(obj, 'meta.video.agency', '-'),
    videoPartner: utils.get(obj, 'meta.video.partner', '-'),
    subGenres: transformArrayToStr(obj, 'meta.subGenre'),
    keywords: transformArrayToStr(obj, 'meta.keywords'),
    sourceDeeplinkMediaId: utils.get(obj, 'meta.sourceDeeplink.mediaId', '-'),
    sourceDeeplinkMediaType: utils.get(obj, 'meta.sourceDeeplink.mediaType', '-'),
  }
}
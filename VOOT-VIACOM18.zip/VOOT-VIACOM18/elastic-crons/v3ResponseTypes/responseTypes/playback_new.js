/* eslint-disable camelcase */
exports.source = ['id', 'availability', 'updated', 'details.mediaVariants', 'details.marketType', 'revised', 'details.externalId', 'details.kalturaMedia', 'meta.downloadable', 'meta.languages', 'details'];

function getDefaultLangugage(languages, profileUrl) {
  if (!languages || languages.length === 0) {
    return '';
  }
  if (languages.length === 1) {
    return languages[0];
  }
  if (profileUrl && profileUrl.profileUrl && profileUrl.profileUrl.indexOf('defaultAudioLang') > -1) {
    const start = profileUrl.profileUrl.indexOf('defaultAudioLang') + 17;
    const end = profileUrl.profileUrl.indexOf('/', start);
    return profileUrl.profileUrl.substring(start, end);
  }
  return languages[0];
}

const PREMIUM_FILE_TYPE = [
  'HLS_LINEAR_APP',
  'HLS_LINEAR_P',
  'DASH_LINEAR_APP',
  'DASHENC_PREMIUMHD',
  'HLSFPS_PREMIUMHD',
  'HLSFPS_TV_PREMIUMHD',
  'DASHENC_TV_PREMIUMHD',
];

const BLOCKED_FILE_TYPE = [
  'HLS_PREMIUMHD',
  'DASH_PREMIUMHD',
  'DASH_MOBILE_HD',
];

exports.transform = (obj, playbackType) => {
  const meta = obj.meta || {};
  const details = obj.details || {};
  const profileTypes = (playbackType ? playbackType.replace(/ /g, '_') : '');
  const isPremium = (details.marketType === 'PREMIUM' || details.marketType === 'PREMIER');
  const profiles = profileTypes.split(',').filter(t => !BLOCKED_FILE_TYPE.includes(t.toUpperCase()) && (!isPremium || PREMIUM_FILE_TYPE.includes(t.toUpperCase())));
  const profileUrls = profiles.reduce((acc, profile) => {
    if (details.mediaVariants && details.mediaVariants[profile]) {
      const profileUrl = `${details.kalturaMedia.base || ''}${details.mediaVariants[profile].url}`;
      const drmLicenseUri = `${details.mediaVariants[profile].key || ''}`;
      const profileFile = details.mediaVariants[profile].id;
      acc.push({
        profile,
        profileUrl,
        drmLicenseUri,
        kalturaProfile: details.mediaVariants[profile].type,
        fileId: `${profileFile}`,
      });
    }
    return acc;
  }, []);

  return {
    id: `${obj.id}`,
    downloadable: meta.downloadable === 'yes',
    multiTrackAudioEnabled: (meta.languages && meta.languages.length > 1),
    entryId: details.kalturaMedia ? details.kalturaMedia.entryId : '',
    duration: details.duration || 0,
    externalId: details.externalId,
    profileUrls,
    languages: meta.languages,
    defaultLanguage: getDefaultLangugage(meta.languages, profileUrls[0]),
    updated: obj.revised ? obj.revised : obj.updated,
  };
};

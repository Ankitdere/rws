/* eslint-disable camelcase */
exports.source = ['id', 'availability', 'updated', 'details.mediaVariants', 'details.marketType', 'revised', 'details.externalId', 'details.kalturaMedia', 'meta.downloadable', 'meta.languages', 'details'];

function getDefaultLangugage(languages, profileUrl) {
  if (!languages || languages.length === 0) {
    return '';
  }
  if (languages.length === 1) {
    return languages[0];
  }
  if (profileUrl && profileUrl.indexOf('defaultAudioLang') > -1) {
    const start = profileUrl.indexOf('defaultAudioLang') + 17;
    const end = profileUrl.indexOf('/', start);
    return profileUrl.substring(start, end);
  }
  return languages[0];
}

function getProfileUrl(entryId, profile) {

  switch (profile) {
    case 'DASH_MOBILE': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/entryId/${entryId}/format/mpegdash/tags/iphonenew/f/a.mpd`;
    case 'WIDEVINE_SBR_DOWNLOAD_HIGH': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/entryId/${entryId}/format/url/tags/widevine/f/a.wvm`;
    case 'WIDEVINE_MBR_MAIN': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/entryId/${entryId}/format/url/tags/widevine_mbr/f/a.wvm`;
    case 'ISM_MAIN': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/entryId/${entryId}/format/sl/tags/ipadnew/f/a.ism`;
    case 'TABLET_MAIN': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/entryId/${entryId}/format/applehttp/tags/iphonenew/f/a.m3u8`;
    case 'DASH_MAIN': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/entryId/${entryId}/format/mpegdash/tags/dash/f/a.mpd`;
    case 'TV_MAIN': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/entryId/${entryId}/format/applehttp/tags/tv/f/a.m3u8`;
    case 'WEB_NEW': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/entryId/${entryId}/format/applehttp/tags/webnew/f/a.m3u8`;
    case 'HLS_WEB_SD': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/entryId/${entryId}/format/applehttp/tags/web_sd/f/a.m3u8`;
    case 'HLSFPS_MOBILE_HD': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/deliveryProfileIds/15521,18781/entryId/${entryId}/format/applehttp/tags/mobile_hd/f/a.m3u8`;
    case 'HLSFPS_MOBILE_SD': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/deliveryProfileIds/15521,18781/entryId/${entryId}/format/applehttp/tags/mobile_sd/f/a.m3u8`;
    case 'WVC_AUTO': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/entryId/${entryId}/format/url/tags/widevine_mbr/f/a.wvm`;
    case 'WVC_HIGH': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/entryId/${entryId}/format/url/tags/wvc_high/protocol/https/f/a.wvm`;
    case 'WVC_LOW': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/entryId/${entryId}/format/url/tags/wvc_low/protocol/https/f/a.wvm`;
    case 'HLSFPS_MAIN': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/deliveryProfileIds/15521,18781/entryId/${entryId}/format/applehttp/tags/iphonenew/f/a.m3u8`;
    case 'DASH_MOBILE_HD': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/entryId/${entryId}/format/mpegdash/tags/mobile_hd/f/a.mpd`;
    case 'DASH_MOBILE_SD': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/entryId/${entryId}/format/mpegdash/tags/mobile_sd/f/a.mpd`;
    case 'HLS_MOBILE_HD': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/entryId/${entryId}/format/applehttp/tags/mobile_hd/f/a.m3u8`;
    case 'HLS_MOBILE_SD': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/entryId/${entryId}/format/applehttp/tags/mobile_sd/f/a.m3u8`;
    case 'HLS_TV_HD': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/entryId/${entryId}/format/applehttp/tags/tv_hd/f/a.m3u8`;
    case 'HLS_TV_SD': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/entryId/${entryId}/format/applehttp/tags/tv_sd/protocol/https/f/a.m3u8`;
    case 'HLS_WEB_HD': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/entryId/${entryId}/format/applehttp/tags/web_hd/f/a.m3u8`;
    case 'JIO_MAIN': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/entryId/${entryId}/format/applehttp/tags/jio/f/a.m3u8`;
    case 'SBR256': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/entryId/${entryId}/format/applehttp/tags/sbr256/f/a.m3u8`;
    case 'DASH_TV': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/entryId/${entryId}/format/mpegdash/tags/ipadnew/f/a.mpd`;
    case '360_MAIN': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/entryId/${entryId}/format/applehttp/tags/360_main/f/a.m3u8`;
    case 'HLS_360_SD': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/entryId/${entryId}/format/applehttp/tags/360_sd/f/a.m3u8`;
    case 'HLS_360_HD': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/entryId/${entryId}/format/applehttp/tags/360_hd/f/a.m3u8`;
    case 'DASHCLEAR': return `https://cdnapisec.kaltura.com/p/1982551/sp/198255100/playManifest/protocol/https/deliveryProfileId/19361/entryId/${entryId}/format/mpegdash/tags/iphonenew/f/a.mpd`;
    default: return '';
  }
}

const PREMIUM_FILE_TYPE = [
  'HLS_LINEAR_APP',
  'HLS_LINEAR_P',
  'DASH_LINEAR_APP',
  'DASHENC_PREMIUMHD',
  'HLSFPS_PREMIUMHD',
];

const BLOCKED_FILE_TYPE = [
  'HLS_PREMIUMHD',
  'DASH_PREMIUMHD',
  'DASH_MOBILE_HD',
];

exports.transform = (obj, playbackType) => {
  const meta = obj.meta || {};
  const details = obj.details || {};
  const profile = (playbackType ? playbackType.replace(/ /g, '_') : '');

  let profileUrl = '';
  let profileFile = '';
  let drmLicenseUri = '';
  const isPremium = (details.marketType === 'PREMIUM' || details.marketType === 'PREMIER');

  if (details.mediaVariants && details.mediaVariants[profile] && !BLOCKED_FILE_TYPE.includes(profile.toUpperCase()) && (!isPremium || PREMIUM_FILE_TYPE.includes(profile.toUpperCase()))) {
    profileUrl = `${details.kalturaMedia.base || ''}${details.mediaVariants[profile].url}`;
    drmLicenseUri = `${details.mediaVariants[profile].key || ''}`;
    profileFile = details.mediaVariants[profile].id;
  }
  return {
    id: `${obj.id}`,
    fileId: `${profileFile}`,
    downloadable: meta.downloadable === 'yes',
    multiTrackAudioEnabled: (meta.languages && meta.languages.length > 1),
    entryId: details.kalturaMedia ? details.kalturaMedia.entryId : '',
    duration: details.duration || 0,
    externalId: details.externalId,
    profileUrl,
    languages: meta.languages,
    drmLicenseUri,
    defaultLanguage: getDefaultLangugage(meta.languages, profileUrl),
    updated: obj.revised ? obj.revised : obj.updated
  };
};

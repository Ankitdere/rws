const common = require('./common');
const sourceDeeplinkGen = require('../shotsDeepLinkGenerator');
const utils = require('./utils');

/* eslint-disable camelcase */
exports.source = ['id', 'updated', 'availability', 'revised', 'created', 'meta.assetRef', 'meta.trailerId',
  'meta.isDAIEnabled', 'meta.daiAssetKey', 'meta.isDVREnabled', 'meta.isHLSEnabled', 'meta.type',
  'meta.seo', 'details.externalId', 'details.kalturaMedia', 'details.image', 'meta.contentDescriptor',
  'meta.releaseYear', 'telecasted', 'slug', 'details.mediaType', 'meta.series', 'meta.genres',
  'meta.characters', 'meta.contributors', 'meta.showId', 'name', 'meta.season', 'meta.downloadable',
  'meta.synopsis', 'meta.title', 'meta.languages', 'meta.SBU', 'meta.age', 'meta.intro', 'meta.credit',
  'meta.recap', 'details.mediaVariants', 'details.marketType', 'meta.isPremium', 'meta.keywords',
  'meta.onAir', 'details.jioMedia', 'meta.pwaAllowAnonymous', 'details.gracenote', 'meta.needsCameraAccess',
  'meta.contentSubject', 'details', 'config', 'details.mediaVariants', 'meta.sourceDeeplink', 'meta.hashtags',
  'meta.refShowId', 'meta.refSeriesId', 'meta.topic', 'stats', 'details.mediaVariants', 'meta.sourceDeeplink',
  'meta.hashtags', 'meta.refShowId', 'meta.refSeriesId', 'meta.topic', 'stats', 'ingested', 'meta.subGenre', 'meta.keywords',
  'meta.sourceDeeplink.mediaId', 'meta.sourceDeeplink.mediaType'];

exports.transform = (obj, playback, show = {}, imageSize = '16x9') => {
  const resp = common.transform(obj, playback, show = {}, imageSize = '16x9');
  const shotsFields = this.shotsNewFields(obj);
  return {
    ...resp,
    ...shotsFields
  };
};

exports.shotsNewFields = (obj) => {
  let sourceDeeplinkUrl = sourceDeeplinkGen.getShotsSourceDeeplink(obj);
  if (sourceDeeplinkUrl === 'vootviacom18://voot/') sourceDeeplinkUrl = '';

  return {
    sourceDeeplinkUrl,
    imageUri: utils.get(obj, 'details.image.9x16') || utils.get(obj, 'details.image.16x9') || '',
    topic: utils.get(obj, 'meta.topic') || '',
    stats: {
      videoViewCount: utils.get(obj, 'stats.videoViewCount') || 0,
      loveCount: utils.get(obj, 'stats.loveCount') || 0,
      commentCount: utils.get(obj, 'stats.commentCount') || 0,
      shareCount: utils.get(obj, 'stats.shareCount') || 0
    },
    mediaVariants: {
      mpd: obj.details.mediaVariants.mpd,
      m3u8: obj.details.mediaVariants.m3u8
    },
    hashtags: { ...utils.get(obj, 'meta.hashtags', {}) },
    subGenres: utils.get(obj, 'meta.subGenre', []),
  }
}

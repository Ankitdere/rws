exports.getAgeMappings = (age) => {
    const ageMap = {
      'U': {
        numeric: 0,
        nemonic: 'U', 
      },
      'U/A 7+': {
        numeric: 7,
        nemonic: '7+', 
      },
      'U/A 13+': {
        numeric: 13,
        nemonic: '13+', 
      },
      'U/A 16+': {
        numeric: 16,
        nemonic: '16+', 
      },
      'A': {
        numeric: 18,
        nemonic: 'A', 
      },
      'default': {
        numeric: 0,
        nemonic: 'U',
      },
    };
  
    if (age in ageMap) {
      return ageMap[age];
    } else {
      return ageMap.default;
    }
};

exports.getImages = (details, meta, imageSize = '') => {
  const suffixes = [];
  suffixes['16x9'] = '_1280X720';
  suffixes['4x3'] = '_1024X768';
  suffixes['1x1'] = '_320X320';
  suffixes['2x3'] = '_850X1275';
  const images = {
    imageUri: '',
    imageUri2: '',
    image16x9: '',
    image4x3: '',
    image1x1: '',
    image2x3: '',
    image3x4: '',
    image9x16: '',
    showImage: '',
  };
  if (details.image && details.image.id && details.image.id.includes('kimg')) {
    images.imageUri = `${details.image.id + suffixes['16x9']}.${details.image.type}`;
    images.imageUri2 = details.image.imageUri2 || images.imageUri;
    images.image16x9 = `${details.image.id + suffixes['16x9']}.${details.image.type}`;
    images.image4x3 = `${details.image.id + suffixes['4x3']}.${details.image.type}`;
    images.image1x1 = `${details.image.id + suffixes['1x1']}.${details.image.type}`;
    images.image2x3 = `${details.image.id + suffixes['2x3']}.${details.image.type}`;
  } else if (details.image && details.image.id) {
    images.imageUri = `${details.image.id}.${details.image.type}`;
    images.imageUri2 = details.image.imageUri2 || images.imageUri;
    images.image16x9 = `${details.image.id}.${details.image.type}`;
    images.image4x3 = `${details.image.id}.${details.image.type}`;
    images.image1x1 = `${details.image.id}.${details.image.type}`;
    images.image2x3 = `${details.image.id}.${details.image.type}`;
  } else if (details.image) {
    images.imageUri = details.image['16x9'] || '';
    images.imageUri2 = details.image.imageUri2 || images.imageUri;
    images.image16x9 = details.image['16x9'] || '';
    images.image4x3 = details.image['4x3'] || details.image['16x9'] || '';
    images.image1x1 = details.image['1x1'] || details.image['16x9'] || '';
    images.image2x3 = details.image['2x3'] || details.image['16x9'] || '';
    images.image9x16 = details.image['9x16'] || '';
  }
  if (details.image3x4 && details.image3x4.id) {
    images.image3x4 = `${details.image3x4.id}.${details.image3x4.type}`;
  }
  if (details.image) {
    images.animation16x9 = details.image['animation16x9'] || '';
  }

  if (meta.showId) {
    images.showImage = `v3Storage/showImages/${meta.showId}.jpg`;
  } else if (meta.series && meta.series.showId) {
    images.showImage = `v3Storage/showImages/${meta.series.showId}.jpg`;
  }

  if (imageSize) {
    const key = `image${imageSize}`;
    if (key in images) {
      images.imageUri = images[key];
    }
  }

  return images;  
};

exports.getPartnerImages = (details, meta, imageSize = '') => {
  const suffixes = [];
  suffixes['16x9'] = '_1280X720';
  suffixes['4x3'] = '_1024X768';
  suffixes['1x1'] = '_320X320';
  suffixes['2x3'] = '_850X1275';
  const images = {
    imageUri: '',
    image16x9: '',
    image4x3: '',
    image1x1: '',
    image2x3: '',
    image3x4: '',
    image9x16: '',
    showImage: '',
  };
  if (details.partnerImage) {
    images.imageUri = details.partnerImage['16x9'] || '';
    images.image16x9 = details.partnerImage['16x9'] || '';
    images.image4x3 = details.partnerImage['4x3'] || details.partnerImage['16x9'] || '';
    images.image1x1 = details.partnerImage['1x1'] || details.partnerImage['16x9'] || '';
    images.image2x3 = details.partnerImage['2x3'] || details.partnerImage['16x9'] || '';
    images.image9x16 = details.partnerImage['9x16'] || '';
    images.image3x4 = details.partnerImage['3x4'] || '';
    images.animation16x9 = details.partnerImage['animation16x9'] || '';
  } else if (details.image) {
    images.imageUri = details.image['16x9'] ? details.image['16x9'] : '';
    images.image16x9 = details.image['16x9'] ? details.image['16x9'] : '';
    images.image4x3 = details.image['4x3'] ? details.image['4x3'] : (details.image['16x9'] ? details.image['16x9'] : '');
    images.image1x1 = details.image['1x1'] ? details.image['1x1'] : (details.image['16x9'] ? details.image['16x9'] : '');
    images.image2x3 = details.image['2x3'] ? details.image['2x3'] : (details.image['16x9'] ? details.image['16x9'] : '');
    images.image9x16 = details.image['9x16'] ? details.image['9x16'] : '';
    if (details.image3x4 && details.image3x4.id) {
      images.image3x4 = `${details.image3x4.id}.${details.image3x4.type}`;
    }
    images.animation16x9 = details.image['animation16x9'] ? details.image['animation16x9'] : '';
  }
  //fix for inconsistent data
  for (key in images) {
    if (images[key] === "jioimage/") { 
      images[key] = '';
    }
  }
  if (meta.showId) {
    images.showImage = `v3Storage/showImages/${meta.showId}.jpg`;
  } else if (meta.series && meta.series.showId) {
    images.showImage = `v3Storage/showImages/${meta.series.showId}.jpg`;
  }

  if (imageSize) {
    const key = `image${imageSize}`;
    if (key in images) {
      images.imageUri = images[key];
    }
  }

  return images;  
};

function getNested(obj, ...args) {
  return args.reduce((obj, level) => obj && obj[level], obj);
}

exports.get = (obj, nestedIndex, defaultValue = undefined) => {
  const value = getNested(obj, ...nestedIndex.split('.'));
  if (typeof value === 'undefined') {
    return defaultValue;
  // eslint-disable-next-line no-else-return
  } else {
    return value;
  }
}

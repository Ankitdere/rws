/* eslint-disable camelcase */
const utils = require('./utils');
exports.source = ['availability', 'id', 'meta.type', 'details.externalId', 'details.kalturaMedia', 'details.image', 'meta.contentDescriptor', 'meta.releaseYear', 'telecasted', 'slug', 'details.mediaType', 'meta.series', 'meta.genres', 'meta.characters', 'meta.contributors', 'meta.showId', 'name', 'meta.season', 'meta.downloadable', 'meta.synopsis', 'meta.title', 'meta.languages', 'meta.SBU', 'meta.age', 'meta.contentSubject', 'details', 'config'];

exports.transform = (obj) => {
  const meta = obj.meta || {};
  const details = obj.details || {};
  let series_showId;
  let series_name;
  let series_id;
  let series_episode;
  let series_season;
  if (details.mediaType === 'EPISODE' || details.mediaType === 'CAC') {
    series_showId = meta.series.showId;
    series_name = meta.series.name;
    series_id = meta.series.id;
    series_episode = meta.series.episode;
    series_season = meta.series.season;
  } else if (details.mediaType === 'SERIES') {
    series_showId = meta.showId;
    series_name = obj.name;
    series_id = obj.id;
    series_season = meta.season;
  } else if (details.mediaType === 'SHOW') {
    series_showId = obj.id;
  }

  let pubmaticAdsEnabled = true; 
  const isConfigKeyPresent = (obj && obj.config) || false;
  // there can be other keys present in config apart from pubmaticAdsEnabled
  if (isConfigKeyPresent && Object.keys(obj.config).includes('pubmaticAdsEnabled')) {
    // if pubmaticAdsEnabled key present then take whatever value is assigned
    pubmaticAdsEnabled = !!obj.config.pubmaticAdsEnabled;
  }

  const ageMap = utils.getAgeMappings(meta.age);
  
  return {
    id: obj.id,
    mediaType: details.mediaType,
    mediaSubType: meta.type,
    downloadable: meta.downloadable === 'yes',
    languages: meta.languages,
    SBU: meta.SBU,
    multiTrackAudioEnabled: (meta.languages && meta.languages.length > 1),
    // subtitleEnabled: true,  //TODO
    shortSynopsis: meta.synopsis ? meta.synopsis.short : '',
    fullSynopsis: meta.synopsis ? meta.synopsis.full : '',
    shortTitle: meta.title ? meta.title.short : '',
    fullTitle: meta.title ? meta.title.full : '',
    series_showId,
    series_name,
    series_season,
    series_episode,
    series_id,
    genres: meta.genres,
    contributors: meta.contributors,
    characters: meta.characters,
    slug: obj.slug,
    // startDate: 1520121600, //TODO
    // endDate: 7258118399, //TODO
    telecastDate: obj.telecasted || '',
    releaseYear: meta.releaseYear,
    contentDescriptor: meta.contentDescriptor,
    contentSubject: meta.contentSubject || '',
    age: meta.age,
    ageNumeric: ageMap.numeric,
    ageNemonic: ageMap.nemonic,
    name: obj.name,
    entryId: details.kalturaMedia ? details.kalturaMedia.entryId : '',
    duration: details.duration || 0,
    image_id: details.image ? details.image.id : '',
    image_type: details.image ? details.image.type : '',
    image_baseUrl: details.image ? details.image.base : '',
    externalId: details.externalId,
    pubmaticAdsEnabled
  };
};

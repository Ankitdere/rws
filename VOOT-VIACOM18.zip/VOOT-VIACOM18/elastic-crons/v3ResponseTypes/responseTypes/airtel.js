const common = require('./common');
const deepLinkGenerator = require('../deepLinkGenerator');
const config = require('../const.json');

exports.source = undefined;

exports.transform = (obj, playback, show) => {
  const resp = common.transform(obj, playback, show);
  const baseUrl = config.imageCDN;
  const imageUri = `${baseUrl}${resp.imageUri}`;
  const image16x9 = `${baseUrl}${resp.image16x9}`;
  const image4x3 = `${baseUrl}${resp.image4x3}`;
  const image1x1 = `${baseUrl}${resp.image1x1}`;
  const image2x3 = `${baseUrl}${resp.image2x3}`;
  const image3x4 = resp.image3x4 ? `${baseUrl}${resp.image3x4}` : '';
  const showImage = resp.showImage ? `${baseUrl}${resp.showImage}` : '';
  let seriesImage = '';
  if (resp.seasonId) {
    seriesImage = `${baseUrl}v3Storage/showImages/${resp.seasonId}.jpg`;
  }
  resp.deeplinkUrl = deepLinkGenerator.getPartnerDeeplinkWithoutSource(obj);
  delete resp.seo;
  delete resp.imageUri2;
  return {
    ...resp,
    imageUri,
    image16x9,
    image4x3,
    image1x1,
    image2x3,
    seriesImage,
    image3x4,
    showImage
  };
};
exports.getKeyMomentsInfo = (obj) => {
  const keymomentInfo = {};
  const sportsMetaFromObj = obj.meta.siInfo || {};

  keymomentInfo.markin_time = sportsMetaFromObj.markin_time || '';
  keymomentInfo.event_id = sportsMetaFromObj.event_id || '';
  keymomentInfo.gameID = sportsMetaFromObj.gameID || '';
  keymomentInfo.gameSeriesID = sportsMetaFromObj.gameSeriesID || '';
  keymomentInfo.event_text = sportsMetaFromObj.event_text || '';
  keymomentInfo.matchNumber = sportsMetaFromObj.matchNumber || '';
  return keymomentInfo;
};

const utils = require('./responseTypes/utils');

exports.getShotsSourceDeeplink = (obj, playback) => {
  const meta = obj.meta || {};
  const vootBaseUrl = 'vootviacom18://voot/';
  const sourceMediaType = utils.get(meta, 'sourceDeeplink.mediaType', '').toUpperCase() || '';
  const sourceMediaId = utils.get(meta, 'sourceDeeplink.mediaId') || 0;

  if (!sourceMediaType || !sourceMediaId) return '';

  switch (sourceMediaType) {
    case 'SHOW':
      return `${vootBaseUrl}details/show/${sourceMediaId}`;
    case 'EPISODE':
    case 'CAC':
    case 'LIVECHANNEL':
    case 'PCCHANNEL':
      return `${vootBaseUrl}playback/${sourceMediaId}`;
    case 'MOVIE':
      return `${vootBaseUrl}details/movie/${sourceMediaId}`;
    case 'CHANNEL':
      return `${vootBaseUrl}details/channel/${sourceMediaId}`;
    case 'SERIES':
      return `${vootBaseUrl}details/show/${meta.refShowId}/season/${sourceMediaId}`;
    case 'SHOTS':
      return `${vootBaseUrl}vootshots/playback/${obj.id}`;
    default:
      return vootBaseUrl;
  }
};


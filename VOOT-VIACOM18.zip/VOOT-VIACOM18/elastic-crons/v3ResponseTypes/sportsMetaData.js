const sportsMatchStatusMap = require('./sportsMatchStatus.json');
const utils = require('./responseTypes/utils');

exports.getSportsInformation = (obj, validValues) => {
  let sportsInformation = {};
  let sportsMetaFromObj = obj.meta.sportsInformation || {};

  if (
    [
      'EPISODE',
      'CAC',
      'SERIES',
      'SHOW',
      'LIVECHANNEL',
      'SHOTS'
    ].includes(obj.details.mediaType)
    ||
    [
      'FIXTURE'
    ].includes(obj.meta.type)
  ) {
    sportsInformation.sport = sportsMetaFromObj.sport || '';
    sportsInformation.competitionType = sportsMetaFromObj.competitionType || '';
    sportsInformation.eventType = sportsMetaFromObj.eventType || '';
    sportsInformation.tournament = sportsMetaFromObj.tournament || '';
  }

  if (
    [
      'EPISODE',
      'CAC',
      'LIVECHANNEL',
      'SHOTS'
    ].includes(obj.details.mediaType)
    ||
    [
      'FIXTURE'
    ].includes(obj.meta.type)
  ) {
    sportsInformation.venueName = sportsMetaFromObj.venueName || '';
    sportsInformation.allParticipants = sportsMetaFromObj.allParticipants || [];
    sportsInformation.teamA = sportsMetaFromObj.teamA || [];
    sportsInformation.teamB = sportsMetaFromObj.teamB || [];
    sportsInformation.scoreA = sportsMetaFromObj.scoreA || '';
    sportsInformation.scoreB = sportsMetaFromObj.scoreB || '';
    sportsInformation.teamACode = sportsMetaFromObj.teamACode || '';
    sportsInformation.teamBCode = sportsMetaFromObj.teamBCode || '';
    sportsInformation.teamAName = sportsMetaFromObj.teamAName || '';
    sportsInformation.teamBName = sportsMetaFromObj.teamBName || '';
    sportsInformation.teamALogo = sportsMetaFromObj.teamALogo || '';
    sportsInformation.teamBLogo = sportsMetaFromObj.teamBLogo || '';

    try {
      sportsInformation.eventState = sportsMetaFromObj.eventState || '';
      sportsInformation.startDate = sportsMetaFromObj.startDate || 0;
      sportsInformation.endDate = sportsMetaFromObj.endDate || 0;
      
      let eventStatus = sportsMetaFromObj.eventStatus;
      // check if there is an eventStatusId mapping
      eventStatus =  utils.get(sportsMatchStatusMap,
        `${sportsMetaFromObj.sport}.${sportsMetaFromObj.eventStatusId}`,
        eventStatus);

      // check if there is an eventSubStatusId mapping
      eventStatus = utils.get(sportsMatchStatusMap,
        `${sportsMetaFromObj.sport}.subStatus.${sportsMetaFromObj.eventStatusId}.${sportsMetaFromObj.eventSubStatusId}`,
        eventStatus);
      
      // Assign the computed eventStatus
      sportsInformation.eventStatus = eventStatus;
      
      sportsInformation.eventSubStatus = sportsMetaFromObj.eventSubStatus || '';
      sportsInformation.eventName = sportsMetaFromObj.eventName || '';
      sportsInformation.eventGroup = sportsMetaFromObj.eventGroup || '';
      sportsInformation.eventStage = sportsMetaFromObj.eventStage || '';
      sportsInformation.eventFormat = sportsMetaFromObj.eventFormat || '';
      sportsInformation.winner = sportsMetaFromObj.winner || '';
      sportsInformation.winningMargin = sportsMetaFromObj.winningMargin || '';
      sportsInformation.resultCode = sportsMetaFromObj.resultCode || '';
      sportsInformation.resultSubCode = sportsMetaFromObj.resultSubCode || '';
      sportsInformation.gameNote = '';
      sportsInformation.eventParticipants = JSON.parse(sportsMetaFromObj.eventParticipants || '{}');
    } catch (err) {}
    
    const { team = {} } = validValues;
    let teamAObj = '';
    let teamBObj = '';
    Object.keys(team).forEach((id) => {
      if ((sportsMetaFromObj.teamACode === team[id].code)
        && (sportsMetaFromObj.sport === team[id].sport)
        && (sportsMetaFromObj.teamAName === team[id].name)) {
        teamAObj = team[id];
      }
      if ((sportsMetaFromObj.teamBCode === team[id].code)
        && (sportsMetaFromObj.sport === team[id].sport)
        && (sportsMetaFromObj.teamBName === team[id].name)) {
        teamBObj = team[id];
      }
    });

    if (teamAObj && teamBObj) {
      sportsInformation.sport = teamAObj.sport || '';
      // sportsInformation.teamAName = teamAObj.name || '';
      // sportsInformation.teamBName = teamBObj.name || '';
      sportsInformation.teamALogo = teamAObj.logo || '';
      sportsInformation.teamBLogo = teamBObj.logo || '';
      sportsInformation.teamAName = teamAObj.short_name || '';
      sportsInformation.teamBName = teamBObj.short_name || '';
      if (sportsInformation.winner === teamAObj.name) {
        sportsInformation.winner = teamAObj.short_name || '';
      } else if (sportsInformation.winner === teamBObj.name) {
        sportsInformation.winner = teamBObj.short_name || '';
      }

      if (utils.get(obj, 'details.jioMedia.partnerName', '').toUpperCase() === 'HBS') {
        sportsInformation.teamALogo = teamAObj.hbsLogo || '';
        sportsInformation.teamBLogo = teamBObj.hbsLogo || '';
        // Handling for penalty scorelines
        if (sportsInformation.resultCode === 3) {
          sportsInformation.scoreA = `${sportsInformation.scoreA}(${sportsMetaFromObj.penaltyScoreA})`;
          sportsInformation.scoreB = `${sportsInformation.scoreB}(${sportsMetaFromObj.penaltyScoreB})`;
        }
      }
    }
  }

  if (
    [
      'EPISODE',
      'CAC',
      'SERIES',
      'SHOTS',
      'SHOW'
    ].includes(obj.details.mediaType)
    ||
    [
      'FIXTURE'
    ].includes(obj.meta.type)
  ) {
    sportsInformation.firstRunnerUp = sportsMetaFromObj.firstRunnerUp || '';
    sportsInformation.secondRunnerUp = sportsMetaFromObj.secondRunnerUp || '';
  }

  return sportsInformation;
}
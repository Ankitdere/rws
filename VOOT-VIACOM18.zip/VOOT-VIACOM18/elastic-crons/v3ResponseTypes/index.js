/* eslint-disable global-require */
const ResponseTypes = {
  short: require('./responseTypes/short'),
  full: require('./responseTypes/full'),
  mobile: require('./responseTypes/mobile'),
  common: require('./responseTypes/common'),
  seo: require('./responseTypes/seo'),
  playback: require('./responseTypes/playback'),
  playback_new: require('./responseTypes/playback_new'),
  partner: require('./responseTypes/partner'),
  mitv: require('./responseTypes/mitv'),
  mitv2: require('./responseTypes/mitv2'),
  airtel: require('./responseTypes/airtel'),
  channel: require('./responseTypes/channel'),
  epg: require('./responseTypes/epg'),
  common_deeplink: require('./responseTypes/common_deeplink'),
  tatasky: require('./responseTypes/tatasky'),
  yupptv: require('./responseTypes/yupptv'),
  shots: require('./responseTypes/shots'),
  shots_full: require('./responseTypes/shots_full'),
};

exports.getResponseType = type => ResponseTypes[type] || ResponseTypes.full;

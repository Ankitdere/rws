const vootBaseUrl = 'jiovootviacom18://jiovoot/';
exports.constants = { vootBaseUrl };

exports.getDeepLink = (obj, playback) => {
  const details = obj.details || {};
  const meta = obj.meta || {};
  switch (details.mediaType) {
    case 'SHOW':
      return `${vootBaseUrl}detail/${obj.id}`;
    case 'EPISODE':
    case 'CAC':
    case 'LIVECHANNEL':
    case 'PCCHANNEL':
      return `${vootBaseUrl}playback/${obj.id}`;
    case 'MOVIE':
      return `${vootBaseUrl}detail/${obj.id}`;
    case 'CHANNEL':
      return `${vootBaseUrl}detail/${obj.id}`;
    case 'SERIES':
      return `${vootBaseUrl}details/show/${meta.showId}/season/${obj.id}`;
    case 'SHOTS':
      return `${vootBaseUrl}vootshots/playback/${obj.id}`;
    default:
      return vootBaseUrl;
  }
};
const tizenMediaTypes = [
  'CAC',
  'EPISODE',
  'MOVIE',
  'SERIES',
];

exports.getTizenV2Deeplink = (obj) => {
  const details = obj.details || {};
  const kaltura = details.kalturaMedia || {};
  const isPremium = (details.marketType === 'PREMIUM' || details.marketType === 'PREMIER');
  if (!details.mediaType || !tizenMediaTypes.includes(details.mediaType) || isPremium) {
    return '';
  }
  return `{"assetId":"${obj.id}#${kaltura.type || ''}"}`;
};

exports.getTizenV3Deeplink = (obj) => {
  const details = obj.details || {};
  const meta = obj.meta || {};
  let showIdOrAssetId = obj.id;
  if (meta.showId) {
    showIdOrAssetId = meta.showId;
  }
  if (meta.series && meta.series.showId) {
    showIdOrAssetId = meta.series.showId;
  }
  const isPremium = (details.marketType === 'PREMIUM' || details.marketType === 'PREMIER');
  const actionData = { assetId: `${obj.id}#${details.mediaType}#${isPremium}#${showIdOrAssetId}` };
  return JSON.stringify(actionData);
};

exports.getTataSkyDeeplink = (obj) => {
  const details = obj.details || {};
  const meta = obj.meta || {};
  // const vootBaseUrl = 'vootviacom18://voot/';
  switch (details.mediaType) {
    case 'SHOW':
      return `${vootBaseUrl}detail/${obj.id}`;
    case 'EPISODE':
    case 'CAC':
    case 'LIVECHANNEL':
    case 'MOVIE':
      return `${vootBaseUrl}playback/${obj.id}`;
    case 'CHANNEL':
      return `${vootBaseUrl}detail/${obj.id}`;
    case 'SERIES':
      return `${vootBaseUrl}details/show/${meta.showId}/season/${obj.id}`;
    default:
      return vootBaseUrl;
  }
};

exports.getPartnerDeeplink = (obj,src) => {
  const details = obj.details || {};
  const meta = obj.meta || {};
  // const vootBaseUrl = 'vootviacom18://voot/';
  switch (details.mediaType) {
    case 'SHOW':
      return `${vootBaseUrl}detail/${obj.id}?src=${src}`;
    case 'EPISODE':
    case 'CAC':
    case 'LIVECHANNEL':
    case 'MOVIE':
      return `${vootBaseUrl}playback/${obj.id}?src=${src}`;
    case 'CHANNEL':
      return `${vootBaseUrl}detail/${obj.id}?src=${src}`;
    case 'SERIES':
      return `${vootBaseUrl}details/show/${meta.showId}/season/${obj.id}?src=${src}`;
    default:
      return vootBaseUrl;
  }
};

exports.getPartnerDeeplinkWithoutSource = (obj) => {
  const details = obj.details || {};
  const meta = obj.meta || {};
  // const vootBaseUrl = 'vootviacom18://voot/';
  switch (details.mediaType) {
    case 'SHOW':
      return `${vootBaseUrl}detail/${obj.id}`;
    case 'EPISODE':
    case 'CAC':
    case 'LIVECHANNEL':
    case 'PCCHANNEL':
    case 'MOVIE':
      return `${vootBaseUrl}playback/${obj.id}`;
    case 'CHANNEL':
      return `${vootBaseUrl}detail/${obj.id}`;
    case 'SERIES':
      return `${vootBaseUrl}details/show/${meta.showId}/season/${obj.id}`;
    default:
      return vootBaseUrl;
  }
};
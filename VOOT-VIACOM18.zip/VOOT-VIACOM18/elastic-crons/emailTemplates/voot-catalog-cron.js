/* eslint-disable max-len */
exports.vccTemplate = (url, date) => {
  const html = `
    <html>
    <body>
    <div style="padding:40px; background-color: #f0efeb69; width:60%; height:20em; border-radius:5px; margin: auto; text-align: center; font-family:'Roboto',sans-serif; margin: 10px auto;">
      <h4 style = "font-weight:800; color:#b7b7a4; font-size:20px" >Voot Jio CMS Full Catalogue Report for ${date}</h4>
      <p style = "font-weight:600; margin-top:5em;margin-bottom:3em; color: #b7b7a4; font-size:12px" > Please click the button to download the report</p >
      <div style="display: block;">
        <a style="font-weight: 600;color:#FFFFFF;text-decoration:none;display: block;border:0.05em solid #bb8f0a52;border-radius:0.12em;box-sizing: border-box;text-align:center;transition: all 0.2s;width:8em;background-color:#cb997e;margin: auto;padding: 10px 20px;" href="${url}">Download</a>
      </div>
      <p style="font-weight:600; font-family:'Roboto',sans-serif;font-size:0.7em;color:#a5a58d;margin:1.5em;">@Tech Team</p>
    </div>
    </body>
    </html>`;
  return html;
};

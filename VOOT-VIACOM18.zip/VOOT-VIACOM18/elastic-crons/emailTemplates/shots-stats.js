/* eslint-disable no-restricted-syntax */
exports.template = (data) => {
  let html = '<html><body>';
  for (const key in data) {
    if (Object.hasOwnProperty.call(data, key)) {
      html += `<h4>${data[key].label} - ${data[key].count}</h4>`;
      if (data[key].split && Object.keys(data[key].split).length) {
        for (const subKey in data[key].split) {
          if (Object.hasOwnProperty.call(data[key].split, subKey)) {
            html += `<p>${subKey} - ${data[key].split[subKey]}</p>`;
          }
        }
      }
    }
  }
  html += '</body></html>';
  return html;
};

/* eslint-disable max-len */
exports.ftvcTemplate = (url, date) => {
  const html = `
      <html>
      <body>
      <div style="padding:40px; background-color: #f0efeb69; width:60%; height:20em; border-radius:5px; margin: auto; text-align: center; font-family:'Roboto',sans-serif; margin: 10px auto;">
        <p style = "font-weight:600; margin-top:5em;margin-bottom:3em; color: #b7b7a4; font-size:12px" > Hello Team,
        </br>
        XML Amazon catalogue cron has been run sucessfully ${date} </p >
        <p>Please click on the below link to see XML amazon catalogue report</p>
        <a href =${url}> ${url} </a>
      </div>
      </body>
      </html>`;
  return html;
};

exports.ftvcErrorTemplate = (errMessage, date) => {
  const html = `
      <html>
      <body>
      <div style="padding:40px; background-color: #f0efeb69; width:60%; height:20em; border-radius:5px; margin: auto; text-align: center; font-family:'Roboto',sans-serif; margin: 10px auto;">
        <p style = "font-weight:600; margin-top:5em;margin-bottom:3em; color: #b7b7a4; font-size:12px" > Hello Team,
        </br>
        Gettting Error in XML Amazon catalogue:- ${date} </p >
        <p>Error Message:- ${errMessage}</p>
      </div>
      </body>
      </html>`;
  return html;
};

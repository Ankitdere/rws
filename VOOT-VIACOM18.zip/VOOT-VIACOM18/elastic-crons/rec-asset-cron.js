/* eslint-disable no-await-in-loop */
const log = require('logger-v18');
const sleep = require('util').promisify(setTimeout);
const elasticClient = require('./modules/elasticClient');
const storageClient = require('./modules/storageClient');
const transformer = require('./modules/transformer');

const { logger } = log;

exports.invoke = async (event) => {
  try {
    logger.log('Received event for handling :', event);
    log.init({
      json: JSON.parse(process.env.logJson), service: 'rec-asset-cron', tags: ['crons'], level: process.env.logLevel,
    });
    logger.log('connecting to elastic search');
    await elasticClient.init();
    const { name } = process.env;
    const toTime = parseInt(new Date().getTime() / 1000, 10);
    let fromTime = (await storageClient.getCronConfig(name)).lastProcessedTime;
    // fromTime = 0;

    let keepGoing = true;
    let fileName = 1;
    while (keepGoing) {
      logger.log({
        fromTime,
        toTime,
        fromTimeStr: new Date(fromTime * 1000),
        toTimeStr: new Date(toTime * 1000),
      });
      const documents = await elasticClient.getUpdatedNonKidsDocumentsForRec(fromTime, toTime);

      if (documents.length <= 0) {
        logger.info('no documents to process, exiting');
        return {};
      }

      logger.info(`got total documents ${documents.length} inserting in algolia`);
      const assets = documents.map((obj) => transformer(obj));
      await storageClient.saveDocumentsForRec(assets, fileName);
      // logger.info('documents inserted in algolia');
      const { revised } = documents[documents.length - 1];
      fileName += 1;
      await storageClient.updateLastProcessedTime(name, revised);
      fromTime = revised;
      keepGoing = documents.length === elasticClient.MAX_DOCUMENTS;
      if (keepGoing) {
        await sleep(2000);
      }
    }
    // return {};
  } catch (err) {
    logger.error('ERROR in rec-asset-cron', Object.keys(err).length ? JSON.stringify(err) : err);
    // throw err;
  }
  return {};
};

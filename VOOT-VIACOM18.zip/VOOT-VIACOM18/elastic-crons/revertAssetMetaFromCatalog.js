/* eslint-disable import/no-extraneous-dependencies */
/* eslint-disable no-await-in-loop */
/* eslint-disable no-restricted-syntax */
const log = require('logger-v18');
const csv = require('csvtojson');
const _ = require('lodash');
const elasticClient = require('./modules/elasticClient');
const storageClient = require('./modules/storageClient');

const { logger } = log;

const arraysToBeFormatted = ['LANGUAGES', 'CONTRIBUTORS', 'CHARACTERS', 'DIRECTOR', 'PRODUCER', 'GENRES'];

const obj = {
  'MEDIA ID': 'id',
  'MEDIA TYPE': 'details.mediaType',
  'MEDIA SUBTYPE': 'meta.type',
  'FULL TITLE': 'meta.title.full',
  'FULL SYNOPSIS': 'meta.synopsis.full',
  LANGUAGES: 'meta.languages',
  SBU: 'meta.SBU',
  'CONTENT SUBJECT': 'meta.contentSubject',
  GENRES: 'meta.genres',
  CONTRIBUTORS: 'meta.contributors',
  CHARACTERS: 'meta.characters',
  'CONTENT DESCRIPTOR': 'meta.contentDescriptor',
  AGE: 'meta.age',
  'IMAGE 16X9': 'details.image.16x9',
  'IMAGE 4X3': 'details.image.4x3',
  'IMAGE 1X1': 'details.image.1x1',
  'IMAGE 2X3': 'details.image.2x3',
  'IMAGE 9x16': 'details.image.9x16',
  'ASSET MARKET TYPE': 'details.marketType',
};

const episodeobj = {
  ...obj,
};

const seriesObj = {
  ...obj,
};

function transform(assetsToTransform) {
  const transformedAssets = [];
  for (let i = 0; i < assetsToTransform.length; i += 1) {
    const asset = assetsToTransform[i];
    asset.CUEPOINTS = (asset.CUEPOINTS && asset.CUEPOINTS.length
      && asset.CUEPOINTS !== '-' && asset.CUEPOINTS.split(',').filter(Boolean)) || '-';
    for (let j = 0; j < arraysToBeFormatted.length; j += 1) {
      asset[arraysToBeFormatted[j]] = (asset[arraysToBeFormatted[j]] && asset[arraysToBeFormatted[j]] !== '-'
       && asset[arraysToBeFormatted[j]].split(';').filter(Boolean)) || '-';
    }
    const transformedAssetObj = {};
    if (asset['MEDIA TYPE'] === 'SERIES') {
      for (const [key, value] of Object.entries(seriesObj)) {
        if (key in asset && asset[key] !== '-') {
          _.set(transformedAssetObj, value, asset[key]);
        }
      }
    } else if (['EPISODE', 'CAC', 'LIVECHANNEL', 'PCCHANNEL'].includes(asset['MEDIA TYPE'])) {
      for (const [key, value] of Object.entries(episodeobj)) {
        if (key in asset && asset[key] !== '-') {
          _.set(transformedAssetObj, value, asset[key]);
        }
      }
    } else {
      for (const [key, value] of Object.entries(obj)) {
        if (key in asset && asset[key] !== '-') {
          _.set(transformedAssetObj, value, asset[key]);
        }
      }
    }
    transformedAssetObj.id = parseInt(transformedAssetObj.id, 10);
    transformedAssets.push(transformedAssetObj);
  }
  return transformedAssets;
}

// function onError(err) {
//   throw Error(err);
// }

async function onComplete(assets) {
  let assetsToTransform = assets.splice(0, 500);
  while (assetsToTransform.length) {
    const transformedAssets = transform(assetsToTransform);
    await elasticClient.bulkUpdate(transformedAssets);
    logger.log('transformedAssets', transformedAssets.map((asset) => asset.id));
    assetsToTransform = assets.splice(0, 500);
  }
}

async function processCSV(stream, assetIds) {
  const assets = [];
  return new Promise((resolve, reject) => {
    csv().fromStream(stream).subscribe((jsonData) => {
      Object.keys(jsonData).forEach((key) => {
        const cleanedKey = key.replace(/[\W_]+/g, ' ');
        // eslint-disable-next-line no-param-reassign
        jsonData[cleanedKey] = jsonData[key];
      });
      if (assetIds.includes(jsonData['MEDIA ID'])
      || assetIds.includes(jsonData['SEASON ID'])
      || assetIds.includes(jsonData['SHOW ID'])) {
        assets.push(jsonData);
      }
    }, (err) => {
      const errObj = {
        errors: true,
        err,
      };
      reject(errObj);
    }, () => {
      resolve(assets);
    });
  });
}

async function invoke(event) {
  try {
    logger.log('Received event for handling :', event);
    log.init({
      json: JSON.parse(process.env.logJson), service: 'revertAssetMetaFromCatalog', level: process.env.logLevel,
    });
    logger.log('connecting to elastic search');
    await elasticClient.init();
    // FIXME: where is this passed from, is this cron active?
    const { date = '2022-01-31', assetIds = ['753731'] } = event;

    if (!date || !assetIds || !assetIds.length) {
      throw Error('event params missing');
    }
    const prefix = `voot-catalog-dump-reports/${process.env.stage}/${date}`;
    const resp = await storageClient.listFolders(prefix);

    if (!resp.Contents.length) {
      throw Error('No files present');
    }

    const { Key } = resp.Contents[0];
    const stream = await storageClient.getObjectStream(Key);
    const assets = await processCSV(stream, assetIds);
    if (assets.errors) {
      throw assets.err;
    } else {
      await onComplete(assets);
    }

    logger.log('CSV Processing complete');
  } catch (error) {
    logger.error('ERROR', Object.keys(error).length ? JSON.stringify(error) : error);
    // throw err;
  }
}

module.exports = {
  invoke,
};

/* eslint-disable no-await-in-loop */
const log = require('logger-v18');
const elasticClient = require('./modules/elasticClient');
const storageClient = require('./modules/storageClient');

const { logger } = log;

exports.invoke = async () => {
  try {
    log.init({
      json: JSON.parse(process.env.logJson), service: 'partner-content-cron', tags: ['crons'], level: process.env.logLevel,
    });
    logger.log('connecting to elastic search');
    await elasticClient.init();
    const { partners } = process.env;
    const partnerTrays = await Promise.all(partners.split(',').map(storageClient.getPartnerTrays));
    logger.log('fetched All partners views object');
    const partnerMap = {};
    await Promise.all(partnerTrays.map(async (obj) => {
      if (obj && obj.trays) {
        partnerMap[`${obj.platformId}`] = [];
        await Promise.all(obj.trays.map(async (t) => {
          if (t.meta && Array.isArray(t.meta.assets)) {
            const res = {
              trayType: t.description,
              trayName: t.title,
              filters: t.filters,
              assets: await elasticClient.getPartnerAssets(t.meta.assets),
            };
            partnerMap[`${obj.platformId}`].push(res);
          } else {
            partnerMap[`${obj.platformId}`].push({
              trayType: t.description,
              trayName: t.title,
              filters: t.filters,
            });
          }
        }));
      }
    }));
    logger.log('fetched assets data and synced with trays');
    // eslint-disable-next-line no-return-await
    await Promise.all(Object.entries(partnerMap).map(async ([key, obj]) => await storageClient.savePartnerTrays(obj, key)));
    logger.info('documents uploaded in s3 bucket');
  } catch (error) {
    logger.error('ERROR', Object.keys(error).length ? JSON.stringify(error) : error);
    // throw err;
  }
  return {};
};

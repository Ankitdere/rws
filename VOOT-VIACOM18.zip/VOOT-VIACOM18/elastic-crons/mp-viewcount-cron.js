/* eslint-disable arrow-parens */
const log = require('logger-v18');
const sleep = require('util').promisify(setTimeout);
const elasticClient = require('./modules/elasticClient');
const util = require('./modules/mixpanelCronUtil');
const mixpanelClient = require('./modules/mixpanelClient');
const algoliaClient = require('./modules/algoliaClient');
const storageClient = require('./modules/storageClient');

const { logger } = log;
const lastestDataFileName = 'latest-data-backup';
const SEARCH_PROMOTED_FILENAME = 'mp-promoted-search';

const { CountType } = util;

function dateFormat(date) {
  const d = new Date(date);
  let month = `${d.getMonth() + 1}`;
  let day = `${d.getDate()}`;
  const year = d.getFullYear();

  if (month.length < 2) month = `0${month}`;
  if (day.length < 2) day = `0${day}`;

  return [year, month, day].join('-');
}

async function getAllDataFromS3(s3path, NUMBER_OF_DAYS, MIN_VIEW) {
  let dayCount = 1;
  const requests = [];
  while (dayCount <= NUMBER_OF_DAYS) {
    const now = new Date();
    const past = new Date(now).setDate(now.getDate() - dayCount);
    let fileName = `${dateFormat(past)}`;
    if (dayCount === 1) {
      fileName = `${dateFormat(now)}_temp`;
    }
    requests.push({ fileName, day: dayCount });
    // eslint-disable-next-line no-plusplus
    dayCount++;
  }
  const allData = await Promise.all(
    requests.map(async (request) => {
      const data = await storageClient.getMpCronDataFile(
        s3path,
        request.fileName,
      );
      return data
        .filter((x) => {
          if (x.key[0] === null || x.key[0] === 'NULL' || x.value < MIN_VIEW) { return false; }
          return true;
        });
    }),
  );
  return allData;
}

async function updateLastestDataToS3(path, data) {
  await storageClient.updateMpDataFile(path, lastestDataFileName, data);
}

function formatForAlgolia(objects) {
  const algoliaObjects = objects.map((object) => {
    if (object.id) {
      if (object.stats && object.stats.mpSearchPopularity) {
        return {
          objectID: `${object.id}`,
          searchCount: object.stats.mpSearchPopularity,
        };
      // eslint-disable-next-line no-else-return
      } else if (object.stats && object.stats.mpViewPopularity) {
        return {
          objectID: `${object.id}`,
          viewCount: object.stats.mpViewPopularity,
        };
      }
    }
    return {};
  });
  const objectsToUpdate = algoliaObjects.filter((obj) => !!obj.objectID);
  logger.log('Algolia Partial Update', objectsToUpdate.length, JSON.stringify(objectsToUpdate));
  return objectsToUpdate;
}

async function bulkUpdatToElastic(type, objectData) {
  const data = [...objectData];
  const assetsData = [];
  const chunkSize = 500;
  while (data.length) {
    assetsData.push(data.splice(0, chunkSize));
  }

  logger.log(`total object : ${objectData.length},  after chunk: ${assetsData.length}`);

  let index = 1;
  // eslint-disable-next-line no-restricted-syntax
  for (const assets of assetsData) {
    const objects = assets.map(asset => util.transformToElasticObj(type, asset));
    logger.info(
      // eslint-disable-next-line no-plusplus
      `inserting object into chunks : ${index++} of total ${assetsData.length}`,
    );
    // eslint-disable-next-line no-await-in-loop
    await elasticClient.bulkUpdate(objects, false);

    const algoliaObjects = formatForAlgolia(objects);
    // eslint-disable-next-line no-await-in-loop
    await algoliaClient.partialUpdate(algoliaObjects);

    // eslint-disable-next-line no-await-in-loop
    await sleep(1000);
  }
}

async function invoke() {
  try {
    const {
      name = 'mp-viewcount-cron', numberOfDays = 30, minView = 100, type = 1,
    } = process.env;

    logger.log(`Recieved event name : ${name} - NumberOf Day : ${numberOfDays} - Minimum View : ${minView} - Type : ${type}`);

    log.init({
      json: JSON.parse(process.env.logJson),
      service: `${name}`,
      tags: ['crons'],
      level: process.env.logLevel,
    });
    logger.log('connecting to elastic search');
    await elasticClient.init();

    const now = new Date();
    const today = dateFormat(now);
    const yesterday = dateFormat(new Date(now).setDate(new Date(now).getDate() - 1));

    logger.log('Running job for ', { today });

    // Fetch yesterday and today's data and store to s3.
    const yesterdayDataFileName = `${yesterday}_temp`;

    const yesterdayData = await storageClient.getMpCronDataFile(name, yesterdayDataFileName);
    if (yesterdayData && yesterdayData.length) {
      logger.log(`updating yesterday : ${yesterday} data `);

      const mpData = await mixpanelClient.getDataFromMixpanel(type, CountType, yesterday, minView);
      await storageClient.updateMpDataFile(name, yesterday, mpData);
      await storageClient.deleteCronDataFile(name, yesterdayDataFileName);
    }
    const todayDataFileName = `${today}_temp`;
    const todaysMpData = await mixpanelClient.getDataFromMixpanel(type, CountType, today, minView);

    console.log('data', todaysMpData);
    await storageClient.updateMpDataFile(name, todayDataFileName, todaysMpData);
    logger.log('fetched data from mixpanel and stored in s3 completed');

    // get last 30 days data from s3
    const allS3Data = await getAllDataFromS3(name, numberOfDays, minView);
    const promotedAssets = (type === 2) ? await storageClient.getPromotedAssets(SEARCH_PROMOTED_FILENAME) : [];
    logger.info('promoted assets', promotedAssets);

    const normalizedData = util.normalizeData(type, allS3Data);
    const lastStoredData = await storageClient.getMpCronDataFile(name, lastestDataFileName);
    const data = util.getUnusedData(normalizedData, lastStoredData);

    // add promoted assets to data
    promotedAssets.forEach(passet => {
      const foundIndex = data.findIndex(a => a.key === passet.key);
      if (foundIndex !== -1) {
        data[foundIndex].weightage = passet.weightage; // overite if already
      } else {
        data.push(passet); // insert if not
      }
    });
    await bulkUpdatToElastic(type, data);
    await updateLastestDataToS3(name, data);

    logger.log(`${name} job completed successfully`);
  } catch (error) {
    logger.error('ERROR', error);
  }
}

module.exports = {
  invoke,
};

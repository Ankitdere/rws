/* eslint-disable no-unused-vars */
/* eslint-disable no-param-reassign */
/* eslint-disable radix */
/* eslint-disable no-plusplus */
/* eslint-disable no-await-in-loop */
/* eslint-disable no-restricted-syntax */
/* eslint-disable no-nested-ternary */
/* eslint-disable no-use-before-define */
const log = require('logger-v18');
// const events = require('events');
const sleep = require('util').promisify(setTimeout);
const fs = require('fs');
const zlib = require('zlib');
const moment = require('moment');
const axios = require('axios');
const { Parser } = require('json2csv');
const tunnel = require('tunnel');
const elasticClient = require('./modules/elasticClient');

const { logger } = log;
const { transform } = require('./v3ResponseTypes/responseTypes/common');

const axiosClient = axios.create({
  baseURL: 'https://api.mixpanel.com/lookup-tables/',
  timeout: 1000 * 60 * 10,
  transformRequest: axios.defaults.transformRequest.concat(
    (data, headers) => {
      // compress strings if over 1KB
      if (typeof data === 'string' && data.length > 1024) {
        headers['Content-Encoding'] = 'gzip';
        const buffer = zlib.gzipSync(data);
        return buffer;
      // eslint-disable-next-line no-else-return
      } else {
        headers['Content-Encoding'] = undefined;
        return data;
      }
    },
  ),
});

const FILE_NAME = `${moment().utcOffset('+05:30').format('YYYY-MM-DDTHH-mm')}-new-full-catalog-report.csv`;
const FILE_PATH = `./uploads/${FILE_NAME}`;
const BATCH_SIZE = 20000;
let FLAG = false;
let seriesWiseMaxEpisode = {};

let i = 0;
// recieve data from elastic client scroll api
async function getDataFromElasticClient(elasticData, total, isLastBatch) {
  const csvData = await transformDataForCsv(elasticData);
  ++i;
  if (!fs.existsSync(FILE_PATH) && !FLAG) {
    const fields = Object.keys({ ...csvData[0] });
    await writeToCsv({ fields, csvData });
    FLAG = true;
  } else {
    await appendToCsv({ csvData });
  }
}

async function transformDataForCsv(elasticData) {
  const csvData = [];
  // const promises = elasticData.map((asset) => elasticClient.getShowDetailsMap([asset]));
  // const showList = await Promise.all(promises);
  const showList = await elasticClient.getShowDetailsMap(elasticData);
  for (let j = 0; j < elasticData.length; j++) {
    const { meta, ingested, disabled } = elasticData[j];
    const result = getTransformedData(elasticData[j], null, showList);
    const filename = (elasticData[j].details && elasticData[j].details.file)
      ? elasticData[j].details.file : '-';
    // eslint-disable-next-line eqeqeq
    const isLastEpisode = ((result.mediaType === 'EPISODE') && (result.episode !== '0') && (result.episode == seriesWiseMaxEpisode[result.seasonId]));
    const isShotsAsset = (result.mediaType === 'SHOTS');
    const tempObj = {
      'Media ID': parseInt(result.id, 10) || '-',
      'MEDIA TYPE': result.mediaType || '-',
      'MEDIA SUBTYPE': result.mediaSubType || '-',
      'FULL TITLE': result.fullTitle || '-',
      'SHOW ID': parseInt(result.showId, 10) || '-',
      'SHOW NAME': result.showName || '-',
      'SEASON ID': parseInt(result.seasonId, 10) || '-',
      'SEASON NUMBER': result.season || '-',
      'EPISODE NUMBER': result.episode || '-',
      LANGUAGES: result.languages
        ? Array.isArray(result.languages)
          ? result.languages.join()
          : result.languages
        : '-',
      SBU: result.SBU || '-',
      'MULTI TRACK AUDIO ENABLED': result ? result.multiTrackAudioEnabled : '-',
      GENRES: result.genres
        ? Array.isArray(result.genres)
          ? result.genres.join()
          : result.genres
        : '-',
      'TELECAST DATE': result.telecastDate || '-',
      DURATION: result.duration,
      'ASSET MARKET TYPE': result.assetMarketType || '-',
      'SHOW MARKET TYPE': result.showMarketType || '-',
      DOWNLOADABLE: result.downloadable || '-',
      'INGEST DATE': ingested
        ? moment.unix(ingested).format('YYYYMMDD') || ''
        : '-',
      'INGEST TIME': ingested
        ? moment.unix(ingested).format('HH:mm:ss') || ''
        : '-',
      'LAST EPISODE?': isLastEpisode
        ? 'TRUE'
        : '-',
      'CONTENT SUBJECT': isShotsAsset
        ? meta && meta.contentSubject
          ? meta.contentSubject
          : '-'
        : '-',
      'SUB GENRES': isShotsAsset
        ? meta && meta.subGenre
          ? Array.isArray(meta.subGenre)
            ? meta.subGenre.join()
            : meta.subGenre
          : '-'
        : '-',
      CONTRIBUTORS: isShotsAsset
        ? meta && meta.contributors
          ? Array.isArray(meta.contributors)
            ? meta.contributors.join()
            : meta.contributors
          : '-'
        : '-',
      'CREATIVE HASHTAGS': isShotsAsset
        ? meta && meta.hashtags && meta.hashtags.creative
          ? Array.isArray(meta.hashtags.creative)
            ? meta.hashtags.creative.join()
            : meta.hashtags.creative
          : '-'
        : '-',
      TOPIC: isShotsAsset
        ? meta && meta.topic
          ? meta.topic
          : '-'
        : '-',
      'VIDEO SOURCE': isShotsAsset
        ? meta && meta.video && meta.video.source
          ? meta.video.source
          : '-'
        : '-',
    };
    csvData.push(tempObj);
  }

  return csvData;
}

async function writeToCsv({ fields, csvData }) {
  const parser = new Parser({ fields });
  const csv = parser.parse(csvData);
  const ws = fs.createWriteStream(FILE_PATH, { encoding: 'utf8' });
  ws.write(`${csv}\r\n`);
  logger.log(`Created a file and wrote data - ${i}`);
  ws.end();
}

async function appendToCsv({ csvData }) {
  const parser = new Parser({ header: false, withBOM: true });
  const csv = parser.parse(csvData);
  fs.appendFileSync(FILE_PATH, `${csv}\r\n`);
  logger.log(`File write complete - ${i}`);
}

// get transformed data from v3ResponseTypes
function getTransformedData(asset, playbackType, showList) {
  if (asset.meta) {
    if (asset.meta.showId) {
      return transform(asset, playbackType, showList[`${asset.meta.showId}`]);
    } if (asset.meta.series && asset.meta.series.showId) {
      return transform(asset, playbackType, showList[`${asset.meta.series.showId}`]);
    }
  }
  return transform(asset, playbackType);
}

function getFilesizeInBytes(filename) {
  const stats = fs.statSync(filename);
  const fileSizeInBytes = stats.size;
  return fileSizeInBytes;
}

async function sendToMixPanel(id, secret) {
  try {
    logger.info('uploading csv of size (bytes)', getFilesizeInBytes(FILE_PATH));
    const contents = fs.readFileSync(FILE_PATH).toString('utf-8');
    let firstLine = contents.substr(0, contents.indexOf('\n'));
    firstLine = firstLine.replace(/"/g, '');
    const payload = firstLine + contents.substr(contents.indexOf('\n'));

    const agent = tunnel.httpsOverHttp({
      proxy: {
        host: 'gcpprodproxy.jio.com',
        port: 8080,
      },
    });

    const resp = await axiosClient.put(
      id,
      payload,
      {
        auth: {
          username: secret,
          password: '',
        },
        headers: {
          Accept: 'application/json',
          'Content-Type': 'text/csv',
        },
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        httpsAgent: agent,
      },
    );
    logger.info('put request succeeded with response', resp.data);
  } catch (err) {
    logger.error('ERROR', JSON.stringify(err.response && err.response.data));
    logger.error('ERROR', err);
  }
}

async function invoke() {
  try {
    log.init({
      json: process.env.logJson,
      service: 'mp-lookup-table-cron',
      tags: ['crons'],
      level: process.env.logLevel,
    });
    logger.info(
      'MP lookup table cron running on ',
      moment().utcOffset('+05:30').format('YYYY-MM-DD HH:MM:SS'),
    );

    logger.info('connecting to elastic search');
    await elasticClient.init();

    logger.info('fetch series wise max episode numbers');
    seriesWiseMaxEpisode = await elasticClient.getLatestEpisodeNumberBySeries();

    logger.info('get the catalog');
    await elasticClient.getFullCatalogDump(getDataFromElasticClient);

    logger.info('Platform - app');
    let id = process.env.mixpanelLookupTableAppId;
    let secret = process.env.mixpanelLookupTableAppSecret;
    if (id && secret) {
      await sendToMixPanel(id, secret);
    }

    logger.info('Platform - web');
    id = process.env.mixpanelLookupTableWebId;
    secret = process.env.mixpanelLookupTableWebSecret;
    if (id && secret) {
      await sendToMixPanel(id, secret);
    }

    logger.info('Platform - tv');
    id = process.env.mixpanelLookupTableTvId;
    secret = process.env.mixpanelLookupTableTvSecret;
    if (id && secret) {
      await sendToMixPanel(id, secret);
    }

    fs.unlinkSync(FILE_PATH);
    logger.info(
      'MP lookup table cron completed on ',
      moment().utcOffset('+05:30').format('YYYY-MM-DD HH:MM:SS'),
    );
  } catch (error) {
    logger.error('ERROR in MP lookup table cron - ', error);
    fs.unlinkSync(FILE_PATH);
    // throw error;
  }
}

module.exports = {
  invoke,
  getDataFromElasticClient,
};

/* eslint-disable array-callback-return */
/* eslint-disable no-param-reassign */
const {
  isEqual, transform, isObject,
} = require('lodash');
const axios = require('axios');
const tunnel = require('tunnel');
const log = require('logger-v18');
const moment = require('moment');
const elasticClient = require('./modules/elasticClient');
const teamCodes = require('./team-name-codes.json');
const helper = require('./utils/helper');
const cachePurge = require('./modules/cachePurge');

// test
require('./modules/rabbitMQClient');

const { logger } = log;
const client = process.env.sportzClientId;

function difference(object, base) {
  return transform(object, (result, value, key) => {
    if (!isEqual(value, base[key])) {
      // eslint-disable-next-line no-param-reassign
      result[key] = isObject(value) && isObject(base[key]) ? difference(value, base[key]) : value;
    }
  });
}

// eslint-disable-next-line no-unused-vars
async function evictCacheTags(ids, assets) {
  // Only sports usecase handled here for now.
  const esAssets = await elasticClient.getObjectByIdsWithSource('global_v4', ids, ['id', 'meta.standings']);
  const oldAssets = [];
  const newAssets = [];
  esAssets.map((asset) => {
    const standings = helper.get(asset, 'meta.standings', {});
    oldAssets[ids.indexOf(asset.id)] = { standings };
  });
  assets.map((asset) => {
    const standings = helper.get(asset, 'meta.standings', {});
    newAssets[ids.indexOf(asset.id)] = { standings, id: asset.id };
  });

  const diff = difference(newAssets, oldAssets);
  logger.log('diff', diff);
  const diffIds = diff.map((obj) => {
    if (('standings' in obj) && Object.keys(obj.standings).length) {
      return obj.id.toString();
    }
    return '';
  });
  const idsForEviction = diffIds.filter((id) => !!id);

  if (idsForEviction.length) {
    logger.log('cache tag eviction for', idsForEviction);
    await cachePurge.purgeByCacheTag(idsForEviction);
  }
}

// eslint-disable-next-line no-unused-vars
function transformStandingsForHBS(response, sport) {
  const standings = helper.get(response.data, 'Standings.0', {});
  standings.groups = standings.Groups;
  standings.series_id = standings.ID;

  delete standings.Groups;
  delete standings.StartDate;
  delete standings.EndDate;
  delete standings.Number;
  delete standings.Code;
  delete standings.Name;
  delete standings.ID;

  const displayGroupName = standings.groups.length > 1;
  standings.groups = standings.groups.map((group) => {
    group.teams = group.Teams;
    group.name = group.Name;
    group.id = group.ID;
    delete group.Teams;
    delete group.Name;
    delete group.ID;

    group.teams = group.teams.map((team) => {
      delete team.teamId;

      team.team_name = team.teamNameLong;
      team.team_short_name = team.teamCountryCode;

      const teamStandings = team.Standings || {};
      team.position = `${teamStandings.Rank || 0}`;
      team.prev_position = `${teamStandings.RankPrevious || 0}`;
      team.played = `${teamStandings.Played || 0}`;
      team.wins = `${teamStandings.Won || 0}`;
      team.lost = `${teamStandings.Lost || 0}`;
      team.tied = `${teamStandings.Drawn || 0}`;
      team.draws = `${teamStandings.Drawn || 0}`;
      team.score_diff = `${teamStandings.ScoreDifference || 0}`;
      team.points_conceded = `${teamStandings.Conceded || 0}`;
      team.points_scored = `${teamStandings.Scored || 0}`;
      team.points = `${teamStandings.Points || 0}`;
      team.away_wins = `${teamStandings.WonAway || 0}`;
      team.away_points_conceded = `${teamStandings.ConcededAway || 0}`;
      team.away_points_scored = `${teamStandings.ScoredAway || 0}`;

      delete team.Standings;
      delete team.teamLogoUrl;
      delete team.teamCountryCode;
      delete team.teamNameLong;
      delete team.teamNameShort;

      return team;
    });

    group.displayGroupName = displayGroupName;
    return group;
  });

  return standings;
}

function transformStandingsForSI(response, sport) {
  const { standings = {} } = response.data;
  const displayGroupName = standings.groups.length > 1;
  standings.groups = standings.groups.map((group) => {
    group.teams = group.teams.team.map((team) => {
      if (('match_result' in team) && ('match' in team.match_result)) {
        team.match_result = [];
      }

      delete team.team_id;
      delete team.team_global_id;
      delete team.trump_matches_won;

      if (!('team_short_name' in team) || !team.team_short_name) {
        if (team.team_name in teamCodes) {
          team.team_short_name = teamCodes[team.team_name];
        }
      }

      if (sport === 'basketball') {
        if ('wins_per' in team) {
          team.wins_per = parseFloat(team.wins_per * 100).toFixed(1);
        }
      }

      return team;
    });

    group.displayGroupName = displayGroupName;
    return group;
  });

  return standings;
}

async function getStandings(seriesid, league, options = {}, type = 'standing') {
  const params = {
    client,
    type,
    seriesid,
    league,
  };

  const hbsHeaders = {
    'X-Api-Key': process.env.hbsApiKey,
  };

  const {
    partner, method, baseURL, url, sport,
  } = options;

  const agent = tunnel.httpsOverHttp({
    proxy: {
      host: 'gcpprodproxy.jio.com',
      port: 8080,
    },
  });

  const requestConfig = {
    method,
    baseURL,
    url,
    params: (partner === 'hbs') ? {} : params,
    headers: (partner === 'hbs') ? hbsHeaders : {},
    httpsAgent: agent,
    proxy: false,
  };

  try {
    const response = await axios(requestConfig);
    if (response.status !== 200) {
      return { error: true, status: response.status, message: response.data };
    }

    let standings = {};
    if (partner === 'hbs') {
      standings = transformStandingsForHBS(response, sport);
    } else {
      standings = transformStandingsForSI(response, sport);
    }
    return standings;
  } catch (err) {
    return { error: true, err };
  }
}

async function invoke() {
  const {
    partner = 'sportzInteractive', sport = 'football', league = 'liga', seriesid = '337',
  } = process.env;
  // const {
  //   partner = 'hbs', sport = 'football', league = 'poc3_fac', seriesid = '285488',
  // } = event;

  log.init({
    json: process.env.logJson,
    service: 'standings-cron',
    tags: ['crons'],
    level: process.env.logLevel,
  });
  logger.info(
    'Standings cron running on ',
    moment().utcOffset('+05:30').format('YYYY-MM-DD HH:MM:SS'),
    `for ${league} ${sport} ${partner} ${seriesid}`,
  );

  let baseURL = process.env.sportzBaseURL;
  let url = process.env.sportzFootballURI;
  if (sport === 'basketball') {
    url = process.env.sportzBasketBallURI;
  }
  let keyForSeriesId = 'meta.sportzInteractiveSeriesId';

  if (partner === 'hbs') {
    baseURL = process.env.hbsBaseURL;
    url = process.env.hbsFootballURI;
    keyForSeriesId = 'meta.hbsRounds';
  }

  const options = {
    partner,
    method: 'get',
    baseURL,
    url,
    sport,
  };

  const res = await elasticClient.getGeneric({
    query: {
      bool: {
        must: [
          {
            match: {
              [keyForSeriesId]: seriesid,
            },
          },
          {
            match: {
              'details.mediaType.keyword': 'SERIES',
            },
          },
        ],
      },
    },
  });

  let esSeriesId = '';
  // eslint-disable-next-line no-underscore-dangle
  const results = res.hits.hits.map((obj) => obj._source);
  if (results.length) {
    // eslint-disable-next-line prefer-destructuring
    esSeriesId = results[0].id;
  }

  const standings = await getStandings(seriesid, league, options);
  if (standings.groups) {
    const loggingOutput = JSON.parse(JSON.stringify(standings));
    delete loggingOutput.groups;
    logger.log(loggingOutput);
  }

  if (standings.error) {
    const { err } = standings;
    logger.error('ERROR', err);
    return;
  }

  if (esSeriesId) {
    const standingsMeta = { id: esSeriesId, meta: { standings } };
    logger.log(standingsMeta);
    await elasticClient.bulkUpdate([standingsMeta]);
    await evictCacheTags([esSeriesId], [standingsMeta]);
  }
}

module.exports = {
  invoke,
};

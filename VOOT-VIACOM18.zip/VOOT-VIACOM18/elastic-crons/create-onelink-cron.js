const { logger } = require('logger-v18');
const { createOneLinkApiBatch } = require('./utils/onelink');

// console.log(process.env);

exports.invoke = async () => {
  try {
    const resp = await createOneLinkApiBatch();
    console.log('Response is ', resp);
  } catch (err) {
    logger.error('Some error occured. ', err);
  }
};

/* eslint-disable arrow-parens */
const log = require('logger-v18');
const axios = require('axios');
const moment = require('moment-timezone');
const tunnel = require('tunnel');
const elasticClient = require('./modules/elasticClient');
// const s3Client = require('./modules/s3Client');
const channels = require('./utils/jio-channels.json');

const { logger } = log;

const axiosClient = axios.create({
  baseURL: process.env.jioEpgBase,
  timeout: 10000,
  headers: { },
});

function getStartOfDay(time) {
  const d = new Date(time);
  d.setUTCHours(0);
  d.setUTCMinutes(0);
  d.setUTCSeconds(0);
  d.setUTCMilliseconds(0);
  return d.getTime();
}
const { jioImageBase } = process.env;

async function copyImageToEpgBucket(episodePoster) {
  if (!jioImageBase || !episodePoster) {
    return;
  }
  const file = `${jioImageBase}${episodePoster}`;
  const response = await axios.get(file, {
    responseType: 'arraybuffer',
  });
  if (response && response.headers && response.headers['content-type'] && response.data) {
    // const contentType = response.headers['content-type'];
    // await s3Client.uploadImage(response.data, `v3Storage/epg/${episodePoster}`, contentType);
  }
}

async function transformEpgContent(jioEpg, channelIds) {
  const {
    startEpoch,
    endEpoch,
    showtime,
    srno,
    showId,
    showname,
    description,
    episodePoster,
  } = jioEpg;
  const imageId = episodePoster.substring(0, episodePoster.lastIndexOf('.'));
  const [imageType] = episodePoster.split('.').splice(-1);
  const startHours = getStartOfDay(startEpoch);
  const createDate = Math.floor(getStartOfDay(new Date().getTime()) / 1000);
  const startDate = Math.floor(startHours / 1000);
  try {
    await copyImageToEpgBucket(episodePoster);
  } catch (err) {
    logger.error(`error in copying image${episodePoster}`, err);
  }
  return channelIds.map(channelId => ({
    srno,
    channelId,
    showtime,
    name: showname,
    createDate,
    startDate,
    istStartDateStr: moment.tz(startEpoch, 'Asia/Kolkata').format('YYYY-MM-DD'),
    istCreateDateStr: moment().tz('Asia/Kolkata').format('YYYY-MM-DD'),
    time: {
      from: Math.floor(startEpoch / 1000),
      to: Math.floor(endEpoch / 1000),
    },
    details: {
      image: {
        id: `v3Storage/epg/${imageId}`,
        base: 'https://v3img.voot.com/',
        type: imageType,
      },
      source: 'jio',
    },
    meta: {
      title: {
        full: showname,
      },
      synopsis: {
        full: description,
      },
      programId: showId,
    },
  }));
}

async function getEPGForchannel(channel, offset) {
  const agent = tunnel.httpsOverHttp({
    proxy: {
      host: 'gcpprodproxy.jio.com',
      port: 8080,
    },
  });
  const resp = await axiosClient.get(`?channel_id=${channel}&offset=${offset}&langId=6`, {
    httpsAgent: agent,
    proxy: false,
  });
  return resp.data.epg;
}

exports.invoke = async () => {
  try {
    log.init({
      json: JSON.parse(process.env.logJson), service: 'jio-epg-elastic-cron', tags: ['crons'], level: process.env.logLevel,
    });
    logger.log('connecting to elastic search');
    await elasticClient.init();
    logger.info('running for these channels', channels);
    const { offset } = process.env;
    // eslint-disable-next-line no-restricted-syntax
    for (const channelInfo of channels) {
      const {
        channel,
        mediaId,
      } = channelInfo;
      let results;
      try {
        // eslint-disable-next-line no-await-in-loop
        results = await getEPGForchannel(channel, offset);
      } catch (err) {
        logger.warn('got error once retrying');
        // eslint-disable-next-line no-await-in-loop
        results = await getEPGForchannel(channel, offset);
      }
      let channelIds;
      if (Array.isArray(mediaId)) {
        channelIds = [...mediaId];
      } else {
        channelIds = [mediaId];
      }
      logger.info(`processing channel id${channel}`);
      // eslint-disable-next-line no-await-in-loop
      const data = (await Promise.all(results.map(a => transformEpgContent(a, channelIds)))).reduce((acc, obj) => ([...acc, ...obj]), []);
      // eslint-disable-next-line no-await-in-loop
      await elasticClient.bulkInsertEPG(data);
    }
    return;
  } catch (err) {
    logger.error('ERROR', Object.keys(err).length ? JSON.stringify(err) : err);
    // throw err;
  }
};

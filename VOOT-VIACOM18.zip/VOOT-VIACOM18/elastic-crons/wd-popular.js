/* eslint-disable arrow-parens */
const log = require('logger-v18');
const axios = require('axios');
const elasticClient = require('./modules/elasticClient');

const { logger } = log;

async function fn(api) {
  try {
    logger.log('connecting to elastic search');
    await elasticClient.init();
    logger.log('api value', api);
    let popularity = 5000;
    let keepGoing = true;
    const LIMIT = 50;
    let offset = 0;
    while (keepGoing) {
      // eslint-disable-next-line no-await-in-loop
      const response = await axios.get(`${api}&limit=${LIMIT}&offSet=${offset}`);
      const [assets] = response.data.assets;
      keepGoing = assets.totalItemCount === LIMIT;
      offset += assets.totalItemCount;
      logger.info(`fetched assets:${assets.totalItemCount} total fetched:${offset} of ${assets.totalItems}`);
      // eslint-disable-next-line no-loop-func
      const objects = assets.items.map(asset => ({
        id: asset.mId,
        stats: {
          // eslint-disable-next-line no-plusplus
          popularity: popularity--,
        },
      }));
      logger.info('inserting object into elastic');
      // eslint-disable-next-line no-await-in-loop
      await elasticClient.bulkUpdate(objects);
    }
  } catch (error) {
    logger.error('ERROR', Object.keys(error).length ? JSON.stringify(error) : error);
    // throw err;
  }
}

exports.invoke = async () => {
  const apis = [process.env.showsApi, process.env.moviesApi];
  apis.forEach(async (api) => {
    logger.log('processing for', api);
    await fn(api);
  });
};

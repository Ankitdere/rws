const { logger } = require('logger-v18');
const mixpanelClient = require('./modules/mixpanelClient');
const util = require('./modules/mixpanelCronUtil');
const algoliaClient = require('./modules/algoliaClient');
const standingsCron = require('./standings-cron');

const { CountType } = util;

function dateFormat(date) {
  const d = new Date(date);
  let month = `${d.getMonth() + 1}`;
  let day = `${d.getDate()}`;
  const year = d.getFullYear();

  if (month.length < 2) month = `0${month}`;
  if (day.length < 2) day = `0${day}`;

  return [year, month, day].join('-');
}

async function testMixpanel() {
  const now = new Date();
  const yesterday = dateFormat(new Date(now).setDate(new Date(now).getDate() - 1));
  const data = await mixpanelClient.getDataFromMixpanel(1, CountType, yesterday, 100);
  return data;
}

async function testAlgolia() {
  await algoliaClient.deleteDocuments([2129675]);
}

async function testStandings(event) {
  await standingsCron.invoke(event);
}

async function invoke() {
  try {
    logger.log('Initiating mixpanel check');
    const data = await testMixpanel();
    logger.log('Finished mixpanel check');
    logger.log('data', (data || []).splice(0, 10));
  } catch (err) {
    logger.log(err);
  }

  try {
    logger.log('Initiating algolia check');
    await testAlgolia();
    logger.log('Finished algolia check');
  } catch (err) {
    logger.log(err);
  }

  try {
    logger.log('Initiating sportz interactive check');
    await testStandings({});
    logger.log('Finished sportz interactive check');
  } catch (err) {
    logger.log(err);
  }

  try {
    logger.log('Initiating HBS check');
    await testStandings({
      partner: 'hbs',
      sport: 'football',
      league: 'FWC',
      seriesid: '285488',
    });
    logger.log('Finished HBS check');
  } catch (err) {
    logger.log(err);
  }
}

module.exports = {
  invoke,
};

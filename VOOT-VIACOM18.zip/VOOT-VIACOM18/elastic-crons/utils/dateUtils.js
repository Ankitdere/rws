function getLastestDate() {
  const currentDate = new Date();
  const monthDenotation = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const day = currentDate.getDate();
  const month = currentDate.getMonth();
  const year = currentDate.getFullYear();
  const fileName = `${day}_${monthDenotation[month]}_${year}.xml`;
  return fileName;
}

module.exports = {
  getLastestDate,
};

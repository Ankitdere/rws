/* eslint-disable max-len */
const { logger } = require('logger-v18');
const trayModule = require('../tray-module/trays');
const storageClient = require('../modules/storageClient');

const { cmsBucketName } = process.env;

// valid values are the values against which API filters are checked for their validity
async function getValidValuesTrays() {
  const keys = [
    'SBULIST',
    'language',
    'genre',
    'mediaTypes',
    'assetLabels',
    'creativeLayouts',
    'team',
    'globalConfig',
    'templateDefaults',
    'ads',
  ];
  try {
    const response = {};
    for (let i = 0; i < keys.length; i += 1) {
      const key = keys[i];
      // eslint-disable-next-line no-await-in-loop
      response[key] = await storageClient.getFile(`meta-management/${key}.json`, cmsBucketName);
    }
    const languageArr = response.language.language.map((obj) => obj.name);
    const SBUDataArr = response.SBULIST.SBULIST.map((obj) => obj.sbuId);
    const assetLabelsObj = response.assetLabels.assetLabels.reduce((acc, curr) => ({ ...acc, [`${curr.label}`]: curr.key }), {});
    const creativeLayoutsObj = response.creativeLayouts.creativeLayouts.reduce((acc, curr) => ({ ...acc, [`${curr.id}`]: curr }), {});
    const teamObj = response.team.team.reduce((acc, curr) => ({ ...acc, [`${curr.id}`]: curr }), {});
    const templateDefaultsObj = response.templateDefaults.templateDefaults.reduce((acc, curr) => ({ ...acc, [`${curr.genre}`]: curr }), {});
    const adsObj = response.ads.ads.reduce((acc, cur) => {
      const platformsObj = cur.platforms.reduce((platformAcc, platformCur) => ({ ...platformAcc, [`${platformCur.platform}`]: platformCur }), {});
      return { ...acc, [`${cur.adServer}`]: platformsObj };
    }, {});
    trayModule.setValidValuesDataForTrays(languageArr, response.genre.genre, SBUDataArr, [], response.mediaTypes.mediaTypes, assetLabelsObj, creativeLayoutsObj, teamObj, response.globalConfig, templateDefaultsObj, adsObj);
  } catch (err) {
    // logger.error('ERROR in bootUp.js getValidValuesTrays, Worker id #', cluster.worker.id || '', 'error message ', ex.message || '');
    logger.error('ERROR in bootUp.js getValidValuesTrays', err);
  }
}

async function setValidValuesTrays() {
  // this call to populate data
  await getValidValuesTrays();
}

module.exports = {
  setValidValuesTrays,
};

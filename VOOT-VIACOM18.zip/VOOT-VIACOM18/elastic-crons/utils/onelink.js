const axios = require('axios');
const https = require('https');
const { logger } = require('logger-v18');
const { getLiveAssetsWithoutOneLink, bulkUpdate, getShowDetailsMap } = require('../modules/elasticClient');
const { getDeepLink } = require('../v3ResponseTypes/deepLinkGenerator');
const { getSEOMetaObject } = require('../v3ResponseTypes/seoMetaGenerator');
const { sanitizeString } = require('./helper');

const oneLinkConfig = JSON.parse(process.env.oneLink);

function getV3DeepLinkUrl(obj) {
  const url = getDeepLink(obj, undefined);
  // logger.debug(`Deeplink url for asset ${obj.id} is ${url}`);
  return url;
}

function getShareImageUrl(details) {
  const root = details.image3x4 ? details.image3x4.base : 'https://v3img.voot.com/';
  const imgRoute = details.image['16x9'] || details.image['4x3'] || details.image['2x3'] || details.image['1x1'];
  return root + imgRoute;
}

function getOneLinkCreateUrl() {
  const { oneLinkId, endpoint } = oneLinkConfig;
  const base = endpoint || 'https://onelink.appsflyer.com/shortlink/v1/';
  if (!oneLinkId) {
    throw new Error(`OneLink API ID not found in config.${process.env.NODE_ENV}.json`);
  }
  const url = base + oneLinkId;
  // logger.debug('Url to create deeplink is ', url);
  return url;
}

function getOneLinkReqBody(dlUrl, desktopUri, title, description, mediaType, imageUrl) {
  try {
    const { params } = oneLinkConfig;
    const validParams = ['af_android_url', 'af_channel', 'af_dp', 'af_ios_url', 'deep_link_sub1'];
    const ogTitle = sanitizeString(title);
    const ogDescription = sanitizeString(description);
    const mediaSource = 'mobile_share';
    const campaign = 'Share Media';
    const adName = `Share for ${sanitizeString(title, 50)}`;
    const adSetName = `Share ${mediaType} Adset`;
    let data = {
      data: {
        pid: mediaSource,
        c: campaign,
        deep_link_value: dlUrl,
        af_web_dp: desktopUri,
        af_ad: adName,
        af_adset: adSetName,
        af_og_title: ogTitle,
        af_og_description: ogDescription,
        af_og_image: imageUrl,
        af_force_deeplink: true,
      },
    };
    if (params) {
      Object.keys(params).map((key) => {
        const dataSoFar = data.data;
        if (validParams.includes(key)) {
          dataSoFar[key] = params[key];
        }
        data = {
          data: dataSoFar,
        };
        return key;
      });
    }
    // logger.debug(data);
    return JSON.stringify(data);
  } catch (e) {
    throw new Error(`Error in Req Body ${e}`);
  }
}

function getOneLinkReqOptions(dlUrl, desktopUrl, title, description, mediaType, imageUrl) {
  if (!oneLinkConfig.apiKey) {
    throw new Error(`One Link Admin API Key not found in config.${process.env.NODE_ENV}.json`);
  }
  const headers = {
    accept: 'application/json',
    authorization: oneLinkConfig.apiKey,
    'content-type': 'application/json',
  };
  const agentOptions = {
    rejectUnauthorized: false,
  };
  const agent = new https.Agent(agentOptions);
  const body = getOneLinkReqBody(dlUrl, desktopUrl, title, description, mediaType, imageUrl);
  const opts = {
    method: 'POST',
    headers,
    httpsAgent: agent,
    data: body,
  };
  // logger.debug('Req options are ', opts);
  return opts;
}

async function getV3SeoMetaUrlStructureNew(documents) {
  try {
    const showList = await getShowDetailsMap(documents);
    // logger.debug(showList);
    const seoMetaObject = documents.map((obj) => {
      if (obj.meta) {
        if (obj.meta.showId) {
          return getSEOMetaObject(obj, showList[`${obj.meta.showId}`]);
        } if (obj.meta.series && obj.meta.series.showId) {
          return getSEOMetaObject(obj, showList[`${obj.meta.series.showId}`]);
        }
      }
      return getSEOMetaObject(obj);
    })[0];
    return seoMetaObject.urlStructureNew;
  } catch (e) {
    throw new Error(`Some error occured while fetching desktop redirect url ${e}.`);
  }
}

async function generateOneLink(data) {
  try {
    logger.info('Generating oneLink for ', data.id);
    const deepLinkUrl = getV3DeepLinkUrl(data);
    if (!deepLinkUrl) {
      return null;
    }
    let desktopRedirectUrl = await getV3SeoMetaUrlStructureNew([data]);
    if (!desktopRedirectUrl) {
      desktopRedirectUrl = oneLinkConfig.desktopFallbackUrl || '';
    }
    const image = getShareImageUrl(data.details);
    // logger.debug('Image url is ', image);
    const options = getOneLinkReqOptions(deepLinkUrl, desktopRedirectUrl, data.name, data.meta.synopsis.full, data.details.mediaType, image);
    const url = getOneLinkCreateUrl();
    const resp = await axios(url, options);
    if (resp.status === 200 && resp.data) {
      // logger.debug('Generated onelink url is ', resp.data);
      const thisUrl = resp.data;
      const time = parseInt(new Date().getTime() / 1000, 10);
      return { url: thisUrl, createdAt: time };
    }
    logger.debug('One link response code is ', resp.status);
    logger.debug('One link response body is ', resp.body);
    return null;
  } catch (e) {
    logger.error(`Error while generating onelink ${e}`);
    return null;
  }
}

async function createOneLinkApiBatch() {
  const batch = 1000;
  if (process.env.NODE_ENV !== 'jio') {
    logger.error('Cannot run the batch job in non-prod environment');
    process.exit();
  }
  logger.info('Processing batch of ', batch);
  try {
    const resp = await getLiveAssetsWithoutOneLink(batch);
    const ids = resp.map((res) => res.id);
    logger.debug('Processing for IDs: ', ids);
    // eslint-disable-next-line max-len
    const oneLinkUrlsMap = await resp.reduce(async (obj, res) => ({ ...await obj, [res.id]: await generateOneLink(res) }), {});
    resp.map((res) => {
      const { details } = res;
      const oneLinkObj = oneLinkUrlsMap[res.id];
      // console.log(oneLinkObj);
      if (oneLinkObj != null || oneLinkObj !== undefined) {
        details.oneLink = oneLinkObj;
        res.details = details;
      }
      return res;
    });
    logger.info('Bulk Updating in ES');
    while (resp.length) {
      const uploadBatch = resp.splice(0, 100);
      // eslint-disable-next-line no-await-in-loop
      await bulkUpdate(uploadBatch);
    }
    return 'Success';
  } catch (e) {
    throw new Error(`Error during batch processing ${e.message}`);
  }
}

module.exports = {
  createOneLinkApiBatch,
};

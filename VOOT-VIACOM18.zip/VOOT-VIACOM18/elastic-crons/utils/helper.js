function getNested(obj, ...args) {
  // eslint-disable-next-line no-shadow
  return args.reduce((obj, level) => obj && obj[level], obj);
}

function get(obj, nestedIndex, defaultValue) {
  const value = getNested(obj, ...nestedIndex.split('.'));
  if (typeof value === 'undefined') {
    return defaultValue;
    // eslint-disable-next-line no-else-return
  } else {
    return value;
  }
}

function sanitizeString(str, len = null) {
  const newString = str.replace(/[^a-z0-9áéíóúñü# .,_-]/gim, '').trim();
  if (!len) {
    return newString;
  }
  return newString.substring(0, len);
}

module.exports = {
  get,
  sanitizeString,
};

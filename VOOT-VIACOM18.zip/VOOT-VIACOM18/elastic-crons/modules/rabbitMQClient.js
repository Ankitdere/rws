const amqp = require('amqplib');
const log = require('logger-v18');

const { logger } = log;
let channel;
const exchangeName = 'topic-exchange';

(async () => {
  try {
    logger.log('Connecting rabbitmq');
    const connection = await amqp.connect(process.env.rabbitMqUrl); // TODO: store in secrets
    channel = await connection.createChannel();
    await channel.assertQueue(process.env.cascadeQueue);
    await channel.assertQueue(process.env.purgeQueue);
    await channel.assertExchange(exchangeName, 'topic', {});
    logger.log('Connected to queue ...');
  } catch (err) {
    logger.error('ERROR in rabbitmq', Object.keys(err).length ? JSON.stringify(err) : err);
  }
})();

async function sendMessage(queue, message) {
  const messageBuffer = Buffer.from(JSON.stringify({ message }));
  await channel.sendToQueue(queue, messageBuffer);
}

async function broadcastMessage(routingKey, message) {
  const messageBuffer = Buffer.from(JSON.stringify({ message }));
  await channel.publish(exchangeName, routingKey, messageBuffer, { expiration: '60000' });
}

module.exports = {
  sendMessage,
  broadcastMessage,
};

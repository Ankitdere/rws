/* eslint-disable no-unused-vars */
const { logger } = require('logger-v18');
const moment = require('moment');
const nodemailer = require('nodemailer');
const { vccTemplate } = require('../emailTemplates/voot-catalog-cron');
const { ftvcTemplate, ftvcErrorTemplate } = require('../emailTemplates/firetv-catalogue');

async function sendVootCatalogReport(fileLocation) {
  const date = moment().format('DD-MM-YYYY');
  const params = {
    Destination: {
      ToAddresses: process.env.vootCatalogReportReceiversTO.split(','),
      CcAddresses: process.env.vootCatalogReportReceiversCC.split(','),
    },
    Message: {
      Body: {
        Html: {
          Charset: 'UTF-8',
          Data: vccTemplate(fileLocation, date),
        },
      },
      Subject: {
        Charset: 'UTF-8',
        Data: `Voot Jio CMS Catalogue Export – ${date}`,
      },
    },
    Source: 'support@voot.com',
  };

  const transporter = nodemailer.createTransport({
    host: '10.166.163.68',
    port: 25,
    secure: false, // true for 465, false for other ports
  });

  const info = await transporter.sendMail({
    from: '"JioVoot Operations" <jiovoot.operations@ril.com>', // sender address
    to: process.env.vootCatalogReportReceiversCC, // list of receivers
    subject: params.Message.Subject.Data, // Subject line
    text: 'Plain text body', // plain text body
    html: params.Message.Body.Html.Data, // html body
  });

  logger.log('Message sent for voot catalog report: ', (info && info.messageId) || '');
}

async function sendAmazonFireTVCatalogueReport(fileLocation) {
  try {
    const date = moment().format('DD-MM-YYYY');
    const params = {
      Destination: {
        ToAddresses: process.env.amazonCatalogueReportReceiversTO.split(','),
        CcAddresses: process.env.amazonCatalogReportReceiversCC.split(','),
      },
      Message: {
        Body: {
          Html: {
            Charset: 'UTF-8',
            Data: ftvcTemplate(fileLocation, date),
          },
        },
        Subject: {
          Charset: 'UTF-8',
          Data: `Jio Cinema Amazon Catalogue Export – ${date}`,
        },
      },
      Source: 'support@voot.com',
    };

    const transporter = nodemailer.createTransport({
      host: 'smtpbp.falconide.com',
      port: 465,
      secure: true, // true for 465, false for other ports
      auth: {
        user: 'voot',
        pass: 'Vtselect@22',
      },
    });

    const info = await transporter.sendMail({
      from: '"JioVoot Operations" <voot-support@voot.com>', // sender address
      to: process.env.amazonCatalogReportReceiversCC, // list of receivers
      subject: params.Message.Subject.Data, // Subject line
      text: 'Plain text body', // plain text body
      html: params.Message.Body.Html.Data, // html body
    });

    logger.log('Message sent for amazon catalog report: ', (info && info.messageId) || '');
  } catch (error) {
    logger.error('Error in sending amazon catalogue report mail::', error);
  }
}

async function sendAmazonFireTVCatalogueErrorReport(errMessage) {
  try {
    const date = moment().format('DD-MM-YYYY');
    const params = {
      Destination: {
        ToAddresses: process.env.amazonCatalogueReportReceiversTO.split(','),
        CcAddresses: process.env.amazonCatalogReportReceiversCC.split(','),
      },
      Message: {
        Body: {
          Html: {
            Charset: 'UTF-8',
            Data: ftvcErrorTemplate(errMessage, date),
          },
        },
        Subject: {
          Charset: 'UTF-8',
          Data: `Voot Cinema Amazon Catalogue Export – ${date}`,
        },
      },
      Source: 'support@voot.com',
    };

    const transporter = nodemailer.createTransport({
      host: 'smtpbp.falconide.com',
      port: 465,
      secure: true, // true for 465, false for other ports
      auth: {
        user: 'voot',
        pass: 'Vtselect@22',
      },
    });

    const info = await transporter.sendMail({
      from: '"JioVoot Operations" <voot-support@voot.com>', // sender address
      to: process.env.amazonCatalogReportReceiversCC, // list of receivers
      subject: params.Message.Subject.Data, // Subject line
      text: 'Plain text body', // plain text body
      html: params.Message.Body.Html.Data, // html body
    });

    logger.log('Message sent for amazon catalog report: ', (info && info.messageId) || '');
  } catch (error) {
    logger.error('Error in sending amazon catalogue report mail::', error);
  }
}

async function sendShotsStatsEmail(emailBody, date) {
  const params = {
    Destination: {
      ToAddresses: process.env.shotsStatsEmailReceiversTO.split(','),
      CcAddresses: process.env.shotsStatsEmailReceiversCC.split(','),
    },
    Message: {
      Body: {
        Html: {
          Charset: 'UTF-8',
          Data: emailBody,
        },
      },
      Subject: {
        Charset: 'UTF-8',
        Data: `Voot Shots Daily Buzz – ${date}`,
      },
    },
    Source: 'support@voot.com',
  };

  const transporter = nodemailer.createTransport({
    host: '10.166.163.68',
    port: 25,
    secure: false, // true for 465, false for other ports
  });

  const info = await transporter.sendMail({
    from: '"JioVoot Operations" <jiovoot.operations@ril.com>', // sender address
    to: process.env.shotsStatsEmailReceiversCC, // list of receivers
    subject: params.Message.Subject.Data, // Subject line
    text: 'Plain text body', // plain text body
    html: params.Message.Body.Html.Data, // html body
  });

  logger.log('Message sent for voot shots stats: ', info.messageId);
}

async function invoke() {
  await sendVootCatalogReport('http://dummy/location');
}

module.exports = {
  sendVootCatalogReport,
  sendShotsStatsEmail,
  invoke,
  sendAmazonFireTVCatalogueReport,
  sendAmazonFireTVCatalogueErrorReport,
};

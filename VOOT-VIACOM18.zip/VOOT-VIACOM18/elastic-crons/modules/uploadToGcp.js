const { Storage } = require('@google-cloud/storage');
// eslint-disable-next-line import/no-extraneous-dependencies
const js2xmlparser = require('js2xmlparser');

const storage = new Storage({ keyFilename: `google-cloud-${process.env.envConfigKey}-key.json` });
const { logger } = require('logger-v18');

const uploadToGCP = async (fileName) => {
  // eslint-disable-next-line no-useless-catch
  try {
    const bucketName = process.env.gcpBucketName || 'partner-catalogue-dev';
    const path = process.env.gcpCatalogPath || 'amazon-catalogue';
    const response = await storage.bucket(bucketName).upload(fileName, { destination: `${path}/${fileName}` });
    logger.info('Successfully uploaded on GCP bucket');
    return response;
  } catch (error) {
    logger.error('Error in Upload GCP::-', error);
    throw error;
  }
};

async function listFiles(prefix, bucketName, maxResults = 20) {
  const options = {
    maxResults,
    prefix,
    delimiter: '/',
  };
  const [files] = await storage.bucket(bucketName).getFiles(options);
  return files.map((file) => ({ filename: file.name, createdDate: file.metadata.timeCreated }));
}

function getLatestFilePath(bucketFiles) {
  const latestFilePath = bucketFiles.reduce((r, a) => (r.createdDate > a.createdDate ? r : a));
  return latestFilePath.filename;
}

async function uploadFile(obj, key, bucketName, path) {
  const options = {
    resumable: false,
  };
  const resp = await storage.bucket(bucketName).file(`${path}/${key}`).save(JSON.stringify(obj), options);
  return resp;
}

async function uploadXML(root, obj, key, bucketName, path) {
  const xmlBuffer = js2xmlparser.parse(root, obj);
  // eslint-disable-next-line new-cap
  const resp = await storage.bucket(bucketName).file(`${path}/${key}`).save(new Buffer.from(xmlBuffer), { contentType: 'application/xml' });
  return resp;
}

module.exports = {
  uploadToGCP,
  listFiles,
  getLatestFilePath,
  uploadFile,
  uploadXML,
};

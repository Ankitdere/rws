const axios = require('axios');

const BASE_URL = process.env.recoApiUrl || 'https://shots-rec-stage.voot.com/v1';

async function updateDisabled(assetIds) {
  if (!Array.isArray(assetIds)) return;
  // eslint-disable-next-line no-param-reassign
  assetIds = assetIds.filter((id) => parseInt(id, 10));
  const resp = await axios.put(`${BASE_URL}/disable-assets`, assetIds);
  // eslint-disable-next-line consistent-return
  return resp.data;
}

module.exports = {
  updateDisabled,
};

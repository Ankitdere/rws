const AWS = require('aws-sdk');
const fs = require('fs');
const log = require('logger-v18');

const { logger } = log;

async function uploadCatalog(fileName, Bucket, Key) {
  try {
    AWS.config.loadFromPath(`./catalogS3Config-${process.env.envConfigKey}.json`);
    const s3 = new AWS.S3({ apiVersion: '2006-03-01' });
    logger.info(`uploading catalog to bucket bucket:${Bucket} key:${Key}  file:${fileName}`);
    const Body = fs.createReadStream(fileName);
    if (!Body || !Bucket || !Key) {
      return;
    }
    await s3.putObject({
      Bucket,
      Key,
      Body,
      ACL: 'bucket-owner-full-control',
    }).promise();
  } catch (error) {
    logger.error('Error in uploading S3 bucket', error);
  }
}

module.exports = {
  uploadCatalog,
};

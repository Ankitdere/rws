/* eslint-disable arrow-body-style */
/* eslint-disable arrow-parens */
const log = require('logger-v18');

const { logger } = log;

const CountType = {
  view: 1,
  search: 2,
  shows: 3,
};

function transformToElasticObj(type, asset) {
  if (type === CountType.view || type === CountType.shows) {
    return {
      id: asset.key,
      stats: {
        mpViewPopularity: asset.weightage,
      },
    };
  }
  if (type === CountType.search) {
    return {
      id: asset.key,
      stats: {
        mpSearchPopularity: asset.weightage,
      },
    };
  }
  return {};
}

function groupByMediaId(allData) {
  // groupby key[media id]
  // eslint-disable-next-line prefer-spread
  const combinedData = [].concat.apply([], allData);
  const result = Object.values(
    combinedData.reduce((acc, { key, weightage }) => {
      acc[key] = {
        key,
        weightage: (acc[key] ? acc[key].weightage : 0) + weightage,
      };
      return acc;
    }, {}),
  );
  return result;
}

function mergedShowData(data) {
  // group data by show id
  // eslint-disable-next-line prefer-spread
  const asset = [].concat.apply([], data);
  const result = Object.values(asset.reduce((acc, { key, value }) => {
    const key0 = key[0]; // this will become id;
    if (key0) {
      acc[key0] = {
        key: [key0],
        value: (acc[key0] ? acc[key0].value : 0) + value,
        episode: (acc[key0] ? acc[key0].episode : 0) + 1,
      };
    }
    return acc;
  }, {}));

  return result;
}

function getUnusedData(latestData, storedData) {
  const groupByMediaIdData = groupByMediaId(latestData);
  const lastViewCountData = [...storedData];
  // Find asset those does not exist, reset weightage to 0
  const removedAssetData = lastViewCountData
    // eslint-disable-next-line eqeqeq
    .filter(obj => !groupByMediaIdData.some(obj2 => obj.key == obj2.key))
    .map((asset) => {
      // eslint-disable-next-line no-param-reassign
      asset.weightage = 0;
      return asset;
    });
  logger.log(`unused asset found : ${removedAssetData.length}`);
  return groupByMediaIdData.concat(removedAssetData);
}

function weightageFormula(type, asset, day) {
  const { value, episode = 1 } = asset;
  if (type === CountType.view) return Math.round(value / day);
  if (type === CountType.search) return value;
  if (type === CountType.shows) return Math.round((value / episode) / day);
  return 0;
}

function normalizeData(type, data) {
  let normalizedData;
  if (type === CountType.shows) {
    normalizedData = data.map(d => mergedShowData(d));
  } else {
    normalizedData = [...data];
  }

  const resultData = normalizedData.map((assets, index) => assets.map((asset) => {
    return {
      key: asset.key[0],
      weightage: weightageFormula(type, asset, index + 1),
    };
  }));
  return resultData;
}
module.exports = {
  CountType,
  transformToElasticObj,
  groupByMediaId,
  getUnusedData,
  normalizeData,
};

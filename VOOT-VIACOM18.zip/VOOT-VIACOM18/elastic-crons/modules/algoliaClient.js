const algoliasearch = require('algoliasearch');
const { logger } = require('logger-v18');

const getClient = (() => {
  let index;
  return () => {
    if (!index) {
      logger.log('initializing algolia client');
      // algoliasearch modules reads the env values in its code internally, thus setting this works.
      // process.env.HTTP_PROXY = 'http://gcpprodproxy.jio.com:8080';
      // process.env.HTTPS_PROXY = 'http://gcpprodproxy.jio.com:8080';

      const client = algoliasearch(
        process.env.algoliaApplicationId,
        process.env.algoliaApiKey,
      );
      index = client.initIndex(process.env.algoliaIndex);

      // proxy is only needed for external calls and "client" is now initialized with proxy values, therefore, unset for rest of the code logic
      // process.env.HTTP_PROXY = '';
      // process.env.HTTPS_PROXY = '';
    }
    return index;
  };
})();

async function saveDocuments(documents) {
  if (!(typeof documents === 'object' && documents.length > 0)) {
    logger.log('issue with processed docs, not saving');
    return;
  }
  // logger.log('savings docs in algolia');
  await getClient().saveObjects(documents);
}

async function deleteDocuments(assetIds) {
  if (!assetIds.length) {
    logger.log('no docs to delete, exiting');
    return;
  }

  logger.log('deleting docs in algolia');
  await getClient().deleteObjects(assetIds);
}

async function partialUpdate(documents) {
  if (!(typeof documents === 'object' && documents.length > 0)) {
    logger.log('no docs to update, exiting');
    return;
  }

  logger.log('updating algolia');
  // The second parameter prevents creation of objects that dont exist
  await getClient().partialUpdateObjects(documents, {
    createIfNotExists: false,
  });
}

module.exports = {
  saveDocuments,
  deleteDocuments,
  partialUpdate,
};

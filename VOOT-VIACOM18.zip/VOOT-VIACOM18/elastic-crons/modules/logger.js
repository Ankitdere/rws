const log = require('logger-v18');

log.init({
  json: JSON.parse(process.env.logJson), service: 'v3sitemap', tags: ['crons'], level: process.env.logLevel,
});

const { logger } = log;

module.exports = logger;

const { logger } = require('logger-v18');
const rabbitMQClient = require('./rabbitMQClient');

async function purge(urls) {
  try {
    await rabbitMQClient.sendMessage(process.env.purgeQueue, {
      type: 'purge',
      objects: urls,
    });

    logger.info(`URL's ${urls} added to queue for purging.`);
  } catch (e) {
    logger.error('ERROR in cache purge - ', e);
  }
}

async function purgeByCacheTag(cacheTags) {
  try {
    await rabbitMQClient.sendMessage(process.env.purgeQueue, {
      type: 'tag-purge',
      objects: cacheTags,
    });

    logger.info(`cache tags ${cacheTags} added to queue for purging.`);
  } catch (e) {
    logger.error('ERROR in cache purge - ', e);
  }
}

module.exports = { purge, purgeByCacheTag };

const log = require('logger-v18');
const fs = require('fs');
const catalogueS3Client = require('./catalogueS3Client');

const { logger } = log;

async function uploadCatalog(fileName, Bucket, Key) {
  try {
    logger.info(`uploading catalog to local bucket:${Bucket} key:${Key} file:${fileName}`);
    const Body = fs.createReadStream(fileName);
    if (!Body || !Bucket || !Key) {
      return;
    }
    await catalogueS3Client.uploadCatalog(fileName, Bucket, Key);
  } catch (error) {
    logger.error('Error in uploading catalog', error);
  }
}

module.exports = {
  uploadCatalog,
};

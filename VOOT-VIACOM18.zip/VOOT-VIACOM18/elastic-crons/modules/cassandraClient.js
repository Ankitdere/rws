const cassandra = require('cassandra-driver');
const log = require('logger-v18');

const { logger } = log;
const { PlainTextAuthProvider } = cassandra.auth;

const client = new cassandra.Client({
  contactPoints: [process.env.cassandraIP],
  localDataCenter: process.env.cassandraDataCenter,
  keyspace: process.env.cassandraKeySpace,
  authProvider: new PlainTextAuthProvider(process.env.cassandraUsername, process.env.cassandraPass), // TODO: put inside secrets
});

async function getRecords(date) {
  logger.info(`Info - Fetching records of ${date} from cassandra`);
  const INDEX = process.env.dynamoQueryIndex;
  const PLAYBACK_TABLE = process.env.playback_db_table;
  const query = `SELECT * FROM ${PLAYBACK_TABLE} WHERE id_date=?;`;
  const options = [`${INDEX}_${date}`];
  try {
    let records = await client.execute(query, options);
    records = records.rows || [];
    logger.log('Responsed with ', records);
    return records;
  } catch (error) {
    throw new Error('ERROR while fetching the records : ', error);
  }
}

module.exports = {
  getRecords,
};

const log = require('logger-v18');
const moment = require('moment');
const slugify = require('slugify');

const { logger } = log;

function getSlug(name) {
  return slugify(name, {
    replacement: '-', // replace spaces with replacement character, defaults to `-`
    remove: /[*+~.()'"!:@]/g, // remove characters that match regex, defaults to `undefined`
    lower: true, // convert to lower case, defaults to `false`
    strict: true, // strip special characters except replacement, defaults to `false`
  });
}

function getDeepLink(obj, isPlayback) {
  const details = obj.details || {};
  const meta = obj.meta || {};
  const vootBaseUrl = 'jiovootviacom18://jiovoot/';
  switch (details.mediaType) {
    case 'SHOW':
      return `${vootBaseUrl}details/show/${obj.id}`;
    case 'EPISODE':
    case 'CAC':
    case 'LIVECHANNEL':
      return `${vootBaseUrl}playback/${obj.id}`;
    case 'MOVIE':
      return isPlayback ? `${vootBaseUrl}playback/${obj.id}` : `${vootBaseUrl}details/movie/${obj.id}`;
    case 'CHANNEL':
      return `${vootBaseUrl}details/channel/${obj.id}`;
    case 'SERIES':
      return `${vootBaseUrl}details/show/${meta.showId}/season/${obj.id}`;
    default:
      return vootBaseUrl;
  }
}

function getLocUrl(obj, info, asset = {}) {
  const slug = (asset && asset.slug) ? asset.slug : '';
  switch (obj.details.mediaType) {
    case 'MOVIE':
      // eslint-disable-next-line max-len
      return info ? `${process.env.jioCinemaUrl}/movies/${getSlug(obj.name)}/${obj.id}` : `${process.env.jioCinemaUrl}/movies/${getSlug(obj.name)}/${obj.id}`;
    default:
      return slug;
  }
}

function getSiteMapUrl(obj) {
  switch (obj.details.mediaType) {
    case 'SHOW':
      return `${process.env.jioCinemaUrl}/sitemap/shows-${obj.id}.xml`;
    default:
      return '';
  }
}

function getISOString(timestamp) {
  try {
    const time = parseInt(timestamp, 10) * 1000;
    return new Date(time).toISOString();
  } catch (err) {
    logger.error(`timestamp invalid:${timestamp}`);
    return new Date().toISOString();
  }
}

function generateUrlNode(obj, priority, changefreq, current = false, info = false, asset = {}) {
  const loc = getLocUrl(obj, info, asset).toLowerCase();
  const lastmod = current ? new Date().toISOString() : getISOString(obj.revised);
  return {
    loc, lastmod, priority, changefreq,
  };
}

function getImagesUrl(details, asset = {}) {
  if (asset.image16x9) {
    return `${process.env.imageBaseUrl}/${asset.image16x9}`;
  }
  return '';
}

function generateVideoNode(obj, asset = {}) {
  const expirydate = getISOString(obj.availability.available.IN.to);
  const publicationdate = getISOString(obj.availability.available.IN.from);
  const duration = asset.duration || 0;
  const title = `<![CDATA[${obj.meta.title.full}]]>`;
  const description = `<![CDATA[${obj.meta.synopsis.full}]]>`;
  const url = getImagesUrl(obj.details, asset);
  const loc = getLocUrl(obj, undefined, asset).toLowerCase();
  const video = {
    'video:thumbnail_loc': url,
    'video:title': title,
    'video:description': description,
    'video:duration': duration,
    'video:expiration_date': expirydate,
    'video:publication_date': publicationdate,
    'video:player_loc': {
      '@': {
        allow_embedd: 'yes',
        autoplay: 'ap=1',
      },
      '#': `https://www.voot.com/mrss/vootplayer/index.html?mId=${obj.id}`,
    },
  };
  return {
    loc,
    'video:video': video,
  };
}

function generateSiteMapNode(obj) {
  const loc = getSiteMapUrl(obj).toLowerCase();
  const lastmod = getISOString(obj.revised);
  return { loc, lastmod };
}

function filterNonRequiredValues(array) {
  return array.filter((item) => !['N/A', 'NA'].includes(item)).filter(Boolean);
}

function generateFeedNode(obj, type, isPlayback, asset = {}) {
  const details = obj.details || {};
  const meta = obj.meta || {};
  const availabilityEnds = getISOString(obj.availability.available.IN.to);
  const availabilityStarts = getISOString(obj.availability.available.IN.from);
  const duration = asset.duration || 0;
  const title = obj.meta.title.full;
  if (!title) {
    return false;
  }
  const loc = getLocUrl(obj, undefined, asset).toLowerCase();
  const id = `${process.env.jioCinemaUrl}/${obj.id}`;
  const deeplink = getDeepLink(obj, isPlayback);
  const androidLink = deeplink.replace(':/', '');
  const languages = obj.meta.languages || [''];
  const offer = obj.details && ['PREMIUM', 'PREMIER'].includes(obj.details.marketType) ? 'subscription' : 'free';
  const actor = (meta.contributors && filterNonRequiredValues(meta.contributors)) || [];
  const director = (meta.movieDirector && filterNonRequiredValues(meta.movieDirector)) || [];

  const resultObj = {
    '@context': ['http://schema.org', { '@language': 'en' }],
    '@type': type,
    '@id': id,
    url: loc,
    name: title,
    potentialAction: [
      {
        '@type': 'WatchAction',
        target: [
          {
            '@type': 'EntryPoint',
            urlTemplate: `${loc}?utm_source=google_web&utm_medium=watchaction`,
            actionPlatform: [
              'http://schema.org/DesktopWebPlatform',
              'http://schema.org/MobileWebPlatform',
              'http://schema.googleapis.com/GoogleVideoCast',
              'http://schema.org/IOSPlatform',
            ],
          },
          {
            '@type': 'EntryPoint',
            urlTemplate: `android-app://com.tv.v18.viola/${androidLink}?utm_source=google_web&utm_medium=watchaction`,
            actionPlatform: [
              'http://schema.org/AndroidPlatform',
            ],
          },
        ],
        actionAccessibilityRequirement: {
          '@type': 'ActionAccessSpecification',
          availabilityStarts,
          availabilityEnds,
          category: offer,
          eligibleRegion: {
            '@type': 'Country',
            name: 'IN',
          },
        },
      },
    ],
    releasedEvent: {
      '@type': 'PublicationEvent',
      location: {
        '@type': 'Country',
        name: 'IN',
      },
      publishedBy: 'Organization',
    },
    inLanguage: languages[0],
    genre: meta.genres || '',
    keywords: meta.keywords || '',
    description: meta.synopsis ? meta.synopsis.full : '',
    duration: duration ? moment.duration(duration, 'seconds').toISOString() : undefined,
    actor,
    director,
    image: {
      '@context': 'http://schema.org',
      '@type': 'ImageObject',
      contentUrl: getImagesUrl(details, asset),
      additionalProperty: [
        {
          '@type': 'PropertyValue',
          name: 'contentAttributes',
          value: ['logo', 'poster', 'hasTitle', 'noLogo', 'noCopyright', 'noMatte', 'smallFormat', 'largeFormat'],
        },
      ],
    },
  };

  const androidTVObj = {
    '@type': 'EntryPoint',
    urlTemplate: `android-app://com.viacom18.tv.voot/${androidLink}?utm_source=google_web&utm_medium=watchaction`,
    actionPlatform: [
      'http://schema.org/AndroidTVPlatform',
    ],
  };

  if (offer === 'subscription') resultObj.potentialAction[0].target.push(androidTVObj);
  else if (offer === 'free') {
    const noLoginRequiredObj = {
      '@type': 'WatchAction',
      target: [androidTVObj],
      actionAccessibilityRequirement: {
        '@type': 'ActionAccessSpecification',
        availabilityStarts,
        availabilityEnds,
        category: 'nologinrequired',
        eligibleRegion: {
          '@type': 'Country',
          name: 'IN',
        },
      },
    };
    resultObj.potentialAction.push(noLoginRequiredObj);
  }
  return resultObj;
}

function generateMovieFeedNode(obj, asset = {}) {
  // eslint-disable-next-line no-undef
  const feedNode = generateFeedNode(obj, 'Movie', isPlayback = true, asset);
  return feedNode;
}

function generateShowFeedNode(obj, asset = {}) {
  return generateFeedNode(obj, 'TVSeries', asset);
}

function generateEpisodeFeedNode(obj, showDetail, asset = {}, showAsset = {}) {
  const resp = generateFeedNode(obj, 'TVEpisode', asset);
  if (!resp) {
    return false;
  }
  const meta = obj.meta || {};
  const series = meta.series || {};
  if (!series.episodeNo) {
    return false;
  }
  const showUrl = getLocUrl(showDetail, undefined, showAsset);
  // delete resp.duration;
  return {
    ...resp,
    episodeNumber: series.episodeNo,
    partOfSeason: {
      '@type': 'TVSeason',
      '@id': `${process.env.jioCinemaUrl}/${showDetail.id}?season${series.season}`,
      seasonNumber: parseInt(series.season, 10),
    },
    partOfSeries: {
      '@type': 'TVSeries',
      '@id': showUrl,
      name: showDetail.name,
    },
  };
}

module.exports = {
  generateUrlNode,
  generateSiteMapNode,
  generateVideoNode,
  generateMovieFeedNode,
  generateShowFeedNode,
  generateEpisodeFeedNode,
};

/* eslint-disable import/no-extraneous-dependencies */
/* eslint-disable no-await-in-loop */
/* eslint-disable consistent-return */
/* eslint-disable no-underscore-dangle */
const { Client } = require('@elastic/elasticsearch');
const { logger } = require('logger-v18');
const { transform } = require('../samsung/transform/samsungTransform');
const common = require('../v3ResponseTypes').getResponseType('common');

const getClient = (() => {
  let client1;
  return () => {
    if (!client1) {
      client1 = new Client({
        node: process.env.elasticSearchHost,
        auth: {
          username: process.env.esAuthUsername,
          password: process.env.esAuthPassword,
        },
        requestTimeout: 5000,
      });
    }
    return client1;
  };
})();

const MAX_DOCUMENTS = 10000;
const SEARCH_SIZE = 1000;

const myIndex = process.env.elasticSearchIndex;
const liveAssetsIndex = process.env.elasticLiveAssetsIndex;
const updateIndex = process.env.elasticSearchUpdateIndex; // global_v4
const epgIndex = process.env.elasticSearchEpgIndex;
const index = process.env.elasticSearchIndex;
async function init() {
  // ping is giving error in gcp
  return true;
  // const res = await getClient().ping({
  //   requestTimeout: 5000,
  // });
  // if (!res) {
  //   logger.error('error in connecting to elasticsearch');
  //   throw new Error('error in connecting to elasticsearch');
  // }
  // logger.info(`connected to elasticsearch response:${res}`);
}

async function getObjectByIdsWithSource(indexName, ids, source, nonFiltered) {
  const assetIds = ids.filter((a) => a);
  const res = await getClient().search({
    index: indexName,
    size: 2000,
    body: {
      query: {
        ids: {
          values: assetIds,
        },
      },
      _source: source,
    },
  });

  return nonFiltered ? res : res.hits.hits.map((obj) => obj._source);
}

async function bulkUpdate(objects, touch = true) {
  if (!(typeof updateIndex === 'string' && objects.length > 0)) {
    return;
  }
  logger.info(
    `bulk updating in to elasticsearch index:${myIndex} length:${objects.length}`,
  );
  const revised = parseInt(new Date().getTime() / 1000, 10);
  const body = objects.reduce((acc, object) => {
    acc.push({
      update: {
        _index: updateIndex,
        _id: `${object.id}`,
      },
    });

    if (touch) {
      acc.push({
        doc: { ...object, id: parseInt(object.id, 10), revised },
      });
    } else {
      acc.push({
        doc: { ...object, id: parseInt(object.id, 10) },
      });
    }

    return acc;
  }, []);
  const res = await getClient().bulk({ body });
  logger.info(
    `bulk updating in to elasticsearch response took:${res.took} errors:${res.errors} items.length:${res.items.length}`,
  );
  if (res.errors) {
    logger.warn(
      `bulk updating in to elasticsearch response took:${res.took} errors:${res.errors} items.length:${res.items.length}`,
    );
    if (res.items) {
      res.items.forEach((item) => {
        if (item.update.error) {
          logger.error(JSON.stringify(item));
        }
      });
    }
  }
}

async function bulkInsertEPG(objects) {
  if (!(typeof epgIndex === 'string' && objects.length > 0)) {
    return;
  }
  logger.info(
    `bulk indexing in to elasticsearch index:${myIndex} length:${objects.length}`,
  );
  const revised = parseInt(new Date().getTime() / 1000, 10);
  const body = objects.reduce((acc, object) => {
    acc.push({
      index: {
        _index: epgIndex,
        _type: 'epg',
      },
    });
    acc.push({ ...object, revised });
    return acc;
  }, []);
  const res = await getClient().bulk({ body });
  logger.info(
    `bulk indexing in to elasticsearch response took:${res.took} errors:${res.errors} items.length:${res.items.length}`,
  );
  if (res.errors) {
    logger.warn(
      `bulk indexing in to elasticsearch response took:${res.took} errors:${res.errors} items.length:${res.items.length}`,
    );
    if (res.items) {
      res.items.forEach((item) => {
        if (item.update.error) {
          logger.error(JSON.stringify(item));
        }
      });
    }
  }
}

async function filterSeriesIds(ids) {
  let res = await getClient().search({
    index: myIndex,
    size: SEARCH_SIZE,
    scroll: '1m',
    body: {
      query: {
        bool: {
          must: [
            {
              ids: {
                values: ids,
              },
            },
            {
              match: {
                'details.mediaType.keyword': 'SERIES',
              },
            },
          ],
        },
      },
      _source: 'meta.showId',
      sort: [{ id: { order: 'asc' } }],
    },
  });
  let AllDocs = res.hits.hits;
  let keepGoing = res.hits.hits.length === SEARCH_SIZE;
  while (keepGoing) {
    logger.log(`fetched ${AllDocs.length}`);
    // eslint-disable-next-line no-await-in-loop
    res = await getClient().scroll({
      // eslint-disable-next-line no-underscore-dangle
      scroll_id: res._scroll_id,
      scroll: '1m',
    });
    AllDocs = AllDocs.concat(res.hits.hits);
    keepGoing = res.hits.hits.length === SEARCH_SIZE && AllDocs.length < MAX_DOCUMENTS;
  }
  return AllDocs;
}

// Modified to fetch assets from country_IN_V4 - VK
// This is to fix the issue of assets appearing before startDate in Algolia.
async function getUpdatedNonKidsDocuments(fromTime, toTime) {
  if (!(typeof fromTime === 'number' && typeof toTime === 'number')) {
    return [];
  }
  logger.info(
    `getUpdatedNonKidsDocuments index:${liveAssetsIndex} fromTime:${fromTime} toTime:${toTime}`,
  );
  let res = await getClient().search({
    index: liveAssetsIndex,
    size: SEARCH_SIZE,
    scroll: '1m',
    body: {
      query: {
        bool: {
          must_not: [
            {
              match: {
                'meta.genres.keyword': 'Kids',
              },
            },
            {
              match: {
                'meta.isSearchable': false,
              },
            },
            {
              bool: {
                must_not: [
                  {
                    terms: {
                      'details.mediaType.keyword': [
                        'LIVECHANNEL',
                        'SHOW',
                        'CAC',
                        'MOVIE',
                        'EPISODE',
                      ],
                    },
                  },
                ],
              },
            },
          ],
          filter: {
            range: {
              revised: {
                gt: `${fromTime}`,
                lte: `${toTime}`,
              },
            },
          },
        },
      },
      sort: [{ revised: { order: 'asc' } }],
    },
  });
  let AllDocs = res.hits.hits;
  let keepGoing = res.hits.hits.length === SEARCH_SIZE;
  while (keepGoing) {
    logger.log(`fetched ${AllDocs.length}`);
    // eslint-disable-next-line no-await-in-loop
    res = await getClient().scroll({
      // eslint-disable-next-line no-underscore-dangle
      scroll_id: res._scroll_id,
      scroll: '1m',
    });
    AllDocs = AllDocs.concat(res.hits.hits);
    keepGoing = res.hits.hits.length === SEARCH_SIZE && AllDocs.length < MAX_DOCUMENTS;
  }
  return AllDocs.map(({ _source }) => _source);
}

/*
Fetch assets which just got published - startDate fix - VK

Index: country_IN_V4 (asset is already live, so it will be available in this index)
Condition: (fromTime < startDate <= toTime) && (endDate > toTime)
Description: The startDate condition only picks assets which got published in the last
interval. The endDate condition excludes assets which are also now unpublished.
*/
async function getRecentlyPublishedNonKidsDocuments(fromTime, toTime) {
  if (!(typeof fromTime === 'number' && typeof toTime === 'number')) {
    return [];
  }
  logger.info(
    `getRecentlyPublishedNonKidsDocuments index:${liveAssetsIndex} fromTime:${fromTime} toTime:${toTime}`,
  );
  let res = await getClient().search({
    index: liveAssetsIndex,
    size: SEARCH_SIZE,
    scroll: '1m',
    body: {
      query: {
        bool: {
          must_not: [
            {
              match: {
                'meta.genres.keyword': 'Kids',
              },
            },
            {
              match: {
                'meta.isSearchable': false,
              },
            },
            {
              bool: {
                must_not: [
                  {
                    terms: {
                      'details.mediaType.keyword': [
                        'LIVECHANNEL',
                        'SHOW',
                        'CAC',
                        'MOVIE',
                        'EPISODE',
                      ],
                    },
                  },
                ],
              },
            },
          ],
          filter: [
            {
              range: {
                'availability.available.IN.from': {
                  gt: `${fromTime}`,
                  lte: `${toTime}`,
                },
              },
            },
            {
              range: {
                'availability.available.IN.to': {
                  gt: `${toTime}`,
                },
              },
            },
          ],
        },
      },
      sort: [{ revised: { order: 'asc' } }],
    },
  });
  let AllDocs = res.hits.hits;
  let keepGoing = res.hits.hits.length === SEARCH_SIZE;
  while (keepGoing) {
    logger.log(`fetched ${AllDocs.length}`);
    // eslint-disable-next-line no-await-in-loop
    res = await getClient().scroll({
      // eslint-disable-next-line no-underscore-dangle
      scroll_id: res._scroll_id,
      scroll: '1m',
    });
    AllDocs = AllDocs.concat(res.hits.hits);
    keepGoing = res.hits.hits.length === SEARCH_SIZE && AllDocs.length < MAX_DOCUMENTS;
  }
  return AllDocs.map(({ _source }) => _source);
}

async function getUpdatedNonKidsDocumentsForRec(fromTime, toTime) {
  if (!(typeof fromTime === 'number' && typeof toTime === 'number')) {
    return [];
  }
  logger.info(
    `getUpdatedNonKidsDocuments index:${myIndex} fromTime:${fromTime} toTime:${toTime}`,
  );
  let res = await getClient().search({
    index: myIndex,
    size: SEARCH_SIZE,
    scroll: '1m',
    body: {
      query: {
        bool: {
          must_not: [
            {
              match: {
                'meta.genres.keyword': 'Kids',
              },
            },
            {
              match: {
                'meta.isRecommended': false,
              },
            },
            {
              bool: {
                must_not: [
                  {
                    match: {
                      'details.mediaType.keyword': 'LIVECHANNEL',
                    },
                  },
                  {
                    match: {
                      'details.mediaType.keyword': 'SHOW',
                    },
                  },
                  {
                    match: {
                      'details.mediaType.keyword': 'CAC',
                    },
                  },
                  {
                    match: {
                      'details.mediaType.keyword': 'MOVIE',
                    },
                  },
                  {
                    match: {
                      'details.mediaType.keyword': 'EPISODE',
                    },
                  },
                  {
                    match: {
                      'details.mediaType.keyword': 'SERIES',
                    },
                  },
                  {
                    match: {
                      'details.mediaType.keyword': 'SHOTS',
                    },
                  },
                ],
              },
            },
          ],
          filter: {
            range: {
              revised: {
                gt: `${fromTime}`,
                lte: `${toTime}`,
              },
            },
          },
        },
      },
      sort: [{ revised: { order: 'asc' } }],
    },
  });
  let AllDocs = res.hits.hits;
  let keepGoing = res.hits.hits.length === SEARCH_SIZE;
  while (keepGoing) {
    logger.log(`fetched ${AllDocs.length}`);
    // eslint-disable-next-line no-await-in-loop
    res = await getClient().scroll({
      // eslint-disable-next-line no-underscore-dangle
      scroll_id: res._scroll_id,
      scroll: '1m',
    });
    AllDocs = AllDocs.concat(res.hits.hits);
    keepGoing = res.hits.hits.length === SEARCH_SIZE && AllDocs.length < MAX_DOCUMENTS;
  }
  return AllDocs.map(({ _source }) => _source);
}

async function getDisabledAssetsInRange(fromTime, toTime) {
  if (!(typeof fromTime === 'number' && typeof toTime === 'number')) {
    return [];
  }
  logger.info(
    `getDisabledAssetsInRange index:${updateIndex} fromTime:${fromTime} toTime:${toTime}`,
  );
  let res = await getClient().search({
    index: updateIndex,
    size: SEARCH_SIZE,
    scroll: '1m',
    _source: ['id', 'revised'],
    body: {
      query: {
        bool: {
          must: [
            { match: { disabled: true } },
            {
              bool: {
                should: [
                  { match: { 'details.mediaType.keyword': 'LIVECHANNEL' } },
                  { match: { 'details.mediaType.keyword': 'SHOW' } },
                  { match: { 'details.mediaType.keyword': 'CAC' } },
                  { match: { 'details.mediaType.keyword': 'MOVIE' } },
                  { match: { 'details.mediaType.keyword': 'EPISODE' } },
                ],
              },
            },
          ],
          filter: {
            range: {
              revised: {
                gt: `${fromTime}`,
                lte: `${toTime}`,
              },
            },
          },
        },
      },
      sort: [{ revised: { order: 'asc' } }],
    },
  });
  let AllDocs = res.hits.hits;
  let keepGoing = res.hits.hits.length === SEARCH_SIZE;
  while (keepGoing) {
    logger.log(`fetched ${AllDocs.length}`);
    // eslint-disable-next-line no-await-in-loop
    res = await getClient().scroll({
      // eslint-disable-next-line no-underscore-dangle
      scroll_id: res._scroll_id,
      scroll: '1m',
    });
    AllDocs = AllDocs.concat(res.hits.hits);
    keepGoing = res.hits.hits.length === SEARCH_SIZE && AllDocs.length < MAX_DOCUMENTS;
  }
  return AllDocs.map(({ _source }) => _source);
}

/*
Fetch assets whose availability was changed to a past/future startDate - VK

Index: global_v4
Condition: (fromTime < revised <= toTime) && (startDate > toTime || endDate < toTime)
Description: The revised condition only picks assets which were updated in the last
interval. The startDate and endDate conditions only pick assets which were either pushed
to a future start date, or were set to a past end date. In both cases, the asset needs
to be deleted from Algolia.
*/
async function getAvailabilityChangedAssetsInRange(fromTime, toTime) {
  if (!(typeof fromTime === 'number' && typeof toTime === 'number')) {
    return [];
  }
  logger.info(
    `getAvailabilityChangedAssetsInRange index:${updateIndex} fromTime:${fromTime} toTime:${toTime}`,
  );
  let res = await getClient().search({
    index: updateIndex,
    size: SEARCH_SIZE,
    scroll: '1m',
    _source: ['id', 'revised'],
    body: {
      query: {
        bool: {
          must: [
            {
              bool: {
                should: [
                  { match: { 'details.mediaType.keyword': 'LIVECHANNEL' } },
                  { match: { 'details.mediaType.keyword': 'SHOW' } },
                  { match: { 'details.mediaType.keyword': 'CAC' } },
                  { match: { 'details.mediaType.keyword': 'MOVIE' } },
                  { match: { 'details.mediaType.keyword': 'EPISODE' } },
                ],
              },
            },
            {
              range: {
                revised: {
                  gt: `${fromTime}`,
                  lte: `${toTime}`,
                },
              },
            },
            {
              bool: {
                minimum_should_match: 1,
                should: [
                  {
                    range: {
                      'availability.available.IN.from': {
                        gt: `${toTime}`,
                      },
                    },
                  },
                  {
                    range: {
                      'availability.available.IN.to': {
                        lt: `${toTime}`,
                      },
                    },
                  },
                ],
              },
            },
          ],
        },
      },
      sort: [{ revised: { order: 'asc' } }],
    },
  });
  let AllDocs = res.hits.hits;
  let keepGoing = res.hits.hits.length === SEARCH_SIZE;
  while (keepGoing) {
    logger.log(`fetched ${AllDocs.length}`);
    // eslint-disable-next-line no-await-in-loop
    res = await getClient().scroll({
      // eslint-disable-next-line no-underscore-dangle
      scroll_id: res._scroll_id,
      scroll: '1m',
    });
    AllDocs = AllDocs.concat(res.hits.hits);
    keepGoing = res.hits.hits.length === SEARCH_SIZE && AllDocs.length < MAX_DOCUMENTS;
  }
  return AllDocs.map(({ _source }) => _source);
}

/*
Fetch assets whose endDate has passed - VK

Index: global_v4
Condition: `${fromTime}` < endDate <= toTime
Description: The condition only picks assets whose endDate was passed in the last
interval.
*/
async function getAssetsBeyondEndDate(fromTime, toTime) {
  if (!(typeof fromTime === 'number' && typeof toTime === 'number')) {
    return [];
  }
  logger.info(
    `getAssetsBeyondEndDate index:${updateIndex} fromTime:${fromTime} toTime:${toTime}`,
  );
  let res = await getClient().search({
    index: updateIndex,
    size: SEARCH_SIZE,
    scroll: '1m',
    _source: ['id', 'revised'],
    body: {
      query: {
        bool: {
          must: [
            {
              bool: {
                should: [
                  { match: { 'details.mediaType.keyword': 'LIVECHANNEL' } },
                  { match: { 'details.mediaType.keyword': 'SHOW' } },
                  { match: { 'details.mediaType.keyword': 'CAC' } },
                  { match: { 'details.mediaType.keyword': 'MOVIE' } },
                  { match: { 'details.mediaType.keyword': 'EPISODE' } },
                ],
              },
            },
            {
              range: {
                'availability.available.IN.to': {
                  gt: `${fromTime}`,
                  lte: `${toTime}`,
                },
              },
            },
          ],
        },
      },
      sort: [{ revised: { order: 'asc' } }],
    },
  });
  let AllDocs = res.hits.hits;
  let keepGoing = res.hits.hits.length === SEARCH_SIZE;
  while (keepGoing) {
    logger.log(`fetched ${AllDocs.length}`);
    // eslint-disable-next-line no-await-in-loop
    res = await getClient().scroll({
      // eslint-disable-next-line no-underscore-dangle
      scroll_id: res._scroll_id,
      scroll: '1m',
    });
    AllDocs = AllDocs.concat(res.hits.hits);
    keepGoing = res.hits.hits.length === SEARCH_SIZE && AllDocs.length < MAX_DOCUMENTS;
  }
  return AllDocs.map(({ _source }) => _source);
}

async function getObjectByIds(ids = []) {
  const res = await getClient().search({
    index: 'global_v4',
    size: 2000,
    body: {
      query: {
        ids: {
          values: ids,
        },
      },
    },
  });
  return res.hits.hits.map((obj) => obj._source);
}

function getShowIds(assets = []) {
  const ids = assets.reduce((acc, obj) => {
    if (obj.meta) {
      if (obj.meta.showId) {
        acc.push(`${obj.meta.showId}`);
      } else if (obj.meta.series && obj.meta.series.showId) {
        acc.push(`${obj.meta.series.showId}`);
      }
    }
    return acc;
  }, []);
  return [...new Set(ids)];
}

async function getShowDetailsMap(assets = []) {
  const showIds = getShowIds(assets);
  if (!showIds.length) {
    return {};
  }
  const shows = await getObjectByIds(showIds);
  if (!shows || !shows.length) {
    return {};
  }
  return shows.reduce((acc, obj) => ({ ...acc, [`${obj.id}`]: obj }), {});
}

async function updateDisableAssets(assetids = [], disable = false) {
  if (!Array.isArray(assetids) || assetids.length < 1) {
    return;
  }
  const revised = parseInt(new Date().getTime() / 1000, 10);
  const params = {
    index: 'global_v4',
    body: {
      query: { ids: { values: assetids } },
      script: {
        inline: `ctx._source.disabled = ${disable}; ctx._source.revised = ${revised};`,
      },
    },
  };
  const resp = await getClient().updateByQuery(params);
  return resp;
}

async function getPartnerAssets(ids = []) {
  const res = await getClient().search({
    index: 'global_v4',
    _source: ['id', 'details.mediaType', 'meta.type', 'details.marketType', 'meta.title.full', 'meta.genres', 'meta.SBU',
      'meta.series.name', 'meta.series.season', 'meta.showName', 'disabled'],
    size: 2000,
    body: {
      query: {
        ids: {
          values: ids,
        },
      },
    },
  });
  if (res.hits.hits) {
    return res.hits.hits.map((obj) => obj._source);
  }
  return [];
}

async function getFullCatalogDump(getDataFromElasticClient) {
  let res = await getClient().search({
    index: updateIndex,
    size: 1000,
    scroll: '1m',
    body: {
      _source: {
        includes: ['telecasted', 'ingested', 'created', 'meta.*', 'name', 'details.jioMedia', 'details.image', 'details.file', 'details.externalId',
          'details.mediaType', 'details.marketType', 'details.duration', 'revised', 'updated', 'slug', 'id', 'disabled', 'availability.available.IN',
          'firstSyncedAt'],
        excludes: ['meta.scenes'],
      },
      query: {
        terms: {
          'details.mediaType.keyword': ['CAC', 'EPISODE', 'MOVIE', 'SHOW', 'SERIES', 'LIVECHANNEL', 'PCCHANNEL', 'SHOTS'],
        },
      },
    },
    sort: ['_doc'],
  });

  if (res.errors) {
    logger.error(
      `getFullCatalogDump elasticsearch response took:${res.took} errors:${res.errors} items.length:${res.items.length}`,
    );
    if (res.items) {
      res.items.forEach((item) => {
        logger.warn(item.index.error);
      });
    }
    throw new Error(res.errors);
  }

  let total = 0;
  let dataDump = res.hits.hits;
  dataDump = dataDump.map(({ _source }) => _source);
  await getDataFromElasticClient(dataDump);
  total += dataDump.length;

  let isLastBatch = false;
  while (dataDump.length === 1000) {
    res = await getClient().scroll({
      scroll_id: res._scroll_id,
      scroll: '1m',
    });
    dataDump = res.hits.hits;
    dataDump = dataDump.map(({ _source }) => _source);
    if (dataDump.length < 1000) {
      isLastBatch = true;
      logger.info('Last batch of data ', isLastBatch);
      logger.info('Length of last batch of data - ', dataDump.length);
    }
    total += dataDump.length;
    await getDataFromElasticClient(dataDump, total, isLastBatch);
  }
  logger.info('Elasticsearch scroll complete');
  logger.info(`Elastic fetched ${total} assets`);
}

async function getLatestEpisodeNumberBySeries() {
  const res = await getClient().search({
    index: 'global_v4',
    size: 0,
    body: {
      query: {
        bool: {
          must: [
            {
              match: {
                'details.mediaType.keyword': 'EPISODE',
              },
            },
          ],
        },
      },
      aggs: {
        seriesWiseEpisode: {
          terms: {
            field: 'meta.series.id',
            size: 3000,
          },
          aggs: {
            maxEpisodeNo: {
              max: {
                field: 'meta.series.episode',
              },
            },
          },
        },
      },
    },
  });

  const { buckets } = res.aggregations.seriesWiseEpisode;
  const seriesWiseMaxEpisode = {};
  buckets.forEach((bucket) => {
    if (bucket.key && bucket.maxEpisodeNo.value) {
      seriesWiseMaxEpisode[bucket.key] = bucket.maxEpisodeNo.value;
    }
  });
  return seriesWiseMaxEpisode;
}

// Modified to fetch assets from country_IN_V4 - VK
// This is to fix the issue of assets appearing before startDate in Algolia.
async function getUpdatedShotsDocuments(fromTime, toTime) {
  if (!(typeof fromTime === 'number' && typeof toTime === 'number')) {
    return [];
  }
  logger.info(
    `getUpdatedShotsDocuments index:${liveAssetsIndex} fromTime:${fromTime} toTime:${toTime}`,
  );
  let res = await getClient().search({
    index: liveAssetsIndex,
    size: SEARCH_SIZE,
    scroll: '1m',
    body: {
      query: {
        bool: {
          must_not: [
            {
              match: {
                'meta.genres.keyword': 'Kids',
              },
            },
            {
              match: {
                'meta.isSearchable': false,
              },
            },
            {
              bool: {
                must_not: [
                  {
                    terms: {
                      'details.mediaType.keyword': [
                        'SHOTS',
                        'CONTAINER',
                      ],
                    },
                  },
                ],
              },
            },
          ],
          filter: {
            range: {
              revised: {
                gt: `${fromTime}`,
                lte: `${toTime}`,
              },
            },
          },
        },
      },
      sort: [{ revised: { order: 'asc' } }],
    },
  });
  let AllDocs = res.hits.hits;
  let keepGoing = res.hits.hits.length === SEARCH_SIZE;
  while (keepGoing) {
    logger.log(`fetched ${AllDocs.length}`);
    // eslint-disable-next-line no-await-in-loop
    res = await getClient().scroll({
      // eslint-disable-next-line no-underscore-dangle
      scroll_id: res._scroll_id,
      scroll: '1m',
    });
    AllDocs = AllDocs.concat(res.hits.hits);
    keepGoing = res.hits.hits.length === SEARCH_SIZE && AllDocs.length < MAX_DOCUMENTS;
  }
  return AllDocs.map(({ _source }) => _source);
}

/*
Fetch assets which just got published - startDate fix - VK

Index: country_IN_V4 (asset is already live, so it will be available in this index)
Condition: (fromTime < startDate <= toTime) && (endDate > toTime)
Description: The startDate condition only picks assets which got published in the last
interval. The endDate condition excludes assets which are also now unpublished.
*/
async function getRecentlyPublishedShotsDocuments(fromTime, toTime) {
  if (!(typeof fromTime === 'number' && typeof toTime === 'number')) {
    return [];
  }
  logger.info(
    `getRecentlyPublishedShotsDocuments index:${liveAssetsIndex} fromTime:${fromTime} toTime:${toTime}`,
  );
  let res = await getClient().search({
    index: liveAssetsIndex,
    size: SEARCH_SIZE,
    scroll: '1m',
    body: {
      query: {
        bool: {
          must_not: [
            {
              match: {
                'meta.genres.keyword': 'Kids',
              },
            },
            {
              match: {
                'meta.isSearchable': false,
              },
            },
            {
              bool: {
                must_not: [
                  {
                    terms: {
                      'details.mediaType.keyword': [
                        'SHOTS',
                        'CONTAINER',
                      ],
                    },
                  },
                ],
              },
            },
          ],
          filter: [
            {
              range: {
                'availability.available.IN.from': {
                  gt: `${fromTime}`,
                  lte: `${toTime}`,
                },
              },
            },
            {
              range: {
                'availability.available.IN.to': {
                  gt: `${toTime}`,
                },
              },
            },
          ],
        },
      },
      sort: [{ revised: { order: 'asc' } }],
    },
  });
  let AllDocs = res.hits.hits;
  let keepGoing = res.hits.hits.length === SEARCH_SIZE;
  while (keepGoing) {
    logger.log(`fetched ${AllDocs.length}`);
    // eslint-disable-next-line no-await-in-loop
    res = await getClient().scroll({
      // eslint-disable-next-line no-underscore-dangle
      scroll_id: res._scroll_id,
      scroll: '1m',
    });
    AllDocs = AllDocs.concat(res.hits.hits);
    keepGoing = res.hits.hits.length === SEARCH_SIZE && AllDocs.length < MAX_DOCUMENTS;
  }
  return AllDocs.map(({ _source }) => _source);
}

async function getDisabledShotsInRange(fromTime, toTime) {
  if (!(typeof fromTime === 'number' && typeof toTime === 'number')) {
    return [];
  }
  logger.info(
    `getDisabledShotsInRange index:${updateIndex} fromTime:${fromTime} toTime:${toTime}`,
  );
  let res = await getClient().search({
    index: updateIndex,
    size: SEARCH_SIZE,
    scroll: '1m',
    _source: ['id', 'revised'],
    body: {
      query: {
        bool: {
          must: [
            { match: { disabled: true } },
            {
              bool: {
                should: [
                  { match: { 'details.mediaType.keyword': 'SHOTS' } },
                  { match: { 'details.mediaType.keyword': 'CONTAINER' } },
                ],
              },
            },
          ],
          filter: {
            range: {
              revised: {
                gt: `${fromTime}`,
                lte: `${toTime}`,
              },
            },
          },
        },
      },
      sort: [{ revised: { order: 'asc' } }],
    },
  });
  let AllDocs = res.hits.hits;
  let keepGoing = res.hits.hits.length === SEARCH_SIZE;
  while (keepGoing) {
    logger.log(`fetched ${AllDocs.length}`);
    // eslint-disable-next-line no-await-in-loop
    res = await getClient().scroll({
      // eslint-disable-next-line no-underscore-dangle
      scroll_id: res._scroll_id,
      scroll: '1m',
    });
    AllDocs = AllDocs.concat(res.hits.hits);
    keepGoing = res.hits.hits.length === SEARCH_SIZE && AllDocs.length < MAX_DOCUMENTS;
  }
  return AllDocs.map(({ _source }) => _source);
}

/*
Fetch assets whose endDate has passed - VK

Index: global_v4
Condition: `${fromTime}` < endDate <= toTime
Description: The condition only picks assets whose endDate was passed in the last
interval.
*/
async function getShotsBeyondEndDate(fromTime, toTime) {
  if (!(typeof fromTime === 'number' && typeof toTime === 'number')) {
    return [];
  }
  logger.info(
    `getShotsBeyondEndDate index:${updateIndex} fromTime:${fromTime} toTime:${toTime}`,
  );
  let res = await getClient().search({
    index: updateIndex,
    size: SEARCH_SIZE,
    scroll: '1m',
    _source: ['id', 'revised'],
    body: {
      query: {
        bool: {
          must: [
            {
              bool: {
                should: [
                  { match: { 'details.mediaType.keyword': 'SHOTS' } },
                  { match: { 'details.mediaType.keyword': 'CONTAINER' } },
                ],
              },
            },
            {
              range: {
                'availability.available.IN.to': {
                  gt: `${fromTime}`,
                  lte: `${toTime}`,
                },
              },
            },
          ],
        },
      },
      sort: [{ revised: { order: 'asc' } }],
    },
  });
  let AllDocs = res.hits.hits;
  let keepGoing = res.hits.hits.length === SEARCH_SIZE;
  while (keepGoing) {
    logger.log(`fetched ${AllDocs.length}`);
    // eslint-disable-next-line no-await-in-loop
    res = await getClient().scroll({
      // eslint-disable-next-line no-underscore-dangle
      scroll_id: res._scroll_id,
      scroll: '1m',
    });
    AllDocs = AllDocs.concat(res.hits.hits);
    keepGoing = res.hits.hits.length === SEARCH_SIZE && AllDocs.length < MAX_DOCUMENTS;
  }
  return AllDocs.map(({ _source }) => _source);
}

async function getAllActiveAssets(getDataFromElasticClient) {
  let res = await getClient().search({
    index: liveAssetsIndex,
    size: 1000,
    // type: '_doc',
    scroll: '1m',
    body: {
      _source: ['id', 'meta.title.full', 'slug', 'details.image', 'meta.synopsis.full', 'details.marketType',
        'details.mediaType', 'meta.showId', 'meta.genres', 'meta.series', 'meta.season', 'meta.showName'],
      query: {
        terms: {
          'details.mediaType.keyword': [
            'SHOW',
            'MOVIE',
          ],
        },
      },
    },
  });

  if (res.errors) {
    logger.error(
      `ERROR Facebook feed elasticsearch response took:${res.took} errors:${res.errors} items.length:${res.items.length}`,
    );
    if (res.items) {
      res.items.forEach((item) => {
        logger.warn(item.index.error);
      });
    }
    throw new Error(res.errors);
  }

  let total = 0;
  let dataDump = res.hits.hits;
  dataDump = dataDump.map(({ _source }) => _source);

  await getDataFromElasticClient(dataDump);
  total += dataDump.length;

  let isLastBatch = false;
  while (dataDump.length === 1000) {
    res = await getClient().scroll({
      scroll_id: res._scroll_id,
      scroll: '1m',
    });
    dataDump = res.hits.hits;
    dataDump = dataDump.map(({ _source }) => _source);
    if (dataDump.length < 1000) {
      isLastBatch = true;
      logger.info('Last batch of data ', isLastBatch);
      logger.info('Length of last batch of data - ', dataDump.length);
    }
    total += dataDump.length;
    await getDataFromElasticClient(dataDump, total, isLastBatch);
  }
  logger.info('Elasticsearch scroll complete');
  logger.info(`Elastic fetched ${total} assets`);
}

async function getGeneric(esQuery) {
  const res = await getClient().search({
    index: updateIndex,
    body: {
      ...esQuery,
    },
  });
  return res;
}

async function getLiveAssetsWithoutOneLink(size) {
  try {
    const res = await getClient().search({
      index: updateIndex,
      size,
      body: {
        _source: ['id', 'name', 'meta', 'details'],
        query: {
          bool: {
            must: [{
              exists: {
                field: 'details.jioMedia.contentId',
              },
            }, {
              terms: {
                'details.mediaType.keyword': ['EPISODE', 'MOVIE', 'SHOW', 'CAC', 'LIVECHANNEL'],
              },
            }],
            must_not: [{
              exists: {
                field: 'details.oneLink',
              },
            }, {
              term: {
                disabled: true,
              },
            }],
          },
        },
      },
    });
    const respData = res ? res.hits.hits.map(({ _source }) => _source) : [];
    return respData;
  } catch (err) {
    throw new Error(`Error while fetching assets ${err}`);
  }
}
async function getMovies(source = ['id', 'revised', 'name', 'details.mediaType', 'meta.title.full']) {
  logger.info('getMovies');
  let res = await getClient().search({
    index,
    size: SEARCH_SIZE,
    scroll: '1m',
    _source: source,
    body: {
      query: {
        match: {
          'details.mediaType.keyword': 'MOVIE',
        },
      },
      sort: [
        { revised: { order: 'desc' } },
      ],
    },
  });
  let AllDocs = res.hits.hits;
  let keepGoing = (res.hits.hits.length === SEARCH_SIZE);
  while (keepGoing) {
    logger.log(`fetched ${AllDocs.length}`);
    res = await getClient().scroll({
      scroll_id: res._scroll_id,
      scroll: '1m',
    });
    AllDocs = AllDocs.concat(res.hits.hits);
    keepGoing = (res.hits.hits.length === SEARCH_SIZE) && AllDocs.length < MAX_DOCUMENTS;
  }
  await getClient().clearScroll({ scroll_id: res._scroll_id });
  return AllDocs.map(({ _source }) => _source);
}
async function getTransformSamsungAssets(documents) {
  const showList = await getShowDetailsMap(documents);
  // eslint-disable-next-line no-loop-func
  const assets = documents.map((obj) => {
    if (obj.meta) {
      if (obj.meta.showId) {
        return transform(obj, undefined, showList[`${obj.meta.showId}`]);
      } if (obj.meta.series && obj.meta.series.showId) {
        return transform(obj, undefined, showList[`${obj.meta.series.showId}`]);
      }
    }
    return transform(obj);
  });
  return assets;
}
async function getShows(source = ['id', 'revised', 'name', 'details.mediaType', 'meta.title.full']) {
  logger.info('getShows');
  let res = await getClient().search({
    index,
    size: SEARCH_SIZE,
    scroll: '1m',
    _source: source,
    body: {
      query: {
        match: {
          'details.mediaType.keyword': 'SHOW',
        },
      },
      sort: [
        { revised: { order: 'desc' } },
      ],
    },
  });
  let AllDocs = res.hits.hits;
  let keepGoing = (res.hits.hits.length === SEARCH_SIZE);
  while (keepGoing) {
    logger.log(`fetched ${AllDocs.length}`);
    // eslint-disable-next-line no-await-in-loop
    res = await getClient().scroll({
      // eslint-disable-next-line no-underscore-dangle
      scroll_id: res._scroll_id,
      scroll: '1m',
    });
    AllDocs = AllDocs.concat(res.hits.hits);
    keepGoing = (res.hits.hits.length === SEARCH_SIZE) && AllDocs.length < MAX_DOCUMENTS;
  }
  await getClient().clearScroll({ scroll_id: res._scroll_id });
  return AllDocs.map(({ _source }) => _source);
}
async function getCAC(showId, from, source = ['id', 'revised', 'name', 'details.mediaType', 'meta.title.full']) {
  logger.info(`getCAC showId:${showId}`);
  let res = await getClient().search({
    index,
    size: 10,
    scroll: '1m',
    _source: source,
    body: {
      query: {
        bool: {
          must: [
            {
              match: {
                'meta.series.showId': showId,
              },
            },
            {
              match: {
                'details.mediaType': 'CAC',
              },
            },
            {
              range: {
                id: {
                  gt: from,
                },
              },
            },
          ],
        },

      },
      sort: [
        { id: { order: 'asc' } },
      ],
    },
  });
  let AllDocs = res.hits.hits;
  let keepGoing = (res.hits.hits.length === SEARCH_SIZE);
  while (keepGoing) {
    logger.log(`fetched ${AllDocs.length}`);
    // eslint-disable-next-line no-await-in-loop
    res = await getClient().scroll({
      // eslint-disable-next-line no-underscore-dangle
      scroll_id: res._scroll_id,
      scroll: '1m',
    });
    AllDocs = AllDocs.concat(res.hits.hits);
    keepGoing = (res.hits.hits.length === SEARCH_SIZE) && AllDocs.length < MAX_DOCUMENTS;
  }
  await getClient().clearScroll({ scroll_id: res._scroll_id });
  return AllDocs.map(({ _source }) => _source);
}
async function getEpisodes(showId, from, source = ['id', 'revised', 'name', 'details.mediaType', 'meta.title.full']) {
  logger.info(`getEpisodes showId:${showId}`);
  let res = await getClient().search({
    index,
    size: SEARCH_SIZE,
    scroll: '1m',
    _source: source,
    body: {
      query: {
        bool: {
          must: [
            {
              match: {
                'meta.series.showId': showId,
              },
            },
            {
              match: {
                'details.mediaType': 'EPISODE',
              },
            },
            {
              range: {
                id: {
                  gt: from,
                },
              },
            },
          ],
        },

      },
      sort: [
        { id: { order: 'asc' } },
      ],
    },
  });
  let AllDocs = res.hits.hits;
  let keepGoing = (res.hits.hits.length === SEARCH_SIZE);
  while (keepGoing) {
    logger.log(`fetched ${AllDocs.length}`);
    // eslint-disable-next-line no-await-in-loop
    res = await getClient().scroll({
      // eslint-disable-next-line no-underscore-dangle
      scroll_id: res._scroll_id,
      scroll: '1m',
    });
    AllDocs = AllDocs.concat(res.hits.hits);
    keepGoing = (res.hits.hits.length === SEARCH_SIZE) && AllDocs.length < MAX_DOCUMENTS;
  }
  await getClient().clearScroll({ scroll_id: res._scroll_id });
  return AllDocs.map(({ _source }) => _source);
}
async function getLiveChannels(source = ['id', 'revised', 'name', 'details.mediaType', 'meta.title.full']) {
  logger.info('getLiveNews');
  let res = await getClient().search({
    index,
    size: SEARCH_SIZE,
    scroll: '1m',
    _source: source,
    body: {
      query: {
        bool: {
          must: [
            {
              match: {
                'details.mediaType.keyword': 'LIVECHANNEL',
              },
            },
          ],
        },
      },
      sort: [
        { id: { order: 'desc' } },
      ],
    },
  });
  let AllDocs = res.hits.hits;
  let keepGoing = (res.hits.hits.length === SEARCH_SIZE);
  while (keepGoing) {
    logger.log(`fetched ${AllDocs.length}`);
    res = await getClient().scroll({
      scroll_id: res._scroll_id,
      scroll: '1m',
    });
    AllDocs = AllDocs.concat(res.hits.hits);
    keepGoing = (res.hits.hits.length === SEARCH_SIZE) && AllDocs.length < MAX_DOCUMENTS;
  }
  await getClient().clearScroll({ scroll_id: res._scroll_id });
  return AllDocs.map(({ _source }) => _source);
}

async function getSeries(source = ['id', 'revised', 'name', 'details.mediaType', 'meta.title.full']) {
  logger.info('get Series');
  let res = await getClient().search({
    index,
    size: SEARCH_SIZE,
    scroll: '1m',
    _source: source,
    body: {
      query: {
        match: {
          'details.mediaType.keyword': 'SERIES',
        },
      },
      sort: [
        { revised: { order: 'desc' } },
      ],
    },
  });
  let AllDocs = res.hits.hits;
  let keepGoing = (res.hits.hits.length === SEARCH_SIZE);
  while (keepGoing) {
    logger.log(`fetched ${AllDocs.length}`);
    // eslint-disable-next-line no-await-in-loop
    res = await getClient().scroll({
      // eslint-disable-next-line no-underscore-dangle
      scroll_id: res._scroll_id,
      scroll: '1m',
    });
    AllDocs = AllDocs.concat(res.hits.hits);
    keepGoing = (res.hits.hits.length === SEARCH_SIZE) && AllDocs.length < MAX_DOCUMENTS;
  }
  await getClient().clearScroll({ scroll_id: res._scroll_id });
  return AllDocs.map(({ _source }) => _source);
}

async function getTransformedAssets(documents) {
  const showList = await getShowDetailsMap(documents);
  // eslint-disable-next-line no-loop-func
  const assets = documents.map((obj) => {
    if (obj.meta) {
      if (obj.meta.showId) {
        return common.transform(obj, undefined, showList[`${obj.meta.showId}`]);
      } if (obj.meta.series && obj.meta.series.showId) {
        return common.transform(obj, undefined, showList[`${obj.meta.series.showId}`]);
      }
    }
    return common.transform(obj);
  });
  return assets;
}

module.exports = {
  init,
  getObjectByIdsWithSource,
  bulkUpdate,
  filterSeriesIds,
  getUpdatedNonKidsDocuments,
  MAX_DOCUMENTS,
  getUpdatedNonKidsDocumentsForRec,
  getDisabledAssetsInRange,
  bulkInsertEPG,
  getShowDetailsMap,
  updateDisableAssets,
  getPartnerAssets,
  getFullCatalogDump,
  getRecentlyPublishedNonKidsDocuments,
  getAvailabilityChangedAssetsInRange,
  getAssetsBeyondEndDate,
  getUpdatedShotsDocuments,
  getRecentlyPublishedShotsDocuments,
  getDisabledShotsInRange,
  getShotsBeyondEndDate,
  getLatestEpisodeNumberBySeries,
  getAllActiveAssets,
  getGeneric,
  getLiveAssetsWithoutOneLink,
  getClient,
  getMovies,
  getTransformSamsungAssets,
  getShows,
  getCAC,
  getEpisodes,
  getLiveChannels,
  getSeries,
  getTransformedAssets,
};

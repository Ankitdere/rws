/* eslint-disable max-len */
const axios = require('axios');
const tunnel = require('tunnel');
const { logger } = require('logger-v18');

// const apiToken = process.env.mixpanelApiKey;
const baseURL = process.env.mixpanelBaseUrl;
const JQL_URL = process.env.mixpanelEndpoint;

// eslint-disable-next-line no-unused-vars
function getScript(type, CountType, date, minView) {
  logger.log(`running script of type ${type}`);
  if (type === CountType.view) {
    return `function main() {
      return Events({
              from_date: "${date}",
              to_date: "${date}",
              event_selectors: [{ event: 'mediaReady', selector: 'properties["Content Type"] == "MOVIE" or properties["Content Type"] == "Movie" ' }]
      })
      .groupBy([getMediaId], mixpanel.reducer.count())
      .filter(function(data){
        if(data.key[0]== null){
          return false;
        } else if(data.value < ${minView}){
          return false;
        }
        return true;
      })
      function getMediaId(event) { 
        return event.properties['Media ID']
      }
    }`;
  }
  if (type === CountType.search) {
    return `function main() {
      return Events({
              from_date: "${date}",
              to_date: "${date}",
              event_selectors: [{ event: 'Search Action', selector: 'properties["Show ID"] == properties["Search Destination Media ID"] or properties["Show ID"] =="" ' }]
      })
      .groupBy([getMediaId], mixpanel.reducer.count())
      .filter(function(data){
        if(data.key[0]== null){
          return false;
        }
        return true;
      })
      function getMediaId(event) { 
        return event.properties['Search Destination Media ID']
      }
    }`;
  }
  if (type === CountType.shows) {
    return `function main() {
      return Events({
              from_date: "${date}",
              to_date: "${date}",
              event_selectors: [{ event: 'mediaReady' }]
      })
      .groupBy([getShowId], mixpanel.reducer.count())
      .filter(function(data){
        if(data.key[0]== null){
          return false;
        } else if(data.value < ${minView}){
          return false;
        }
        return true;
      })
      function getShowId(event){
        return event.properties['Show ID']
      }
    }`;
  }
  logger.log('not matched any if condition');
  return '';
}

async function getDataFromMixpanel(type, CountType, date, minView) {
  if (!type || !CountType || !date) {
    throw Error('invalid mixpanel script configuration');
  }

  console.log('values', type, CountType, date, minView);
  const agent = tunnel.httpsOverHttp({
    proxy: {
      host: 'gcpprodproxy.jio.com',
      port: 8080,
    },
  });

  // const script = getScript(type, CountType, date, minView);
  const script = `function main() {
    return Events({
            from_date: "${date}",
            to_date: "${date}",
            event_selectors: [{ event: 'mediaReady', selector: 'properties["Content Type"] == "MOVIE" or properties["Content Type"] == "Movie" ' }]
    })
    .groupBy([getMediaId], mixpanel.reducer.count())
    .filter(function(data){
      if(data.key[0]== null){
        return false;
      } else if(data.value < ${minView}){
        return false;
      }
      return true;
    })
    function getMediaId(event) { 
      return event.properties['Media ID']
    }
  }`;
  const requesturl = `${baseURL}${JQL_URL}?project_id=${process.env.mpProjectId}`;
  const resp = await axios.post(`${requesturl}`, `script=${script}`, {
    headers: {
      authorization: `Basic ${process.env.mpSAUsername}:${process.env.mpSASecret}`,
    },
    httpsAgent: agent,
  });

  return resp.data;
}

module.exports = {
  getDataFromMixpanel,
};

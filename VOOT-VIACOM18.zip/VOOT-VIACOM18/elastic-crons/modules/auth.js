const axios = require('axios');
const log = require('logger-v18');

const { logger } = log;
async function getToken() {
  let resp = null;
  try {
    resp = await axios.get(`${process.env.gcpMetadataApi}`, {
      headers: {
        'Metadata-Flavor': 'Google',
      },
      proxy: false,
    });
    logger.log('auth resp', resp.data);
    resp = resp.data;
  } catch (error) {
    logger.error('ERROR in gcp auth', Object.keys(error).length ? JSON.stringify(error) : error);
  }
  return resp;
}
module.exports = {
  getToken,
};

/* eslint-disable default-param-last */
/* eslint-disable max-len */
/* eslint-disable no-unused-vars */
// eslint-disable-next-line import/no-extraneous-dependencies
const axios = require('axios');
const xmlToJs = require('xml2js');
const { Storage } = require('@google-cloud/storage');
const { logger } = require('logger-v18');

const { stage } = process.env;
const storage = new Storage();

const getClient = (() => {
  let client;
  return () => {
    if (!client) {
      client = storage.bucket(process.env.configBucketName);
    }
    return client;
  };
})();

async function getFile(key, bucket = process.env.configBucketName) {
  const storageBucket = storage.bucket(bucket);
  // logger.log('fetching file - ', key);
  const [data] = await storageBucket.file(key).download();
  return data ? JSON.parse(data.toString()) : null;
}

async function saveFile(key, body, options = {}, bucket = process.env.configBucketName) {
  const storageBucket = storage.bucket(bucket);
  const resp = await storageBucket.file(key).save(JSON.stringify(body), options);
  return resp;
}

async function deleteFile(Key) {
  const resp = await getClient().file(Key).delete();
  return resp;
}

async function getCronConfig(configFileName) {
  if (!configFileName) {
    return {};
  }
  try {
    const object = await getFile(`${stage}/status/${configFileName}-config.json`);
    logger.log('config file from gcs', object);
    // const cronConfig = object.toString();
    // return JSON.parse(cronConfig);
    return object;
  } catch (err) {
    logger.warn('ERROR in fetching config, will return 0 as value of time', err);
    return {
      lastProcessedTime: 0,
    };
  }
}

async function updateLastProcessedTime(configFileName, time) {
  if (!configFileName || !time) return;

  logger.log('updating lastProcessedTime in config file');
  const cronConfig = await getCronConfig(configFileName);
  logger.log(`got revised time:${time} from documents `, cronConfig);
  cronConfig.lastProcessedTime = time;
  await saveFile(
    `${stage}/status/${configFileName}-config.json`,
    cronConfig,
    { contentType: 'application/json' },
  );
  logger.log('updated config file and saved in GCS', cronConfig);
}

/** start methods for mixpanel data process */
async function getMpCronDataFile(path, fileName) {
  if (!fileName) {
    return [];
  }
  try {
    const object = await getFile(
      `${stage}/mpdata/${path}/${fileName}.json`,
    );
    // const cronConfig = object.Body.toString();
    // return JSON.parse(cronConfig);
    return object;
  } catch (err) {
    logger.error(`ERROR ${err.message} -- For asset : ${fileName}`);
    return [];
  }
}

async function updateMpDataFile(path, fileName, data) {
  if (!fileName || !data) {
    return;
  }
  await saveFile(
    `${stage}/mpdata/${path}/${fileName}.json`,
    data,
    { contentType: 'application/json' },
  );
  logger.log(`updated mixpanel data to storage filename : ${fileName} `);
}

async function deleteCronDataFile(path, fileName) {
  if (!fileName) {
    return;
  }
  logger.log(`delete data file : ${fileName}`);
  await deleteFile(
    `${stage}/mpdata/${path}/${fileName}.json`,
  );
}

async function saveDocumentsForRec(objects, fileName) {
  if (typeof objects !== 'object' || objects.length <= 0 || !fileName) {
    return;
  }
  const {
    recBucketName,
    recBasePath,
  } = process.env;
  const today = new Date();
  const path = `${recBasePath}${today.getUTCFullYear()}/${today.getUTCMonth() + 1}/${today.getUTCDate()}`
    + `/${today.getUTCHours()}/${today.getUTCMinutes()}/${fileName}.json`;
  await saveFile(
    path,
    objects,
    { contentType: 'application/json' },
    recBucketName,
  );
  logger.log(`updated rec data to storage filename : ${path} length:${objects.length}`);
}

async function getPromotedAssets(fileName) {
  if (!fileName) {
    return [];
  }
  try {
    const object = await getFile(
      `${stage}/mpdata/${fileName}.json`,
    );
    // const cronConfig = object.Body.toString();
    // return JSON.parse(cronConfig);
    return object;
  } catch (err) {
    logger.error(`${err.message} -- For asset : ${fileName}`);
    return [];
  }
}

async function getPartnerTrays(partnerId) {
  if (!partnerId) {
    return {};
  }
  try {
    const object = await getFile(
      `platform/${partnerId}/views/content/live/0.json`,
      process.env.cmsBucketName,
    );
    // const cronConfig = object.Body.toString();
    // return JSON.parse(cronConfig);
    return object;
  } catch (err) {
    logger.error(`${err.message} for partner ${partnerId}`);
    return {};
  }
}

async function savePartnerTrays(objects, partnerId) {
  if (typeof objects !== 'object' || objects.length <= 0 || !partnerId) {
    return;
  }
  const { cmsBucketName } = process.env;
  const today = new Date();
  const path = `partner-content/${partnerId}/${today.getUTCFullYear()}-${today.getUTCMonth() + 1}-${today.getUTCDate()}`;
  await saveFile(
    path,
    objects,
    { contentType: 'application/json' },
    cmsBucketName,
  );
  logger.log(`uploaded partner ${partnerId} trays and asstes data to storage filename : ${path} length:${objects.length}`);
}

async function initiateMultiPart(filePath, Bucket = process.env.configBucketName, accessToken) {
  const headers = {
    Authorization: `Bearer ${accessToken}`,
    'Content-Type': 'text/csv',
  };
  const resp = await axios.post(`https://${Bucket}.storage.googleapis.com/${filePath}?uploads`, {}, {
    headers,
    proxy: false,
  });
  const json = await xmlToJs.parseStringPromise(resp.data);
  return json.InitiateMultipartUploadResult;
}

async function uploadPart(UploadId, filePath, PartNumber, data, Bucket = process.env.configBucketName, accessToken) {
  const headers = {
    Authorization: `Bearer ${accessToken}`,
    'Content-Type': 'text/csv',
  };
  const resp = await axios.put(`https://${Bucket}.storage.googleapis.com/${filePath}?partNumber=${PartNumber}&uploadId=${UploadId}`, data, {
    headers,
    proxy: false,
    maxContentLength: Infinity,
    maxBodyLength: Infinity,
  });

  return { ETag: resp.headers.etag, PartNumber };
}

async function completeMultiPart(UploadId, filePath, dataParts, Bucket = process.env.configBucketName, accessToken) {
  let body = '<CompleteMultipartUpload>';
  const end = '</CompleteMultipartUpload>';
  dataParts.forEach((part) => {
    body += `<Part><PartNumber>${part.PartNumber}</PartNumber><ETag>${part.ETag}</ETag></Part>`;
  });
  body += end;

  const headers = {
    Authorization: `Bearer ${accessToken}`,
    'Content-Length': body.length || 0,
    'Content-Type': 'text/csv',
  };
  const resp = await axios.post(`https://${Bucket}.storage.googleapis.com/${filePath}?uploadId=${UploadId}`, body, {
    headers,
    proxy: false,
  });
  const json = await xmlToJs.parseStringPromise(resp.data);

  return json.CompleteMultipartUploadResult;
}

async function abortMultiPart(UploadId, filePath, Bucket = process.env.configBucketName, accessToken) {
  try {
    const headers = {
      Authorization: `Bearer ${accessToken}`,
      Host: `${Bucket}.storage.googleapis.com`,
      Date: new Date(),
      'Content-Length': 0,
    };

    const resp = await axios.delete(`https://${Bucket}.storage.googleapis.com/${filePath}?uploadId=${UploadId}`, {
      headers,
      // proxy: false,
    });
    logger.info('Success - Abort complete ', resp);
  } catch (err) {
    logger.error('ERROR in multipart abort', Object.keys(err).length ? JSON.stringify(err) : err);
    throw err;
  }
}

async function listFolders(prefix, maxResults = 20) {
  const options = {
    maxResults,
    prefix,
    delimiter: '/',
  };
  const resp = await getClient().getFiles(options);
  return resp[2].prefixes;
}

async function getObjectStream(Key) {
  // const stream = await getClient().getObject({ Key }).createReadStream();
  // return stream;
}

async function doesFileExist(Key, bucket = process.env.configBucketName) {
  const storageBucket = storage.bucket(bucket);
  const [resp] = await storageBucket.file(Key).exists();
  return resp;
}

async function saveFileRaw(Key, body, bucket = process.env.configBucketName) {
  const storageBucket = storage.bucket(bucket);
  const options = {
    resumable: false,
  };
  const resp = await storageBucket.file(Key).save(body, options);
  return resp;
}

module.exports = {
  getFile,
  saveFile,
  updateLastProcessedTime,
  getCronConfig,
  getMpCronDataFile,
  updateMpDataFile,
  deleteCronDataFile,
  saveDocumentsForRec,
  getPromotedAssets,
  getPartnerTrays,
  savePartnerTrays,
  initiateMultiPart,
  uploadPart,
  completeMultiPart,
  abortMultiPart,
  listFolders,
  getObjectStream,
  doesFileExist,
  saveFileRaw,
};

/* eslint-disable camelcase */
/* eslint-disable no-plusplus */
/* eslint-disable no-tabs */
const log = require('logger-v18');
const fs = require('fs');
const moment = require('moment');
const sleep = require('util').promisify(setTimeout);
const { Parser } = require('json2csv');
const elasticClient = require('./modules/elasticClient');
const gcpAuth = require('./modules/auth');

const { logger } = log;
const { transform } = require('./v3ResponseTypes/responseTypes/common');
const {
  initiateMultiPart, uploadPart, completeMultiPart, abortMultiPart,
} = require('./modules/storageClient');
const config = require('./v3ResponseTypes/const.json');

const FILE_NAME = 'catalog_media_title.csv';
const FILE_PATH = `./uploads/${FILE_NAME}`;
const KEY = `facebook-feed/${FILE_NAME}`;
let UPLOAD_ID = null;
const BATCH_SIZE = 20000;
let FLAG = false;
let PART_NUMBER = 0;
const DATA_PARTS = [];
const APPLE_STORE_ID = 1011777157;
const ANDROID_PACKAGE_NAME = 'com.tv.v18.viola';
const APP_NAME = 'Voot';
const { facebookFeedBucket } = process.env;
let ACCESS_TOKEN = null;

let k = 0;

function getTransformedData(asset, playbackType) {
  return transform(asset, playbackType, undefined, undefined);
}

async function transformDataForCsv(elasticData) {
  const csvData = [];

  for (let j = 0; j < elasticData.length; j += 1) {
    // eslint-disable-next-line no-continue
    if (!elasticData[j].details || !elasticData[j].meta) continue;
    const result = getTransformedData(elasticData[j], null);
    const mediaId = parseInt(result.id, 10);
    const title = result.fullTitle;
    const URL = result.slug;
    const imageURL = result.imageUri;
    const baseUrl = config.imageCDN;
    const mediaType = result.mediaType === 'SHOW' ? 'TV_SHOW' : result.mediaType;
    if (
      mediaId
    && title
    && URL
    && imageURL
    && mediaType
    ) {
      const tempObj = {
        media_title_id: mediaId,
        title,
        url: URL,
        'image[0].url': `${baseUrl}${imageURL}`,
        'image[0].tag[0]': title,
        description: result.fullSynopsis || '',
        price: result.isPremium ? 299 : 0,
        title_display_name: title,
        content_category: mediaType,
        'genre[0]': result.genres.length ? result.genres[0] : '',
        'applink.android_app_name': APP_NAME,
        'applink.android_package': ANDROID_PACKAGE_NAME,
        'applink.android_url': result.deeplinkUrl || '',
        'applink.ios_app_name': APP_NAME,
        'applink.ios_app_store_id': APPLE_STORE_ID,
        'applink.ios_url': result.deeplinkUrl || '',
        'applink.ipad_app_name': APP_NAME,
        'applink.ipad_app_store_id': APPLE_STORE_ID,
        'applink.ipad_url': result.deeplinkUrl || '',
        'applink.iphone_app_name': APP_NAME,
        'applink.iphone_app_store_id': APPLE_STORE_ID,
        'applink.iphone_url': result.deeplinkUrl || '',
      };

      csvData.push(tempObj);
    }
  }
  return csvData;
}

async function writeToCsv({ fields, csvData }) {
  const parser = new Parser({ fields, withBOM: true });
  const csv = parser.parse(csvData);
  const ws = fs.createWriteStream(FILE_PATH, { encoding: 'utf8' });
  ws.write(`${csv}\r\n`);
  logger.log(`Created a file and wrote data - ${k}`);
  ws.end();
}

async function appendToCsv({ csvData }) {
  const parser = new Parser({ header: false, withBOM: true });
  const csv = parser.parse(csvData);
  fs.appendFileSync(FILE_PATH, `${csv}\r\n`);
  logger.log(`File write complete - ${k}`);
}

async function getDataFromElasticClient(elasticData, total, isLastBatch) {
  const csvData = await transformDataForCsv(elasticData);
  k += 1;
  if (!fs.existsSync(FILE_PATH) && !FLAG) {
    const fields = Object.keys({ ...csvData[0] });
    await writeToCsv({ fields, csvData });
    FLAG = true;
  } else {
    await appendToCsv({ csvData });
    if ((total % BATCH_SIZE === 0) || isLastBatch) {
      logger.info('Starting Upload part');
      const csv = fs.readFileSync(FILE_PATH);
      const result = await uploadPart(UPLOAD_ID, KEY, ++PART_NUMBER, csv, facebookFeedBucket, ACCESS_TOKEN);
      logger.info('Finished Upload part ', result);
      DATA_PARTS.push(result);
      fs.writeFileSync(FILE_PATH, '');
    }
  }
}

async function invoke() {
  try {
    log.init({
      json: process.env.logJson,
      service: 'facebook-feed-cron',
      tags: ['crons'],
      level: process.env.logLevel,
    });
    logger.info(
      'Facebook Feed cron running on ',
      moment().utcOffset('+05:30').format('YYYY-MM-DD HH:mm:SS'),
    );
    logger.info('Connecting to elastic search');
    await elasticClient.init();

    logger.info('generating token for multipart upload');
    const { access_token } = await gcpAuth.getToken();
    if (!access_token) {
      throw Error('GCP Auth failed');
    }
    ACCESS_TOKEN = access_token;

    logger.info('Initiating multipart upload');
    const { UploadId } = await initiateMultiPart(KEY, facebookFeedBucket, ACCESS_TOKEN);
    UPLOAD_ID = UploadId;
    if (!UPLOAD_ID) {
      throw Error('ERROR no upload id found');
    }
    logger.info('Initiated multipart, uploadId', UPLOAD_ID);

    logger.info('starting elastic scroll');
    await elasticClient.getAllActiveAssets(getDataFromElasticClient);

    // wait for the last the batch of data to get written and uploaded
    await sleep(5000);

    const { Location } = await completeMultiPart(UPLOAD_ID, KEY, DATA_PARTS, facebookFeedBucket, ACCESS_TOKEN);
    logger.info('Succesfully completed multipart upload, ID - ', UPLOAD_ID);
    logger.info('Uploaded facebook-feed at', Location);

    fs.unlinkSync(FILE_PATH);
    logger.info(
      'Facebook feed cron completed on ',
      moment().utcOffset('+05:30').format('YYYY-MM-DD HH:mm:SS'),
    );
  } catch (err) {
    logger.error('ERROR in Facebook feed cron - ', Object.keys(err).length ? JSON.stringify(err) : err);
    if (UPLOAD_ID) {
      await abortMultiPart(UPLOAD_ID, KEY, facebookFeedBucket, ACCESS_TOKEN);
    }
    fs.unlinkSync(FILE_PATH);
    // throw err;
  }
}

module.exports = {
  invoke,
};

const googleFeedJiositemap = {
  type: ['MOVIE', 'SHOW', 'EPISODE', 'SITEMAP'],
  priority: 1,
  changefreq: 1,
  sitemapType: 'FEED',
};

module.exports = {
  googleFeedJiositemap,
};

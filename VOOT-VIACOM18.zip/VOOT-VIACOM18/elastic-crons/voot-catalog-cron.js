/* eslint-disable camelcase */
/* eslint-disable radix */
/* eslint-disable no-plusplus */
/* eslint-disable no-await-in-loop */
/* eslint-disable no-restricted-syntax */
/* eslint-disable no-nested-ternary */
/* eslint-disable no-use-before-define */
const log = require('logger-v18');
// const events = require('events');
const sleep = require('util').promisify(setTimeout);
const fs = require('fs');
const moment = require('moment');
const { Parser } = require('json2csv');
const elasticClient = require('./modules/elasticClient');
const storageClient = require('./modules/storageClient');
const gcpAuth = require('./modules/auth');

const { logger } = log;
const { transform } = require('./v3ResponseTypes/responseTypes/common');
const { transform: shotsFullTransform } = require('./v3ResponseTypes/responseTypes/shots_full');
const { sendVootCatalogReport } = require('./modules/emailClient');
const {
  // eslint-disable-next-line no-unused-vars
  initiateMultiPart, uploadPart, completeMultiPart, abortMultiPart,
} = require('./modules/storageClient');

// const CUSTOM_DATA_EMITTER = new events.EventEmitter();
const FILE_NAME = `${moment().utcOffset('+05:30').format('YYYY-MM-DDTHH-mm')}-new-full-catalog-report.csv`;
const FILE_PATH = `./uploads/${FILE_NAME}`;
const KEY = `voot-catalog-dump-reports/${process.env.NODE_ENV}/${FILE_NAME}`;
let UPLOAD_ID = null;
// const BATCH_SIZE = 20000;
const BATCH_SIZE = 10000;
let FLAG = false;
let PART_NUMBER = 0;
const DATA_PARTS = [];
let ACCESS_TOKEN = null;

let i = 0;
// recieve data from elastic client scroll api
async function getDataFromElasticClient(elasticData, total, isLastBatch) {
  const csvData = await transformDataForCsv(elasticData);
  ++i;
  if (!fs.existsSync(FILE_PATH) && !FLAG) {
    const fields = Object.keys({ ...csvData[0] });
    await writeToCsv({ fields, csvData });
    FLAG = true;
  } else {
    await appendToCsv({ csvData });
    if ((total % BATCH_SIZE === 0) || isLastBatch) {
      logger.info('Starting Upload part');
      const csv = fs.readFileSync(FILE_PATH);
      const result = await uploadPart(UPLOAD_ID, KEY, ++PART_NUMBER, csv, undefined, ACCESS_TOKEN);
      logger.info('Finished Upload part ', result);
      DATA_PARTS.push(result);
      fs.writeFileSync(FILE_PATH, '');
    }
  }
}

async function transformDataForCsv(elasticData) {
  const csvData = [];
  // const promises = elasticData.map((asset) => elasticClient.getShowDetailsMap([asset]));
  // const showList = await Promise.all(promises);
  const showList = await elasticClient.getShowDetailsMap(elasticData);
  for (let j = 0; j < elasticData.length; j++) {
    const {
      meta, ingested, disabled, availability, firstSyncedAt,
    } = elasticData[j];
    const startDateTime = (availability && availability.available && availability.available.IN)
      ? availability.available.IN.from : 0;
    const result = getTransformedData(elasticData[j], null, showList);
    const filename = (elasticData[j].details && elasticData[j].details.file)
      ? elasticData[j].details.file : '-';
    const tempObj = {
      'MEDIA ID': parseInt(result.id, 10) || '-',
      'MEDIA TYPE': result.mediaType || '-',
      'MEDIA SUBTYPE': result.mediaSubType || '-',
      'FILE NAME': filename || '-',
      NAME: result.name || '-',
      'SHORT TITLE': result.shortTitle || '-',
      'FULL TITLE': result.fullTitle || '-',
      'SHORT SYNOPSIS': result.shortSynopsis || '-',
      'FULL SYNOPSIS': result.fullSynopsis || '-',
      'SHOW ID': parseInt(result.showId, 10) || '-',
      'SHOW NAME': result.showName || '-',
      'SEASON ID': parseInt(result.seasonId, 10) || '-',
      'SEASON NAME': result.seasonName || '-',
      'SEASON NUMBER': result.season || '-',
      'EPISODE NUMBER': result.episode || '-',
      LANGUAGES: result.languages
        ? Array.isArray(result.languages)
          ? result.languages.join(';')
          : result.languages
        : '-',
      'DEFAULT LANGUAGE': result.defaultLanguage
        ? Array.isArray(result.defaultLanguage)
          ? result.defaultLanguage.join(';')
          : result.defaultLanguage
        : '-',
      CUEPOINTS: meta && meta.cueTimes
        ? Array.isArray(meta.cueTimes)
          ? meta.cueTimes.join()
          : meta.cueTimes
        : '-',
      SBU: result.SBU || '-',
      'MULTI TRACK AUDIO ENABLED': result ? result.multiTrackAudioEnabled : '-',
      'CONTENT SUBJECT': result.contentSubject || '-',
      GENRES: result.genres
        ? Array.isArray(result.genres)
          ? result.genres.join(';')
          : result.genres
        : '-',
      'SUB GENRES': result.subGenres || '-', // FIXME: fixed for shots
      KEYWORDS: result.keywords || '-', // FIXME: fixed for shots
      CONTRIBUTORS: result.contributors
        ? Array.isArray(result.contributors)
          ? result.contributors.join(';')
          : result.contributors
        : '-',
      CHARACTERS: result.characters
        ? Array.isArray(result.characters)
          ? result.characters.join(';')
          : result.characters
        : '-',
      'TREND HASHTAGS': result.trendHashtags || '-',
      'CREATIVE HASHTAGS': result.creativeHashtags || '-',
      TOPIC: result.topic || '-',
      'MUSIC SOURCE': result.musicSource || '-',
      'MUSIC NAME': result.musicName || '-',
      'MUSIC ARTISTS': result.musicArtists || '-',
      'MUSIC LABEL': result.musicLabel || '-',
      'SOURCE DEEPLINK MEDIA ID': result.sourceDeeplinkMediaId || '-',
      'SOURCE DEEPLINK MEDIA TYPE': result.sourceDeeplinkMediaType || '-',
      'SOURCE DEEPLINK URL': result.sourceDeeplinkUrl || '-',
      'VIDEO SOURCE': result.videoSource || '-',
      'VIDEO CREATOR': result.videoCreator || '-',
      'VIDEO AGENCY': result.videoAgency || '-',
      'VIDEO PARTNER': result.videoPartner || '-',
      DIRECTOR: meta && meta.movieDirector
        ? Array.isArray(meta.movieDirector)
          ? meta.movieDirector.join(';')
          : meta.movieDirector
        : '-',
      PRODUCER: meta && meta.movieProducer
        ? Array.isArray(meta.movieProducer)
          ? meta.movieProducer.join(';')
          : meta.movieProducer
        : '-',
      'TELECAST DATE': result.telecastDate || '-',
      'RELEASE YEAR': result.releaseYear || '-',
      'CONTENT DESCRIPTOR': result.contentDescriptor || '-',
      AGE: result.age || '-',
      'JIO CONTENT ID': result.entryId || '-',
      DURATION: result.duration || '-',
      'IMAGE URI': result.imageUri || '-',
      'IMAGE 16X9': result.image16x9 || '-',
      'IMAGE 4X3': result.image4x3 || '-',
      'IMAGE 1X1': result.image1x1 || '-',
      'IMAGE 2X3': result.image2x3 || '-',
      'IMAGE 3X4': '-', // FIXME:
      'IMAGE 9x16': result.image9x16 || '-',
      'ANIMATION 16x9': result.animation16x9 || '-',
      'SHOW IMAGE': result.showImage || '-',
      'SERIES IMAGE': result.showImage || '-', // FIXME:
      'EXTERNAL ID': result.externalId || '-',
      'BADGE NAME': result.badgeName || '-',
      'BADGE TYPE': result.badgeType || '-',
      'INTRO START': result.introStart || 0,
      'INTRO END': result.introEnd || 0,
      'RECAP START': result.recapStart || 0,
      'RECAP END': result.recapEnd || 0,
      'CREDIT START': result.creditStart || 0,
      'CREDIT END': result.creditEnd || 0,
      'DAI ENABLED': result.isDAIEnabled || '-',
      'DAI ASSET KEY': result.daiAssetKey || '-',
      'DVR ENABLED': result.isDVREnabled || '-',
      'ASSET MARKET TYPE': result.assetMarketType || '-',
      'SHOW MARKET TYPE': result.showMarketType || '-',
      'IS PWA LOGIN DISABLED': result.isPwaLoginDisabled || '-',
      DOWNLOADABLE: result.downloadable || '-',
      DISABLED: disabled || '-',
      'TRAILER ID': result.trailerId || '-',
      'INGEST DATE': ingested
        ? moment.unix(ingested).format('YYYYMMDD') || ''
        : '-',
      'INGEST TIME': ingested
        ? moment.unix(ingested).format('HH:mm:ss') || ''
        : '-',
      'START DATE': startDateTime
        ? moment.unix(startDateTime).format('YYYYMMDD') || ''
        : '-',
      'START TIME': startDateTime
        ? moment.unix(startDateTime).format('HH:mm:ss') || ''
        : '-',
      'CATALOG START DATE': '-', // FIXME:
      'CATALOG START TIME': '-', // FIXME:
      'CATALOG END DATE': '-', // FIXME:
      'CATALOG END TIME': '-', // FIXME:
      SLUG: result.slug || '-',
      'UPLOAD TIME': result.uploadTime || '-',
      UPDATED: result.updated || '-',
      'FIRST SYNCED AT': firstSyncedAt || '-',
      IS_PREMIUM: result.isPremium || '-',
      IS_SHOW_PREMIUM: result.isShowPremium || '-',
      ON_AIR: result.onAir || '-',
      IS_RECOMMENDED: !(meta && meta.isRecommended === false),
      'Game ID': result.gameId || '',
      'Series ID': result.gameSeriesId || '',
    };
    csvData.push(tempObj);
  }

  return csvData;
}

async function writeToCsv({ fields, csvData }) {
  const parser = new Parser({ fields, withBOM: true });
  const csv = parser.parse(csvData);
  const ws = fs.createWriteStream(FILE_PATH, { encoding: 'utf8' });
  ws.write(`${csv}\r\n`);
  logger.log(`Created a file and wrote data - ${i}`);
  ws.end();
}

async function appendToCsv({ csvData }) {
  const parser = new Parser({ header: false, withBOM: true });
  const csv = parser.parse(csvData);
  fs.appendFileSync(FILE_PATH, `${csv}\r\n`);
  logger.log(`File write complete - ${i}`);
}

// get transformed data from v3ResponseTypes
function getTransformedData(asset, playbackType, showList) {
  if (asset.meta) {
    if (asset.meta.showId) {
      if (asset.details.mediaType === 'SHOTS') {
        return shotsFullTransform(asset, playbackType, showList[`${asset.meta.showId}`], undefined);
      }
      return transform(asset, playbackType, showList[`${asset.meta.showId}`], undefined);
    } if (asset.meta.series && asset.meta.series.showId) {
      if (asset.details.mediaType === 'SHOTS') {
        return shotsFullTransform(asset, playbackType, showList[`${asset.meta.series.showId}`], undefined);
      }
      return transform(asset, playbackType, showList[`${asset.meta.series.showId}`], undefined);
    }
  }
  if (asset.details.mediaType === 'SHOTS') {
    return shotsFullTransform(asset, playbackType, undefined, undefined);
  }
  return transform(asset, playbackType, undefined, undefined);
}

async function invoke() {
  try {
    log.init({
      json: process.env.logJson,
      service: 'voot-catalog-cron',
      tags: ['crons'],
      level: process.env.logLevel,
    });
    logger.info(
      'Voot catalog cron running on ',
      moment().utcOffset('+05:30').format('YYYY-MM-DD HH:mm:SS'),
    );

    logger.info('generating token for multipart upload');
    const { access_token } = await gcpAuth.getToken();
    if (!access_token) {
      throw Error('GCP Auth failed');
    }
    ACCESS_TOKEN = access_token;

    logger.info('Initiating multipart upload');
    const { UploadId } = await storageClient.initiateMultiPart(KEY, undefined, ACCESS_TOKEN);
    UPLOAD_ID = UploadId;
    if (!UPLOAD_ID) {
      throw Error('ERROR no upload id found');
    }
    logger.info('Initiated multipart, uploadId', UPLOAD_ID);

    logger.info('starting elastic scroll');
    await elasticClient.getFullCatalogDump(getDataFromElasticClient);

    // wait for the last the batch of data to get written and uploaded
    await sleep(5000);

    const { Location } = await completeMultiPart(UPLOAD_ID, KEY, DATA_PARTS, undefined, ACCESS_TOKEN);
    logger.info('Succesfully completed multipart upload, ID - ', UPLOAD_ID);
    logger.info('Uploaded voot-catalog-cron at', Location);

    if (process.env.stage === 'jio') {
      await sendVootCatalogReport(Location);
      logger.info('Email Sent');
    }

    fs.unlinkSync(FILE_PATH);
    logger.info(
      'Voot catalog cron completed on ',
      moment().utcOffset('+05:30').format('YYYY-MM-DD HH:mm:SS'),
    );
  } catch (err) {
    logger.error('ERROR in voot catalog report - ', Object.keys(err).length ? JSON.stringify(err) : err);
    if (UPLOAD_ID) {
      await abortMultiPart(UPLOAD_ID, KEY, undefined, ACCESS_TOKEN);
    }
    fs.unlinkSync(FILE_PATH);
    // throw error;
  }
}

module.exports = {
  invoke,
  getDataFromElasticClient,
};

const cacheBusiness = require("./src/business/cacheBusiness");
/**
 * Configure
 * @param {*} params 
 * @param {*} flags 
 */
async function configure() {
	try {
		// Response
		await cacheBusiness.settingAllInCache();
		console.log("in configure ");
		// eslint-disable-next-line no-undef
		return Promise.resolve({ code: 200, message: "AuthV4 server configured successfully." });
	} catch (error) {
		console.error(error);
		if (error && error.code && error.message) {
			// eslint-disable-next-line no-undef
			return Promise.reject({ code: error.code, message: error.message, data: error.data });
		} else {
			// eslint-disable-next-line no-undef
			return Promise.reject({ code: 409, message: "An error occured while populating settings cache. Please restart this service." });
		}
	}
}

/**
 * Initialize
 * @param {*} params 
 * @param {*} flags 
 */
async function initialize() {
	try {
		// const config = require('./src/config/envConfig');
		// console.log(config.dummy)
		console.log("in Initialize ");
		const app = require("./src/app");
		const config = require("./src/config");
		const PORT = process.env.PORT || 5000;
		config.mongoConnect;

		app.listen(PORT, () => {
			console.log(`Auth V4 Server started at port ${ PORT }`);
		});
		app.keepAliveTimeout = 62 * 1000;
		// This should be bigger than `keepAliveTimeout + your server's expected response time`
		app.headersTimeout = 65 * 1000;
		// Response
		// eslint-disable-next-line no-undef
		return Promise.resolve({ code: 200, message: "Auth server initialized successfullly." });
	} catch (error) {
		console.error(" An error occured while configuring AuthV4 server. Please restart this service.");
		console.error(error);
		// Exit process
		process.exit();
	}
}

module.exports = {
	configure,
	initialize
};
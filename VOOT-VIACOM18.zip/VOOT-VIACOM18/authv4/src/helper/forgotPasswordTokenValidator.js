const errorConfig = require("../config").errorConfig;
const apiResponse = require("../utils").apiResponse;
const tokenService = require("../services").tokenService;
const {ipService, kafkaService, notificationService}= require("../services");
const { configuration } = require("../config");

module.exports = forgotPasswordTokenValidator;
async function forgotPasswordTokenValidator(request, response, next) {
	try {
		console.debug("Reached Forgot Password Token Validator");
		const headers = request.headers;
		console.info(JSON.stringify(headers));
		if (!headers.forgotpasswordtoken ) {
			console.error("tokenvalidator()::Forgot Password token not available in header");
			throw ({ message: errorConfig.invalidRequestHeader });
		}
       
		const { decoded, user } = await tokenService.verifyForgotpasswordToken(headers.forgotpasswordtoken );
		request.userToken = user;
		request.tokenInfo = decoded;
		//sending region notification into queue
		const { region, country } = await ipService.getCountryAndRegionDetails(request);
		if (configuration.kafkaConfig.enable.isUpdateAuth && ((region !== user.region) || (country !== user.country)))
		{
			const regionNotificationObj = await notificationService.createRegionNotification(
				user,
				{ region, country }
			);
			kafkaService.pushEventToKafka(configuration.kafkaConfig.topic.updateAuthData, regionNotificationObj);
		}
		console.info(`tokenvalidator()::Forgot Passsword token verified for uid : ${decoded.uid}`);
		next();
	} catch (error) {
		console.error(error.message);
		if (error.message == errorConfig.expiredProfileToken.description)
			return response.status(401).send(apiResponse.error(errorConfig.expiredProfileToken.description, errorConfig.expiredProfileToken.code));
		return response.status(400).send(apiResponse.error(errorConfig.invalidAccessToken.description, errorConfig.invalidAccessToken.code));

	}
}
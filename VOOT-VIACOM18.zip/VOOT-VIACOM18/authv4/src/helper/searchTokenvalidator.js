
const errorConfig = require("../config").errorConfig;
const apiResponse = require("../utils").apiResponse;
const config = require("../config").configuration;
const verifyToken = require("../services/AnonymousTokenService").verifyToken;

module.exports = searchTokenValidator;
async function searchTokenValidator(request, response, next) {
	console.log("Reached search Token Validator");
	const headers = request.headers;
	try {

		console.info(JSON.stringify(headers));
		if (!headers.accesstoken) {
			console.error("searchTokenvalidator()::Access token not available in header");
			throw ({ message: errorConfig.invalidRequestHeader });
		}
		//config.searchDetails.jwt.secret.access
		console.log("INSIDE SEARCH VALIDATOR");
		const { decoded} = await verifyToken(headers.accesstoken,config.internalServiceAPI.jwt.secret.access , null, "searchDetails");
		console.info(`searchTokenvalidator()::Access token verified for uid : ${decoded}`);
		next();
	} catch (error) {
		console.log(error);
		if (error.message == errorConfig.expiredProfileToken.description)
			return response.status(401).send(apiResponse.error(errorConfig.expiredProfileToken.description, errorConfig.expiredProfileToken.code));
		return response.status(400).send(apiResponse.error(errorConfig.invalidAccessToken.description, errorConfig.invalidAccessToken.code));
	}
}
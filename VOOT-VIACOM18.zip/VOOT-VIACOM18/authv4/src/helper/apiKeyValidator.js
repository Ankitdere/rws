const apiKeyModel = require("../models/index").apiKeyValidator;
const commonUtils = require("../utils").common;
const errorUtilities = require("../config").errorConfig;
const { apiResponse } = require("../utils");
const Config = require("../config").configuration;
const mixpanelConfig = require("../config/mixPanelConfig");
const _ = require("lodash");
module.exports = { apiKeyvalidator };
async function apiKeyvalidator(request, response, next) {
	let eventBaseName = "";
	if (_.get(request, "path") === "/token") eventBaseName = mixpanelConfig.token;
	else if (_.get(request, "path") === "/token/verify") eventBaseName = mixpanelConfig.tokenVerify;
	else if (_.get(request, "path") === "/token/refresh") eventBaseName = mixpanelConfig.tokenRefresh;
	let params = {};
	try {
		let partnerName;
		console.log("Reached middleware for ApiKey Validator");
		const headers = request.headers;
		const XVootVendorAuthorization = request.header("X-Voot-Vendor-Authorization");
		if(_.has(headers,"x-voot-vendor-authorization") && _.isEmpty(XVootVendorAuthorization))
		{
			return response.status(400).send(apiResponse.error(errorUtilities.invalidXVootVendorAuthorization.description, errorUtilities.invalidXVootVendorAuthorization.code,eventBaseName+mixpanelConfig.clientValidation_Error,params,params.clientId,400));    
		}
		if(!_.isEmpty(XVootVendorAuthorization))
		{
			let decodedValue=await decode(XVootVendorAuthorization.split(" ")[1]);
			request.body.clientId=decodedValue["data"].toString().split(":")[1];
			request.body.apiKey=decodedValue["data"].toString().split(":")[2];
			request.body.grantType=decodedValue["data"].toString().split(":")[0]; 
			if(_.isEmpty(request.body.clientId) || _.isEmpty(request.body.apiKey) || _.isEmpty(request.body.grantType))
			{
				return response.status(400).send(apiResponse.error(errorUtilities.invalidXVootVendorAuthorization.description, errorUtilities.invalidXVootVendorAuthorization.code,eventBaseName+mixpanelConfig.clientValidation_Error,params,params.clientId,400));    
			}  
		}
    
		console.info(JSON.stringify(headers));
		console.log(request.method);
		let method = request.method;
		if (method == "POST") {
			let body = request.body;
			params.grantType = body.grantType;
			params.apiKey = body.apiKey;
			params.clientId = body.clientId;
			if (body.partnerName) partnerName = body.partnerName;
		}
		else if (method == "HEAD") {
			params.grantType = headers.granttype;
			params.apiKey = headers.apikey;
			// source = request.params.source;
			params.clientId = headers.clientid;
		}
		// console.log(grantType, apiKey, source);
		const { error } = apiKeyModel.validateApiKey(params);
		if (error) {
			console.error("\n Error in middleware for ApiKet Validator \n", error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error),0,eventBaseName+mixpanelConfig.clientValidation_Error,params,params.clientId,400));
		}
		if (partnerName && partnerName != Config.AnonymousTokenClientAndPartnerMap[params.clientId]) {
			console.error(`Invaliad Partner Name is provided: partnerName ${ params.partnerName } and ClientId ${ params.clientId }`);
			return response.status(400).send(apiResponse.error(errorUtilities.invalidAnonymosTokenPartnerName.description, errorUtilities.invalidAnonymosTokenPartnerName.code,eventBaseName+mixpanelConfig.clientValidation_Error,params,params.clientId,400));
		}
		console.info("apiKeyvalidator():: verify apikey");
		if (params.apiKey == Config.AnonymousTokenClientIdApiKey[params.clientId]) {
			next();
		}
		else {
			return response.status(400).send(apiResponse.error(errorUtilities.invalidAnonymosTokenInvalidApikey.description, errorUtilities.invalidAnonymosTokenInvalidApikey.code,eventBaseName+mixpanelConfig.clientValidation_Error,params,params.clientId,400));
		}
	} catch (error) {
		console.error(error.message);
		if (error.message == errorUtilities.expiredProfileToken.description)
			return response.status(401).send(apiResponse.error(errorUtilities.expiredProfileToken.description, errorUtilities.expiredProfileToken.code,eventBaseName+mixpanelConfig.clientValidation_Error,params,params.clientId,400));
		if (error.code == errorUtilities.decodeXAuthTokenError.code)
			return response.status(400).send(apiResponse.error(errorUtilities.invalidXVootVendorAuthorization.description, errorUtilities.invalidXVootVendorAuthorization.code,eventBaseName+mixpanelConfig.clientValidation_Error,params,params.clientId,400));    
		return response.status(400).send(apiResponse.error(errorUtilities.invalidAccessToken.description, errorUtilities.invalidAccessToken.code,eventBaseName+mixpanelConfig.clientValidation_Error,params,params.clientId,400));
	}
}
async function decode(encoded) {
	try {
		// Initialize
		let decoded = null;

		// Decode
		decoded = Buffer.from(encoded, "base64").toString("ascii");
        
		// eslint-disable-next-line no-undef
		return Promise.resolve({ code: 200, message: "Successfully decoded Base64 string.", data: decoded });
	} catch (error) {
		// eslint-disable-next-line no-undef
		return Promise.reject({ code: 409, message: "An error occured while decoding from Base64: " + error });
	}
}
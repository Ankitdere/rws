
const errorConfig = require("../config").errorConfig;
const apiResponse = require("../utils").apiResponse;
const tokenService = require("../services").tokenService;
const mixPanelConfig = require("../config/mixPanelConfig");
const _ = require("lodash");
const { ipService, notificationService, kafkaService} = require("../services");
const {configuration} = require("../config");

module.exports = tokenvalidator;
async function tokenvalidator(request, response, next) {
	console.debug("Reached Token Validator");
	const headers = request.headers;
	try {
		console.info(JSON.stringify(headers));
		if (!headers.accesstoken) {
			console.error("tokenvalidator()::Access token not available in header");
			throw ({ message: errorConfig.invalidRequestHeader });
		}
		
		const {
			decoded, user, subProfileData = null,
		} = await tokenService.verifyToken(headers.accesstoken);
		request.userToken = user;
		request.tokenInfo = decoded;
		const { region, country } = await ipService.getCountryAndRegionDetails(request);
		request.headers.region = region;
		request.headers.country = country;
		if (configuration.kafkaConfig.enable.isUpdateAuth && (region !== user.region || country !== user.country))
		{ 
			//check for region and push into the kafka queue
			const notificationObj = await notificationService.createRegionNotification(
				user,
				{
					region,
					country
				}
			);
			kafkaService.pushEventToKafka(configuration.kafkaConfig.topic.updateAuthData, notificationObj);
		}
		
		if (subProfileData !== null) request.subProfileData = subProfileData;

		console.info(`tokenvalidator()::Access token verified for uid : ${decoded["uid"]}`);
		next();
	} catch (error) {
		console.error(error.message);
		if (error.message == errorConfig.expiredProfileToken.description)
			return response.status(401).send(apiResponse.error(errorConfig.expiredProfileToken.description, errorConfig.expiredProfileToken.code,mixPanelConfig.tokenValidation+mixPanelConfig.error,{originalUrl:_.get(request,"originalUrl",headers),headers:headers, input:_.get(request,"input")},_.get(headers,"uid","No_Uid"),400));
		return response.status(400).send(apiResponse.error(errorConfig.invalidAccessToken.description, errorConfig.invalidAccessToken.code,mixPanelConfig.tokenValidation+mixPanelConfig.error,{originalUrl:_.get(request,"originalUrl",headers), input:_.get(request,"input"),headers:headers},_.get(headers,"uid","No_Uid"),400));
	}
}
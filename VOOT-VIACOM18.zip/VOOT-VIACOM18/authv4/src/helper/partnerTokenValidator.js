
const {errorConfig,configuration ,mixpanelEvent} = require("../config");
const apiResponse = require("../utils").apiResponse;
const tokenService = require("../services").tokenService;
const _ = require("lodash");
module.exports = partnerTokenValidator;

async function partnerTokenValidator(request, response, next) {
	try {
		console.log("Reached Partner Token Validator");
		const headers = request.headers;
		const input = request.body;
		const typeArr = ["Tata-Sky", "M2MIT"];
		let token = request.header("x-partner-token");
		if (!_.has(input, "partnerName")) {
			return response.status(400).send(apiResponse.error("partnerName is required",2010 ,mixpanelEvent.partnerNotification+_.get(input,"partnerName","")+mixpanelEvent.clientValidation_Error,input,_.get(input.data,"uniqueId",""),400,false ));
		}
		if (_.isEmpty(input.partnerName)) {
			return response.status(400).send(apiResponse.error("partnerName is not allowed to be empty", 2010,mixpanelEvent.partnerNotification+_.get(input,"partnerName","")+mixpanelEvent.clientValidation_Error,input,_.get(input.data,"uniqueId",""),400,false ));
		}
		else if (!_.includes(typeArr, input.partnerName)) {
			return response.status(400).send(apiResponse.error("partnerName must be one of the type [Tata-Sky,M2MIT]",2010,mixpanelEvent.partnerNotification+_.get(input,"partnerName","")+mixpanelEvent.clientValidation_Error,input,_.get(input.data,"uniqueId",""),400,false )) ;
		}
      
		if (input.partnerName == configuration.tSkyDetails.partnerType) {
			const ip = _.get(headers, "true-client-ip") || _.get(headers, "True-Client-IP") || _.get(headers, "x-appengine-user-ip");
			if (configuration.tSkyDetails.whiteListIp) {
				if (!(configuration.tSkyDetails.whiteListIp.includes(ip))) {
					return response.status(401).send(apiResponse.error("No Permission to Access.", 2012,mixpanelEvent.partnerNotification+_.get(input,"patnerName","")+mixpanelEvent.clientValidation_Error,input,_.get(input.data,"uniqueId",""),400,false ));
				}
			}
		}
		if (!token) {
			console.error("tokenvalidator()::Access token not available in header");
			return response.status(401).send(apiResponse.error(errorConfig.partnerTokenNotProvided.description, errorConfig.partnerTokenNotProvided.code,mixpanelEvent.partnerNotification+_.get(input,"partnerName","")+mixpanelEvent.clientValidation_Error,input,400,false ));
		}
		const  decoded = await tokenService.verifyPartnerToken(token,input.partnerName);
		request.tokenInfo = decoded;
       
		next();
	} catch (error) {
		console.log("My error",error);
		console.error(error.message);
		if (error.message == errorConfig.invalidPartnerToken.description) {
			return response.status(401).send(apiResponse.error(errorConfig.invalidPartnerToken.description, errorConfig.invalidPartnerToken.code,mixpanelEvent.partnerNotification+_.get(request.body,"partnerName","")+mixpanelEvent.clientValidation_Error,{token:request.header("x-partner-token"),body:request.body},_.get(request.body.data,"uniqueId"),401,false ));
		}
		else if (error.message == errorConfig.partnerTokenNotProvided.description) {
			return response.status(401).send(apiResponse.error(errorConfig.partnerTokenNotProvided.description, errorConfig.partnerTokenNotProvided.code,mixpanelEvent.partnerNotification+_.get(request.body,"partnerName","")+mixpanelEvent.clientValidation_Error,{token:request.header("x-partner-token"),body:request.body},_.get(request.body.data,"uniqueId"),401,false ));
		}        
		return response.status(400).send(apiResponse.error(errorConfig.invalidPartnerToken.description, errorConfig.invalidPartnerToken.code,mixpanelEvent.partnerNotification+_.get(request.body,"partnerName","")+mixpanelEvent.clientValidation_Error,{token:request.header("x-partner-token"),body:request.body},_.get(request.body.data,"uniqueId"),401,false ));
	}
}

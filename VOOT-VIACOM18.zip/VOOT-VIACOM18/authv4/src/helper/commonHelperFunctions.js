const userProfileService =require("../services/usersProfile");
const _ =require("lodash");
const moment = require("moment");
module.exports = {
	setDocumentTimeStamp
};

async function setDocumentTimeStamp(uId = "", createdAtCheck = ""){
	try{
		if(_.isEmpty(uId)){
			return false;
		}
		if(createdAtCheck)
		{
			let storeData = {};
			switch(createdAtCheck){
			case "Cancel":
				storeData = {cancelledAt:moment().utcOffset(+530).unix()};
				break;
			case "Register":
				storeData = {createdAt:moment().utcOffset(+530).unix()};
				break;
			case "Activate":
				storeData = {activatedAt:moment().utcOffset(+530).unix()};
				break;
			default:
				storeData = {renewedAt:moment().utcOffset(+530).unix()};
				break;                                
			}                  
			await userProfileService.updateUserInformation({uid:uId},storeData);
          
			return true;
		}
		return true;
	}catch(err){
		console.log(err);
		return false;
	}
        
}
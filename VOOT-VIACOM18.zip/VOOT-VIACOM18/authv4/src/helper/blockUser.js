const { configuration, errorConfig } = require("../config");
const { apiResponse } = require("../utils");
const mixpanelConfig = require("../config/mixPanelConfig");
const _ = require("lodash");
const apiNameConst = Object.freeze({login:"login",signUp:"sign-up"});
module.exports = { blockUser };

function blockUser(request, response, next) {
	try {
		if(request.hasOwnProperty("custom_error")===true)
			return response.status(400).send(apiResponse.error(request.custom_error,400));

		if(request.hasOwnProperty("body")===false || Object.keys(request.body).length == 0){
			return response.status(400).send(apiResponse.error(errorConfig.requestBody,400));
		}else{
			if(request.body.hasOwnProperty("data")==false){
				return response.status(400).send(apiResponse.error(errorConfig.requestBodyData,400));
			}
			const { deviceId } = request.body;
			const { email, mobile, countryCode } = request.body.data;
			let distinctId = (email) ? email : `${ countryCode }${ mobile }`;
			if (configuration.blockUserList.includes(deviceId)) {
				console.log("Block user in block user middleware");
				let apiName = _.get(request, "path", "").toLowerCase().split("/")[1];
				if (apiName==apiNameConst.login) {
					return response.status(400).send(apiResponse.error(errorConfig.wrongPassword.description, errorConfig.wrongPassword.code,mixpanelConfig.blockUser+mixpanelConfig.clientValidation_Error,request.body,distinctId,400));
				} else if (apiName == apiNameConst.signUp) {
					return response.status(400).send(apiResponse.error(errorConfig.emailAlreadyRegistered.description, errorConfig.emailAlreadyRegistered.code,mixpanelConfig.blockUser+mixpanelConfig.clientValidation_Error,request.body,distinctId,400));
				}
			}
		}
		next();
	} catch (err) {
		console.log("error in block", err);
		next();
	}
}
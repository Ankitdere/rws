const { configuration } = require("../config");
const { apiResponse } = require("../utils");

module.exports = { blockPartner };

function blockPartner(request, response, next) {
	try {
		console.info("Reached block Partner middleware");
		const input = request.body;
		if (configuration.blockPartnerConfig.partnerName.includes(input.partnerName)) {
			if (configuration.blockPartnerConfig.actionType.includes(input.action)) {
				return response.status(400).send(apiResponse.error("This Partner is not allowed to do further action", 2010));
			}
		}
		next();
	} catch (err) {
		console.log("Error in blocking Partner", err);
	}
}
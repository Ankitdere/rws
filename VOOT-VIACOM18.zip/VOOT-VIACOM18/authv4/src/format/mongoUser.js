"use strict";
const randomId = require("randomstring");
const generateHash = require("../utils/firebaseHash").generateHash;
const _ = require("lodash");
module.exports = {
	initFormatTraditionalUser,
	initFormatSocailUser,
	initFormatMobileUser,
	updateFormatTraditionalUser,
	updateFormatSocailUser,
	generatePasswordHashAndSalt,
	initFormatForOtherPartner,
	initFormatForFirebaseOtherPartner,
	initFormatAmazoneUser,
	initFormatExistingSocailUser,
	providedMobileCollection,
	initFormatMobileUserByUid
};

async function initFormatTraditionalUser(input) {
	let uid = randomId.generate({
		length: 28,
		charset: "alphanumeric"
	});
	let salt = randomId.generate({
		length: 8,
		charset: "alphanumeric"
	});
	let passwordHash = await generateHash(input.data.password, salt);
	let date = new Date().toGMTString();
	let userAuthMongo = {
		uid,
		email: input.data.email,
		emailVerified: false,
		customClaims: {
			customUid: uid
		},
		metadata: {
			creationTime: date,
			lastSignInTime: date
		},
		passwordHash: passwordHash,
		passwordSalt: salt,
		providerData: [{
			uid,
			displayName: "",
			email: input.data.email,
			photoURL: "",
			providerId: "password"
		}]
	};
	return userAuthMongo;
}

async function generatePasswordHashAndSalt(password) {
	let salt = randomId.generate({
		length: 8,
		charset: "alphanumeric"
	});
	let passwordHash = await generateHash(password, salt);
	let generatedData = {
		passwordHash: passwordHash,
		passwordSalt: salt,
	};
	return generatedData;
}

async function initFormatSocailUser(authData, isFacebook, isApple = false, isAmazon = false) {
	let uid = randomId.generate({
		length: 28,
		charset: "alphanumeric"
	});
	let date = new Date().toGMTString();
	let userAuth = {
		uid,
		email: authData.email || `${uid}@voot.com`,
		emailVerified: false,
		customClaims: {
			customUid: uid
		},
		metadata: {
			creationTime: date,
			lastSignInTime: date
		},
		passwordHash: "",
		passwordSalt: "",
		providerData: [{
			uid: authData.id,
			displayName: authData.name,
			email: authData.email,
			photoURL: authData.picture
		}],
	};
	if (isFacebook) {
		userAuth.providerData[0].providerId = "facebook.com";
		userAuth.providerData[0].fbuid = authData.id;
		userAuth.fbuid = authData.id;
	} else if (isApple) {
		userAuth.providerData[0].providerId = "apple.com";
		userAuth.providerData[0].appleid = authData.sub;
		userAuth.appleid = authData.sub;
	} else if (isAmazon) {
		userAuth.providerData[0].providerId = "amazon.com";
		userAuth.phoneNumber = authData.phoneNumber;

	}
	else {
		userAuth.providerData[0].providerId = "google.com";
		userAuth.providerData[0].guid = authData.id;
		userAuth.guid = authData.id;
	}
	return userAuth;
}



async function updateFormatTraditionalUser(userAuth, input) {
	let date = new Date().toGMTString();
	let salt = randomId.generate({
		length: 8,
		charset: "alphanumeric"
	});
	let passwordHash = await generateHash(input.data.password, salt);
	let providerData = userAuth.providerData;
	providerData.push({
		uid: userAuth.uid,
		displayName: "",
		email: userAuth.email,
		photoURL: "",
		providerId: "password"
	});
	let updateUserAuth = {
		uid: userAuth.uid,
		email: userAuth.email,
		emailVerified: false,
		customClaims: {
			customUid: userAuth.uid
		},
		metadata: {
			creationTime: userAuth.metadata.creationTime,
			lastSignInTime: date
		},
		passwordHash: passwordHash,
		passwordSalt: salt,
		providerData: providerData,
		guid: _.get(userAuth, "guid"),
		fbuid: _.get(userAuth, "fbuid"),
		appleid: _.get(userAuth, "appleid")
	};
	return updateUserAuth;
}

async function updateFormatSocailUser(userAuth, isFacebook, authData) {
	let date = new Date().toGMTString();
	let providerData = userAuth.providerData;
	let providerId = "google.com";
	if (isFacebook)
		providerId = "facebook.com";

	providerData.push({
		uid: authData.uid,
		displayName: authData.name,
		email: userAuth.email || authData.email,
		photoURL: authData.photoURL,
		providerId: providerId
	});

	let updateUserAuth = {
		uid: userAuth.uid,
		email: userAuth.email || authData.email,
		emailVerified: false,
		customClaims: {
			customUid: userAuth.uid
		},
		metadata: {
			creationTime: userAuth.metadata.creationTime,
			lastSignInTime: date
		},
		passwordHash: userAuth.passwordHash,
		passwordSalt: userAuth.salt,
		providerData: providerData
	};

	if (isFacebook)
		updateUserAuth.fbuid = authData.uid;
	else
		updateUserAuth.guid = authData.uid;

	return updateUserAuth;
}

async function initFormatForOtherPartner(authData, name) {
	if (name == "tata-sky") {
		name = "tatasky";
	}
	let uid = randomId.generate({
		length: 28,
		charset: "alphanumeric"
	});
	let date = new Date().toGMTString();
	let Email = `${uid}@${name}.com`;
	let userAuth = {
		uid,
		email: authData.email || `${uid}@${name}.com`,
		emailVerified: false,
		customClaims: {
			customUid: uid
		},
		metadata: {
			creationTime: date,
			lastSignInTime: date
		},
		passwordHash: "",
		passwordSalt: "",
		providerData: [{
			uid: uid,
			displayName: authData.partnerDisplayName,
			email: Email,
		}],
	};
	if (name == "jio") {
		userAuth.providerData[0].providerId = "jio.com";
		userAuth.jiouid = uid;
		userAuth.providerData[0].externalId = _.get(authData.data, "externalId", "");
	} else if (name == "tatasky" || name == "tata-sky") {
		userAuth.providerData[0].providerId = "tatasky.com";
		userAuth.providerData[0].uniqueId = _.get(authData.data, "uniqueId", "");
		userAuth.providerData[0].externalId = _.get(authData.data, "externalId", "");
		userAuth.providerData[0].dsn = _.get(authData.data, "dsn", "");
		userAuth.tskyuid = uid;
	}
	return userAuth;
}
async function initFormatForFirebaseOtherPartner(uid, authData, name, partnerData = "") {

	if (name == "tata-sky") {
		name = "tatasky";
	}
	let date = new Date().toGMTString();
	let Email = `${uid}@${name}.com`;
	let userAuth = {
		uid,
		email: _.get(authData, "email", `${uid}@${name}.com`),
		emailVerified: false,
		customClaims: {
			customUid: uid
		},
		metadata: {
			creationTime: date,
			lastSignInTime: date
		},
		passwordHash: "",
		passwordSalt: "",
		providerData: [{
			uid: uid,
			displayName: authData.name,
			email: Email,
		}],
	};
	if (name == "jio") {
		userAuth.providerData[0].providerId = "jio.com";
		userAuth.providerData[0].externalId = _.get(authData, "externalId", "");
		userAuth.jiouid = uid;
	} else if (name == "tatasky" || name =="tata-sky" || name =="Tata-Sky") {
		userAuth.providerData[0].providerId = "tatasky.com";
		userAuth.providerData[0].uniqueId = _.get(authData.data, "uniqueId", _.get(partnerData, "uniqueId", ""));
		userAuth.providerData[0].externalId = _.get(authData.data, "externalId", _.get(partnerData, "externalId", ""));
		userAuth.providerData[0].dsn = _.get(authData.data, "dsn", _.get(partnerData, "deviceId", ""));
		userAuth.tskyuid = uid;
	}
	return userAuth;
}
async function initFormatMobileUser(userSignUpData) {
	let uid = randomId.generate({
		length: 28,
		charset: "alphanumeric"
	});
	let salt = randomId.generate({
		length: 8,
		charset: "alphanumeric"
	});
	let passwordHash = await generateHash(_.get(userSignUpData, "password"), salt);
	let date = new Date().toGMTString();
	let userAuthMongo = {
		uid,
		email: userSignUpData.email,
		phoneNumber: _.get(userSignUpData, "mobile", _.get(userSignUpData, "mobile_number")),
		emailVerified: false,
		customClaims: {
			customUid: uid
		},
		metadata: {
			creationTime: date,
			lastSignInTime: date
		},
		passwordHash: passwordHash,
		passwordSalt: salt,
		providerData: [{
			uid,
			displayName: "",
			email: "",
			photoURL: "",
			providerId: "phone",
			phoneNumber: userSignUpData.mobile
		},
		{
			uid,
			displayName: "",
			email: userSignUpData.email,
			photoURL: "",
			providerId: "password",
			phoneNumber: ""
		}]
	};
	// if(AmazoneDetails!=false){
	//     userAuthMongo.providerData.pop();
	//     userAuthMongo.passwordHash='';
	//     userAuthMongo.passwordSalt= '';  
	// }
	console.debug("UserAuth mongo........", userAuthMongo);
	return userAuthMongo;
}
async function initFormatAmazoneUser(userSignUpData,email,profileType="mobile") {
	let uid = randomId.generate({
		length: 28,
		charset: "alphanumeric"
	});
	let salt = randomId.generate({
		length: 8,
		charset: "alphanumeric"
	});
	let passwordHash;
	if (_.has(userSignUpData, "password"))
		passwordHash = await generateHash(_.get(userSignUpData, "password"), salt);
	let date = new Date().toGMTString();
	let userAuthMongo = {
		uid,
		email: email?email:userSignUpData.email,
		phoneNumber:_.get(userSignUpData,"mobile_number",_.get(userSignUpData,"mobile")),
		emailVerified: false,
		customClaims: {
			customUid: uid
		},
		metadata: {
			creationTime: date,
			lastSignInTime: date
		},
		passwordHash: passwordHash ? passwordHash : "",
		passwordSalt: salt,
		providerData: [{
			uid,
			displayName: "",
			email: email,
			photoURL: "",
			providerId: "phone",
			phoneNumber:_.get(userSignUpData,"mobile_number",_.get(userSignUpData,"mobile")),
		},
		{
			uid,
			displayName: "",
			email: email,
			photoURL: "",
			providerId: "password",
			phoneNumber: ""
		}]
	};
	if(email){
		//userAuthMongo.providerData.pop();
		userAuthMongo.passwordHash = "";
		userAuthMongo.passwordSalt = "";
	}
	if(profileType=="email"){
		userAuthMongo.providerData.shift();
		_.unset(userAuthMongo,"phoneNumber");
	}
	console.log("UserAuth mongo........", userAuthMongo);
	return userAuthMongo;
}

async function initFormatExistingSocailUser(authData, uid, isFacebook, isApple = false) {
	// let uid = userData.uid;
	let date = new Date().toGMTString();
	let userAuth = {
		uid,
		email: authData.email || `${uid}@voot.com`,
		emailVerified: false,
		customClaims: {
			customUid: uid
		},
		metadata: {
			creationTime: date,
			lastSignInTime: date
		},
		passwordHash: "",
		passwordSalt: "",
		providerData: [{
			uid: authData.id,
			displayName: authData.name,
			email: authData.email,
			photoURL: authData.picture
		}],
	};
	if (isFacebook) {
		userAuth.providerData[0].providerId = "facebook.com";
		userAuth.providerData[0].fbuid = authData.id;
		userAuth.fbuid = authData.id;
	} else if (isApple) {
		userAuth.providerData[0].providerId = "apple.com";
		userAuth.providerData[0].appleid = authData.sub;
		userAuth.appleid = authData.sub;
	}
	else {
		userAuth.providerData[0].providerId = "google.com";
		userAuth.providerData[0].guid = authData.id;
		userAuth.guid = authData.id;
	}
	return userAuth;
}

async function providedMobileCollection(uid,mobile,email){
	let providerData= [{
		uid,
		displayName: "",
		email: "",
		photoURL: "",
		providerId: "phone",
		phoneNumber: mobile
	},
	{
		uid,
		displayName: "",
		email: email,
		photoURL: "",
		providerId: "password",
		phoneNumber: ""
	}];
	return providerData;
}

async function initFormatMobileUserByUid ( userSignUpData, uid ) {
	let salt = randomId.generate( {
		length: 8,
		charset: "alphanumeric"
	} );
	let passwordHash = await generateHash( _.get( userSignUpData, "password" ), salt );
	let date = new Date().toGMTString();
	let userAuthMongo = {
		uid,
		email: userSignUpData.email,
		phoneNumber: _.get( userSignUpData, "mobile", _.get( userSignUpData, "mobile_number" ) ),
		emailVerified: false,
		customClaims: {
			customUid: uid
		},
		metadata: {
			creationTime: date,
			lastSignInTime: date
		},
		passwordHash: passwordHash,
		passwordSalt: salt,
		providerData: [ {
			uid,
			displayName: "",
			email: "",
			photoURL: "",
			providerId: "phone",
			phoneNumber: userSignUpData.mobile
		},
		{
			uid,
			displayName: "",
			email: userSignUpData.email,
			photoURL: "",
			providerId: "password",
			phoneNumber: ""
		} ]
	};
	console.debug( "UserAuth mongo........", userAuthMongo );
	return userAuthMongo;
}
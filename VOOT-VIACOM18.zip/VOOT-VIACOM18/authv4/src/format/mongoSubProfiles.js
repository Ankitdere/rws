"use strict";
const randomId = require("randomstring");
const _ = require("lodash");
const config = require("../config").configuration;
const { common } = require("../utils");
const Constant = require("../utils/constant/generic");
const tokenService = require("../services/tokenService");
const commonUtil = require("../utils").common;
const ipService = require("../services/ipService");

module.exports = {
	initFormatSubProfile,
	getAllSubProfileFormat,
	initFormatSubProfileUpdate,
	createSubProfileResponse,
	updateSubProfileResponse
};

/**
 * 
 * @param {Object} input 
 * @param {Object} userData 
 * @returns {Object}
 */
async function initFormatSubProfile(input, request) {
	const { userToken, tokenInfo } = request;
	const uid = tokenInfo.uid;
	const childUid = randomId.generate({
		length: 28,
		charset: "alphanumeric"
	});
	const deviceId = tokenInfo.deviceId;
	const ProfileName = input.profilename;
	const BirthDate = input.birthdate || _.get(userToken, "profileData.BirthDate", "");
	const languages = input.languages || _.get(userToken, "profileData.Preferences.Languages", "");
	const isPrimary = false;
	const Gender = input.gender || _.get(userToken, "profileData.Gender", "");
	const userAuthMongo = {
		uid,
		childUid,
		ProfileName,
		BirthDate,
		languages,
		Gender,
		isPrimary,
		deviceId
	};
	return userAuthMongo;
}

/**
 * 
 * @param {Object} input 
 * @returns {Object}
 */
async function initFormatSubProfileUpdate(input) {
	const updateSubProfileData = {};
	if (input.profilename) updateSubProfileData.ProfileName = input.profilename;
	if (input.birthdate) updateSubProfileData.BirthDate = input.birthdate;
	if (input.gender) updateSubProfileData.Gender = input.gender;
	if (input.languages) updateSubProfileData.languages = input.languages;
	return updateSubProfileData;
}

/**
 * 
 * @param {Object} subProfileData  
 * @param {Object} request 
 * @returns {Object}
 */
async function getAllSubProfileFormat(subProfileData, request,userProfileData="") {
	const { userToken, tokenInfo } = request;
	const finalOutput = [];
	const uid = tokenInfo.uid;
	let profileName = _.get(userToken, "profileData.ProfileName", "");
	if (profileName === "") profileName = _.get(userToken, "profileData.FirstName", "") + " " + _.get(userToken, "profileData.LastName", "");
	let BirthDate = common.dateFormat(_.get(userToken, "profileData.BirthDate", ""));
	if (_.isEmpty(BirthDate)) {
		BirthDate = config.defaultDateOfBirth;
	}
	let Age = "" + new Date().getFullYear() - Number(BirthDate.split("-")[2]) + "";
	const Gender = _.get(userToken, "profileData.Gender", "");
	let languages = _.get(userToken, "profileData.Preferences.Languages",config.DefaultProfileLanguages);
	if (typeof languages === "string") {
		languages = languages.split(",");
	}
	if (_.isEmpty(languages)) {
		languages = config.DefaultProfileLanguages;
	}


	const deviceId = tokenInfo.deviceId;
	const response = {
		uId: uid,
		childUid: uid,
		profileName: profileName,
		isPrimary: true,   
		birthDate: common.dateFormat(BirthDate),
		age: String(Age),
		gender: Gender,
		languages: languages,
		deviceId: deviceId,
		parentPinMode: {}
	};

	if(	userProfileData && userProfileData.parentPinMode && userProfileData.parentPinMode.isParentPinEnabled){
		response.parentPinMode.isParentPinEnabled= userProfileData.parentPinMode.isParentPinEnabled;
	}
	else{
		response.parentPinMode.isParentPinEnabled=false;
	}
	response.isKidProfile=false;
	if(request.headers && userProfileData.profileData && userProfileData.profileData.BirthDate){
		const birthDate = userProfileData.profileData.BirthDate;
		const { country } = await ipService.getCountryAndRegionDetails(request);
		console.log("country and birthday in getAllSubProfileFormat", birthDate, country ,commonUtil.isKidProfile(birthDate,country) );
		_.set(response, "isKidProfile",commonUtil.isKidProfile(birthDate,country));
	}
	const isParentPinSet=(userProfileData && userProfileData.parentPinMode)? true: false;
	_.set(response, "parentPinMode.isParentPinSet",isParentPinSet);
	finalOutput.push(response);
	if (subProfileData.status === Constant.NO_UID_FOUND) return { data: finalOutput };
	for (let res of subProfileData.data) {
		let dateofBirth = common.dateFormat(res.BirthDate);
		if (_.isEmpty(dateofBirth)) {
			dateofBirth = config.defaultDateOfBirth;
		}
		let Age = "" + new Date().getFullYear() - Number(dateofBirth.split("-")[2]) + "";
		let lang = _.get(res, "languages",config.DefaultProfileLanguages);
		if (typeof lang === "string") {
			lang = lang.split(",");
		}
		if (_.isEmpty(lang)) {
			lang = config.DefaultProfileLanguages;
		}
		const response = {
			uId: res.uid,
			childUid: res.childUid,
			profileName: res.ProfileName,
			isPrimary: false,  
			birthDate: common.dateFormat(res.BirthDate),
			age: String(Age),
			gender: res.Gender,
			languages: lang,  
			deviceId: res.deviceId,
			isKidProfile: res.isKidProfile,
			parentPinMode: {
			}
		};
		if(	userProfileData && userProfileData.parentPinMode && userProfileData.parentPinMode.isParentPinEnabled){
			response.parentPinMode.isParentPinEnabled= userProfileData.parentPinMode.isParentPinEnabled;
		}
		else{
			response.parentPinMode.isParentPinEnabled=false;
		}
		_.set(response, "parentPinMode.isParentPinSet",isParentPinSet);
		response.isKidProfile=false;
		if(request.headers && res.BirthDate){
			const birthDate = res.BirthDate;
			const { country } = await ipService.getCountryAndRegionDetails(request);
			console.log("country and birthday in getAllSubProfileFormat",
				birthDate,
				country,
				commonUtil.isKidProfile(birthDate,country) );
			_.set(response, "isKidProfile",commonUtil.isKidProfile(birthDate,country));
		}
		finalOutput.push(response);
	}
	return { data: finalOutput };
}

/**
 * 
 * @param {Object} userAuthMongo 
 * @param {Object} tokenInfo 
 * @returns {Object}
 */
async function createSubProfileResponse(userAuthMongo, tokenInfo, { country }) {
	let birthDate = commonUtil.dateFormat(userAuthMongo.BirthDate);
	if (_.isEmpty(birthDate)) {
		birthDate = config.defaultDateOfBirth;
	}
	let ageCalculation = "" + new Date().getFullYear() - Number(birthDate.split("-")[2]) + "";


	//let languages = _.get(userAuthMongo, "languages",[]);
	let languages = _.get(userAuthMongo, "languages",config.DefaultProfileLanguages);
	if (typeof languages === "string") {
		languages = languages.split(",");
	}
	if (_.isEmpty(languages)) {
		languages = config.DefaultProfileLanguages;
	}

	const response = {
		uId: userAuthMongo.uid,
		childUid: userAuthMongo.childUid,
		profileName: userAuthMongo.ProfileName,
		isPrimary: false,
		birthDate: common.dateFormat(birthDate),
		age: String(ageCalculation),
		gender: userAuthMongo.Gender,
		deviceId: userAuthMongo.deviceId,
		languages:languages,
	};
	response.isKidProfile=false;
	if(!_.isEmpty(birthDate)){
		console.log("country and birthday in getAllSubProfileFormat", birthDate, country ,commonUtil.isKidProfile(birthDate,country) );
		_.set(response, "isKidProfile",commonUtil.isKidProfile(birthDate,country));
	}
	_.pullAt(tokenInfo, "exp");
	_.pullAt(tokenInfo, "iss");
	_.pullAt(tokenInfo, "iat");
	_.pullAt(tokenInfo, "TncAgreement");
	tokenInfo.childUid = userAuthMongo.childUid;
	let authToken = await tokenService.createAccessTokenAndRefreshToken(tokenInfo);
	_.set(response, "authToken", authToken);
	return response;
}

/**
 * 
 * @param {Object} userData 
 * @param {Object} tokenInfo 
 * @returns {Object}
 */
async function updateSubProfileResponse(userData, tokenInfo,{ country }) {
	let birthDate = common.dateFormat(_.get(userData, "BirthDate"));
	if (_.isEmpty(birthDate)) {
		birthDate = config.defaultDateOfBirth;
	}
	let ageCalculation = "" + new Date().getFullYear() - Number(birthDate.split("-")[2]) + "";
	//let languages = _.get(userData, "languages",[]);
	let languages = _.get(userData, "languages",config.DefaultProfileLanguages);
	if (typeof languages === "string") {
		languages = languages.split(",");
	}
	if (_.isEmpty(languages)) {
		languages = config.DefaultProfileLanguages;
	}

	const response = {
		uId: tokenInfo.uid,
		childUid: userData.childUid,
		profileName: _.get(userData, "ProfileName"),
		isPrimary: false,
		birthDate: common.dateFormat(birthDate),
		age: String(ageCalculation),
		gender: _.get(userData, "Gender"),
		deviceId: tokenInfo.deviceId,
		languages: languages
	};
	response.isKidProfile=false;
	if(!_.isEmpty(birthDate)){
		console.log("country and birthday in getAllSubProfileFormat", birthDate, country ,commonUtil.isKidProfile(birthDate,country) );
		_.set(response, "isKidProfile",commonUtil.isKidProfile(birthDate,country));
	}
	return response;
}




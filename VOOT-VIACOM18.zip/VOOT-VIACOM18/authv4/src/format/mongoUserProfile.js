"use strict";
const config = require("../config").configuration;
const _ = require("lodash");
const moment = require("moment");
const uuidv1 = require("uuid/v1");

module.exports = {
	initFormatUserProfileTraditional,
	initFormatUserProfileSocail,
	fillLanguages,
	initFormatForUserProfileSocail,
	initorUpdateProfilePartner
};

function initFormatUserProfileTraditional(userAuth, input, countryCode) {
	let languages = fillLanguages(input);
	if (!_.has(input,"tncVersion") || _.isEmpty(input,"tncVersion")) {
		console.debug("tncVersion and tncAcceptTime is blank", input.tncVersion);
		// if tncVersion is empty then both value will null
		input.tncAcceptTime = "";input.tncVersion="";
	}else{
		input.tncAcceptTime = Date.now();
	} 
	let userProfileData = {
		uid: _.get(userAuth, "uid"),
		email: _.get(userAuth, "email"),
		mobile: _.get(userAuth, "phoneNumber", ""),
		profileData: {
			ProfileName: _.get(input, "profilename", ""),
			Age: _.get(input, "age", ""),
			BirthDate: _.get(input, "birthdate"),
			City: _.get(input, "city", ""),
			Currency: _.get(input, "currency", ""),
			FirstName: _.get(input, "firstname", ""),
			FullName: _.get(input, "fullname", ""),
			Gender: _.get(input, "gender", ""),
			Imageurl: _.get(input, "imageurl", ""),
			LastName: _.get(input, "lastname", ""),
			Preferences: { Languages: languages },
			CountryCode: _.get(input, "countryCode", countryCode),
			Mobile: _.get(input, "mobile", ""),
			TncVersion: _.get(input, "tncVersion", ""),
			TncAcceptTime: _.get(input, "tncAcceptTime", ""),
			uid: _.get(userAuth, "uid"),
			isFirstLogin: _.get(input, "IsFirstLogin", true),
			NormalUser: {
				IsEmailSubscribed: "false",
				RegistrationProvider: "password",
				AccessToken: uuidv1()
			},
			//isProfileUpdated: false
		},
		createdAt:  moment().utcOffset(+530).unix()   
	};
	return userProfileData;
}

function fillLanguages(input) {
    
	if (_.isEmpty(_.get(input, "languages"))){
		return _
			.chain(_.get(input, "languages", config.DefaultProfileLanguages))
			.concat(config.DefaultProfileLanguages)
			.uniq()
			.value();
	} else {
		return _
			.chain(_.get(input, "languages",config.DefaultProfileLanguages))
			.uniq()
			.value();
	}
}

function initFormatUserProfileSocail(userAuth, fbData, countryCode) {
	let languages = fillLanguages({});
	let userProfileData = {
		uid: _.get(userAuth, "uid"),
		email: _.get(userAuth, "email"),
		profileData: {
			ProfileName: _.get(fbData, "name", ""),
			Age: _.get(fbData, "age", ""),
			BirthDate: _.get(fbData, "birthdate"),
			City: _.get(fbData, "city", ""),
			Currency: _.get(fbData, "currency", ""),
			FirstName: _.get(fbData, "firstname", ""),
			FullName: _.get(fbData, "name", ""),
			Gender: _.get(fbData, "gender", ""),
			Imageurl: _.get(fbData, "picture", ""),
			LastName: _.get(fbData, "lastname", ""),
			Preferences: { Languages: languages },
			CountryCode: _.get(fbData, "countryCode", countryCode),
			mobile: _.get(fbData, "mobile", ""),
			uid: _.get(userAuth, "uid"),
			isProfileUpdated: _.get(userAuth, "isProfileUpdated")

		}
	};
	return userProfileData;
}

function initFormatForUserProfileSocail(input = "", email = "", googleData = "", facebookData = "", appleData = "",amazonData="") {
	const inputData = input.data;
	inputData.languages = fillLanguages(inputData);
	const data = [];
	if (!_.has(inputData, "tncVersion") || _.isEmpty(inputData, "tncVersion")) {
		console.debug("tncVersion and tncAcceptTime is blank", inputData.tncVersion,googleData,facebookData);
		// if tncVersion is empty then both value will null
		inputData.tncAcceptTime = ""; inputData.tncVersion = "";
	} else {
		inputData.tncAcceptTime = Date.now();
	}

	if (inputData.age)
		data.push({ Age: inputData.age });
	if (inputData.birthdate)
		data.push({ BirthDate: inputData.birthdate });
	if (inputData.city)
		data.push({ City: inputData.city });
	if (inputData.currency)
		data.push({ Currency: inputData.currency });
	if (inputData.profilename)
		data.push({ ProfileName: inputData.profilename });
	if (inputData.firstname)
		data.push({ FirstName: inputData.firstname });
	if (inputData.fullname)
		data.push({ FullName: inputData.fullname });
	if (inputData.gender)
		data.push({ Gender: inputData.gender });
	if (inputData.imageUrl)
		data.push({ Imageurl: inputData.imageurl });
	if (inputData.lastname)
		data.push({ LastName: inputData.lastname });
	if (inputData.languages)
		data.push({ Preferences: { Languages: inputData.languages } });
	if (inputData.countryCode)
		data.push({ CountryCode: inputData.countryCode });
	if (inputData.mobile)
		data.push({ mobile: inputData.mobile });
	if (inputData.tncVersion)
		data.push({ TncVersion: inputData.tncVersion });
	if (inputData.tncAcceptTime)
		data.push({ TncAcceptTime: parseInt(inputData.tncAcceptTime) });

	if (input.type === "google") {
		data.push({
			GmailUser: {
				IsEmailSubscribed: "false",
				PhotoUrl: "",//googleData.ImageUrl
				RegistrationProvider: "google",
				GmailId: ""
			}
		});
	} else if (input.type === "mobile") {
		data.push({ Mobile: inputData.mobile });
	} else if (input.type === "facebook") {
		data.push({
			FacebookUser: {
				FacebookId: "", //UID(facebook)  or ID (facebook)
				IsEmailSubscribed: "false",
				PhotoUrl: "",
				RegistrationProvider: "facebook",
			}
		});
	} else if (input.type === "apple") {
		data.push({
			AppleUser: {
				AppleId: appleData.sub, //UID(facebook)  or ID (facebook)
				IsEmailSubscribed: "false",
				PhotoUrl: "",
				RegistrationProvider: "apple",
				Provider: "apple",
				lastLoginDate: moment().format("MMMM Do YYYY, h:mm:ss a"),
				appleAccessToken: appleData.accessToken,
				appleRefreshToken: appleData.refreshToken,
				aud: appleData.aud
			}
		});
	} else if (input.type === "amazon") {
		data.push({
			FullName: _.get(amazonData,"name",""),
			Mobile: _.get(amazonData,"mobile",""),
			ProfileName:_.get(amazonData,"name",""),
			CountryCode: _.get(amazonData,"countryCode",""),
			ProfileType:_.get(amazonData,"profileType",""),
			AmazonDetails: {
				externalId: _.get(amazonData,"externalId"), //UID(facebook)  or ID (facebook)
				IsEmailSubscribed: "false",
				PhotoUrl: "",
				RegistrationProvider: "amazon",
				Provider:"amazon",
				LastLoginDate : moment().format("MMMM Do YYYY, h:mm:ss a"),
				Name: _.get(amazonData,"name",""),
				PostalAddress: _.get(amazonData,"postal_address",""),
				PostalCode: _.get(amazonData,"postal_code",""),
				Mobile_Number:_.get(amazonData,"mobile_number",""),
				Email:_.get(amazonData,"email",""),
				region: _.get(input.data, "region","IN") 
			}
		});
	} else {
		data.push({
			NormalUser: {
				IsEmailSubscribed: "false",
				RegistrationProvider: "password",
				AccessToken: uuidv1()
			}
		});
	}
	//Need to create a auth token
	// data.push({authToken:uuidv1()});
	console.info("Data", data);
	let profileData = {};
	data.forEach(function (temp) {
		profileData = Object.assign(profileData, temp);
	});
	if (!_.has(profileData, "ProfileName") || _.isEmpty(profileData.ProfileName)) {
		_.set(profileData, "ProfileName", _.get(profileData, "FirstName", ""));
	}
	console.debug("profileData", profileData);
	const result = {
		email: email,
		profileData: profileData
	};
	console.log("result", result);
	return result;
}
function initorUpdateProfilePartner(uId, partnerData, newUser, partnerType, lastLoginCount, tempEmail) {
	console.log("***********PartnerData***********", partnerData);
	let profileData;
	let lastLoginDate = moment().format("MMMM Do YYYY, h:mm:ss a");
	let parTnerDataWithoOutSubscription = JSON.parse(JSON.stringify(partnerData));
	// delete parTnerDataWithoOutSubscription.subscription;
	console.log("initorUpdateProfilePartner:parTnerDataWithoOutSubscription : ",parTnerDataWithoOutSubscription);
	if (newUser == false) {
		profileData = {
			partnerType: partnerType,
			...parTnerDataWithoOutSubscription,
			lastLoginDate: lastLoginDate,
			lastLoginCount: lastLoginCount + 1,

		};
	} else {
		profileData = {
			tempEmail: tempEmail,
			partnerType: partnerType,
			...parTnerDataWithoOutSubscription,
			lastLoginDate: lastLoginDate,
			lastLoginCount: 1,
			profileData: {
				Preferences: { Languages: ["Hindi", "English"] },
				Gender: "U"
			},
			uid: uId
		};
	}
	return profileData;
}


"use strict";

const commonUtil = require("../utils").common;
const config = require("../config").configuration;
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");
// const { envConfig } = require('../config');
const configuration = require("../config/configuration");
const apiResponse = require("../utils").apiResponse;
const mixPanelConfig = require("../config/mixPanelConfig");
const tokenService = require("../services/tokenService");
const constant = require("../utils/constant/generic");

module.exports = {
	v3SignUpResponse,
	v3LoginResponse,
	v3ProfileResponse,
	jioSubscriptionResponse,
	responseUpdateProfileData,
	v3UserProfileResponse,
	emailForgotPassResponse,
	phoneNumberResponse,
	emailResponse,
	phoneNumberForgotPassResponse,
	partnerApiResponse,
	v3getPartnerProfileResponse,
	OtpRetriveFormate,
	errorResponseCodeForAnonymous,
	errorResponseCodeForVerifyAnonymous,
	v3SearchApiResponse,
	responseGetLoginDetailsByDeviceId,
	v3UserProfileCommonResponse
};

async function v3SignUpResponse(userAuth, userProfile, deviceId, kalthuraLoginResponse) {
	const tokenService = require("../services").tokenService;
	let birthDate = commonUtil.dateFormat(_.get(userProfile, "profileData.BirthDate", "")) || "";
	if (_.isEmpty(birthDate)) {
		birthDate = config.defaultDateOfBirth;
	}
	let ageCalculation = "" + new Date().getFullYear() - Number(birthDate.split("-")[2]) + "";

	let isPasswordChangeableFlag = false;
	_.findKey(userAuth.providerData, EachItem => {
		if ((_.get(EachItem, "providerId")) == "password") {
			isPasswordChangeableFlag = true;
			return isPasswordChangeableFlag;
		} else {
			isPasswordChangeableFlag = false;
			console.debug("Variable Name", isPasswordChangeableFlag);
		}
	});
	_.set(userProfile, "profileData.IsPasswordChangeable", isPasswordChangeableFlag);
	if (_.isEmpty(userProfile, "profileData.TncVersion")) {
		console.debug("tncVersion and tncAcceptTime is blank", userProfile.profileData.TncVersion);
		// if tncVersion is empty then both value will null
		userProfile.profileData.TncAcceptTime = null;
		// userProfile.profileData.TncAcceptTime = ''; userProfile.profileData.TncVersion = '';
	} else {

		userProfile.profileData.TncAcceptTime = Date.now();
	}
	let fullName;
	if (!_.isEmpty(userProfile.profileData, "FullName")) {
		fullName = _.get(userProfile, "profileData.FullName");
	} else {
		fullName = `${_.get(userProfile, "profileData.FirstName")} ${_.get(userProfile, "profileData.LastName")}`;
	}
	let languages = _.get(userProfile, "profileData.Preferences.Languages", _.get(userProfile, "profileData.preferences.languages", config.DefaultProfileLanguages));
	if (typeof languages === "string") {
		languages = languages.split(",");
	}
	if (_.isEmpty(languages)) {
		languages = config.DefaultProfileLanguages;
	}
	let email = _.get(userProfile, "email") ? _.get(userProfile, "email") : _.get(userAuth, "providerData[0].email");
	let maskEmail = commonUtil.maskEmail(email);
	let phoneNumber = userAuth.phoneNumber;
	let maskMobileNumber = commonUtil.maskMobileNumber(_.get(userAuth, "profileData.Mobile") ? String(_.get(userAuth, "profileData.Mobile")) : String(phoneNumber), _.get(userAuth, "profileData.CountryCode", ""));
	if (_.isEmpty(userAuth.phoneNumber)) {
		phoneNumber = "";
		maskMobileNumber = "";
	}
	if (!_.isEmpty(email) && (email.split("@")[0] == userProfile.uid || _.get(userProfile, "providerData[0].providerId") == "phone")) {
		email = "",
		maskEmail = "";
	}

	const response = {
		uId: userAuth.uid ? userAuth.uid : _.get(userProfile, "uid"),
		email: email,
		mobile: _.get(userProfile, "profileData.Mobile") ? String(_.get(userProfile, "profileData.Mobile")) : String(phoneNumber),
		countryCode: _.get(userProfile, "profileData.CountryCode", ""),
		profileUrl: "",
		age: ageCalculation,
		languages: languages,
		birthDate: birthDate,
		firstName: _.get(userProfile, "profileData.FirstName", ""),
		profileName: _.get(userProfile, "profileData.ProfileName", _.get(userProfile, "profileData.FirstName", "")),
		lastName: _.get(userProfile, "profileData.LastName", ""),
		fullName: fullName ? fullName : `${_.get(userProfile, "profileData.FirstName")} ${_.get(userProfile, "profileData.LastName")}`,
		gender: _.get(userProfile, "profileData.Gender", "U"),
		householdId: _.get(kalthuraLoginResponse, "householdId", 0),
		kUserId: _.get(kalthuraLoginResponse, "kUserId"),
		kTokenId: _.get(kalthuraLoginResponse, "kTokenId"),
		kToken: _.get(kalthuraLoginResponse, "kToken"),
		ks: _.get(kalthuraLoginResponse, "ks"),
		parentKs: _.get(kalthuraLoginResponse, "ks"),
		isTemporaryPassword: false,
		isFirstLogin: _.get(userProfile, "profileData.isFirstLogin", true),
		tncVersion: _.get(userProfile, "profileData.TncVersion", ""),
		tncAcceptTime: parseInt(_.get(userProfile, "profileData.TncAcceptTime", null)),
		subTitle: _.get(userProfile, "profileData.SubTitle", ""),
		isProfileUpdated: _.get(userProfile, "profileData.isProfileUpdated"),
		isPasswordChangeable: _.get(userProfile, "profileData.IsPasswordChangeable", ""),
		maskedIdentity: maskMobileNumber ? maskMobileNumber : maskEmail,
		partnerType: _.get(userProfile, "partnerType", "")
	};

	if (_.trim(response.fullName) == "undefined undefined") {
		_.set(response, "fullName", "");
	}
	if (_.isEmpty(_.trim(response.fullName))) {
		response.fullName = _.get(userAuth, "providerData[0].displayName", "") || "";
		console.debug(_.get(response, "fullName", ""));
		if (_.isEmpty(response.firstName)) {
			response.firstName = _.split(_.get(response, "fullName", ""), " ")[0];
		}
		if (!_.isEmpty(response.fullName) && _.isEmpty(response.lastName)) {
			response.lastName = _.split(_.get(response, "fullName", ""), " ")[1];
		}
	}
	if (_.isEmpty(response.profileName)) {
		response.profileName = _.get(response, "firstName", "");
	}
	if (_.isEmpty(response.email)) {
		response.email = "";
	}
	if (_.isEmpty(response.tncVersion)) {
		response.tncAcceptTime = null;
	}
	if (_.get(userProfile, "profileData.ProfileType") == "email") {
		_.set(response, "mobile", "");
		_.set(response, "countryCode", _.get(userProfile, "profileData.AmazonDetails.Region", ""));
	}
	if (_.isEmpty(response.fullName) && (_.has(userProfile.profileData, "AmazonDetails"))) {
		response.fullName = _.get(userProfile, "profileData.AmazonDetails.name", _.get(userProfile, "profileData.AmazonDetails.Name", ""));
		response.profileName = _.get(userProfile, "profileData.AmazonDetails.name", _.get(userProfile, "profileData.AmazonDetails.Name", ""));
		// {accountData = { ...accountData, ProfileName: response.fullName };
		// console.log('Update_Profile accountData: for uid ::: ', response.uId);}

	}

	let authToken = await tokenService.createAccessTokenAndRefreshToken({ uid: response.uId, email: response.email, deviceId: deviceId, kUserId: _.get(response, "kUserId") });
	// TODO: kUserId: _.get(response, 'kUserId') : Need to add kUserId after kaltura migration in auth token
	_.set(response, "authToken", authToken);
	_.findKey(userAuth.providerData, EachItem => {
		if ((_.get(EachItem, "providerId")) == "phone") {
			_.set(response, "email", "");
		}
	});
	if (response.mobile && (response.mobile.indexOf("+") >= 0)) {
		const { Mobile, CountryCode } = await commonUtil.splitMobileWithCountryCode(response.mobile);
		response.mobile = Mobile;
		response.countryCode = CountryCode;
	}
	return { data: response };
}



async function v3LoginResponse(userAuth, userProfile, input, kalthuraLoginResponse) {
	const tokenService = require("../services").tokenService;
	let email = _.get(userProfile, "email") ? _.get(userProfile, "email") : _.get(userAuth, "providerData[0].email");
	let maskEmail = commonUtil.maskEmail(email);
	let phoneNumber = userAuth.phoneNumber;
	let maskMobileNumber = commonUtil.maskMobileNumber(_.get(userProfile, "profileData.Mobile") ? String(_.get(userProfile, "profileData.Mobile")) : String(phoneNumber), _.get(userProfile, "profileData.CountryCode", ""));
	if (_.isEmpty(userAuth.phoneNumber)) {
		phoneNumber = "";
		maskMobileNumber = "";
	}
	if (!_.isEmpty(email) && (email.split("@")[0] == userProfile.uid || _.get(userProfile, "providerData[0].providerId") == "phone")) {
		email = "",
		maskEmail = "";
	}
	let isTempPassword = _.get(userProfile, "_system", false);
	if (isTempPassword)
		isTempPassword = true;
	let birthDate = commonUtil.dateFormat(_.get(userProfile, "profileData.BirthDate", "")) || "";
	
	if (_.isEmpty(birthDate)) {
		birthDate = config.defaultDateOfBirth;
	}
	let ageCalculation = new Date().getFullYear() - Number(birthDate.split("-")[2]);
	let languages = _.get(userAuth, "profileData.Preferences.Languages", _.get(userProfile, "profileData.preferences.languages", config.DefaultProfileLanguages));
	if (typeof languages === "string") {
		languages = languages.split(",");
	}
	if (_.isEmpty(languages)) {
		languages = config.DefaultProfileLanguages;
	}
	//check for Windows NT 6.3 to uid             
	if (input.deviceBrand.toLowerCase().trim() == "pc/mac") {
		input.deviceId = _.get(userAuth, "uid");
	}
	let isPasswordChangeableFlag = false;
	_.findKey(userAuth.providerData, EachItem => {
		if ((_.get(EachItem, "providerId")) == "password") {
			isPasswordChangeableFlag = true;
			return isPasswordChangeableFlag;
		} else {
			isPasswordChangeableFlag = false;
			console.debug("Variable Name", isPasswordChangeableFlag);
		}
	});


	_.set(userProfile, "profileData.IsPasswordChangeable", isPasswordChangeableFlag);
	const response = {
		uId: userAuth.uid,
		email: email,
		mobile: _.get(userProfile, "profileData.Mobile", _.get(userAuth, "phoneNumber", "")),
		countryCode: _.get(userProfile, "profileData.CountryCode", ""),
		profileUrl: "",
		age: String(ageCalculation),
		languages: languages,
		birthDate: birthDate,
		firstName: _.get(userProfile, "profileData.FirstName", ""),
		profileName: _.get(userProfile, "profileData.ProfileName", _.get(userProfile, "profileData.FirstName", _.get(userProfile, "profileData.FullName", ""))),
		lastName: _.get(userProfile, "profileData.LastName", ""),
		gender: _.get(userProfile, "profileData.Gender", ""),
		fullName: `${_.get(userProfile, "profileData.FirstName", "")} ${_.get(userProfile, "profileData.LastName", "")}`,
		householdId: _.get(kalthuraLoginResponse, "householdId", 0),
		kUserId: _.get(kalthuraLoginResponse, "kUserId"),
		kTokenId: _.get(kalthuraLoginResponse, "kTokenId"),
		kToken: _.get(kalthuraLoginResponse, "kToken"),
		ks: _.get(kalthuraLoginResponse, "ks"),
		parentKs: _.get(kalthuraLoginResponse, "ks"),
		isFirstLogin: _.get(userProfile, "profileData.isFirstLogin", false),
		isTemporaryPassword: isTempPassword,
		tncVersion: _.get(userProfile, "profileData.TncVersion", ""),
		tncAcceptTime: parseInt(_.get(userProfile, "profileData.TncAcceptTime", "")),
		isProfileUpdated: _.get(userProfile, "profileData.isProfileUpdated"),
		subTitle: _.get(userProfile, "profileData.SubTitle", ""),
		isPasswordChangeable: _.get(userProfile, "profileData.IsPasswordChangeable", ""),
		maskedIdentity: maskMobileNumber ? maskMobileNumber : maskEmail,
		partnerType: _.get(userProfile, "partnerType", "")
	};
	if (_.trim(response.fullName) == "undefined undefined") {
		_.set(response, "fullName", "");
	}
	if (_.isEmpty(_.trim(response.fullName))) {
		response.fullName = _.get(userAuth, "providerData[0].displayName");
		console.debug(_.get(response, "fullName", ""));
		response.firstName = _.split(_.get(response, "fullName", ""), " ")[0];
		response.lastName = _.split(_.get(response, "fullName", ""), " ")[1];
		let accountData = null;
		if (response.firstName) accountData = { ...accountData, ProfileName: response.firstName };
		if (response.firstName) accountData = { ...accountData, FirstName: response.firstName };
		if (response.lastName) accountData = { ...accountData, LastName: response.lastName };
		console.debug("Update_Profile accountData: for uid ::: ", response.uId, accountData);

	}
	if (_.get(userProfile, "profileData.ProfileType") == "email") {
		_.set(response, "mobile", "");
		_.set(response, "countryCode", _.get(input, "data.region", ""));
	}
	if (_.isEmpty(response.fullName) && (_.has(userProfile, "profileData.AmazonDetails"))) {
		let accountData = null;
		response.fullName = _.get(userProfile, "profileData.AmazonDetails.name", _.get(userProfile, "profileData.AmazonDetails.Name", ""));
		response.profileName = _.get(userProfile, "profileData.AmazonDetails.name", _.get(userProfile, "profileData.AmazonDetails.Name", ""));
		{
			accountData = { ...accountData, ProfileName: response.fullName };
			console.log("Update_Profile accountData: for uid ::: ", response.uId, accountData);
		}


	}
	if (_.isEmpty(response.profileName)) {
		response.profileName = response.firstName;
	}

	// TODO : kUserId: _.get(response, 'kUserId'),
	if (response.isProfileUpdated == undefined) {  //removed isProfileUpdated for existing user     
		delete response.isProfileUpdated;
	}
	let authToken = await tokenService.createAccessTokenAndRefreshToken({ uid: response.uId, email: response.email, deviceId: _.get(input, "deviceId"), kUserId: _.get(response, "kUserId") });
	_.set(response, "authToken", authToken);
	_.findKey(userAuth.providerData, EachItem => {
		if ((_.get(EachItem, "providerId")) == "phone") {
			_.set(response, "email", "");
		}
	});
	return { data: response };
}

/**
 * @param {Object} options
 */
function getTataSkyBrandingChanges(options) {
	let response = {};

	if (Object.hasOwnProperty.call(options, "email") === true) {
		let { email: customerEmail = "" } = options;
		response.email = customerEmail;
		const { oldEmailSuffix = [], newEmailSuffix = "" } = configuration.tSkyDetails;
		const isValidEmail = (customerEmail !== "") && (customerEmail.length > 0);

		if (isValidEmail) {
			const suffix = oldEmailSuffix.filter((item) => customerEmail.indexOf(item) !== -1);
			const emailTobeUpdated = suffix.length && suffix[0];
			
			if (emailTobeUpdated) {
				customerEmail = customerEmail.replace(suffix[0], newEmailSuffix);
				response.email = customerEmail;
			}
		}
	}
	return response;
}

/**
 * @param {Object} user 
 * @param {Object} userRecords 
 * @returns {Object}
 */
async function v3ProfileResponse(user, userRecords, headers) {
	let birthDate = commonUtil.dateFormat(_.get(user, "profileData.BirthDate", ""));
	if (_.isEmpty(birthDate)) {
		birthDate = config.defaultDateOfBirth;
	}
	let ageCalculation = new Date().getFullYear() - Number(birthDate.split("-")[2]);
	let languages = _.get(user, "profileData.Preferences.Languages", _.get(user, "profileData.preferences.languages", configuration.DefaultProfileLanguages));
	if (typeof languages === "string") {
		languages = languages.split(",");
	}
	if (_.isEmpty(languages)) {
		languages = configuration.DefaultProfileLanguages;
	}
	let email = _.get(userRecords, "email") ? _.get(userRecords, "email") : _.get(userRecords, "providerData[0].email");

	if (!_.isEmpty(email) && (email.split("@")[0] == userRecords.uid || (email.split("@")[0] == userRecords.mobile)) /* || _.get(userRecords, 'providerData[0].providerId') == "phone")*/) {
		email = "";
	}

	const isTataSkyPartner = _.get(userRecords, "partnerType") == config.tSkyDetails.partnerType;
	if (isTataSkyPartner) {
		const brandingOptions = { email };
		const brandChanges = getTataSkyBrandingChanges(brandingOptions);
		if (Object.hasOwnProperty.call(brandChanges, "email")) {
			email = brandChanges.email;
		}
	}

	let phoneNumber = userRecords.mobile;
	if (_.isEmpty(userRecords.mobile)) {
		phoneNumber = "";
	}
	let amazonCredentials = _.get(user, "profileData.AmazonPayUser", "");
	const response = {
		uId: userRecords.uid,
		email: email,
		//mobile: _.get(user, 'profileData.phoneNumber', ''),
		mobile: _.get(user, "profileData.Mobile") ? String(_.get(user, "profileData.Mobile")) : String(phoneNumber),
		countryCode: _.get(user, "profileData.CountryCode", ""),
		profileUrl: "",
		age: String(ageCalculation),
		languages: languages,
		birthDate: birthDate,
		firstName: _.get(user, "profileData.FirstName", ""),
		profileName: _.get(user, "profileData.ProfileName", _.get(user, "profileData.FirstName", "")),
		lastName: _.get(user, "profileData.LastName", ""),
		fullName: `${_.get(user, "profileData.FirstName", "")} ${_.get(user, "profileData.LastName", "")}`,
		gender: _.get(user, "profileData.Gender"),
		amazonCredentials: amazonCredentials ? amazonCredentials : "",
	};
	response.isKidProfile=false;
	if(headers && user.profileData && user.profileData.BirthDate){
		const birthDate = user.profileData.BirthDate;
		const region = _.get(headers, "region", "NA");
		_.set(response, "isKidProfile",commonUtil.isKidProfile(birthDate,region));
	}
	const isParentPinSet = (user && user.parentPinMode)? true : false;
	_.set(response, "isParentPinSet", isParentPinSet);

	return { data: response };
}
async function v3UserProfileResponse(user, deviceDetails, localCredentials, headers, getAllValuesAlongWithKSM, supportoldformat = false) {
	const response = {
		subTitle: _.get(user, "profileData.SubTitle", ""),
		tncVersion: _.get(user, "profileData.TncVersion", ""),
		tncAcceptTime: parseInt(_.get(user, "profileData.TncAcceptTime", null)),
		kidSafeMode: {
			deviceId: _.get(deviceDetails, "deviceId", _.get(headers, "deviceId")),
			pin: _.get(localCredentials, "pin"),
			status: _.get(deviceDetails, "status", "ksmNotActivated"),
			contentRestriction: _.get(deviceDetails, "contentRestriction"),
			recovery: {
				mobile: _.get(localCredentials, "mobile", _.get(user, "profileData.Mobile", "")),
				countryCode: _.get(localCredentials, "countryCode", _.get(user, "profileData.CountryCode", "")),
			}
		},
		parentPinMode: {}
	};
	if (_.isUndefined(response.kidSafeMode.pin) && _.isUndefined(response.kidSafeMode.contentRestriction)) {
		_.set(response.kidSafeMode, "status", "off");
	}
	if (!getAllValuesAlongWithKSM) {
		_.pullAt(response, "subTitle");
		_.pullAt(response, "tncVersion");
		_.pullAt(response, "tncAcceptTime");
	}
	if (supportoldformat) {
		_.pullAt(response, "kidSafeMode");
	}
	response.isKidProfile=false;
	if(user.profileData && user.profileData.BirthDate){
		const birthDate = user.profileData.BirthDate;
		const country = _.get(headers, "country", "NA");
		console.log("birth and country in v3UserProfileResponse ",birthDate,country, commonUtil.isKidProfile(birthDate,country));
		_.set(response, "isKidProfile",commonUtil.isKidProfile(birthDate,country));

	}
	const isParentPinSet = (user && user.parentPinMode)? true : false;
	_.set(response, "parentPinMode.isParentPinSet", isParentPinSet);
	const isParentPinEnabled = (user && user.parentPinMode && user.parentPinMode.isParentPinEnabled)? true : false;
	_.set(response, "parentPinMode.isParentPinEnabled", isParentPinEnabled);
	console.log("My response", response);
	return { data: response };
}
async function v3UserProfileCommonResponse(user, deviceDetails, headers=null ) {
	const response = {
		age: _.get(user, "data.age", ""),
		name: _.get(user, "data.fullName", ""),
		gender: _.get(user, "data.gender", ""),
		kidSafeMode: {
			deviceId: _.get(deviceDetails, "data.kidSafeMode.deviceId"),
			pin: _.get(deviceDetails, "data.kidSafeMode.pin"),
			status: _.get(deviceDetails, "data.kidSafeMode.status"),
			contentRestriction: _.get(deviceDetails, "data.kidSafeMode.contentRestriction"),
			recovery: {
				mobile: _.get(deviceDetails, "data.kidSafeMode.recovery.mobile"),
				countryCode: _.get(deviceDetails, "data.kidSafeMode.recovery.countryCode"),
			}
		}
	};
	response.isKidProfile=false;
	if(headers && user && user.data.birthDate){
		const birthDate = user.data.birthDate;
		const country = _.get(headers, "country", "NA");
		console.log("birth and country in v3UserProfileCommonResponse",birthDate,country, commonUtil.isKidProfile(birthDate,country));
		_.set(response, "isKidProfile",commonUtil.isKidProfile(birthDate,country));

	}
	_.set(response, "isParentPinSet",user && user.parentPinMode);
	const isParentPinSet = (user && user.parentPinMode)? true : false;
	_.set(response, "isParentPinSet", isParentPinSet);


	return { data: response };
}
async function jioSubscriptionResponse(kalturaHouseholdId, kalturaUserLoginResult, kalturaAppTokenResponse, user, userRecords, entitlementStatus, input) {

	let birthDate = commonUtil.dateFormat(_.get(userRecords, "profileData.BirthDate", "").split("/").join("-"));
	if (_.isEmpty(birthDate)) {
		birthDate = config.defaultDateOfBirth;
	}
	let ageCalculation = new Date().getFullYear() - Number(birthDate.split("-")[2]);
	let languages = _.get(userRecords, "profileData.Preferences.Languages", _.get(userRecords, "profileData.preferences.languages", config.DefaultProfileLanguages));
	if (typeof languages === "string") {
		languages = languages.split(",");
	}
	if (_.isEmpty(languages)) {
		languages = config.DefaultProfileLanguages;
	}
	const response = {
		uId: _.get(userRecords, "profileData.uid", _.get(user, "uid", "")),
		email: _.get(userRecords, "email", ""),
		mobile: _.get(userRecords, "profileData.mobileNumber", ""),
		age: ageCalculation,
		languages: languages,
		birthDate: birthDate,
		firstName: _.get(userRecords, "profileData.FirstName", ""),
		profileName: _.get(userRecords, "profileData.ProfileName", _.get(user, "profileData.FirstName", "")),
		lastName: _.get(userRecords, "profileData.LastName", ""),
		fullName: `${_.get(userRecords, "profileData.FirstName", "")} ${_.get(user, "profileData.LastName", "")}`,
		gender: _.get(userRecords, "profileData.Gender", ""),
		householdId: kalturaHouseholdId,
		kUserId: _.get(kalturaUserLoginResult, "result.user.id"),
		kTokenId: _.get(kalturaAppTokenResponse, "result.id"),
		kToken: _.get(kalturaAppTokenResponse, "result.token"),
		ks: _.get(kalturaUserLoginResult, "result.loginSession.ks"),
		parentKs: _.get(kalturaUserLoginResult, "result.loginSession.ks"),
		entitlementStatus: entitlementStatus
	};
	if (_.isEmpty(_.trim(response.fullName))) {
		response.fullName = _.get(userRecords, "providerData[0].displayName", "");
		console.log(_.get(response, "fullName", ""));
		if (_.isEmpty(response.firstName)) {
			response.firstName = "" || _.split(_.get(response, "fullName", ""), " ")[0];
		}
		if (_.isEmpty(response.lastName)) {
			response.lastName = "" || _.split(_.get(response, "fullName", ""), " ")[1];
		}
	}
	if (_.isEmpty(response.profileName)) {
		response.profileName = _.get(response, "firstName", "");
	}
	let authToken = await tokenService.createAccessTokenAndRefreshToken({ uid: response.uId, email: response.email, kUserId: _.get(response, "kUserId"), deviceId: _.get(input, "deviceId") });
	_.set(response, "authToken", authToken);
	return { data: response };
}

function responseUpdateProfileData(data) {
	let uid = _.get(data, "profileData.Uid");
	let email = _.get(data, "profileData.Email");
	let mobile = _.get(data, "profileData.mobile");
	if (uid) {
		data.profileData.uid = uid;
	}
	if (email) {
		data.profileData.email = email;
	}
	if (mobile) {
		data.profileData.mobile = mobile;
	}
	return data;
}

async function partnerApiResponse(
	kalturaHouseholdId,
	kalturaUserLoginResult,
	kalturaAppTokenResponse,
	user,
	userRecords,
	tempEmail,
	input = "",
	tokenExpiryDay = null
) {
	const tokenService = require("../services").tokenService;
	let birthDate = commonUtil.dateFormat(
		_.get(userRecords, "profileData.BirthDate", "").split("/").join("-")
	);
	if (_.isEmpty(birthDate)) {
		birthDate = config.defaultDateOfBirth;
	}
	let ageCalculation = new Date().getFullYear() - Number(birthDate.split("-")[2]);
	let languages = _.get(
		userRecords,
		"profileData.Preferences.Languages",
		_.get(
			userRecords,
			"profileData.preferences.languages",
			config.DefaultProfileLanguages
		)
	);
	if (typeof languages === "string") {
		languages = languages.split(",");
	}
	if (_.isEmpty(languages)) {
		languages = config.DefaultProfileLanguages;
	}
	const response = {
		uId: _.get(userRecords, "profileData.uid", _.get(userRecords, "uid", "")),
		email: _.get(userRecords, "email", ""),
		mobile: _.get(userRecords, "mobile", ""),
		externalId: _.get(userRecords, "externalId", ""),
		partnerType: _.get(userRecords, "partnerType", ""),
		age: ageCalculation,
		languages: languages,
		birthDate: birthDate,
		firstName: _.get(userRecords, "profileData.FirstName", ""),
		profileName: _.get(userRecords, "profileData.ProfileName", _.get(user, "profileData.FirstName", "")),
		lastName: _.get(userRecords, "profileData.LastName", ""),
		fullName: `${_.get(userRecords, "profileData.FirstName", "")} ${_.get(user, "profileData.LastName", "")}`,
		gender: _.get(userRecords, "profileData.Gender", "U"),
		householdId: kalturaHouseholdId,
		kUserId: _.get(kalturaUserLoginResult, "result.user.id"),
		kTokenId: _.get(kalturaAppTokenResponse, "result.id"),
		kToken: _.get(kalturaAppTokenResponse, "result.token"),
		ks: _.get(kalturaUserLoginResult, "result.loginSession.ks"),
		parentKs: _.get(kalturaUserLoginResult, "result.loginSession.ks"),
		countryCode: _.get(userRecords, "profileData.CountryCode", ""),
		isTemporaryPassword: "",
		tncVersion: _.get(userRecords, "profileData.TncVersion", ""),
		tncAcceptTime: parseInt(_.get(userRecords, "profileData.TncAcceptTime", "")),
		isProfileUpdated: _.get(userRecords, "profileData.isProfileUpdated", false),
		isPasswordChangeable: _.get(userRecords, "profileData.IsPasswordChangeable", false),
		profileUrl: "",
		subTitle: _.get(userRecords, "profileData.SubTitle", ""),
		authToken: "",
		partnerDisplayName: "",
	};
	if (!_.has(userRecords, "tncVersion") || _.isEmpty(userRecords, "tncVersion")) {
		_.set(response, "tncAcceptTime", null);
		_.set(response, "tncVersion", "");
	} else {
		_.set(response, "tncAcceptTime", Date.now());
	}
	if (_.isEmpty(_.trim(response.fullName))) {
		response.fullName = _.get(userRecords, "providerData[0].displayName", "");
		console.log(_.get(response, "fullName", ""));
		if (_.isEmpty(response.firstName)) {
			response.firstName = "" || _.split(_.get(response, "fullName", ""), " ")[0];
		}
		if (_.isEmpty(response.lastName)) {
			response.lastName = "" || _.split(_.get(response, "fullName", ""), " ")[1];
		}
	}
	const isJioPartner = _.get(response, "partnerType") == config.jioSubscription.partnerType;
	const isTataSkyPartner = _.get(response, "partnerType") == config.tSkyDetails.partnerType;

	if (isJioPartner) {
		const isFirstLogin = _.get(userRecords, "lastLoginCount") > 1 ? false : true;
		_.set(response, "isFirstLogin", isFirstLogin);
	} else if (isTataSkyPartner) {
		let { email: customerEmail = "" } = response;
		const {
			partnerDisplayName,
			oldEmailSuffix = [], newEmailSuffix = "",
		} = configuration.tSkyDetails;
		const isValidEmail = (customerEmail !== "") && (customerEmail.length > 0);

		if (isValidEmail) {
			const suffix = oldEmailSuffix.filter((item) => customerEmail.indexOf(item) !== -1);
			const emailTobeUpdated = suffix.length && suffix[0];

			if (emailTobeUpdated) {
				customerEmail = customerEmail.replace(suffix[0], newEmailSuffix);
				_.set(response, "email", customerEmail);
			}
		}
		const isFirstLogin = _.get(userRecords, "lastLoginCount") > 2 ? false : true;
		_.set(response, "isFirstLogin", isFirstLogin);
		_.set(response, "partnerDisplayName", partnerDisplayName);
	}

	if (_.isUndefined(response.lastName)) response.lastName = "";
	if (_.isEmpty(response.profileName)) response.profileName = _.get(response, "firstName", "");

	const payload = {
		uid: response.uId,
		email: tempEmail,
		kUserId: response.kUserId,
		deviceId: _.get(input, "deviceId"),
		partnerType: _.get(response, "partnerType", ""),
	};
	const authToken = await tokenService.createAccessTokenAndRefreshToken(payload, false, tokenExpiryDay);
	_.set(response, "authToken", authToken);
	return { data: response };
}

async function emailForgotPassResponse(userExists, otpOutput = null,) {
	let response;
	response = {
		isExist: userExists ? true : false,
		isPosted: userExists ? true : false,
		attempts: _.get(otpOutput, "attempts", 0),
		maxAttempts: config.Otp.maxAttempts,
		message: errorConfig.emailOtpSuccessMsg
	};
	return response;
}
async function emailResponse(userExists, otpOutput = null, service = null, otpVerified = null) {
	let response;
	if (service == "resendOtp") {
		response = {
			isExist: userExists ? true : false,
			//isVerified: otpVerified ? true : false,    
			attempts: _.get(otpOutput, "attempts", 0),
			maxAttempts: _.get(otpOutput, "maxAttempts", 0),
			message: (userExists || otpVerified) ? errorConfig.emailAlreadyRegistered.description : errorConfig.emailNotRegistered.description
		};
	} else {
		response = {
			isExist: userExists ? true : false,
			//isVerified: otpVerified ? true : false,
			attempts: _.get(otpOutput, "attempts", 0),
			maxAttempts: _.get(otpOutput, "maxAttempts", 0),
			message: (userExists || otpVerified) ? errorConfig.emailAlreadyRegistered.description : errorConfig.emailNotRegistered.description

		};
	}
	return response;

}
async function phoneNumberResponse(userExists, otpOutput = null, service = null, otpVerified = null, isPosted = true) {
	let response;
	if (service == "resendOtp") {
		response = {
			isExist: userExists ? true : false,
			isPosted: isPosted ? true : false,
			attempts: _.get(otpOutput, "attempts", 0),
			maxAttempts: _.get(otpOutput, "maxAttempts", 0),
			message: (userExists || otpVerified) ? errorConfig.mobileVerify : errorConfig.OtpResent
		};
	} else {
		response = {
			isExist: userExists ? true : false,
			//isVerified: otpVerified ? true : false,
			attempts: _.get(otpOutput, "attempts", 0),
			maxAttempts: _.get(otpOutput, "maxAttempts", 0),
			message: (userExists || otpVerified) ? errorConfig.mobileVerify : errorConfig.signUpOTPSent

		};
	}
	return response;

}
async function phoneNumberForgotPassResponse(userExists, otpOutput = null) {
	let response;
	response = {
		isExist: userExists ? true : false,
		isPosted: true,
		attempts: _.get(otpOutput, "attempts", 0),
		maxAttempts: config.Otp.maxAttempts,
		message: errorConfig.forgotPasswordOtpSuccess
	};
	return response;

}

async function OtpRetriveFormate(usersData, type) {
	console.log(usersData);
	let response;
	if (type == "forgotpassword") {
		if (usersData && usersData._system && usersData._system.forgotPasswordEmail) {
			response = {
				otp: usersData._system.forgotPasswordEmail.otp,
				createdAt: usersData._system.forgotPasswordEmail.createdAt,
				updatedAt: usersData._system.forgotPasswordEmail.updatedAt,
				attempts: usersData._system.forgotPasswordEmail.attempts,
				status: {
					code: 200,
					message: "ok"
				}
			};
		}
		else if (usersData && usersData._system && usersData._system.forgotPasswordMobile) {
			response = {
				otp: usersData._system.forgotPasswordMobile.otp,
				createdAt: usersData._system.forgotPasswordMobile.createdAt,
				updatedAt: usersData._system.forgotPasswordMobile.updatedAt,
				attempts: usersData._system.forgotPasswordMobile.attempts,
				status: {
					code: 200,
					message: "ok",
				},
			};
		}
		else {
			throw { code: "otp/data-not-found" };
		}
	}
	if (type == "signup") {
		if (usersData && usersData._system && usersData._system.signUpRequest) {
			response = {
				otp: usersData._system.signUpRequest.otp,
				createdAt: usersData._system.signUpRequest.createdAt,
				updatedAt: usersData._system.signUpRequest.updatedAt,
				attempts: usersData._system.signUpRequest.attempts,
				status: {
					code: 200,
					message: "ok",
				},
			};
		}
		else {
			throw { code: "otp/data-not-found" };
		}
	}
	if (type == "ims") {
		if (usersData && usersData._system && usersData._system.imsRequest) {
			response = {
				otp: usersData._system.imsRequest.otp,
				createdAt: usersData._system.imsRequest.createdAt,
				updatedAt: usersData._system.imsRequest.updatedAt,
				attempts: usersData._system.imsRequest.attempts,
				status: {
					code: 200,
					message: "ok",
				},
			};
		}
		else {
			throw { code: "otp/data-not-found" };
		}
	}
	return response;

}


async function v3getPartnerProfileResponse(uid, userRecords) {
	let birthDate = commonUtil.dateFormat(_.get(userRecords, "profileData.BirthDate", ""));
	if (_.isEmpty(birthDate)) {
		birthDate = config.defaultDateOfBirth;
	}
	let ageCalculation = new Date().getFullYear() - Number(birthDate.split("-")[2]);
	let languages = _.get(userRecords, "profileData.Preferences.Languages", _.get(userRecords, "profileData.preferences.languages", config.DefaultProfileLanguages));
	if (typeof languages === "string") {
		languages = languages.split(",");
	}
	if (_.isEmpty(languages)) {
		languages = configuration.DefaultProfileLanguages;
	}
	let email = _.get(userRecords, "email") ? _.get(userRecords, "email") : _.get(userRecords, "providerData[0].email");

	if (!_.isEmpty(email) && (email.split("@")[0] == userRecords.uid || (email.split("@")[0] == userRecords.mobile)) /* || _.get(userRecords, 'providerData[0].providerId') == "phone")*/) {
		email = "";
	}

	let phoneNumber = userRecords.mobile;
	if (_.isEmpty(userRecords.mobile)) {
		phoneNumber = "";
	}
	let amazonCredentials = _.get(userRecords, "profileData.AmazonPayUser", "");
	const response = {
		uId: userRecords.uid || uid,
		email: email,
		deviceId: _.get(userRecords, "deviceId", ""),
		uniqueId: _.get(userRecords, "uniqueId", ""),
		externalId: _.get(userRecords, "externalId", ""),
		partnerType: _.get(userRecords, "partnerType", _.get(userRecords, "partnerName", "")),
		mobile: _.get(userRecords, "profileData.Mobile") ? String(_.get(userRecords, "profileData.Mobile")) : String(phoneNumber),
		countryCode: _.get(userRecords, "profileData.CountryCode", ""),
		profileUrl: "",
		age: String(ageCalculation),
		languages: languages,
		birthDate: birthDate,
		kUserId: _.get(userRecords, "kUserId"),
		tempEmail: _.get(userRecords, "tempEmail"),
		firstName: _.get(userRecords, "profileData.FirstName", ""),
		profileName: _.get(userRecords, "profileData.ProfileName", _.get(userRecords, "profileData.FirstName", "")),
		lastName: _.get(userRecords, "profileData.LastName", ""),
		fullName: `${_.get(userRecords, "profileData.FirstName", "")} ${_.get(userRecords, "profileData.LastName", "")}`,
		gender: _.get(userRecords, "profileData.Gender"),
		subscription: _.get(userRecords, "subscription"),
		amazonCredentials: amazonCredentials ? amazonCredentials : "",
	};
	if (_.isEmpty(response.countryCode) && (_.size(response.mobile) > 10)) {
		let { Mobile, CountryCode } = commonUtil.splitMobileWithCountryCode(_.get(response, "mobile"));
		_.set(response, "mobile", Mobile);
		_.set(response, "countryCode", CountryCode);
	}
	return { data: response };
}

function errorResponseCodeForAnonymous(grantType, errorObj, eventBaseName, input, uid) {
	let modifiedErrorObj = errorObj;
	console.log(grantType, "grantType");
	if (errorObj && errorObj.status && errorObj.status.code) {
		switch (grantType) {
		case configuration.AnonymousGrantType.anonymous: {
			switch (errorObj.status.code) {
			case errorConfig.invalidAccessToken.code: {
				modifiedErrorObj = apiResponse.error(errorConfig.invalidAnonymousToken.description, errorConfig.invalidAnonymousToken.code, eventBaseName + mixPanelConfig.serverValidation_Error, input, input.clientId, 400);
			} break;
			case errorConfig.expiredAnonymosToken.code: {
				modifiedErrorObj = apiResponse.error(errorConfig.expiredAnonymousToken.description, errorConfig.expiredAnonymousToken.code, eventBaseName + mixPanelConfig.serverValidation_Error, input, input.clientId, 400);
			}
				break;
			}
		}
			break;
		case configuration.AnonymousGrantType.authorization_token:
		case configuration.AnonymousGrantType.interactivity: {
			switch (errorObj.status.code) {
			case errorConfig.invalidAccessToken.code: {
				modifiedErrorObj = apiResponse.error(errorConfig.invalidInteractivityToken.description, errorConfig.invalidInteractivityToken.code, eventBaseName + mixPanelConfig.serverValidation_Error, input, (uid) ? uid : input.clientId, 400);
			} break;
			case errorConfig.expiredAnonymosToken.code: {
				modifiedErrorObj = apiResponse.error(errorConfig.expiredInteractivityToken.description, errorConfig.expiredInteractivityToken.code, eventBaseName + mixPanelConfig.serverValidation_Error, input, (uid) ? uid : input.clientId, 400);
			}
				break;
			}
		}
			break;
		case configuration.AnonymousGrantType.vendor_feature_token: {
			switch (errorObj.status.code) {
			case errorConfig.invalidAccessToken.code: {
				modifiedErrorObj = apiResponse.error(errorConfig.invalidVendorFeatureTokenAccessToken.description, errorConfig.invalidVendorFeatureTokenAccessToken.code, eventBaseName + mixPanelConfig.serverValidation_Error, input.clientId, grantType, 400);
			} break;
			case errorConfig.expiredAnonymosToken.code: {
				modifiedErrorObj = apiResponse.error(errorConfig.expiredVendorFeatureTokenAccessToken.description, errorConfig.expiredVendorFeatureTokenAccessToken.code, eventBaseName + mixPanelConfig.serverValidation_Error, input.clientId, grantType, 400);
			}
				break;
			}
		}
			break;
		}
	}
	return modifiedErrorObj;
}
function errorResponseCodeForVerifyAnonymous(grantType, errorObj, baseEventName, clientId, accessToken) {
	let modifiedErrorObj = errorObj;
	console.log(grantType, "grantType");
	if (errorObj && errorObj.status && errorObj.status.code) {
		switch (grantType) {
		case configuration.AnonymousGrantType.anonymous: {
			switch (errorObj.status.code) {
			case errorConfig.invalidAccessToken.code: {
				modifiedErrorObj = apiResponse.error(errorConfig.invalidAnonymousAccessToken.description, errorConfig.invalidAnonymousAccessToken.code, baseEventName + mixPanelConfig.serverValidation_Error, { clientId, grantType, accessToken }, clientId, 400);
			} break;
			case errorConfig.expiredAnonymosToken.code: {
				modifiedErrorObj = apiResponse.error(errorConfig.expiredAnonymousAccessToken.description, errorConfig.expiredAnonymousAccessToken.code, baseEventName + mixPanelConfig.serverValidation_Error, { clientId, grantType, accessToken }, clientId, 400);
			}
				break;
			}
		}
			break;
		case configuration.AnonymousGrantType.interactivity: {
			switch (errorObj.status.code) {
			case errorConfig.invalidAccessToken.code: {
				modifiedErrorObj = apiResponse.error(errorConfig.invalidInteractivityAccessToken.description, errorConfig.invalidInteractivityAccessToken.code, baseEventName + mixPanelConfig.serverValidation_Error, { clientId, grantType, accessToken }, clientId, 400);
			} break;
			case errorConfig.expiredAnonymosToken.code: {
				modifiedErrorObj = apiResponse.error(errorConfig.expiredInteractivityAccessToken.description, errorConfig.expiredInteractivityAccessToken.code, baseEventName + mixPanelConfig.serverValidation_Error, { clientId, grantType, accessToken }, clientId, 400);
			}
				break;
			}
		}
			break;
		case configuration.AnonymousGrantType.vendor_feature_token: {
			switch (errorObj.status.code) {
			case errorConfig.invalidAccessToken.code: {
				modifiedErrorObj = apiResponse.error(errorConfig.invalidVendorFeatureTokenAccessToken.description, errorConfig.invalidVendorFeatureTokenAccessToken.code, baseEventName + mixPanelConfig.serverValidation_Error, { clientId, grantType, accessToken }, clientId, 400);
			} break;
			case errorConfig.expiredAnonymosToken.code: {
				modifiedErrorObj = apiResponse.error(errorConfig.expiredVendorFeatureTokenAccessToken.description, errorConfig.expiredVendorFeatureTokenAccessToken.code, baseEventName + mixPanelConfig.serverValidation_Error, { clientId, grantType, accessToken }, clientId, 400);
			}
				break;
			}
		}
			break;
		}
	}
	return modifiedErrorObj;
}
async function v3SearchApiResponse(userAuth, userProfile, deviceId, kalthuraLoginResponse) {
	const tokenService = require("../services").tokenService;
	let birthDate = commonUtil.dateFormat(_.get(userProfile, "profileData.BirthDate", "")) || "";
	if (_.isEmpty(birthDate)) {
		birthDate = config.defaultDateOfBirth;
	}
	let ageCalculation = "" + new Date().getFullYear() - Number(birthDate.split("-")[2]) + "";
	let isPasswordChangeableFlag = false;
	_.findKey(userAuth.providerData, EachItem => {
		if ((_.get(EachItem, "providerId")) == "password") {
			isPasswordChangeableFlag = true;
			return isPasswordChangeableFlag;
		} else {
			isPasswordChangeableFlag = false;
			console.debug("Variable Name", isPasswordChangeableFlag);
		}
	});
	_.set(userProfile, "profileData.IsPasswordChangeable", isPasswordChangeableFlag);
	if (_.isEmpty(userProfile, "profileData.TncVersion")) {
		console.debug("tncVersion and tncAcceptTime is blank", userProfile.profileData.TncVersion);
		// if tncVersion is empty then both value will null
		userProfile.profileData.TncAcceptTime = null;
		// userProfile.profileData.TncAcceptTime = ''; userProfile.profileData.TncVersion = '';
	} else {

		userProfile.profileData.TncAcceptTime = Date.now();
	}
	let fullName;
	if (!_.isEmpty(userProfile.profileData, "FullName")) {
		fullName = _.get(userProfile, "profileData.FullName");
	} else {
		fullName = `${_.get(userProfile, "profileData.FirstName")} ${_.get(userProfile, "profileData.LastName")}`;
	}
	let languages = _.get(userProfile, "profileData.Preferences.Languages", _.get(userProfile, "profileData.preferences.languages", config.DefaultProfileLanguages));
	if (typeof languages === "string") {
		languages = languages.split(",");
	}
	if (_.isEmpty(languages)) {
		languages = config.DefaultProfileLanguages;
	}
	let email = _.get(userProfile, "email") ? _.get(userProfile, "email") : _.get(userAuth, "providerData[0].email");
	let maskEmail = commonUtil.maskEmail(email);
	let phoneNumber = userAuth.phoneNumber;
	let maskMobileNumber = commonUtil.maskMobileNumber(_.get(userAuth, "profileData.Mobile") ? String(_.get(userAuth, "profileData.Mobile")) : String(phoneNumber), _.get(userAuth, "profileData.CountryCode", ""));
	if (_.isEmpty(userAuth.phoneNumber)) {
		phoneNumber = "";
		maskMobileNumber = "";
	}
	if (!_.isEmpty(email) && (email.split("@")[0] == userProfile.uid || _.get(userProfile, "providerData[0].providerId") == "phone")) {
		email = "",
		maskEmail = "";
	}

	const response = {
		uId: userAuth.uid ? userAuth.uid : _.get(userProfile, "uid"),
		email: email,
		mobile: _.get(userProfile, "profileData.Mobile") ? String(_.get(userProfile, "profileData.Mobile")) : String(phoneNumber),
		countryCode: _.get(userProfile, "profileData.CountryCode", ""),
		profileUrl: "",
		age: ageCalculation,
		languages: languages,
		birthDate: birthDate,
		firstName: _.get(userProfile, "profileData.FirstName", ""),
		profileName: _.get(userProfile, "profileData.ProfileName", _.get(userProfile, "profileData.FirstName", "")),
		lastName: _.get(userProfile, "profileData.LastName", ""),
		fullName: fullName ? fullName : `${_.get(userProfile, "profileData.FirstName")} ${_.get(userProfile, "profileData.LastName")}`,
		gender: _.get(userProfile, "profileData.Gender", "U"),
		householdId: _.get(kalthuraLoginResponse, "householdId", 0),
		kUserId: _.get(kalthuraLoginResponse, "kUserId"),
		kTokenId: _.get(kalthuraLoginResponse, "kTokenId"),
		kToken: _.get(kalthuraLoginResponse, "kToken"),
		ks: _.get(kalthuraLoginResponse, "ks"),
		parentKs: _.get(kalthuraLoginResponse, "ks"),
		isTemporaryPassword: false,
		isFirstLogin: _.get(userProfile, "profileData.isFirstLogin", true),
		tncVersion: _.get(userProfile, "profileData.TncVersion", ""),
		tncAcceptTime: parseInt(_.get(userProfile, "profileData.TncAcceptTime", null)),
		subTitle: _.get(userProfile, "profileData.SubTitle", ""),
		isProfileUpdated: _.get(userProfile, "profileData.IsProfileUpdated", _.get(userProfile, "profileData.isProfileUpdated")),
		isPasswordChangeable: _.get(userProfile, "profileData.IsPasswordChangeable", ""),
		maskedIdentity: maskMobileNumber ? maskMobileNumber : maskEmail,
		amazonDetails: _.get(userProfile, "profileData.amazondetails", ""),
		googleDetails: _.get(userProfile, "profileData.googleDetails", ""),
		facebookDetails: _.get(userProfile, "profileData.facebookDetails", ""),
		appleDetails: _.get(userProfile, "profileData.appleDetails", ""),
	};

	if (_.trim(response.fullName) == "undefined undefined") {
		_.set(response, "fullName", "");
	}
	if (_.isEmpty(_.trim(response.fullName))) {
		response.fullName = _.get(userAuth, "providerData[0].displayName", "") || "";
		console.debug(_.get(response, "fullName", ""));
		if (_.isEmpty(response.firstName)) {
			response.firstName = _.split(_.get(response, "fullName", ""), " ")[0];
		}
		if (!_.isEmpty(response.fullName) && _.isEmpty(response.lastName)) {
			response.lastName = _.split(_.get(response, "fullName", ""), " ")[1];
		}
	}
	if (_.isEmpty(response.profileName)) {
		response.profileName = _.get(response, "firstName", "");
	}
	if (_.isEmpty(response.email)) {
		response.email = "";
	}
	if (_.isEmpty(response.tncVersion)) {
		response.tncAcceptTime = null;
	}
	if (_.isEmpty(response.fullName) && (_.has(userProfile.profileData, "AmazonDetails"))) {
		response.fullName = _.get(userProfile, "profileData.AmazonDetails.name", _.get(userProfile, "profileData.AmazonDetails.Name", ""));
		response.profileName = _.get(userProfile, "profileData.AmazonDetails.name", _.get(userProfile, "profileData.AmazonDetails.Name", ""));
		// {accountData = { ...accountData, ProfileName: response.fullName };
		// console.log('Update_Profile accountData: for uid ::: ', response.uId);}

	}
	// amazon
	if (_.has(userProfile.profileData, "AmazonPayUser")) {
		response.amazonDetails = _.get(userProfile, "profileData.AmazonPayUser", _.get(userProfile, "profileData.AmazonPayUser", ""));
	} else {
		response.amazonDetails = null;
	}
	// google
	if (_.has(userProfile.profileData, "GmailUser")) {
		response.googleDetails = _.get(userProfile, "profileData.GmailUser", _.get(userProfile, "profileData.GmailUser", ""));
	} else {
		response.googleDetails = null;
	}

	// fb
	if (_.has(userProfile.profileData, "FacebookUser")) {
		response.facebookDetails = _.get(userProfile, "profileData.FacebookUser", _.get(userProfile, "profileData.FacebookUser", ""));
	} else {
		response.facebookDetails = null;
	}
	// apple
	if (_.has(userProfile.profileData, "AppleUser")) {
		response.appleDetails = _.get(userProfile, "profileData.AppleUser", _.get(userProfile, "profileData.AppleUser", ""));
	} else {
		response.appleDetails = null;
	}

	let authToken = await tokenService.createAccessTokenAndRefreshToken({ uid: response.uId, email: response.email, deviceId: deviceId, kUserId: _.get(response, "kUserId") });
	// TODO: kUserId: _.get(response, 'kUserId') : Need to add kUserId after kaltura migration in auth token
	_.set(response, "authToken", authToken);
	_.findKey(userAuth.providerData, EachItem => {
		if ((_.get(EachItem, "providerId")) == "phone") {
			_.set(response, "email", "");
		}
	});
	return { data: response };
}

function responseGetLoginDetailsByDeviceId(data) {
	let response = {
		data: {
			"deviceId": _.get(data, "deviceId"),
			"createdAt": _.get(data, "createdAt"),
			"deviceBrand": _.get(data, "deviceBrand"),
			"type": _.get(data, "type"),
			"updatedAt": _.get(data, "updatedAt"),
			"profileName": _.get(data, "ProfileName", "")
		}

	};
	if (data.type != constant.USER_LOGIN_TYPES.mobile && data.email) response.data.email = commonUtil.maskEmail(_.get(data, "email"));
	if (data.type == constant.USER_LOGIN_TYPES.mobile && data.mobile) response.data.mobile = commonUtil.maskMobileNumber(_.get(data, "countryCode") + "" + _.get(data, "mobile"));
	if (data.type == constant.USER_LOGIN_TYPES.mobile && data.countryCode) response.data.countryCode = _.get(data, "countryCode");
	return response;
}

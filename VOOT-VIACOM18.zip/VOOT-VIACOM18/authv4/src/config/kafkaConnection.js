const { Kafka } = require("kafkajs");
const { configuration } = require("../config");

let producer = null;
let isConnected = false;

/**
 * function to connect MSK and create producer. 
 * @returns kafka producer object.
 */
async function getkafkaProducer() {
	const toBeConnected =
		configuration.kafkaConfig.enable.isauthV4 &&
		!isConnected &&
		!producer;
	if (!toBeConnected) return isConnected ? producer : null;

	const kafkaConfig = {
		clientId: "my-app",
		brokers: configuration.kafkaConfig.brokers,
		ssl: true,
	};
	const Client = new Kafka(kafkaConfig);
	//create producer
	console.log("client", Client);
	producer = Client.producer({ allowAutoTopicCreation: true });
	console.log("producer", producer);
	await producer.connect();
	console.log("Kafka producer is ready.");
	isConnected = true;
	return producer;
}

module.exports = {
	getkafkaProducer,
};

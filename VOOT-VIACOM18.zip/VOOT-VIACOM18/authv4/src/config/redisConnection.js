const redis = require("ioredis");
const configuration = require("../config").configuration;
const port_redis = configuration.redis.port;
let redis_client;

const isLocal = process.env.IS_LOCAL === "true";

if (isLocal == true) console.log("No redis in local running instance");
else if (!redis_client && configuration.redis.redisEnable == true) {

	redis_client = new redis({
		port: port_redis,
		host: configuration.redis.host,
		db: configuration.redis.db,
		password: configuration.redis.redisPassword
	});
	redis_client.on("error", (err) => {
		console.log("Redis error: " + err);
		configuration.redis.redisEnable = false;
	});
	if (configuration.redis.redisEnable == true) {
		redis_client.on("connect", () => {
			console.log("Connected to redis");
		});
	} else {
		console.log("Please Enable Redis Configuration");
	}
}
module.exports = {
	redis_client,
};

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const configuration = require("../config").configuration;
const AWS = require("aws-sdk");
AWS.config.update({
	accessKeyId: configuration.SQS.accessKeyId,
	secretAccessKey: configuration.SQS.secretAccessKey,
	region: configuration.SQS.region
});
// var  pinpoint = new AWS.Pinpoint();
module.exports.default = new AWS.SQS();
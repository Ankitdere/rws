const nodeCache = require("node-cache");
const basicConfig = require("../config/basicConfig");
const cache = new nodeCache({ checkperiod: basicConfig.cacheConfig.checkperiod});
module.exports = cache;
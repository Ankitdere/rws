const config = {
	prod: {
		cacheConfig: {
			checkperiod: 4,
		},
	},
	dev: {
		cacheConfig: {
			checkperiod: 2,
		},
	},
	debug: {
		cacheConfig: {
			checkperiod: 2,
		},
	},
};
const envConfig = config[process.env.VOOT_ENV] || config.debug;
envConfig.nameOFSSM = [
	`/${process.env.VOOT_ENV}/voot/select/all/database/mongo`,
	`/${process.env.VOOT_ENV}/voot/select/all/firebase/all`,
	`/${process.env.VOOT_ENV}/voot/select/all/kaltura/all`,
	`/${process.env.VOOT_ENV}/voot/select/all/partners/flipkart`,
	`/${process.env.VOOT_ENV}/voot/select/authV4/AWS/all`,
	`/${process.env.VOOT_ENV}/voot/select/authV4/anonymous/all`,
	`/${process.env.VOOT_ENV}/voot/select/authV4/appple_Sign_in/all`,
	`/${process.env.VOOT_ENV}/voot/select/authV4/basic/all`,
	`/${process.env.VOOT_ENV}/voot/select/authV4/google/all`,
	`/${process.env.VOOT_ENV}/voot/select/authV4/hash_config/all`,
	`/${process.env.VOOT_ENV}/voot/select/authV4/jwt/all`,
	`/${process.env.VOOT_ENV}/voot/select/authV4/pXApiDetails/all`,
	`/${process.env.VOOT_ENV}/voot/select/authV4/redis/all`,
	`/${process.env.VOOT_ENV}/voot/select/authV4/tSkyDetails/all`,
	`/${process.env.VOOT_ENV}/voot/select/all/sms/all`,
	`/${process.env.VOOT_ENV}/voot/select/all/partners/flipkart`,
	`/${process.env.VOOT_ENV}/voot/select/all/partners/airtel`,
	`/${process.env.VOOT_ENV}/voot/select/all/partners/yupp_tv`,
	`/${process.env.VOOT_ENV}/voot/select/all/Mailer/all`,
	`/${process.env.VOOT_ENV}/voot/select/authV4/M2MITDetails/all`,
	`/${process.env.VOOT_ENV}/voot/select/authV4/M2MITDetails/certificate`,
	`/${process.env.VOOT_ENV}/voot/select/authV4/jio_subscription_details/all`,
	`/${process.env.VOOT_ENV}/voot/select/authV4/jio_subscription_details/certificate`,
	`/${process.env.VOOT_ENV}/voot/select/all/wd/all`,
	`/${process.env.VOOT_ENV}/voot/select/authV4/swagger_host/all`,
	`/${process.env.VOOT_ENV}/voot/select/authV4/get_otp_details/all`,
	`/${process.env.VOOT_ENV}/voot/select/all/mixpanel/partner_notifications/project_token`,
	`/${process.env.VOOT_ENV}/voot/select/all/mixpanel/voot_auth/project_token`,
	`/${process.env.VOOT_ENV}/voot/select/all/kafka/all`,
	`/${process.env.VOOT_ENV}/voot/select/all/ksm_config/basic_info`,
	`/${process.env.VOOT_ENV}/voot/select/all/ksm_config/device_and_platform`,
	`/${process.env.VOOT_ENV}/voot/select/authV4/internal_service_api/all`,
	`/${process.env.VOOT_ENV}/voot/select/authV4/limitConfig`
];
module.exports = envConfig;
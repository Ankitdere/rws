// const envConfig = require('./envConfig');
const mongoConnect = require("./dbConnection");
const errorConfig = require("./errorConfig");
const configuration = require("./configuration");
const forgotPasswordTemplate = require("./forgotPasswordTemplate");
const deleteProfileTemplate = require("./deleteProfileTemplate");
const mixpanelEvent = require("./mixPanelConfig");


module.exports = {
	// envConfig,
	mongoConnect,
	errorConfig,
	configuration,
	forgotPasswordTemplate,
	deleteProfileTemplate,
	mixpanelEvent
};


"use strict";
const mongoose = require("mongoose");
const fs = require("fs");
const autoIncrement = require("mongoose-auto-increment");
const config = require("./configuration");

mongoose.Promise = global.Promise;

let { dbURL: connectionUri } = config.mongo;
const isLocal = process.env.IS_LOCAL === "true";
if(isLocal) connectionUri = process.env.MONGO_URI;

const cert = fs.readFileSync(`${__dirname}/rds-combined-ca-bundle.pem`); 
// Connect to MongoDB
const options = {
	sslCA: cert,
	useNewUrlParser: true ,
	useUnifiedTopology: true
};
console.log(connectionUri, "<>>>>>>>>>>>>>>>>>", options);
mongoose.connect(connectionUri, options);
mongoose.set("useCreateIndex", true);
const db = mongoose.connection;
autoIncrement.initialize(db);
db.on("error", console.error.bind(console, "connection error:"));
db.once("open", function callback() {
	console.log("Database connection to MongoDB opened.");
});

console.log("Loading MongoDB Settings ...");
module.exports = mongoose;

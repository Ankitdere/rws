module.exports = {
	subject: "Account Deletion Request from iOS",
	header: `
   <!DOCTYPE HTML>
   <html>
   <head>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
   <title></title>
   </head>

   <body bgcolor="#8d8e90">
   <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#8d8e90">
    <tr>
      <td>
       <table width="600" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFFFFF" align="center" style="padding-top:10px;">
          <tr>
           <td>
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="20"><a href= "#" target="_blank"><!--<img src="images/PROMO-GREEN2_01_01.jpg" width="61" height="76" border="0" alt=""/>--></a></td>
                <td width="93"><a href= "www.voot.com" target="_blank"><img src="https://voot-v2-cms.s3.amazonaws.com/fe-images/76X76-APP.JPG" width="93" height="76" border="0" alt=""/></a></td>
                <td width="365"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="46" align="right" valign="middle"><table width="100%" border="0" cellspacing="0" cellpadding="0">
            </table></td>
          </tr>
          <tr>
            <td height="30"><img src="https://voot-static.s3.amazonaws.com/mail/PROMO-GREEN2_01_04.jpg" width="350" height="30" border="0" alt=""/></td>
          </tr>
       </table></td>
    </tr>
   </table>
  </td>
</tr>
<tr>
<td align="center">&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td><table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
				<td width="5%">&nbsp;</td>
				<td width="90%" colspan="2" align="left" valign="top">
   `,
	bodySubject: `
    <p>The user with below details has requested for account deletion- </p>

    <table width="100%">
    <tr>
      <td>Phone Number: </td>
      <td>{mobile}</td>
    </tr>
    <tr>
      <td>Email: </td>
      <td>{email}</td>   
    </tr>
    <tr>
      <td>UID: </td>
      <td>{uid}</td>   
    </tr>
    <tr>
      <td>Timestamp of Request: </td>
      <td>{timestamp}</td> 
    </tr>        
    </table>
    <br />
  </font>
          `,
	footer: `<td width="5%">&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
        <td align="left" valign="top">
         <font style="font-family: Verdana, Geneva, sans-serif; color:#666766; font-size:13px; line-height:21px">
          <br/>Regards,<br/>
          Voot Team</font>
        </td>
      
    
      <td>&nbsp;</td>
    </tr>
  </table></td>
  </tr>
  <tr>
  <td>&nbsp;</td>
  </tr>
  <tr>
  <td>&nbsp;</td>
  </tr>
  <tr>
      <td><img src="https://voot-static.s3.amazonaws.com/mail/PROMO-GREEN2_07.jpg" width="598" height="7" style="display:block" border="0" alt=""/></td>
  </tr>
  <tr>
  <td>&nbsp;</td>
  </tr>
  <tr>
  <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
      <td width="13%" align="center">&nbsp;</td>
      <td width="14%" align="center"><!-- <font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><a href= "#" style="color:#010203; text-decoration:none"><strong>UNSUBSCRIBE </strong></a></font> --></td>
      <td width="2%" align="center"><!-- <font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><strong>|</strong></font> --></td>
      <td width="9%" align="center"><!-- <font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><a href= "http://voot.com/about-us" style="color:#010203; text-decoration:none"><strong>ABOUT </strong></a></font> --></td>
      <td width="2%" align="center"><!-- <font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><strong>|</strong></font> --></td>
      <td width="11%" align="center"><font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><a href= "http://voot.com/about-us" style="color:#010203; text-decoration:none"><strong>ABOUT US</strong></a></font></td>
      <td width="2%" align="center"><font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><strong>|</strong></font></td>
      <td width="11%" align="center"><font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><a href= "http://voot.com/contact-us" style="color:#010203; text-decoration:none" target="_blank"><strong>CONTACT US</strong></a></font></td>
      <td width="2%" align="center"><font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><strong>|</strong></font></td>
      <td width="17%" align="center"><font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><strong>STAY CONNECTED</strong></font></td>
      <td width="4%" align="right"><a href="https://facebook.com/voot/" target="_blank"><img src="https://voot-static.s3.amazonaws.com/mail/PROMO-GREEN2_09_01.jpg" alt="facebook" width="22" height="19" border="0" /></a></td>
      <td width="5%" align="center"><a href="https://twitter.com/justvoot" target="_blank"><img src="https://voot-static.s3.amazonaws.com/mail/PROMO-GREEN2_09_02.jpg" alt="twitter" width="23" height="19" border="0" /></a></td>
      <td width="4%" align="right"><!-- <a href="#" target="_blank"><img src="https://voot-static.s3.amazonaws.com/mail/PROMO-GREEN2_09_03.jpg" alt="linkedin" width="20" height="19" border="0" /></a>--></td>
      <td width="5%">&nbsp;</td>
      </tr>
  </table></td>
  </tr>
  <tr>
  <td>&nbsp;</td>
  </tr>
  <tr>
  <td align="center"><font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#231f20; font-size:8px"><strong> <a href= "#" style="color:#010203; text-decoration:none"></a></strong></font></td>
  </tr>
  <tr>
  <td>&nbsp;</td>
  </tr>
  </table></td>
  </tr>
  </table>
  </body>
  </html>`
};
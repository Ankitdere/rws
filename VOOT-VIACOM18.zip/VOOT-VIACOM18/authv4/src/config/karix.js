const Config = require("./configuration");
const https = require("https"); 

module.exports = {sendSMS};

function sendSMS(mobile, sendMsg) {
	const sanitizedMobile = mobile.replace("+", ""); // Remove + symbol from country code (e.g +91 = 91)
	// eslint-disable-next-line no-undef
	return new Promise((resolve, reject) => {
		const urlEncodedMessage = encodeURIComponent(sendMsg).replace(/'/g, "%27");
		const msgURL = `${Config.Karix.url}?ver=${Config.Karix.ver}&key=${Config.Karix.key}&encrpt=${Config.Karix.encrpt}&send=${Config.Karix.send}&dest=${sanitizedMobile}&text=${urlEncodedMessage}`;
		console.debug({msgURL});
		_httpClient().get(msgURL, (response) => {
			let karixResponse = "";
			// A chunk of data has been received.
			response.on("data", (chunk) => {
				karixResponse += chunk;
			});
			response.on("end", () => {
				console.log({karixResponse});
				return resolve(karixResponse);
			});
		}).on("error", (error) => {
			console.error("SMS failed by Karix", error, msgURL);
			return reject(error.message);
		});
	});
}

//   static getRemainingSmsCredits(): Promise<number> {
//     const apiURL: string = `${Config.SmsCredits.url}?uname=${Config.SmsCredits.username}&pass=${Config.SmsCredits.password}`;
//     console.log({apiURL});
//     return new Promise((resolve, reject) => {
//       this._httpClient().get(apiURL, (response) => {
//         // API expected to return only integer value of remaining SMS credits
//         let data = '';
//         response.on('data', (chunk) => {
//           data += chunk;
//         });
//         response.on('end', () => {
//           const remainingCredits: number = parseInt(data);
//           if (isNaN(remainingCredits)) {
//             const message = `Invalid value encountered for remaining SMS credits. Expected a number, got ${remainingCredits}`;
//             console.log(message);
//             return reject(message);
//           }
//           return resolve(remainingCredits);
//         });
//       }).on('error', (error) => {
//         console.log('Unable to get remaining SMS credits: ', error, apiURL);
//         return reject(error.message);
//       });
//     });
//   }

function _httpClient() {
	return https;
}


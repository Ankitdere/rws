module.exports = {
	forgotPasswordEmail: "Use {Password} as your login Password to reset your Voot account password.",
	forgotPasswordMobile: "Use {OTP} as your OTP to reset your Voot password. If you didnt make this request please alert us at support@voot.com. - Voot",
	forgotPasswordMobileHashCode: "<#> Use {OTP} as your OTP to reset your Voot password. If you did not make this request, please alert us at support@voot.com. -{HASHCODE}",
	// Email body/messages
	bodyWelcomeEmail: "Welcome to Voot. Your account is active. Subscribe now to explore the world of your favorite programs.",
	// OTP template
	signUp: "Use {OTP} as your OTP to verify your mobile number on Voot.\r\n \r\n - Voot",
	signUpHashCode:"<#> {OTP} is your OTP for verifying your mobile number on Voot. - {HASHCODE}",
	ims: ((process.env.VOOT_ENV=="prod")?"{OTP} is your OTP for verifying your mobile number on Voot.\n\n@interactivity.voot.com #{OTP}":"{OTP} is your OTP for verifying your mobile number on Voot.\n\n@cfe-stage.voot.com #{OTP}"),
	// pin recovery SMS 
	recoveryPin:"{OTP} is your Parent PIN on Voot. In case this doesn't work, please write to support@voot.com",
	// Mail subjects
	forgotPasswordSubject: "Voot Forgot Password Request",
	welcomeSubject: "Voot :: Welcome",
	bodyHeader: `
           <!DOCTYPE HTML>
            <html>
            <head>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
            <title></title>
            </head>

            <body bgcolor="#8d8e90">
            <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#8d8e90">
            <tr>
                <td><table width="600" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFFFFF" align="center" style="padding-top:10px;">
                    <tr>
                    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                            <td width="20"><a href= "#" target="_blank"><!--<img src="images/PROMO-GREEN2_01_01.jpg" width="61" height="76" border="0" alt=""/>--></a></td>
                            <td width="93"><a href= "www.voot.com" target="_blank"><img src="https://voot-v2-cms.s3.amazonaws.com/fe-images/76X76-APP.JPG" width="93" height="76" border="0" alt=""/></a></td>
                            <td width="365"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                <td height="46" align="right" valign="middle"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    
                                    </table></td>
                                </tr>
                                <tr>
                                    <td height="30"><img src="https://voot-static.s3.amazonaws.com/mail/PROMO-GREEN2_01_04.jpg" width="350" height="30" border="0" alt=""/></td>
                                </tr>
                            </table></td>
                        </tr>
                        </table></td>
                    </tr>
                    <tr>
                    <td align="center">&nbsp;</td>
                    </tr>
                    <tr>
                    <td>&nbsp;</td>
                    </tr>
                    <tr>
                    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                            <td width="5%">&nbsp;</td>
                            <td width="90%" colspan="2" align="left" valign="top">
                <font style="font-family: Georgia, 'Times New Roman', Times, serif; color:#010101; font-size:24px">
                <strong>
                    <em>Hi {displayName},</em></strong></font><br /><br />
                    <font style="font-family: Verdana, Geneva, sans-serif; color:#666766; font-size:13px; line-height:21px">
            `,
	bodySubject: `
            <p>We received a request to reset the password associated with this e-mail address.</p>

            <p>Please enter the password <strong>{Password}</strong> in the login screen by clicking register/login and reset your password to something more memorable.</p>
            <table width="100%">
            <tr>
            <td align="center" style="padding:10px 0;">
                <a href="www.voot.com" target="_blank" style="color:#ffffff; text-decoration: underline"><img src="https://voot-static.s3.amazonaws.com/mail/take-me-to-voot-button.png" alt="" width="217" height="32" border="0"></a>
            </td>        
            </tr>    
            </table>
            <p>If you did not request to have your password reset you can safely ignore this email.</p>
            <br />
          </font></td>
          `,
	footer: `<td width="5%">&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
        <td align="left" valign="top">
         <font style="font-family: Verdana, Geneva, sans-serif; color:#666766; font-size:13px; line-height:21px">
          <br/>Regards,<br/>
          Voot Team</font>
        </td>
      
    
      <td>&nbsp;</td>
    </tr>
  </table></td>
  </tr>
  <tr>
  <td>&nbsp;</td>
  </tr>
  <tr>
  <td>&nbsp;</td>
  </tr>
  <tr>
      <td><img src="https://voot-static.s3.amazonaws.com/mail/PROMO-GREEN2_07.jpg" width="598" height="7" style="display:block" border="0" alt=""/></td>
  </tr>
  <tr>
  <td>&nbsp;</td>
  </tr>
  <tr>
  <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
      <td width="13%" align="center">&nbsp;</td>
      <td width="14%" align="center"><!-- <font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><a href= "#" style="color:#010203; text-decoration:none"><strong>UNSUBSCRIBE </strong></a></font> --></td>
      <td width="2%" align="center"><!-- <font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><strong>|</strong></font> --></td>
      <td width="9%" align="center"><!-- <font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><a href= "http://voot.com/about-us" style="color:#010203; text-decoration:none"><strong>ABOUT </strong></a></font> --></td>
      <td width="2%" align="center"><!-- <font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><strong>|</strong></font> --></td>
      <td width="11%" align="center"><font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><a href= "http://voot.com/about-us" style="color:#010203; text-decoration:none"><strong>ABOUT US</strong></a></font></td>
      <td width="2%" align="center"><font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><strong>|</strong></font></td>
      <td width="11%" align="center"><font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><a href= "http://voot.com/contact-us" style="color:#010203; text-decoration:none" target="_blank"><strong>CONTACT US</strong></a></font></td>
      <td width="2%" align="center"><font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><strong>|</strong></font></td>
      <td width="17%" align="center"><font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><strong>STAY CONNECTED</strong></font></td>
      <td width="4%" align="right"><a href="https://facebook.com/voot/" target="_blank"><img src="https://voot-static.s3.amazonaws.com/mail/PROMO-GREEN2_09_01.jpg" alt="facebook" width="22" height="19" border="0" /></a></td>
      <td width="5%" align="center"><a href="https://twitter.com/justvoot" target="_blank"><img src="https://voot-static.s3.amazonaws.com/mail/PROMO-GREEN2_09_02.jpg" alt="twitter" width="23" height="19" border="0" /></a></td>
      <td width="4%" align="right"><!-- <a href="#" target="_blank"><img src="https://voot-static.s3.amazonaws.com/mail/PROMO-GREEN2_09_03.jpg" alt="linkedin" width="20" height="19" border="0" /></a>--></td>
      <td width="5%">&nbsp;</td>
      </tr>
  </table></td>
  </tr>
  <tr>
  <td>&nbsp;</td>
  </tr>
  <tr>
  <td align="center"><font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#231f20; font-size:8px"><strong> <a href= "#" style="color:#010203; text-decoration:none"></a></strong></font></td>
  </tr>
  <tr>
  <td>&nbsp;</td>
  </tr>
  </table></td>
  </tr>
  </table>
  </body>
  </html>`,
	forgotPassBodyHeader: `
           <!DOCTYPE HTML>
            <html>
            <head>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
            <title></title>
            </head>

            <body bgcolor="#8d8e90">
            <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#8d8e90">
            <tr>
                <td><table width="600" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFFFFF" align="center" style="padding-top:10px;">
                    <tr>
                    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                            <td width="20"><a href= "#" target="_blank"><!--<img src="images/PROMO-GREEN2_01_01.jpg" width="61" height="76" border="0" alt=""/>--></a></td>
                            <td width="93"><a href= "www.voot.com" target="_blank"><img src="https://voot-v2-cms.s3.amazonaws.com/fe-images/76X76-APP.JPG" width="93" height="76" border="0" alt=""/></a></td>
                            <td width="365"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                <td height="46" align="right" valign="middle"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    
                                    </table></td>
                                </tr>
                                <tr>
                                    <td height="30"><img src="https://voot-static.s3.amazonaws.com/mail/PROMO-GREEN2_01_04.jpg" width="350" height="30" border="0" alt=""/></td>
                                </tr>
                            </table></td>
                        </tr>
                        </table></td>
                    </tr>
                    <tr>
                    <td align="center">&nbsp;</td>
                    </tr>
                    <tr>
                    <td>&nbsp;</td>
                    </tr>
                    <tr>
                    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                            <td width="5%">&nbsp;</td>
                            <td width="90%" colspan="2" align="left" valign="top">
                <font style="font-family: Georgia, 'Times New Roman', Times, serif; color:#010101; font-size:24px">
                <strong>
                    <em>Hi {displayName},</em></strong></font><br /><br />
                    <font style="font-family: Verdana, Geneva, sans-serif; color:#666766; font-size:13px; line-height:21px">
            `,
	forgotPassBodySubject: `
            <table width="100%">
            <tr>
            <td align="center" style="padding:10px 0;">
                <a href="https://www.voot.com?token={forgotPasswordToken}" target="_blank" style="color:#ffffff; text-decoration: underline"><img src="https://voot-static.s3.amazonaws.com/mail/take-me-to-voot-button.png" alt="" width="217" height="32" border="0"></a>
            </td>        
            </tr>    
            </table>
            <p>If you did not request to have your password reset you can safely ignore this email.</p>
            <br />
          </font></td>
          `,
	forgotPassFooter: `<td width="5%">&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
        <td align="left" valign="top">
         <font style="font-family: Verdana, Geneva, sans-serif; color:#666766; font-size:13px; line-height:21px">
          <br/>Regards,<br/>
          Voot Team</font>
        </td>
      
    
      <td>&nbsp;</td>
    </tr>
  </table></td>
  </tr>
  <tr>
  <td>&nbsp;</td>
  </tr>
  <tr>
  <td>&nbsp;</td>
  </tr>
  <tr>
      <td><img src="https://voot-static.s3.amazonaws.com/mail/PROMO-GREEN2_07.jpg" width="598" height="7" style="display:block" border="0" alt=""/></td>
  </tr>
  <tr>
  <td>&nbsp;</td>
  </tr>
  <tr>
  <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
      <td width="13%" align="center">&nbsp;</td>
      <td width="14%" align="center"><!-- <font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><a href= "#" style="color:#010203; text-decoration:none"><strong>UNSUBSCRIBE </strong></a></font> --></td>
      <td width="2%" align="center"><!-- <font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><strong>|</strong></font> --></td>
      <td width="9%" align="center"><!-- <font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><a href= "http://voot.com/about-us" style="color:#010203; text-decoration:none"><strong>ABOUT </strong></a></font> --></td>
      <td width="2%" align="center"><!-- <font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><strong>|</strong></font> --></td>
      <td width="11%" align="center"><font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><a href= "http://voot.com/about-us" style="color:#010203; text-decoration:none"><strong>ABOUT US</strong></a></font></td>
      <td width="2%" align="center"><font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><strong>|</strong></font></td>
      <td width="11%" align="center"><font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><a href= "http://voot.com/contact-us" style="color:#010203; text-decoration:none" target="_blank"><strong>CONTACT US</strong></a></font></td>
      <td width="2%" align="center"><font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><strong>|</strong></font></td>
      <td width="17%" align="center"><font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#010203; font-size:9px; text-transform:uppercase"><strong>STAY CONNECTED</strong></font></td>
      <td width="4%" align="right"><a href="https://facebook.com/voot/" target="_blank"><img src="https://voot-static.s3.amazonaws.com/mail/PROMO-GREEN2_09_01.jpg" alt="facebook" width="22" height="19" border="0" /></a></td>
      <td width="5%" align="center"><a href="https://twitter.com/justvoot" target="_blank"><img src="https://voot-static.s3.amazonaws.com/mail/PROMO-GREEN2_09_02.jpg" alt="twitter" width="23" height="19" border="0" /></a></td>
      <td width="4%" align="right"><!-- <a href="#" target="_blank"><img src="https://voot-static.s3.amazonaws.com/mail/PROMO-GREEN2_09_03.jpg" alt="linkedin" width="20" height="19" border="0" /></a>--></td>
      <td width="5%">&nbsp;</td>
      </tr>
  </table></td>
  </tr>
  <tr>
  <td>&nbsp;</td>
  </tr>
  <tr>
  <td align="center"><font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#231f20; font-size:8px"><strong> <a href= "#" style="color:#010203; text-decoration:none"></a></strong></font></td>
  </tr>
  <tr>
  <td>&nbsp;</td>
  </tr>
  </table></td>
  </tr>
  </table>
  </body>
  </html>`,
	//New Format For Forgot Password Include Deep link along with new Email Template
	passwordReset: "Voot Password Reset",
	deepLink2: "www.voot.com/forgotpwd/",
	newForgotPasswordTemplate: `
 <p>You recently requested to reset your password on VOOT via the Forgot Password link on the app/website. </p>

 <p>Please click the link below to confirm and continue resetting your password on Voot.</p>
 <p>After clicking the link below, the OTP for resetting your password is:{Password}</p>
 <table width="100%">
 <tr>
 <td align="center" style="padding:10px 0;">
     <a href="{DEEPLINK}" target="_blank" style="color:#ffffff; text-decoration: underline"><img src="https://voot-static.s3.amazonaws.com/mail/take-me-to-voot-button.png" alt="" width="217" height="32" border="0"></a>
 </td>        
 </tr>    
 </table>
 <p>Please note the above password reset link will be valid for the next 30 minutes.</p>
 <p>If you did not request a password reset,please ignore this email or send us an email at <a href="support@voot.com">support@voot.com</a></p>
  <br />
</font></td>
`
};
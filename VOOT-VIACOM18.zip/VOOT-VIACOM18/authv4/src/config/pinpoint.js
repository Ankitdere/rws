"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const configuration = require("../config").configuration;
const AWS = require("aws-sdk");
AWS.config.update({
	accessKeyId: configuration.AWS1.accessKeyId,
	secretAccessKey: configuration.AWS1.secretAccessKey,
	region: configuration.AWS1.region
});
// var  pinpoint = new AWS.Pinpoint();
module.exports.default = new AWS.Pinpoint();

"use strict";
const Joi = require("joi");
const errorConfig = require("../config").errorConfig;

module.exports = jioSubscription;

function jioSubscription(input) {
	const schema = Joi.object().keys({
		deviceName: Joi.string().empty().required().label(errorConfig.validationError.deviceName),
		deviceId: Joi.string().empty().required().label(errorConfig.validationError.deviceId),
		ssoToken: Joi.string().empty().required().label(errorConfig.validationError.ssoToken),
		buildNumber: Joi.string().optional(),
		uid: Joi.string().optional(),
		subscriberId: Joi.string().empty().required().label(errorConfig.validationError.subscriberId),
		accessToken: Joi.string().optional()
	});
	return Joi.validate(input, schema, { abortEarly: false });
}

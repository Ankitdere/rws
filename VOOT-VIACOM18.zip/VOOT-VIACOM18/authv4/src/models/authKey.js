"use strict";

const Joi = require("joi");
const errorConfig = require("../config").errorConfig;
module.exports = authKey;

function authKey(input) {
	const schema = Joi.object().keys({
		accessToken : Joi.string().required().label(errorConfig.validationError.accessToken),
		lastLoginProvider : Joi.string().optional().empty("").label(errorConfig.validationError.lastLoginProvider),
		profileId: Joi.string().optional()
	});

	return Joi.validate(input, schema, { abortEarly: false });
}
"use strict";
const Joi = require("joi");
const errorConfig = require("../config").errorConfig;

module.exports = kalturaBuildData;

function kalturaBuildData(input) {
	const schema = Joi.object().keys({
		uid: Joi.string().required().label(errorConfig.validationError.uid),
		email: Joi.string().email({ minDomainAtoms: 2 }).required().label(errorConfig.validationError.email),
		platform: Joi.string().required().label(errorConfig.validationError.platform),
		kalturaBuildNo: Joi.string().optional().label(errorConfig.validationError.kalturaBuildNo),
		kUserId: Joi.string().optional().label(errorConfig.validationError.kUserId),
	});
	return Joi.validate(input, schema, { abortEarly: false });
}
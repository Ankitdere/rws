"use strict";
const Joi = require("joi");
const errorUtilities = require("../config").errorConfig;
const constant = require("../utils/constant/generic");

module.exports = checkUser;

function checkUser(input,type) {
	console.debug("Reached checkUserEmail Validation Model");		
	let schemaData;
	const typeSchema = Joi.object().keys({ type: Joi.string().valid("email","mobile").required().label(errorUtilities.validationError.type) });
	let { error } = Joi.validate({ type: type }, typeSchema, { abortEarly: false });
	if (error) {
		return { error };
	}

	switch (input.type) {
	case ("email"):
		schemaData = Joi.object().keys({
			type: Joi.string().valid("email","mobile").required().label(errorUtilities.validationError.type),
			email: Joi.string().email({ minDomainAtoms: 2 }).required().label(errorUtilities.validationError.email)
		});
		break;
	case ("mobile"):
		schemaData = Joi.object().keys({
			type: Joi.string().valid("email","mobile").required().label(errorUtilities.validationError.type),
			mobile: Joi.string().regex(/^\d+$/).length(10).required().label(errorUtilities.validationError.mobile),
			countryCode: Joi.string().min(2).max(4).regex(/^(\+)(\d{1,3}|\d{1,4})$/).required().label(errorUtilities.validationError.countryCode),
			otpVersion: Joi.string().valid(constant.VALID_OTP_VERSION.v1,constant.VALID_OTP_VERSION.v2).optional().label(errorUtilities.validationError.otpVersion)
		});
		break;
	default:
		break;
	}    
	return Joi.validate(input, schemaData, { abortEarly: false });
}


const Joi = require( "joi" );
const errorConfig = require( "../config" ).errorConfig;

module.exports = synchCrmData;

function synchCrmData ( input ) {
	let schema;
	schema = Joi.object().keys( {
		uid: Joi.string().optional().trim().label( errorConfig.validationError.uid ),
		email: Joi.string().email( { minDomainAtoms: 2 } ).optional().label( errorConfig.validationError.email ),
		mode: Joi.string().optional().trim().label( errorConfig.validationError.uid )
	} ).required().min( 1 ).label( errorConfig.validationError.emptyBody );

	return Joi.validate( input, schema, { abortEarly: false } );
}

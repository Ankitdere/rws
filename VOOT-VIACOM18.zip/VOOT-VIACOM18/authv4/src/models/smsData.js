const Joi = require("joi");
const { errorConfig } = require("../config");

/**
 * Date in dd-mm-yyyy format
 */
const DATE_REGEX = /^([0-2][0-9]|(3)[0-1])(-)(((0)[0-9])|((1)[0-2]))(-)\d{4}$/;

/** 
 * @param {Object} value 
 */
const validate = function (value) {
	const { validationError } = errorConfig;
	const schema = {
		startDate: Joi.string()
			.required()
			.regex(DATE_REGEX)
			.label(validationError.startDate),
		endDate: Joi.string()
			.required()
			.regex(DATE_REGEX)
			.label(validationError.endDate)
	};
	const options = {
		abortEarly: false,
	};
	return Joi.validate(value, schema, options);
};

module.exports = validate;
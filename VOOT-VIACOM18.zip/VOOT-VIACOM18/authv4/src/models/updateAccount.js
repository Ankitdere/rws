
"use strict";
const baseJoi = require("joi");
const dateJoiExtension = require("@hapi/joi-date");
const errorConfig = require("../config").errorConfig;
const Joi = baseJoi.extend(dateJoiExtension);
const apiResponse = require("../utils").apiResponse;
const _ = require("lodash");

function updateAccount(headers, input) {
	const headersValidation= {
		accessToken:_.get(headers,"accessToken"),
		apiVersion:_.get(headers,"apiVersion",null)
	};
	const headersSchema = Joi.object().keys({ 
		accessToken: Joi.string().required().label(errorConfig.validationError.accessToken),
		apiVersion: Joi.string().allow(null,"").optional().label(errorConfig.validationError.apiVersion)
	});
	let { error } = Joi.validate(headersValidation, headersSchema, { abortEarly: false });
	if (error) {
		return { error };
	}
	if (_.keys(input).length == 0) {
		return { error: apiResponse.error(errorConfig.emptyBody.description,errorConfig.emptyBody.code)};
	}
	const schema = Joi.object().keys({
		languages: Joi.array().items(Joi.string().allow("")).label(errorConfig.validationError.languages),
		firstname: Joi.string().min(3).max(25).optional().label(errorConfig.validationError.firstName),
		lastname: Joi.string().optional(),
		profilename: Joi.string().allow("").optional().label(errorConfig.validationError.profileName),
		gender: Joi.string().valid("M", "F", "O", "U").optional().label(errorConfig.validationError.gender),
		birthdate: Joi.date().utc().max("now").format("DD-MM-YYYY").optional().raw().label(errorConfig.validationError.birthdate),
		tncVersion:Joi.string().regex(/^\d+(\.\d{1,2})?$/).optional().label(errorConfig.validationError.tncVersion),
		tncAcceptTime:Joi.date().timestamp().raw().optional().label(errorConfig.validationError.tncAcceptTime)
	});
	return Joi.validate(input, schema, { abortEarly: false });
}
module.exports = updateAccount;



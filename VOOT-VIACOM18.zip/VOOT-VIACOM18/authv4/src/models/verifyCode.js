"use strict";
const Joi = require("joi");
const errorConfig = require("../config").errorConfig;

module.exports = verifyCode;

function verifyCode(input) {
	const schema = Joi.object().keys({
		deviceBrand: Joi.string().empty().required().label(errorConfig.validationError.deviceBrand),
		deviceId: Joi.string().empty().required().label(errorConfig.validationError.deviceId),
		code: Joi.string().empty().required().label(errorConfig.validationError.code)
	});

	return Joi.validate(input, schema, { abortEarly: false });
}

"use strict";
const Joi = require("joi");
const errorUtilities = require("../config").errorConfig;

module.exports = verifyOtp;

function verifyOtp(input) {   
	const schemaToValidate = Joi.object().keys({
		mobile: Joi.string().regex(/^\d+$/).length(10).required().label(errorUtilities.validationError.mobile),
		countryCode: Joi.string().min(2).max(4).regex(/^(\+)(\d{1,3}|\d{1,4})$/).required().label(errorUtilities.validationError.countryCode),
		otp: Joi.string().length(4).regex(/^\d+$/).trim().required().label(errorUtilities.validationError.otp),
		action: Joi.string().min(3).valid("imsOtp").optional().label(errorUtilities.validationError.action),
	});
	return Joi.validate(input, schemaToValidate, { abortEarly: false });
}


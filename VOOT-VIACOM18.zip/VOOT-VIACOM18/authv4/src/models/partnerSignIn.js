"use strict";
const Joi = require("joi");
const errorConfig = require("../config").errorConfig;
const config = require("../config").configuration;
const _ = require("lodash");
const apiResponse = require("../utils").apiResponse;

module.exports = partnerSignIn;

function partnerSignIn(input) {
	console.debug("Reached partnerSignIn Validation Model");
	let schemaData;
	let schema = {
		partnerType: Joi.string().required().valid([config.tSkyDetails.partnerType, config.jioSubscription.partnerType]).label(errorConfig.validationError.partnerType),
		deviceId: Joi.string().required().label(errorConfig.validationError.deviceId),
		deviceBrand: Joi.string().required().label(errorConfig.validationError.deviceBrand),
		data: Joi.object().required().label(errorConfig.validationError.emptyBody)
	};
	//TODO :need optimization because JOI Assertion error
	const typeArr = [config.tSkyDetails.partnerType, config.jioSubscription.partnerType];
	if ((!_.has(input, "partnerType"))) {
		throw { https: 400, error: apiResponse.error(errorConfig.partnerTypeIsRequired.description, errorConfig.partnerTypeIsRequired.code) };
	} else if ((_.isEmpty(input.partnerType))) {
		throw { https: 400, error: apiResponse.error(errorConfig.partnerTypeIsNotAllowToEmpty.description, errorConfig.partnerTypeIsNotAllowToEmpty.code) };
	}
	else if (!_.includes(typeArr, input.partnerType)) {
		throw { https: 400, error: apiResponse.error(errorConfig.PartnerTypeMissing.description, errorConfig.PartnerTypeMissing.code) };
	}
	
	switch (input.partnerType) {
	case (config.tSkyDetails.partnerType):
		schemaData = Joi.object().keys({
			token: Joi.string().required().label(errorConfig.validationError.partnerToken),
			dsn: Joi.string().required().label(errorConfig.validationError.indsn),
			source: Joi.string().optional().valid(config.tSkyDetails.source_sign_in).label(errorConfig.validationError.insource),
		}).required().label(errorConfig.validationError.emptyBody);
		break;
	case (config.jioSubscription.partnerType):
		schemaData = Joi.object().keys({
			token: Joi.string().required().label(errorConfig.validationError.partnerToken),
			externalId: Joi.string().min(1).required().label(errorConfig.validationError.inexternalId),
		}).required().label(errorConfig.validationError.emptyBody);
		break;
	default:
		break;
	}

	schema = Joi.object().keys(Object.assign({}, schema, { data: schemaData }));
	return Joi.validate(input, schema, { abortEarly: false });
}

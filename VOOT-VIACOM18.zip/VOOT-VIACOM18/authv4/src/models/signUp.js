
"use strict";
const baseJoi = require("joi");
const dateJoiExtension = require("@hapi/joi-date");
const errorUtilities = require("../config").errorConfig;
const Joi = baseJoi.extend(dateJoiExtension);

module.exports = signUp;

function signUp(input) {
	//console.log("Reached SignUp Validation Model");
	let schemaData;
	let schema = {
		type: Joi.string().valid("traditional", "mobile").required().label(errorUtilities.validationError.type),
		deviceId: Joi.string().required().label(errorUtilities.validationError.deviceId),
		deviceBrand: Joi.string().required().label(errorUtilities.validationError.deviceBrand),
		kUserId: Joi.string(),
		countryCode: Joi.string().optional(),
		data: Joi.string()
	};
	switch (input.type) {
	case ("traditional"):
		schemaData = Joi.object().keys({
			email: Joi.string().email({ minDomainAtoms: 2 }).required().label(errorUtilities.validationError.email),
			password: Joi.string().min(6).max(16).required().trim().label(errorUtilities.validationError.password),
			firstname: Joi.string().optional().allow("").label(errorUtilities.validationError.firstName),
			profilename: Joi.string().optional().allow("").label(errorUtilities.validationError.profileName),
			lastname: Joi.string().allow("").optional(),
			gender: Joi.string().valid("M", "F", "O", "U").required().label(errorUtilities.validationError.gender),
			birthdate: Joi.date().utc().max("now").format("DD-MM-YYYY").raw().required().label(errorUtilities.validationError.birthdate),
			languages: Joi.array().items(Joi.string().allow("")).label(errorUtilities.validationError.languages),
			tncVersion:Joi.string().regex(/^\d+(\.\d{1,2})?$/).optional().label(errorUtilities.validationError.tncVersion),
			tncAcceptTime:Joi.date().timestamp().raw().optional().label(errorUtilities.validationError.tncAcceptTime)
		}).required().label(errorUtilities.validationError.emptyBody);
		break;
	case ("facebook"):
	case ("google"):
		schemaData = Joi.object().keys({
			token: Joi.string().required().label(errorUtilities.validationError.token),
			uid: Joi.string().required().label(errorUtilities.validationError.uid)
		}).required().label(errorUtilities.validationError.emptyBody);
		break;
	case ("mobile"):
		schemaData = Joi.object().keys({
			mobile: Joi.string().regex(/^\d+$/).length(10).required().trim().label(errorUtilities.validationError.mobile),
			countryCode: Joi.string().min(2).max(4).regex(/^(\+)(\d{1,3}|\d{1,4})$/).required().trim().label(errorUtilities.validationError.countryCode),
			password: Joi.string().min(6).max(16).required().trim().label(errorUtilities.validationError.password),
			firstname: Joi.string().min(3).max(25).optional().label(errorUtilities.validationError.firstName),
			profilename: Joi.string().min(3).max(25).optional().label(errorUtilities.validationError.profileName),
			lastname: Joi.string().allow("").optional(),
			gender: Joi.string().valid("M", "F", "O", "U").required().label(errorUtilities.validationError.gender),
			birthdate: Joi.date().utc().max("now").format("DD-MM-YYYY").raw().required().label(errorUtilities.validationError.birthdate),
			languages: Joi.array().items(Joi.string().allow("")).label(errorUtilities.validationError.languages),
			tncVersion:Joi.string().regex(/^\d+(\.\d{1,2})?$/).optional().label(errorUtilities.validationError.tncVersion),
			tncAcceptTime:Joi.date().timestamp().raw().optional().label(errorUtilities.validationError.tncAcceptTime)
		}).required().label(errorUtilities.validationError.emptyBody);
		break;
	default:
		break;
	}
	schema = Joi.object().keys(Object.assign({}, schema, { data: schemaData }));
	return Joi.validate(input, schema, { abortEarly: false });
}



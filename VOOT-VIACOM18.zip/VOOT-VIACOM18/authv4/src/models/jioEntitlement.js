"use strict";
const Joi = require("joi");
const errorConfig = require("../config").errorConfig;

module.exports = jioSubscription;

function jioSubscription(input) {
	const schema = Joi.object().keys({
		deviceName: Joi.string().empty().optional(),
		deviceId: Joi.string().empty().optional(),
		buildNumber: Joi.string().optional(),
		uid: Joi.string().optional(),
		ssoToken: Joi.string().empty().required().label(errorConfig.validationError.ssoToken),
		accessToken: Joi.string().empty().required().label(errorConfig.validationError.accessToken),
		ks: Joi.string().empty().required().label(errorConfig.validationError.ks),
	});
	return Joi.validate(input, schema, { abortEarly: false });
}
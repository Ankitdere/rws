"use strict";
const baseJoi = require("joi");
const dateJoiExtension = require("@hapi/joi-date");
const errorConfig = require("../config").errorConfig;
const Joi = baseJoi.extend(dateJoiExtension);
module.exports = updateProfile;

/**
 * 
 * @param {Object} headers 
 * @param {Object} input 
 * @returns {Object}
 */
function updateProfile(headers, input) {

	let schema;
	const headerValidation = Joi.object().keys({
		accessToken: Joi.string()
			.required()
			.label(errorConfig.validationError.accessToken)
	});

	let { error } = Joi.validate(headers, headerValidation, { abortEarly: false });
	if (error) {
		return { error };
	}
	schema = Joi.object().keys({
		childUid:Joi.string()
			.required()
			.label(errorConfig.validationError.invalidSubProfileUid),
		profilename: Joi.string()
			.min(3)
			.max(50)
			.optional()
			.label(errorConfig.validationError.invalidProfileName),
		gender: Joi
			.string()
			.valid("M", "F", "O", "U")
			.label(errorConfig.validationError.gender),
		birthdate: Joi
			.date()
			.utc()
			.max("now")
			.format("DD-MM-YYYY")
			.raw()
			.label(errorConfig.validationError.birthdate),
		languages: Joi
			.array()
			.items(Joi
				.string()
				.allow("", null)
				.label(errorConfig.validationError.languages))
			.min(1)
			.label(errorConfig.validationError.languages),


	}).label(errorConfig.validationError.emptyBody);

	return Joi.validate(input, schema, { abortEarly: false });
}



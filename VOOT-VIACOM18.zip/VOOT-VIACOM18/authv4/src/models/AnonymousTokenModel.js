const Joi = require("joi");
const errorUtilities = require("../config").errorConfig;
const Config = require("../config").configuration;
module.exports = { validateCreateToken };

function validateCreateToken(input) {
	let schemaData;
	schemaData = Joi.object().keys({
		grantType: Joi.string().valid(Config.AnonymousGrantType.anonymous, Config.AnonymousGrantType.refresh_token,Config.AnonymousGrantType.authorization_token,Config.AnonymousGrantType.interactivity,Config.AnonymousGrantType.vendor_feature_token).required().label(errorUtilities.validationError.grantType),
		refreshToken: Joi.string().required().when("grantType", {
			is: "refresh_token",
			then: Joi.string().required(),
			otherwise: Joi.forbidden()
		}).label(errorUtilities.validationError.refreshToken),
		code: Joi.string().label(errorUtilities.validationError.code),
		partnerName: Joi.valid(Config.AnonymousTokenSource).label(errorUtilities.validationError.partnerName),
		clientId: Joi.string().required().valid(Config.AnonymousTokenClientId).label(errorUtilities.validationError.clientId),
		apiKey: Joi.string().required().valid(Config.AnonymousTokenClientIdApiKey.ZXFuYTrEEnjryJIOActive,Config.AnonymousTokenClientIdApiKey.ZXIgTWFuY2hlc3RlcjEJIO,Config.AnonymousTokenClientIdApiKey.HGgeweiTYV3243OIff3234).label(errorUtilities.validationError.apiKey)
	}).required().label(errorUtilities.validationError.emptyBody);
	return Joi.validate(input, schemaData, { abortEarly: false });
}
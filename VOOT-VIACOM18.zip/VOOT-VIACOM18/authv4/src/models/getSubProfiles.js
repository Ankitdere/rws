"use strict";
const baseJoi = require("joi");
const dateJoiExtension = require("@hapi/joi-date");
const errorConfig = require("../config").errorConfig;
const Joi = baseJoi.extend(dateJoiExtension);
module.exports = getSubProfiles;

/**
 * 
 * @param {*} headers 
 * @returns 
 */
function getSubProfiles(headers) {

	const headerValidation = Joi.object().keys({
		accessToken: Joi.string()
			.required()
			.label(errorConfig.validationError.accessToken)
	});

	return Joi.validate(headers, headerValidation, { abortEarly: false });
}



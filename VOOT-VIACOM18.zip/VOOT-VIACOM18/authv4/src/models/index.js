const login = require("./login");
const signUp = require("./signUp");
const updateAccount = require("./updateAccount");
const updateProfile = require("./updateProfile");
const loginCode = require("./loginCode");
const verifyCode = require("./verifyCode");
const activateCode = require("./activateCode");
const forgotPassword = require("./forgotPassword");
const passwordChange = require("./passwordChange");
const profileAccessToken = require("./profileAccessToken");
const refreshAccessToken = require("./refreshAccessToken");
const refreshKs = require("./refreshKs");
const authKey = require("./authKey");
const jioEntitlement = require("./jioEntitlement");
const jioSubscription = require("./jioSubscription");
const verifyOtpForgotPassword = require("./verifyOtpForgotPassword");
const resetPasswordWithLogin = require("./resetPasswordWithLogin");
const changePasswordWithLogin = require("./changePasswordWithLogin");
const appleRedirect = require("./appleRedirect");
const checkUser=require("./checkUser");
const resendOtp =require("./resendOtp");
const verifyOtp= require("./verifyOtp");
const resetPassword=require("./resetPassword");
const { partnerNotification, partnerNotificationDateValidator,partnerNotificationM2MIT} = require("./partnerNotification");
const partnerSignIn = require("./partnerSignIn");
const partnerDetails =require("./partnerDetails");
const anonymousTokenModel = require("./AnonymousTokenModel");
const apiKeyValidator = require("./apiKeyModel");
const getProfile =require("./getProfile");
const authsTokens =require("./authsTokens");
const getOtpDetailsModel = require("./getOtpDetails");
const searchDetailsModel = require("./searchDetailsModel");
const loginInfoByDeviceId = require( "./loginInfoByDeviceId" );
const kalturaBuildModel = require("./kalturaBuildModel");
const checkKalturaAccountModel = require("./checkKalturaAccountModel");
const createSubProfile = require("./createSubProfile");
const getSubProfiles = require("./getSubProfiles");
const getSubProfilesAccessToken = require("./getSubProfilesAccessToken");
const deleteSubProfile = require( "./deleteSubProfile" );
const updateSubProfile = require( "./updateSubProfile" );


const sendMessageModel = require("./sendMessageModel");
const smsData = require("./smsData");
const checkEmail = require("./checkEmail");

module.exports = {
	login,
	signUp,
	updateAccount,
	updateProfile,
	loginCode,
	verifyCode,
	activateCode,
	forgotPassword,
	passwordChange,
	profileAccessToken,
	refreshAccessToken,
	refreshKs,
	authKey,
	jioEntitlement,
	jioSubscription,
	verifyOtpForgotPassword,
	resetPasswordWithLogin,
	changePasswordWithLogin,
	appleRedirect,
	checkUser,
	resendOtp,
	verifyOtp,
	resetPassword,
	partnerNotification,
	partnerSignIn,
	partnerNotificationDateValidator,
	partnerNotificationM2MIT,
	partnerDetails,
	anonymousTokenModel,
	apiKeyValidator,
	getProfile,
	authsTokens,
	getOtpDetailsModel,
	searchDetailsModel,
	loginInfoByDeviceId,
	kalturaBuildModel,
	checkKalturaAccountModel,
	createSubProfile,
	getSubProfiles,
	getSubProfilesAccessToken,
	deleteSubProfile,
	updateSubProfile,
	sendMessageModel,
	smsData,
	checkEmail,
};
const Joi = require("joi");
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");

module.exports = checkKalturaData;

function checkKalturaData(input) {
	let schema;
	if (_.has(input, "uid")) {
		schema = Joi.object().keys({
			uid: Joi.string().required().trim().label(errorConfig.validationError.uid)
		});
	} else if ((_.has(input, "email"))) {
		schema = Joi.object().keys({
			email: Joi.string().email({ minDomainAtoms: 2 }).required().label(errorConfig.validationError.email)
		});
	} else {

		schema = Joi.object().keys({
			email: Joi.string().email({ minDomainAtoms: 2 }).required().label(errorConfig.validationError.email)
		});
	}
	return Joi.validate(input, schema, { abortEarly: false });
}

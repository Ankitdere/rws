"use strict";
const Joi = require( "joi" );
const errorConfig = require( "../config" ).errorConfig;

module.exports = loginInfoByDeviceId;

function loginInfoByDeviceId ( input ) {
	const schema = Joi.object().keys( {
		deviceId: Joi.string().required().label( errorConfig.validationError.deviceId ),
	} );
	return Joi.validate( input, schema, { abortEarly: false } );
}
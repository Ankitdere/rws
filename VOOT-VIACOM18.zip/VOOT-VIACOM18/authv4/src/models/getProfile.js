
"use strict";

const Joi = require("joi");
const errorConfig = require("../config").errorConfig;
module.exports = getProfile;

function getProfile(headers, DeviceList, PlatformList) {
	//Need to confirm get-profile should handle version  

	console.log("Header Need To validate........", headers);
	const schema = Joi.object().keys({
		accessToken: Joi.string().required().label(errorConfig.validationError.accessToken),
		profiletype: Joi.string().min(3).valid("ALL", "kidSafeMode","COMMON").optional().label(errorConfig.validationError.profileType),
		apiVersion: Joi.string().valid("v2").optional().label(errorConfig.validationError.apiVersion),
		deviceId: Joi.string().when("apiVersion", { is: Joi.exist(), then: Joi.required().not("null").label(errorConfig.validationError.deviceId), otherwise: Joi.optional().label(errorConfig.validationError.deviceId) }),
		device: Joi.string().valid(DeviceList).when("apiVersion", { is: Joi.exist(), then: Joi.required().valid(DeviceList).label(errorConfig.validationError.device), otherwise: Joi.optional().label(errorConfig.validationError.device) }),
		platform: Joi.string().valid(PlatformList).when("apiVersion", { is: Joi.exist(), then: Joi.required().valid(PlatformList).label(errorConfig.validationError.platform), otherwise: Joi.optional().label(errorConfig.validationError.platform) })
	});
	return Joi.validate(headers, schema, { abortEarly: false });
}
"use strict";
const Joi = require("joi");
const errorUtilities = require("../config").errorConfig;
const _ = require("lodash");
const constant = require("../utils/constant/generic");
module.exports = resendOtp;

function resendOtp(input) {
	let schemaToValidate;
	if ( (_.has(input, "mobile")) || (_.has(input, "countryCode")) ) {
		schemaToValidate = Joi.object().keys({
			mobile: Joi.string().regex(/^\d+$/).length(10).required().label(errorUtilities.validationError.mobile),
			countryCode: Joi.string().min(2).max(4).regex(/^(\+)(\d{1,3}|\d{1,4})$/).required().label(errorUtilities.validationError.countryCode),
			action: Joi.string().min(3).valid("forgotPasswordOtp","imsOtp").optional().label(errorUtilities.validationError.action),
			otpVersion: Joi.string().valid(constant.VALID_OTP_VERSION.v1,constant.VALID_OTP_VERSION.v2).optional().label(errorUtilities.validationError.otpVersion)
			// templateVersion: Joi.string().valid("V2","v2").optional().label(errorUtilities.validationError.templateVersion)
		});
	} else if ( (_.has(input, "email")) || (_.has(input, "templateVersion")) || (_.has(input, "action")) ) {

		schemaToValidate = Joi.object().keys({
			email: Joi.string().email({ minDomainAtoms: 2 }).required().label(errorUtilities.validationError.email),
			action: Joi.string().min(3).valid("forgotPasswordOtp").required().label(errorUtilities.validationError.action),
			templateVersion: Joi.string().valid("V2","v2").required().label(errorUtilities.validationError.templateVersion)
		});
	}
	else {
		schemaToValidate = Joi.object().keys({
			mobile: Joi.string().regex(/^\d+$/).length(10).required().label(errorUtilities.validationError.mobile),
			countryCode: Joi.string().min(2).max(4).regex(/^(\+)(\d{1,3}|\d{1,4})$/).required().label(errorUtilities.validationError.countryCode),
		});
	}
	return Joi.validate(input, schemaToValidate, { abortEarly: false });
}



"use strict";
const baseJoi = require("joi");
const dateJoiExtension = require("@hapi/joi-date");
const errorConfig = require("../config").errorConfig;
const Joi = baseJoi.extend(dateJoiExtension);
const configuration = require("../config").configuration;

module.exports = authsTokens;

function authsTokens(headers, input, DeviceList, PlatformList) {

	const headerValidation = Joi.object().keys({
		accessToken: Joi.string().required().label(errorConfig.validationError.accessToken),
		// templateVersion: Joi.string().valid("V2", "v2").optional(),
		device: Joi.string().valid(DeviceList).required().label(errorConfig.validationError.device),
		platform: Joi.string().valid(PlatformList).required().label(errorConfig.validationError.platform)
	});
	let { error } = Joi.validate(headers, headerValidation, { abortEarly: false });
	if (error) {
		return { error };
	}
	let schemaData;
	let schema;
	const { kidSafeModeRecovery, kidSafeModeReset, parentPinModeRecovery, parentPinModeReset } = configuration.ksmConfig; 
	if( kidSafeModeReset || parentPinModeReset){
		schema = {
			type: Joi.string().valid([
				kidSafeModeRecovery,
				kidSafeModeReset,
				parentPinModeRecovery,
				parentPinModeReset
			]).required().label(errorConfig.validationError.ksmtype)
		};
	}else{
		schema = {
			type: Joi.string().valid([
				kidSafeModeRecovery,
				kidSafeModeReset,
				parentPinModeRecovery,
				parentPinModeReset
			]).required().label(errorConfig.validationError.ksmtype),
			
			kidSafeMode: Joi.object(),
			parentPinMode: Joi.object()
		};
	}
	
	switch (input.type) {
	case kidSafeModeReset:
	case parentPinModeReset:
		schemaData = {};
		break;
	case kidSafeModeRecovery:
		schemaData = Joi.object().when("type", {
			is: Joi.only(kidSafeModeRecovery), then: Joi.object().required().keys({
				recovery: Joi.object().required().keys({
					mobile: Joi.string().regex(/^\d+$/).length(10).required().label(errorConfig.validationError.mobile),
					countryCode: Joi.string().min(2).max(4).regex(/^(\+)(\d{1,3}|\d{1,4})$/).required().label(errorConfig.validationError.countryCode),
				}).label(errorConfig.validationError.ksmrecovery)
			}).label(errorConfig.validationError.kidsSafeMode), otherwise: Joi.optional().label(errorConfig.validationError.ksmtype)
		});
		schema = Joi.object().keys(Object.assign({}, schema, { kidSafeMode: schemaData }));
		break;
	case parentPinModeRecovery:
		schemaData = Joi.object().when("type", {
			is: Joi.only(parentPinModeRecovery), then: Joi.object().required().keys({
				recovery: Joi.object().required().keys({
					mobile: Joi.string().regex(/^\d+$/).length(10).required().label(errorConfig.validationError.mobile),
					countryCode: Joi.string().min(2).max(4).regex(/^(\+)(\d{1,3}|\d{1,4})$/).required().label(errorConfig.validationError.countryCode),
				}).label(errorConfig.validationError.ksmrecovery)
			}).label(errorConfig.validationError.parentPinMode), otherwise: Joi.optional().label(errorConfig.validationError.ksmtype)
		});
		schema = Joi.object().keys(Object.assign({}, schema, { parentPinMode: schemaData }));
		break;
	}
	return Joi.validate(input, schema, { abortEarly: false });
}
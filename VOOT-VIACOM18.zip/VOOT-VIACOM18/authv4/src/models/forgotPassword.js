const Joi = require("joi");
const errorConfig = require("../config").errorConfig;
const constant = require("../utils/constant/generic");
const _ = require("lodash");
module.exports = forgotPassword;

function forgotPassword(input) {
	let schema;
	if ((_.has(input, "mobile")) || (_.has(input, "countryCode"))) {

		schema = Joi.object().keys({
			mobile: Joi
				.string()
				.regex(/^\d+$/)
				.length(10)
				.required()
				.trim()
				.label(errorConfig.validationError.mobile),
			countryCode: Joi
				.string()
				.min(2)
				.max(4)
				.regex(/^(\+)(\d{1,3}|\d{1,4})$/)
				.required()
				.trim()
				.label(errorConfig.validationError.countryCode),
			otpVersion: Joi
				.string()
				.valid(constant.VALID_OTP_VERSION.v2)
				.optional()
				.label(errorConfig.validationError.otpVersionForgotPassword)
		});
	} else if ((_.has(input, "email")) && (_.has(input, "templateVersion"))) {

		schema = Joi.object().keys({
			email: Joi
				.string()
				.email({ minDomainAtoms: 2 })
				.required()
				.label(errorConfig.validationError.email),
			templateVersion: Joi
				.string()
				.valid("V2", "v2")
				.required()
				.label(errorConfig.validationError.templateVersion),
		});
	} else {

		schema = Joi.object().keys({
			email: Joi
				.string()
				.email({ minDomainAtoms: 2 })
				.required()
				.label(errorConfig.validationError.email)
		});
	}
	return Joi.validate(input, schema, { abortEarly: false });
}

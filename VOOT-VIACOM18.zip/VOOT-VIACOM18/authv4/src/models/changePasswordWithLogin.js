const Joi = require("joi");
const errorConfig = require("../config").errorConfig;

module.exports = changePasswordWithLogin;

function changePasswordWithLogin(accessToken, input) {
	const accessTokenSchema = Joi.object().keys({ accessToken: Joi.string().required() });
	let schemaToValidate;
	let { error } = Joi.validate({ accessToken: accessToken }, accessTokenSchema, { abortEarly: false });
	if (error) {
		return { error };
	}
	schemaToValidate = Joi.object().keys({
		oldPassword: Joi.string().min(1).max(16).required().label(errorConfig.validationError.oldPassword),
		newPassword: Joi.string().min(6).max(16).required().label(errorConfig.validationError.newPassword),
		deviceId: Joi.string().required().label(errorConfig.validationError.deviceId),
		deviceBrand: Joi.string().required().label(errorConfig.validationError.deviceBrand)
	});
       
	return Joi.validate(input, schemaToValidate, { abortEarly: false });
}

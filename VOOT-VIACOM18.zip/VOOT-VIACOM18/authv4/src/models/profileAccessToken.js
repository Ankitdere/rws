
"use strict";

const Joi = require("joi");

module.exports = profileAccessToken;

function profileAccessToken(accessToken) {
	const schema = Joi.object().keys({ accessToken: Joi.string().required() });
	return Joi.validate({ accessToken: accessToken }, schema, { abortEarly: false });
}

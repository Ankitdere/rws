"use strict";
const baseJoi = require("joi");
const dateJoiExtension = require("@hapi/joi-date");
const errorConfig = require("../config").errorConfig;
const Joi = baseJoi.extend(dateJoiExtension);
const apiResponse = require("../utils").apiResponse;
const _ = require("lodash");
const configuration =require("../config").configuration;
module.exports = updateProfile;

function updateProfile(headers, input,DeviceList,PlatformList) {

	let schema,finalJson={};
	const headerValidation = Joi.object().keys({
		accessToken: Joi.string().required().label(errorConfig.validationError.accessToken),
		apiVersion: Joi.string().valid("v2").optional().label(errorConfig.validationError.apiVersion),
		device: Joi.string().valid(DeviceList).when("apiVersion", { is: Joi.exist(), then: Joi.required().label(errorConfig.validationError.device), otherwise: Joi.optional().label(errorConfig.validationError.device) }),
		platform: Joi.string().valid(PlatformList).when("apiVersion", { is: Joi.exist(), then: Joi.required().label(errorConfig.validationError.platform), otherwise: Joi.optional().label(errorConfig.validationError.device) })
	});



	let { error } = Joi.validate(headers, headerValidation, { abortEarly: false });
	if (error) {
		return { error };
	}

	if (headers && headers.apiVersion && headers.apiVersion=="v2") {
		console.log("i am inside api version ");
    
		let typeArr = [];
		let results = [];
		for (let device in configuration.ksmPlatformAndDeviceConfig.ksm) {
			if (configuration.ksmPlatformAndDeviceConfig.ksm.hasOwnProperty(device)) {
				console.log(device + " -> " + configuration.ksmPlatformAndDeviceConfig.ksm[device]);
				let jsonObject = {};
				jsonObject[device] = device;
				jsonObject[device] ={};
				for (let platform in configuration.ksmPlatformAndDeviceConfig.ksm[device]) {
					typeArr.push(platform);
				}
				jsonObject[device] = typeArr;
				typeArr = [];
				results.push(jsonObject);
				Object.assign(finalJson, ...results);   
			}
		}
        
		console.log("Final obkject",finalJson);
		if (!_.includes(_.get(finalJson,_.get(headers, "device")), _.get(headers, "platform"))) {
			throw apiResponse.error(errorConfig.invalidDeviceAndPlatformMissMatch.description, errorConfig.invalidDeviceAndPlatformMissMatch.code);
		}

	}
	if(headers.apiVersion=="v2") {
		if( input.kidSafeMode && input.parentPinMode ){
			throw apiResponse.error(errorConfig.bothPinModeNotAllowed.description, errorConfig.bothPinModeNotAllowed.code);
		}
		schema = Joi.object().keys({
			subTitle: Joi
				.string()
				.min(3)
				.max(25)
				.alphanum()
				.optional().label(errorConfig.validationError.subTitle) ,
				
			kidSafeMode: Joi.object().optional().keys({
				deviceId: Joi.string().required().not("null").label(errorConfig.validationError.deviceId),
				contentRestriction: Joi.number().optional().valid([18, 16, 13]).label(errorConfig.validationError.ksmcontentRestriction),
				status: Joi.string().valid("enabled", "disabled").optional().label(errorConfig.validationError.ksmstatus),
				pin: Joi.string().optional().label(errorConfig.validationError.ksmpin),
				recovery: Joi.object().keys({
					mobile: Joi.string().regex(/^\d+$/).length(10).required().label(errorConfig.validationError.mobile),
					countryCode: Joi.string().min(2).max(4).regex(/^(\+)(\d{1,3}|\d{1,4})$/).required().label(errorConfig.validationError.countryCode),
				}).label(errorConfig.validationError.ksmrecovery)
			}).min(2).label(errorConfig.validationError.kidsSafeMode),
			
			//parent pin validations
			parentPinMode:Joi.object().optional().keys({
				deviceId: Joi
					.string()
					.optional()
					.not("null").label(errorConfig.validationError.deviceId),
				isParentPinEnabled: Joi
					.boolean()
					.valid(true, false)
					.optional().label(errorConfig.validationError.isParentPinEnabled),
				pin: Joi
					.string()
					.optional().label(errorConfig.validationError.ksmpin),
				recovery: Joi.object().keys({
					mobile: Joi
						.string()
						.regex(/^\d+$/)
						.length(10)
						.required().label(errorConfig.validationError.mobile),
					countryCode: Joi
						.string()
						.min(2)
						.max(4)
						.regex(/^(\+)(\d{1,3}|\d{1,4})$/)
						.required().label(errorConfig.validationError.countryCode),

				}).label(errorConfig.validationError.ksmrecovery)
			}).min(1).label(errorConfig.validationError.parentPinMode) 
			
		}).label(errorConfig.validationError.emptyBody);
	}else{
		schema = Joi.object().keys({
			subTitle: Joi
				.string()
				.min(3)
				.max(25)
				.alphanum()
				.required()
				.label(errorConfig.validationError.subTitle) 
      
		}).label(errorConfig.validationError.emptyBody);
	}


	return Joi.validate(input, schema, { abortEarly: false });
}



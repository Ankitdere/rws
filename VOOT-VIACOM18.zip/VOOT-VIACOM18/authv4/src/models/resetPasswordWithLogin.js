const Joi = require("joi");
const errorConfig = require("../config").errorConfig;

module.exports = resetPasswordWithLogin;

function resetPasswordWithLogin( input,header) {
	const resetpasswordTokenSchema = Joi.object().keys({ forgotpasswordtoken: Joi.required() });
	let { error } = Joi.validate(header, resetpasswordTokenSchema, { abortEarly: false });
	if (error) {
		return { error };
	}
	const schemaToValidate = Joi.object().keys({
		deviceId: Joi.string().required().label(errorConfig.validationError.deviceId),
		deviceBrand: Joi.string().required().label(errorConfig.validationError.deviceBrand),
		newPassword: Joi.string().min(6).max(16).required().label(errorConfig.validationError.newPassword)
	});
	return Joi.validate(input, schemaToValidate, { abortEarly: false });
}

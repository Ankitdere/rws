"use strict";
const Joi = require("joi");
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");

module.exports = verifyOtpForgotPassword;

function verifyOtpForgotPassword(input) {
	let schemaToValidate;
	if ((_.has(input, "mobile")) || (_.has(input, "countryCode"))) {
		schemaToValidate = Joi.object().keys({

			mobile: Joi.string().regex(/^\d+$/).length(10).required().label(errorConfig.validationError.mobile),
			countryCode: Joi.string().min(2).max(4).regex(/^(\+)(\d{1,3}|\d{1,4})$/).required().label(errorConfig.validationError.countryCode),
			action: Joi.string().min(3).valid("forgotPasswordOtp").optional().label(errorConfig.validationError.action),
			otp: Joi.string().length(4).regex(/^\d+$/).trim().required().label(errorConfig.validationError.otp)
		});
	} else if ((_.has(input, "email")) || (_.has(input, "templateVersion")) || (_.has(input, "action"))) {
		schemaToValidate = Joi.object().keys({
			templateVersion: Joi.string().valid("V2", "v2").required().label(errorConfig.validationError.templateVersion),
			email: Joi.string().email({ minDomainAtoms: 2 }).required().label(errorConfig.validationError.email),
			action: Joi.string().min(3).valid("forgotPasswordOtp").required().label(errorConfig.validationError.action),
			otp: Joi.string().length(4).regex(/^\d+$/).trim().required().label(errorConfig.validationError.otp)
		});
	}
	else {
		schemaToValidate = Joi.object().keys({
			mobile: Joi.string().regex(/^\d+$/).length(10).required().label(errorConfig.validationError.mobile),
			countryCode: Joi.string().min(2).max(4).regex(/^(\+)(\d{1,3}|\d{1,4})$/).required().label(errorConfig.validationError.countryCode),
			otp: Joi.string().length(4).regex(/^\d+$/).trim().required().label(errorConfig.validationError.otp)
		});
	}
	return Joi.validate(input, schemaToValidate, { abortEarly: false });
}



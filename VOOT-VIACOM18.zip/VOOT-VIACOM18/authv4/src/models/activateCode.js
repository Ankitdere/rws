"use strict";
const Joi = require("joi");
const errorConfig = require("../config").errorConfig;

module.exports = activateCode;

function activateCode(input) {
	const schema = Joi.object().keys({
		code: Joi.string().required().label(errorConfig.validationError.code),
		accessToken: Joi.string().required()
	});
	return Joi.validate(input, schema, { abortEarly: false });
}
const Joi = require("joi");
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");

module.exports = getOtpDetails;

function getOtpDetails(input) {
	let schema;
    
	if ((_.has(input, "mobile")) || (_.has(input, "countryCode"))) {
		schema = Joi.object().keys({
			mobile: Joi.string().regex(/^\d+$/).length(10).required().trim().label(errorConfig.validationError.mobile),
			countryCode: Joi.string().min(2).max(4).regex(/^(\+)(\d{1,3}|\d{1,4})$/).required().trim().label(errorConfig.validationError.countryCode),
			type: Joi.string().valid("signup", "forgotpassword", "ims").required().label(errorConfig.validationError.type),
		});
	} else if ((_.has(input, "email"))) {

		schema = Joi.object().keys({
			email: Joi.string().email({ minDomainAtoms: 2 }).required().label(errorConfig.validationError.email),
			type: Joi.string().valid("signup", "forgotpassword").required().label(errorConfig.validationError.type),
		});
	} else {

		schema = Joi.object().keys({
			email: Joi.string().email({ minDomainAtoms: 2 }).required().label(errorConfig.validationError.email)
		});
	}
	return Joi.validate(input, schema, { abortEarly: false });
}

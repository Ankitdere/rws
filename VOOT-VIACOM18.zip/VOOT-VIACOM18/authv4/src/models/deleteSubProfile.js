"use strict";
const baseJoi = require("joi");
const dateJoiExtension = require("@hapi/joi-date");
const errorConfig = require("../config").errorConfig;
const Joi = baseJoi.extend(dateJoiExtension);
module.exports = deleteSubProfile;

/**
 * 
 * @param {Object} headers 
 * @param {Object} input 
 * @returns {Object}
 */
function deleteSubProfile(headers, input) {

	let schema;
	const headerValidation = Joi.object().keys({
		accessToken: Joi.string()
			.required()
			.label(errorConfig.validationError.accessToken)
	});

	let { error } = Joi.validate(headers, headerValidation, { abortEarly: false });
	if (error) {
		return { error };
	}
	schema = Joi.object().keys({
		childUid: Joi.string()
			.required()
			.label(errorConfig.validationError.invalidSubProfileUid)

	}).label(errorConfig.validationError.emptyBody);

	return Joi.validate(input, schema, { abortEarly: false });
}



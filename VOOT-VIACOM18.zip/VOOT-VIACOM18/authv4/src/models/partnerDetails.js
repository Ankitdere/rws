"use strict";
const Joi = require("joi");
const errorUtilities = require("../config").errorConfig;
const Config = require("../config").configuration;
const _ = require("lodash");
const { apiResponse } = require("../utils");
const GenericConstantUtil = require("../utils/constant/generic");

module.exports = partnerDetails;

function partnerDetails(input) {
	console.log("Reached Partner Validation Model");
	try {
		let schemaData;
		// let schema: any = {
		// 	partnerType: Joi.string().valid([Config.tSkyDetails.partnerType, Config.M2MITDetails.partnerName]).required().label(errorUtilities.validationError.partnerType),
		// 	uniqueId:Joi.string().min(1).required().label(errorUtilities.validationError.uniqueId),
		// };
		//TODO :need optimization because JOI Assertion error
		const typeArr = [Config.tSkyDetails.partnerType, Config.M2MITDetails.partnerName, Config.jioSubscription.partnerType,GenericConstantUtil.PARTNER.YUPPTV.CODE,GenericConstantUtil.PARTNER.FLIPKART.CODE];
		if ((!_.has(input, "partnerType"))) {
			throw { https: 400, error: apiResponse.error(errorUtilities.partnerTypeIsRequired.description, errorUtilities.partnerTypeIsRequired.code) };
		} else if ((_.isEmpty(input.partnerType))) {
			throw { https: 400, error: apiResponse.error(errorUtilities.partnerTypeIsNotAllowToEmpty.description, errorUtilities.partnerTypeIsNotAllowToEmpty.code) };
		}
		else if (!_.includes(typeArr, input.partnerType)) {
			throw { https: 400, error: apiResponse.error(errorUtilities.allPartnerTypeMissing.description, errorUtilities.PartnerTypeMissing.code) };
		}

		switch (input.partnerType) {
		case (Config.tSkyDetails.partnerType):
			schemaData = Joi.object().keys({
				partnerType: Joi.string().valid([Config.tSkyDetails.partnerType, Config.M2MITDetails.partnerName, Config.jioSubscription.partnerType, GenericConstantUtil.PARTNER.YUPPTV.CODE, GenericConstantUtil.PARTNER.FLIPKART.CODE]).required().label(errorUtilities.validationError.partnerType),
				uniqueId: Joi.string().min(1).required().label(errorUtilities.validationError.uniqueId),
			}).required().label(errorUtilities.validationError.emptyBody);
			break;
		case (Config.M2MITDetails.partnerName):
			schemaData = Joi.object().keys({
				partnerType: Joi.string().valid([Config.tSkyDetails.partnerType, Config.M2MITDetails.partnerName, Config.jioSubscription.partnerType, GenericConstantUtil.PARTNER.YUPPTV.CODE, GenericConstantUtil.PARTNER.FLIPKART.CODE]).required().label(errorUtilities.validationError.partnerType),
				uniqueId: Joi.string().min(1).required().label(errorUtilities.validationError.uniqueId),
			}).required().label(errorUtilities.validationError.emptyBody);
			break;
		case (Config.jioSubscription.partnerType):
			schemaData = Joi.object().keys({
				partnerType: Joi.string().valid([Config.tSkyDetails.partnerType, Config.M2MITDetails.partnerName, Config.jioSubscription.partnerType, GenericConstantUtil.PARTNER.YUPPTV.CODE, GenericConstantUtil.PARTNER.FLIPKART.CODE]).required().label(errorUtilities.validationError.partnerType),
				externalId: Joi.string().min(1).required().label(errorUtilities.validationError.externalId),
			}).required().label(errorUtilities.validationError.emptyBody);
			break;
		case (GenericConstantUtil.PARTNER.YUPPTV.CODE):
			schemaData = Joi.object().keys({
				partnerType: Joi.string().valid([Config.tSkyDetails.partnerType, Config.M2MITDetails.partnerName, Config.jioSubscription.partnerType, GenericConstantUtil.PARTNER.YUPPTV.CODE, GenericConstantUtil.PARTNER.FLIPKART.CODE]).required().label(errorUtilities.validationError.partnerType),
				uniqueId: Joi.string().min(1).required().label(errorUtilities.validationError.uniqueId),
			}).required().label(errorUtilities.validationError.emptyBody);
			break;
		case (GenericConstantUtil.PARTNER.FLIPKART.CODE):
			schemaData = Joi.object().keys({
				partnerType: Joi.string().valid([Config.tSkyDetails.partnerType, Config.M2MITDetails.partnerName, Config.jioSubscription.partnerType, GenericConstantUtil.PARTNER.YUPPTV.CODE, GenericConstantUtil.PARTNER.FLIPKART.CODE]).required().label(errorUtilities.validationError.partnerType),
				uniqueId: Joi.string().min(1).required().label(errorUtilities.validationError.uniqueId),
			}).required().label(errorUtilities.validationError.emptyBody);
			break;

		default:
			break;
		}


		//schema = Joi.object().keys(Object.assign({}, schema, { schema: schemaData }));
		return Joi.validate(input, schemaData, { abortEarly: false });
	} catch (e) {
		throw e;
	}
}



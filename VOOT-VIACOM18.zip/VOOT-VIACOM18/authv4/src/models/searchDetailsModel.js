const Joi = require("joi");
const errorConfig = require("../config").errorConfig;

module.exports = searchDetails;

async function searchDetails(input, headers) {
	input = JSON.stringify(input);
	input = JSON.parse(input);
	//verify headers
	const headerValidation = Joi.object().keys({
		accessToken: Joi.string().required().label(errorConfig.validationError.accessToken),
		apiVersion: Joi.string().valid("v1").required().label(errorConfig.validationError.apiVersion),
	});
	let {error}= Joi.validate(headers, headerValidation, { abortEarly: false });
	if (error) {
		console.log("ERROR IN MODEL", error, error.stack);
		throw error;
	}
	let schemaData;
	schemaData = {
		data: Joi.object().required().keys({
			uid: Joi.string().required().label(errorConfig.validationError.uid),
			mobile: Joi.string().regex(/^\d+$/).length(10).optional().label(errorConfig.validationError.mobile),
			countryCode: Joi.string().min(2).max(4).regex(/^(\+)(\d{1,3}|\d{1,4})$/).when("mobile", { is: Joi.exist(), then: Joi.required().label(errorConfig.validationError.countryCode), otherwise: Joi.optional().label(errorConfig.validationError.countryCode) }),
			email: Joi.string().when("mobile", { is: Joi.exist(), then: Joi.optional().label(errorConfig.validationError.email), otherwise: Joi.string().email({ minDomainAtoms: 2 }).optional().label(errorConfig.validationError.email) }),
			flags: Joi.object().keys({
				basic: Joi.boolean().required().label(errorConfig.validationError.basicFlag),
				authToken: Joi.boolean().required().label(errorConfig.validationError.authTokenFlag),
				subscription: Joi.boolean().required().label(errorConfig.validationError.subscriptionFlag),
				entitlement: Joi.boolean().required().label(errorConfig.validationError.entitlementFlag),
				"provider.amazon": Joi.boolean().required().label(errorConfig.validationError.amazonDetailsFlag),
				"provider.all": Joi.boolean().required().label(errorConfig.validationError.allDetailsFlag),
				"provider.google": Joi.boolean().required().label(errorConfig.validationError.googleDetailsFlag),
				"provider.facebook": Joi.boolean().required().label(errorConfig.validationError.facebookDetailsFlag),
				"provider.apple": Joi.boolean().required().label(errorConfig.validationError.appleDetailsFlag),
                

			}).required().label(errorConfig.validationError.emptyBody)
		}).required().label(errorConfig.validationError.emptyBody)
	};
	//schema = Joi.object().keys(Object.assign({}, schema, { data: schemaData }));
	return Joi.validate(input, schemaData, { abortEarly: false });

   
}

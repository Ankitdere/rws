"use strict";
const Joi = require("joi");

module.exports = appleRedirect;

function appleRedirect(input) {

	console.log("Reached apple Redirect Validation Model");
	const schema = Joi.object().keys({
		id_token: Joi.string().required(),
		code: Joi.string().optional(),
		state: Joi.string().optional()
	}).unknown();
	return Joi.validate(input, schema, { abortEarly: false });

}
"use strict";
const baseJoi = require("joi");
const dateJoiExtension = require("@hapi/joi-date");
const errorConfig = require("../config").errorConfig;
const Joi = baseJoi.extend(dateJoiExtension);
module.exports = createProfile;

/**
 * 
 * @param {Object} headers 
 * @param {Object} input 
 * @returns {Object}
 */
function createProfile(headers, input) {

	let schema;
	const headerValidation = Joi.object().keys({
		accessToken: Joi.string()
			.required()
			.label(errorConfig.validationError.accessToken)
	});

	const { error } = Joi.validate(headers, headerValidation, { abortEarly: false });
	if (error) {
		return { error };
	}
	//validate date is string or not
	if (input.hasOwnProperty("birthdate")) {
		const birthDateSchema = Joi.object().keys({
			birthdate: Joi.string().label(errorConfig.validationError.birthdate)
		});
		const { error } = Joi.validate({ birthdate: input.birthdate }, birthDateSchema, { abortEarly: false });
		if (error) {
			return { error };
		}
	}	
	schema = Joi.object().keys({
		profilename: Joi.string()
			.min(3)
			.max(50)
			.required()
			.label(errorConfig.validationError.invalidProfileName),
		gender: Joi
			.string()
			.valid("M", "F", "O", "U")
			.label(errorConfig.validationError.gender),
		birthdate: Joi.date().utc().max("now")
			.format("DD-MM-YYYY")
			.raw()
			.label(errorConfig.validationError.birthdate),
		languages: Joi
			.array()
			.items(
				Joi.
					string().
					allow(""))
			.label(errorConfig.validationError.languages),
		isKidProfile: Joi
			.boolean()
			.optional()
			.label(errorConfig.validationError.isKidProfile),

	}).label(errorConfig.validationError.emptyBody);

	return Joi.validate(input, schema, { abortEarly: false });
}



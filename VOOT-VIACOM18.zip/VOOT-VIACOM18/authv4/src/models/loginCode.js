"use strict";
const Joi = require("joi");
const errorConfig = require("../config").errorConfig;

module.exports = loginCode;

function loginCode(input) {
	const schema = Joi.object().keys({
		deviceBrand: Joi.string().required().label(errorConfig.validationError.deviceBrand),
		deviceId: Joi.string().required().label(errorConfig.validationError.deviceId),
	});
	return Joi.validate(input, schema, { abortEarly: false });
}
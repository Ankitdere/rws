const Joi = require("joi");
const errorConfig = require("../config").errorConfig;

module.exports = sendMessage;
/**
 * validation
 * @param {*} input 
 * @returns 
 */
function sendMessage(input) {
	let schema;
	schema = {
		uid: Joi.string().required().trim().label(errorConfig.validationError.uid),
		sms:Joi.object().optional().keys({
			body: Joi.string().required().label(errorConfig.validationError.body),
			templateId:Joi.string().required().label(errorConfig.validationError.templateId),
			type:Joi.string().required().label(errorConfig.validationError.smsType),
			header:Joi.string().required().label(errorConfig.validationError.smsHeader),
		}),
		email:Joi.object().keys({
			subject: Joi.string().required().label(errorConfig.validationError.subject),
			body: Joi.string().required().label(errorConfig.validationError.body),
		}).when("sms", { is: Joi.exist(), then: Joi.optional().label(errorConfig.validationError.email), 
			otherwise: Joi.required().label(errorConfig.validationError.email) }),
		priority: Joi.string().valid("sms", "email").required().trim().label(errorConfig.validationError.priority)
		
	};
	
	return Joi.validate(input, schema, { abortEarly: false });
}

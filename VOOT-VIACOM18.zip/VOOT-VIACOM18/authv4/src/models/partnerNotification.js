"use strict";

const Joi = require("joi");
const errorConfig = require("../config").errorConfig;
const config = require("../config").configuration;
const _ = require("lodash");
const apiResponse = require("../utils").apiResponse;
const moment = require("moment");

module.exports = {
	partnerNotification,
	partnerNotificationDateValidator,
	partnerNotificationM2MIT
};

function partnerNotification(input) {
	let schemaData;
	let schema = {
		partnerToken: Joi.string().required().label(errorConfig.validationError.requiredPartnerToken),
		partnerName: Joi.string().valid(["Tata-Sky", "M2MIT"]).required().label(errorConfig.validationError.tataskypartner),
		action: Joi.string().valid( [ "Register", "Cancel", "Renew", "Trial_Period", "Grace_Period" ] ).required().label( errorConfig.validationError.partnerAction ),
		data: Joi.object().required().label(errorConfig.validationError.partnerData),
	};
	const typeArr = [ "Register", "Renew", "Cancel", "Trial_Period", "Grace_Period" ];
	if (!_.has(input, "action")) {
		throw { https: 400, error: apiResponse.error(errorConfig.actionIsRequired.description, errorConfig.actionIsRequired.code) };
	}
	if (_.isEmpty(input.action)) {
		throw { https: 400, error: apiResponse.error("action is not allowed to be empty", errorConfig.actionIsRequired.code) };
	}
	else if (!_.includes(typeArr, input.action)) {
		throw { https: 400, error: apiResponse.error(errorConfig.invalidActionType.description, errorConfig.invalidActionType.code) };
	}
	if (!_.has(input, "data")) {
		throw { https: 400, error: apiResponse.error("data is required", 2011) };
	}
	switch (input.action) {
	case ("Renew"):
	case ("Cancel"):
	case ("Register"):
	case ( "Trial_Period" ):
	case ("Grace_Period"):
		schemaData = Joi.object().keys({
			uniqueId: Joi.string().min(1).required().label(errorConfig.validationError.uniqueId),
			externalId: Joi.string().min(1).required().label(errorConfig.validationError.externalId),
			dsn: Joi.string().required().label(errorConfig.validationError.dsn),
			startDate: Joi.string().regex(/^([0-2][0-9]|(3)[0-1])(-)(((0)[0-9])|((1)[0-2]))(-)\d{4}$/).optional().label(errorConfig.validationError.startDate),
			endDate: Joi.string().regex(/^([0-2][0-9]|(3)[0-1])(-)(((0)[0-9])|((1)[0-2]))(-)\d{4}$/).optional().label(errorConfig.validationError.endDate),
			transactionId: Joi.string().required().label(errorConfig.validationError.transactionId),
			source: Joi.string().valid(config.tSkyDetails.source_notification).required().label(errorConfig.validationError.source),
			deviceType: Joi.string().required().valid(["OPEN", "CLOSED"]).label(errorConfig.validationError.deviceType),
		});
		break;

	default:
		break;
	}
	schema = Joi.object().keys(Object.assign({}, schema, { data: schemaData }));
	return Joi.validate(input, schema, { abortEarly: false });
}

function partnerNotificationDateValidator(input) {
	if (!(_.has(input.data, "startDate"))) {
		const today = moment().format("DD-MM-YYYY");
		input.data.startDate = today;
	}
	if (!(_.has(input.data, "endDate"))) {
		if ( _.get( input, "action" ) == "Trial_Period" ) {
			// input.data.endDate  = moment(moment(today, "DD-MM-YYYY").add(15, 'days',"DD-MM-YYYY"));
			input.data.endDate = `${config.tSkyDetails.dummyFreeTrialEndDate}`;
		}
		if (_.get(input, "action") == "Grace_Period") {
			// input.data.endDate  = moment(moment(today, "DD-MM-YYYY").add(30, 'days'),"DD-MM-YYYY");
			input.data.endDate = `${config.tSkyDetails.dummyGracePeriodEndDate}`;

		} else {
			input.data.endDate = `${config.tSkyDetails.dummyendDate}`;
		}
	}
	console.log("Input End Date", input.data.endDate);
	if ((_.has(input.data, "startDate")) && (_.has(input.data, "endDate"))) {
		const startDate = moment(input.data.startDate, "DD-MM-YYYY");
		const endDate = moment(input.data.endDate, "DD-MM-YYYY");
		const currentDate = moment(new Date(), "DD-MM-YYYY");
		if (startDate.isValid() == false) {
			throw { https: 400, error: apiResponse.error(errorConfig.invalidStartDateFormat.description, errorConfig.invalidEndDateFormat.code) };
		} else if (endDate.isValid() == false) {
			throw { https: 400, error: apiResponse.error(errorConfig.invalidEndDateFormat.description, errorConfig.invalidEndDateFormat.code) };
		} if (startDate.isBefore(endDate) == false) {
			throw { https: 400, error: apiResponse.error(errorConfig.invalidDateFormat.description, errorConfig.invalidDateFormat.code) };
		} if (endDate.isBefore(currentDate) == true) {
			throw { https: 400, error: apiResponse.error(errorConfig.invalidEndDateCurrentFormat.description, errorConfig.invalidDateFormat.code) };
		}
	}
}
function partnerNotificationM2MIT(input) {
	let schemaData;
	let schema = {
		partnerToken: Joi.string().required().label(errorConfig.validationError.requiredPartnerToken),
		partnerName: Joi.string().valid(["Tata-Sky", "M2MIT"]).required().label(errorConfig.validationError.tataskypartner),
		action: Joi.string().valid("Register", "Cancel", "Activate").required().label(errorConfig.validationError.partnerAction),
		data: Joi.string().required().label(errorConfig.validationError.partnerData),
	};
	const typeArr = ["Register", "Activate", "Cancel"];
	if (!_.has(input, "action")) {
		throw { https: 400, error: apiResponse.error(errorConfig.actionIsRequired.description, errorConfig.actionIsRequired.code) };
	}
	if (_.isEmpty(input.action)) {
		throw { https: 400, error: apiResponse.error("action is not allowed to be empty", errorConfig.actionIsRequired.code) };
	}
	else if (!_.includes(typeArr, input.action)) {
		throw { https: 400, error: apiResponse.error(errorConfig.invalidActionM2MIType.description, errorConfig.invalidActionType.code) };
	}
	if (!_.has(input, "data")) {
		throw { https: 400, error: apiResponse.error("data is required", 2011) };
	}
	switch (input.action) {
	case ("Activate"):
		schemaData = Joi.object().keys({
			uniqueId: Joi.string().min(1).required().label(errorConfig.validationError.uniqueId),
			planId: Joi.string().valid(["VS-101", "VS-102", "VS-103", "VS-104"]).required().label(errorConfig.validationError.planId)
		});
		break;
	case ("Cancel"):
		schemaData = Joi.object().keys({
			uniqueId: Joi.string().min(1).required().label(errorConfig.validationError.uniqueId),
		});
		break;
	case ("Register"):
		schemaData = Joi.object().keys({
			uniqueId: Joi.string().min(1).required().label(errorConfig.validationError.uniqueId),
			mobile: Joi.string().regex(/^(\+)(\d+)$/).length(13).required().label(errorConfig.validationError.mobile),
			password: Joi.string().min(6).max(15).required().label(errorConfig.validationError.password),
			deviceId: Joi.string().required().label(errorConfig.validationError.deviceId),
			deviceBrand: Joi.string().required().label(errorConfig.validationError.deviceBrand),
		});
		break;

	default:
		break;
	}
	schema = Joi.object().keys(Object.assign({}, schema, { data: schemaData }));

	return Joi.validate(input, schema, { abortEarly: false });

}
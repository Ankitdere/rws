const Joi = require("joi");
const errorConfig = require("../config").errorConfig;

module.exports = resetPassword;

function resetPassword( input,header) {
	const resetpasswordTokenSchema = Joi.object().keys({ 
		forgotpasswordtoken: Joi.required(),
		buildNumber:Joi.optional(),
		deviceInfo : Joi.optional(),
		uid :Joi.optional(),
	});
	let { error } = Joi.validate(header, resetpasswordTokenSchema, { abortEarly: false });
	if (error) {
		return { error };
	}
    
	const schemaToValidate = Joi.object().keys({
		newPassword: Joi.string().min(6).max(15).required().label(errorConfig.validationError.newPassword)
	});
	return Joi.validate(input, schemaToValidate, { abortEarly: false });
    
}

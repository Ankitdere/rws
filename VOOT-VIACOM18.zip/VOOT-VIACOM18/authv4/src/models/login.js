"use strict";
const Joi = require("joi");
const errorUtilities = require("../config").errorConfig;
const constant=require("../utils/constant/generic");

module.exports = login;

function login(input) {
	console.debug("Reached Login Validation Model");
	let schemaData;
	let schema = {
		type: Joi.string().valid("traditional", "facebook", "google", "mobile","apple","amazon").required().label(errorUtilities.validationError.type),
		deviceId: Joi.string().required().label(errorUtilities.validationError.deviceId),
		deviceBrand: Joi.string().required().label(errorUtilities.validationError.deviceBrand),
		data: Joi.string()
	};

	switch (input.type) {
	case ("traditional"):
		schemaData = Joi.object().keys({
			email: Joi.string().email({ minDomainAtoms: 2 }).required().label(errorUtilities.validationError.email),
			password: Joi.string().min(1).max(16).required().label(errorUtilities.validationError.password),
		}).required().label(errorUtilities.validationError.emptyBody);
		break;
	case ("facebook"):
	case ("google"):
		schemaData = Joi.object().keys({
			token: Joi.string().required().label(errorUtilities.validationError.token),
			uid: Joi.string().required().label(errorUtilities.validationError.uid)
		}).required().label(errorUtilities.validationError.emptyBody);
		break;
	case ("mobile"):
		schemaData = Joi.object().keys({
			mobile: Joi.string().regex(/^\d+$/).length(10).required().label(errorUtilities.validationError.mobile),
			countryCode: Joi.string().min(2).max(4).regex(/^(\+)(\d{1,3}|\d{1,4})$/).required().label(errorUtilities.validationError.countryCode),
			password: Joi.string().min(1).max(15).required().label(errorUtilities.validationError.password),
		}).required().label(errorUtilities.validationError.emptyBody);
		break;
	case ("apple"):
		schemaData = Joi.object().keys({
			token: Joi.string().required().label(errorUtilities.validationError.token),
			rawNonce: Joi.string().required().label(errorUtilities.validationError.rawNonce),
			email: Joi.string().email({ minDomainAtoms: 2 }).optional().label(errorUtilities.validationError.email),
			firstname: Joi.string().optional().allow("").label(errorUtilities.validationError.firstName),
			authCode: Joi.string().optional().label(errorUtilities.validationError.authCode),
			lastname: Joi.string().allow("").optional(),
			redirectUrlApple: Joi.string().optional(),
		}).required().label(errorUtilities.validationError.emptyBody);
		break;
	case ("amazon"):
		schemaData = Joi.object().keys({
			token: Joi.string().required().label(errorUtilities.validationError.token),
			region: Joi.string().valid(constant.VALID_REGIONS_FOR_AMAZON_LOGIN).optional().label(errorUtilities.validationError.region),
		}).required().label(errorUtilities.validationError.emptyBody);
		break;
	default:
		break;
	}
	schema = Joi.object().keys(Object.assign({}, schema, { data: schemaData }));
	return Joi.validate(input, schema, { abortEarly: false });
}


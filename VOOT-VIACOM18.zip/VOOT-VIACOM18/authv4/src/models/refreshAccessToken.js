"use strict";

const Joi = require("joi");

module.exports = refreshAccessToken;

function refreshAccessToken(refreshAccessToken) {
	const schema = Joi.object().keys({ refreshAccessToken: Joi.string().required() });
	return Joi.validate({ refreshAccessToken: refreshAccessToken }, schema, { abortEarly: false });
}
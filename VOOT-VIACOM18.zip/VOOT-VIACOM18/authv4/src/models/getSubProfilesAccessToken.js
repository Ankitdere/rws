"use strict";
const baseJoi = require("joi");
const dateJoiExtension = require("@hapi/joi-date");
const errorConfig = require("../config").errorConfig;
const Joi = baseJoi.extend(dateJoiExtension);
module.exports = getSubProfilesAccessToken;

/**
 * 
 * @param {Object} headers 
 * @param {Object} input 
 * @returns {Object}
 */
function getSubProfilesAccessToken(headers, input) {
	let schema;
	const headerValidation = Joi.object().keys({
		accessToken: Joi.string()
			.required()
			.label(errorConfig.validationError.accessToken),
		device: Joi
			.string()
			.optional()
			.not("null")
			.label(errorConfig.validationError.device),
		platform: Joi
			.string()
			.optional()
			.not("null")
			.label(errorConfig.validationError.platform)
	});

	let { error } = Joi.validate(headers, headerValidation, { abortEarly: false });
	if (error) {
		return { error };
	}
	//parent pin validations
	schema= Joi.object().keys({
		childUid: Joi.string()
			.required()
			.label(errorConfig.validationError.invalidSubProfileUid),
		parentPinMode: Joi.object().optional().keys({
			pin: Joi
				.string()
				.required()
				.not("null")
				.label(errorConfig.validationError.ksmpin),
			deviceId: Joi
				.string()
				.optional()
				.label(errorConfig.validationError.deviceId),
			device: Joi
				.string()
				.optional()
				.label(errorConfig.validationError.device),
			platform: Joi
				.string()
				.optional()
				.label(errorConfig.validationError.device)
		}).label(errorConfig.validationError.parentPinMode)

	}).label(errorConfig.validationError.emptyBody);
 
	return Joi.validate(input, schema, { abortEarly: false });
}



"use strict";

const Joi = require("joi");
const errorConfig = require("../config").errorConfig;
module.exports = refreshKs;

function refreshKs(accessToken, input) {
	const accessTokenSchema = Joi.object().keys({ accessToken: Joi.string().required() });
	let { error } = Joi.validate({ accessToken: accessToken }, accessTokenSchema, { abortEarly: false });
	if (error) {
		return { error };
	}

	const schema = Joi.object().keys({
		uid: Joi.string().required().label(errorConfig.validationError.uid),
		kTokenId: Joi.string().required().label(errorConfig.validationError.kTokenId),
		kToken: Joi.string().required().label(errorConfig.validationError.kToken)
	});

	return Joi.validate(input, schema, { abortEarly: false });
}
const Joi = require("joi");
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");

module.exports = passwordChange;

function passwordChange(accessToken, input) {
	const accessTokenSchema = Joi.object().keys({ accessToken: Joi.string().required() });
	let { error } = Joi.validate({ accessToken: accessToken }, accessTokenSchema, { abortEarly: false });
	if (error) {
		return { error };
	}
	let schemaToValidate;
	if ((_.has(input, "mobile")) || (_.has(input, "countryCode"))) {
		schemaToValidate = Joi.object().keys({ 
			mobile: Joi.string().regex(/^\d+$/).length(10).required().label(errorConfig.validationError.mobile),
			countryCode: Joi.string().min(2).max(4).regex(/^(\+)(\d{1,3}|\d{1,4})$/).required().label(errorConfig.validationError.countryCode),
			newPassword: Joi.string().min(6).max(16).required().label(errorConfig.validationError.newPassword),
		});
	}else{
		schemaToValidate = Joi.object().keys({
			email: Joi.string().email({ minDomainAtoms: 2 }).required().label(errorConfig.validationError.email),
			newPassword: Joi.string().min(6).max(16).required().label(errorConfig.validationError.newPassword),
		});
	}
	return Joi.validate(input, schemaToValidate, { abortEarly: false });
}

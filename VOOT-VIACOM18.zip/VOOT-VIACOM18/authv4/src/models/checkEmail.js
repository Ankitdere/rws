const Joi = require("joi");
const {
	errorConfig
} = require("../config");

/**
 * @param {object} input 
 * @returns validates model correct or not
 */
function validate(input) {
	const schema = Joi.object()
		.keys({
			email: Joi.string()
				.email({ minDomainAtoms: 2 })
				.required()
				.label(errorConfig.validationError.email),
		});
	const options = {
		abortEarly: false,
	};
	return Joi.validate(input, schema, options);
}

module.exports = validate;
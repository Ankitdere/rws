const JWT = require("jsonwebtoken");
const To = require("../utils/to");
const ModuleError = require("../errors/module");
const Config = require("../config/configuration");
const PostResponseInterceptor = require("./post-response");
const Base64Util = require("../utils/base64");
const ParseUtil = require("../utils/parse");
const GenericValidationUtil = require("../utils/validate/generic");
const mixpanelService = require("../services/mixpanelService");
const commonUtil = require("../utils").common;
const _ = require("lodash");
const kafkaService = require("../services/kafkaService");
const notificationService = require("../services/notificationService");
module.exports = {
	verifyPartnerToken: verifyPartnerToken,
	verifyTokenForOnePartnerUser: verifyTokenForOnePartnerUser,
};

/**
 * Verify partner token
 * @param request 
 * @param response 
 * @param next 
 */
async function verifyPartnerToken(request, response, next) {
	let eventName;
	let partner = {};
	try {
		console.log("Start - interceptors -> auth -> verifyPartnerToken");

		// Initialize
		let error, headerResult;

		let authorizationHeaderArr = null;

		// Populate
		[error, headerResult] = await To(Base64Util.decode(request.headers.authorization.replace("Basic ", "")));
		if (error) {
			throw new ModuleError(401, "Unable to decode partner credentials.", null);
		} else if (!headerResult.data) {
			throw new ModuleError(500, "An error occured while verifying partner credentials.", null);
		} else {
			authorizationHeaderArr = headerResult.data.split(":");
			if (authorizationHeaderArr && authorizationHeaderArr.length == 2) {
				// Retrieve partner details
				partner = Config.partners.find(p => p.auth.accessId == authorizationHeaderArr[0] && p.auth.secretAccessKey == authorizationHeaderArr[1]);
				if (partner) {
					request.query.partner = JSON.stringify(partner);
				} else {
					throw new ModuleError(401, "Invalid partner credentials.", null);
				}
			} else {
				throw new ModuleError(401, "Partner credentials aren't sent in the required format.", null);
			}
		}
		console.log("request.query.partner,,,,,,,,,,", request.query.partner);
		console.log("End - interceptors -> auth -> verifyPartnerToken");
		next();
	} catch (error) {
		let notificationObj = await notificationService.getInitialNotificationObj(request.body);
		let basic = { partnerType: "", uniqueId: "", deviceId: "" };
		if (partner) {
			basic.partnerType = partner.name;
		}
		if (request.body) {
			basic.uniqueId = (request.body.user && request.body.user.uniqueId) ? request.body.user.uniqueId : request.body.externalId;
			basic.deviceId = (request.body.device) ? request.body.device.id : request.body.deviceId;
		}
		notificationObj = await notificationService.updateBasicInfo(notificationObj, basic);
		if (Config.kafkaConfig.enable.processNotification && Config.kafkaConfig.enable.processNotificationError) {
			let validationErrorData;
			if (error && error.code && error.message) {
				validationErrorData = { code: error.code.toString(), message: error.message, data: error.data };
				request.query.error = JSON.stringify({ code: error.code.toString(), message: error.message, data: error.data });
			} else {
				validationErrorData = { code: 500, message: "An error occured while validating partner's request body: " + error };
				request.query.error = JSON.stringify({ code: 500, message: "An error occured while validating partner's request body: " + error });
			}
			notificationObj = await notificationService.updateNotificationStage(notificationObj, false, "validation", validationErrorData);
			kafkaService.pushEventToKafka(Config.kafkaConfig.topic.partnerNotification, notificationObj);

		}
		if(error.code=="403"||error.code=="400"){
			eventName = await commonUtil.preparePartnerEventName(request.method,request.path,false,true,false);
		}else{
			eventName = await commonUtil.preparePartnerEventName(request.method,request.path,true,false,false); 
		}
		let eventProps = {userInput: request.headers,input:_.get(request,"headers"), Message: error.message, ErrorCode: _.get(error,"code"), distinct_id: request.distinctId, StatusCode :error.code};
		mixpanelService(eventName, eventProps, request.distinctId, _.get(request,"body",""), null, false); 
		console.error("Error - interceptors -> auth -> verifyPartnerToken");
		if (error && error.code && error.message) {
			request.query.error = JSON.stringify({ code: error.code, message: error.message, data: error.data });
		} else {
			request.query.error = JSON.stringify({ code: 500, message: "An error occured while validating partner token: " + error });
		}
		PostResponseInterceptor.processOne(request, response, next);
	}
}

/**
 * Verify access token for one partner user
 * @param {*} request 
 * @param {*} response 
 * @param {*} next 
 */
async function verifyTokenForOnePartnerUser(request, response, next) {
	try {
		// Initialize
		let error, partnerResult, decoded;
		let partner = {};
		let accessToken = null;

		// Retrieve
		accessToken = request.headers["accessToken"];

		// Validate
		if (!accessToken) {
			throw new ModuleError(400, "Access token is missing.", null);
		}

		// Retrieve partner details from query params
		[error, partnerResult] = await To(ParseUtil.fromStringifiedJsonToObject(request.query.partner));
		if (error) {
			throw new ModuleError(error.code, error.message, error.data);
		} else if (!partnerResult.data) {
			throw new ModuleError(500, "An error occured while retrieving partner details internally.", null);
		} else {
			partner = partnerResult.data;
		}

		// Validate
		if (GenericValidationUtil.isValidJwt(accessToken, partner.jwt.secret.access)) {
			decoded = JWT.decode(accessToken);

			// Assign as query param
			request.query.authUser = JSON.stringify({
				uId: decoded.uId
			});
		} else {
			throw new ModuleError(401, "Invalid access token.", null);
		}

		next();
	} catch (error) {
		if (error && error.code && error.message) {
			request.query.error = JSON.stringify({ code: error.code, message: error.message, data: error.data });
		} else {
			request.query.error = JSON.stringify({ code: 500, message: "An error occured while validating partner token: " + error });
		}
		PostResponseInterceptor.processOne(request, response, next);
	}
}
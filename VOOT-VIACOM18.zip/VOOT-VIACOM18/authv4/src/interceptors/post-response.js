const ModuleError = require("../errors/module");
const ParseUtil = require("../utils/parse");
const To = require("../utils/to");
const notificationService = require("../services/notificationService");
const kafkaService = require("../services/kafkaService");
const config = require("../config/configuration");
const mixpanelService = require("../services/mixpanelService");
const mixpanelConfig = require("../config/mixPanelConfig");
const _ = require("lodash");
const commonUtil = require("../utils").common;
module.exports = {
	processOne: processOne,
};

/**
 * Process one
 * @param request 
 * @param response 
 * @param next 
 */
async function processOne(request, response) {
	let eventName;
	try {
		console.log("Start - interceptors -> post-response -> processOne");
		// Initialize
		let error, result;

		if (request.query.result) {
			[error, result] = await To(ParseUtil.fromStringifiedJsonToObject(request.query.result));
			if (error) {
				throw new ModuleError(error.code, error.message, error.data);
			} else if (!result.data) {
				throw new ModuleError(500, "An error occured while processing result of this request. Please try again.", null);
			}
		} else if (request.query.error) {
			[error, result] = await To(ParseUtil.fromStringifiedJsonToObject(request.query.error));
			if (error) {
				throw new ModuleError(error.code, error.message, error.data);
			} else if (!result.data) {
				throw new ModuleError(500, "An error occured while processing error of this request. Please try again.", null);
			}
		} else {
			throw new ModuleError(500, "An error occured while processing this request. Please try again.", null);
		}

		console.log("End - interceptors -> post-response -> processOne");
		eventName = await commonUtil.preparePartnerEventName(request.method,request.path,false,false,mixpanelConfig.success);
		if (result.data.code != 200) {
			console.dir(result.data);
			eventName = await commonUtil.preparePartnerEventName(request.method,request.path,false,false,mixpanelConfig.error);
		}
		let basic = {
			partnerType: result.partnerName,
		};
		if ( request.body ) {
			basic.uniqueId = ( request.body && request.body.user ) ? request.body.user.uniqueId || request.body.externalId : "";
			basic.deviceId = ( request.body && request.body.device ) ? request.body.device.id || request.body.deviceId : "";
			basic.partnerReferenceId = ( request.body && request.body.partnerReferenceId ) ? request.body.partnerReferenceId : null;
		}
		//Only Execute in Sync Process
		if (!config["YuppTvAsyncConfig"].ïsEnable) { 
			let notificationObj = await notificationService.getfinalNotificationObj(basic,request.body);
			// Response
			if (config.kafkaConfig.enable.processNotification) {
				if (result.data.code == "200") {
					kafkaService.pushEventToKafka(config.kafkaConfig.topic.partnerNotification, notificationObj);
				}
			}
		}
		let eventProps = {userInput: request.headers,input:result.data.data, Message: result.data.message, ErrorCode: "", distinct_id: request.distinctId, StatusCode : result.data.code};
		mixpanelService(eventName, eventProps, request.distinctId, _.get(request,"body",""), null, false);
		response.status(result.data.code).send({ code: result.data.code, message: result.data.message, data: result.data.data });
	} catch (error) {
		if(error.code=="400"||error.code=="403"){
			eventName = await commonUtil.preparePartnerEventName(request.method,request.path,false,true,false);
		}else{
			eventName = await commonUtil.preparePartnerEventName(request.method,request.path,true,false,false);
		}
		let eventProps = {userInput: request.headers,input:_.get(request,"body",_.get(request,"headers")), Message: error.message, ErrorCode: _.get(error,"code"), distinct_id: request.distinctId, StatusCode :error.code};
		mixpanelService(eventName, eventProps, request.distinctId,  _.get(request,"body",""), null, false); 
		console.error("Error - interceptors -> post-response -> processOne");
		if (error && error.code && error.message) {
			response.status(error.code).send({ code: error.code, message: error.message, data: error.data });
		} else {
			console.log("response of api ",{ code: 500, message: "An error occured while processing this request: " + error, data: null });
			response.status(500).send({ code: 500, message: "An error occured while processing this request: " + error, data: null });
		}
	}
}
const Crypto = require("crypto");
const To = require("../utils/to");
const ModuleError = require("../errors/module");
const ParseUtil = require("../utils/parse");
const GenericValidationUtil = require("../utils/validate/generic");
const PostResponseInterceptor = require("./post-response");
const notificationService = require("../services/notificationService");
const kafkaService = require("../services/kafkaService");
const config = require("../config/configuration");
const mixpanelService = require("../services/mixpanelService");
const _ = require("lodash");
const commonUtil = require("../utils").common;

module.exports = {
	verifyRequestBodyForOnePatner: verifyRequestBodyForOnePatner,
	verifyIp: verifyIp,
};

/**
 * Process one
 * @param request 
 * @param response 
 * @param next 
 */
async function verifyRequestBodyForOnePatner(request, response, next) {
	let error, result;
	let signature = request.headers["x-voot-signature"];
	let timestamp = request.headers["x-voot-timestamp"];
	let partner = null;
	let queryParams = null;
	let queryParamsForSignature = "";
	let requestBody = null;
	let constructedSignature = null;
	let eventName;
	try {
		console.log("Start - interceptors -> pre-request -> verifyRequestBodyForOnePatner");

		// Initialize

		// Validate
		if (!request.query.partner) {
			throw new ModuleError(400, "Partner details are either missing or invalid.", null);
		} else {
			// Populate
			[error, result] = await To(ParseUtil.fromStringifiedJsonToObject(request.query.partner));
			if (error) {
				throw new ModuleError(error.code, error.message, error.data);
			} else if (!result.data) {
				throw new ModuleError(500, "An error occured while retrieving partner details internally.", null);
			} else {
				partner = result.data;
			}
		}

		// Check if signature validation is enabled for this partner
		if (partner.api.requestBody.hashing.isEnabled) {
			// Populate query params
			queryParams = JSON.parse(JSON.stringify(request.query));

			// Remove transient params that got attached
			delete queryParams.partner;
			delete queryParams.authUser;
			delete queryParams.result;
			delete queryParams.error;

			// If query params is empty, make it ""
			if (!GenericValidationUtil.isNonEmptyObject(queryParams)) {
				queryParamsForSignature = "";
			} else {
				queryParamsForSignature = JSON.stringify(queryParams);
			}
			if (!GenericValidationUtil.isNonEmptyObject(request.body)) {
				requestBody = "";
			} else {
				requestBody = JSON.stringify(request.body);
			}

			// Construct signature
			constructedSignature = Crypto
				.createHmac(partner.api.requestBody.hashing.algorithm, partner.api.requestBody.hashing.secret)
				.update(queryParamsForSignature + "|" + requestBody + "|" + timestamp)
				.digest("hex");

			console.log("constructedSignature: ", constructedSignature);

			// Compare
			if (constructedSignature != signature) {
				throw new ModuleError(403, "Partner signature validation failed for this request body.", null);
			}
		}
		console.log("Parter data for verifyRequestBodyForOnePatner",request.body, partner);
		console.log("End - interceptors -> pre-request -> verifyRequestBodyForOnePatner");
		next();
	} catch (error) {
		console.log("error in verifyRequestBodyForOnePatner", error, partner);
		let notificationObj = await notificationService.getInitialNotificationObj(request.body);
		let basic = { partnerType:"",uniqueId:"",deviceId:""};
		if (partner) {
			basic.partnerType = partner.name;
		}
		if (request.body) {
			basic.uniqueId = (request.body.user && request.body.user.uniqueId) ? request.body.user.uniqueId : request.body.externalId;
			basic.deviceId = (request.body.device) ? request.body.device.id : request.body.deviceId;
		}
		notificationObj = await notificationService.updateBasicInfo(notificationObj, basic);
		console.log("notification.......1", notificationObj);
		let validationErrorData;

		if(error.code=="403"||error.code=="400"){
			eventName = await commonUtil.preparePartnerEventName(request.method,request.path,false,true,false);
		}else{
			eventName = await commonUtil.preparePartnerEventName(request.method, request.path, true, false, false);
		}
		let eventProps = {userInput: request.headers,input:_.get(request,"headers"), Message: error.message, ErrorCode: _.get(error,"code"), distinct_id: request.distinctId, StatusCode :error.code};
		mixpanelService(eventName, eventProps, request.distinctId, _.get(request, "body", null), null, false);
		console.error("Error - interceptors -> pre-request -> verifyRequestBodyForOnePatner");
		if (error && error.code && error.message) {
			validationErrorData= { code: error.code.toString(), message: error.message, data: error.data };
			request.query.error = JSON.stringify({ code: error.code.toString(), message: error.message, data: error.data });
		} else {
			validationErrorData = { code: 500, message: "An error occured while validating partner's request body: " + error };
			request.query.error = JSON.stringify({ code: 500, message: "An error occured while validating partner's request body: " + error });
		}
		notificationObj = await notificationService.updateNotificationStage(notificationObj, false, "validation", validationErrorData, "error");

		if (config.kafkaConfig.enable.processNotification && config.kafkaConfig.enable.processNotificationError) {
			kafkaService.pushEventToKafka(config.kafkaConfig.topic.partnerNotification, notificationObj);
		}
		PostResponseInterceptor.processOne(request, response, next);
	}
}

/**
 * Validate IP
 * @param request 
 * @param response 
 * @param next 
 */
async function verifyIp(request, response, next) {
	let eventName;
	let partner = null;
	try {
		console.log("Start - interceptors -> pre-request -> verifyIp");

		// Initialize
		let error, result;
		let requestIp = request.headers["x-voot-forwarded-for"] || request.headers["true-client-ip"] || request.headers["True-Client-IP"] || request.headers["x-appengine-user-ip"];

		let vootEnvironment = process.env.VOOT_ENV;

		console.log("requestIp: ", requestIp, ", vootEnvironment: ", vootEnvironment);

		// Validate
		if (!vootEnvironment) {
			throw new ModuleError(403, "Unable to identify execution environment.", null);
		} else {
			vootEnvironment = vootEnvironment.toLowerCase();
		}
		if (!request.query.partner) {
			throw new ModuleError(400, "Partner details are either missing or invalid.", null);
		} else {
			// Populate
			[error, result] = await To(ParseUtil.fromStringifiedJsonToObject(request.query.partner));
			if (error) {
				throw new ModuleError(error.code, error.message, error.data);
			} else if (!result.data) {
				throw new ModuleError(500, "An error occured while retrieving partner details internally.", null);
			} else {
				partner = result.data;
			}
		}

		// Check if signature validation is enabled for this partner
		console.log(partner.default.whitelist.ip[vootEnvironment]);
		if (partner.default.whitelist.ip[vootEnvironment]) {
			if (!partner.default.whitelist.ip[vootEnvironment].includes(requestIp)) {
				throw new ModuleError(403, "Request received from an invalid IP address.", null);
			} 
		} else {
			throw new ModuleError(403, "No IP addresses whitelisted for this partner.", null);
		}

		console.log("End - interceptors -> pre-request -> verifyIp");
		next();
	} catch (error) {
		let notificationObj = await notificationService.getInitialNotificationObj(request.body);
		let basic = { partnerType: "", uniqueId: "", deviceId: "" };
		if (partner) {
			basic.partnerType = partner.name;
		}
		if (request.body) {
			basic.uniqueId = (request.body.user && request.body.user.uniqueId) ? request.body.user.uniqueId : request.body.externalId;
			basic.deviceId = (request.body.device) ? request.body.device.id : request.body.deviceId;
		}
		notificationObj = await notificationService.updateBasicInfo(notificationObj, basic);
		let validationErrorData;
		if (config.kafkaConfig.enable.processNotification && config.kafkaConfig.enable.processNotificationError) {
			if (error && error.code && error.message) {
				validationErrorData = { code: error.code.toString(), message: error.message, data: error.data };
				request.query.error = JSON.stringify({ code: error.code.toString(), message: error.message, data: error.data });
			} else {
				validationErrorData = { code: 500, message: "An error occured while validating partner's request body: " + error };
				request.query.error = JSON.stringify({ code: 500, message: "An error occured while validating partner's request body: " + error });
			}
			notificationObj = await notificationService.updateNotificationStage(notificationObj, false, "validation", validationErrorData);

			kafkaService.pushEventToKafka(config.kafkaConfig.topic.partnerNotification, notificationObj);
		}
		if (error.code == "400" || error.code == "403") {
			eventName = await commonUtil.preparePartnerEventName(request.method, request.path, false, true, false);
		}
		eventName = await commonUtil.preparePartnerEventName(request.method, request.path, true, false, false);
		let eventProps = { userInput: request.headers, input: _.get(request, "headers"), Message: error.message, ErrorCode: _.get(error, "code"), distinct_id: request.distinctId, StatusCode: error.code };
		mixpanelService(eventName, eventProps, request.distinctId, _.get(request, "body", null), null, false);
		if (error && error.code && error.message) {
			request.query.error = JSON.stringify({ code: error.code.toString(), message: error.message, data: error.data });
		} else {
			request.query.error = JSON.stringify({ code: 500, message: "An error occured while validating partner's ip: " + error });
		}
		PostResponseInterceptor.processOne(request, response, next);
	}
}
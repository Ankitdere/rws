module.exports = {
	checkDeviceId: checkDeviceId,
};

// Imports
//const To = require("../utils/to");
//const DeviceBusiness = require("../business/device");
const { errorConfig } = require("../config");
/**
 * Check if a given device id exists as part of request body
 * @param request 
 * @param response 
 * @param next 
 */
async function checkDeviceId(request, response, next) {
	try {
		if (request.body && request.body.data && request.body.deviceId) {
			// eslint-disable-next-line no-unused-vars
			let error, result;
			if(request.hasOwnProperty("custom_error"))
				delete request.custom_error;
			if(request.body.hasOwnProperty("data")===false)
				request.custom_error = errorConfig.requestBodyData;
         
			// eslint-disable-next-line no-unused-vars
			let data=request.body.data;
			let requestIp = request.headers["x-voot-forwarded-for"] || request.headers["true-client-ip"] || request.headers["True-Client-IP"] || request.headers["x-appengine-user-ip"];
			/* if(request.body.type=="traditional" && (data.hasOwnProperty("email")===false || data.hasOwnProperty("password")===false  || request.body.hasOwnProperty("deviceBrand")===false || request.body.hasOwnProperty("type")===false)){
                request.custom_error = errorConfig.requestMandatory;
            }else if(request.body.type=="mobile" && (data.hasOwnProperty("mobile")===false || data.hasOwnProperty("password")===false  || request.body.hasOwnProperty("deviceBrand")===false || request.body.hasOwnProperty("type")===false)){
                request.custom_error = errorConfig.requestMandatory;
            }else{
            if (request.body && request.body.data && request.body.type=="traditional" && request.body.data.email && !commonUtils.isEmail(request.body.data.email))
                request.custom_error = errorConfig.invalidEmail.description;
            if (request.body && request.body.data && request.body.type=="mobile" && request.body.data.mobile && !commonUtils.isMobileNumberValid(request.body.data.countryCode+request.body.data.mobile))
                request.custom_error = errorConfig.invalidMobile.description;*/
			if(request.hasOwnProperty("custom_error")===false){
				request.true_client_ip = requestIp;
				/* [error, result] = await To(DeviceBusiness.createOne(
                {
                    email: request.body.data.email,
                    password: request.body.data.password,
                    mobile: request.body.data.mobile,
                    deviceId: request.body.deviceId,
                    brand: request.body.deviceBrand,
                    type: request.body.type,
                    requestIp: requestIp
                },
                null,
                null
            ));  */
			}

			//}
		}else{
			request.custom_error = "DeviceId is required";
		}
		next();
	} catch (error) {
		next();
	}
}
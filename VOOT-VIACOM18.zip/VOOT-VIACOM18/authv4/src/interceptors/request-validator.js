const ModuleError = require("../errors/module");
const PostResponseInterceptor = require("./post-response");
const mixpanelService = require("../services/mixpanelService");
const GenericValidationUtil = require("../utils/validate/generic");
const _ = require("lodash");
const commonUtil = require("../utils").common;
const base64 = require( "../utils/base64" );
module.exports = {
	partnerRequestHeaders: partnerRequestHeaders,
};

/**
 * Validate request headers for partner
 * @param request 
 * @param response 
 * @param next 
 */
async function partnerRequestHeaders(request, response, next) {
	let eventName;
	try {
		console.log("Start - interceptors -> request-validator -> partnerRequestHeaders");
		if ((request.method == "GET" && request.path == "/purchases/status") || (request.method == "PUT" && request.path == "/purchases/status")) {
			if (!request.headers["uniqueid"] || !_.has(request.headers,"uniqueid")) {
				throw new ModuleError(400, "All the required fields are missing: uniqueId.", null);
			}
			if (!GenericValidationUtil.isBase64(request.headers["uniqueid"])) {
				throw new ModuleError(400, "Invalid uniqueId. It must be Base64 encoded.", null);
			}
			request.distinctId = ( request.headers && request.headers.uniqueid ) ? await ( await base64.decode( _.get( request.headers, "uniqueid" ) ) ).data : "NO_UID";
			console.debug( "request.distinctId typeOf and value", typeof request.distinctId, request.distinctId );
		}else{
			request.distinctId = _.get(request.headers, "uniqueid", _.get(request.body.user, "uniqueId", _.get(request.body.user, "mobile", "NO_UID")));
		}
		// Validate authorization

		if (!request.headers.authorization) {
			throw new ModuleError(400, "Authorization header is either missing or invalid.", null);
		} else if (!request.headers.authorization.includes("Basic ")) {
			throw new ModuleError(400, "Authorization header is either missing or invalid.", null);
		}

		// Validate X-Voot-Timestamp
		if (!request.headers["x-voot-timestamp"]) {
			throw new ModuleError(400, "X-Voot-Timestamp header is either missing or invalid.", null);
		} else if (!parseInt(request.headers["x-voot-timestamp"])) {
			throw new ModuleError(400, "X-Voot-Timestamp header is either missing or invalid.", null);
		}

		// Validate X-Voot-Signature
		if (!request.headers["x-voot-signature"]) {
			throw new ModuleError(400, "X-Voot-Signature header is either missing or invalid.", null);
		}

		console.log("End - interceptors -> request-validator -> partnerRequestHeaders");
		next();
	} catch (error) {
		//mixpanel
		eventName = await commonUtil.preparePartnerEventName(request.method, request.path, false, true, false);
       
		let eventProps = { userInput: request.headers, input: _.get(request, "body",_.get(request,"headers")), Message: error.message, ErrorCode: _.get(error, "code"), distinct_id: request.distinctId, StatusCode: error.code };
		mixpanelService(eventName, eventProps, request.distinctId, _.get(request, "body", null), null, false);
        
		console.error("Error - interceptors -> request-validator -> partnerRequestHeaders");
		if (error && error.code && error.message) {
			request.query.error = JSON.stringify({ code: error.code.toString(), message: error.message, data: error.data });
		} else {
			request.query.error = JSON.stringify({ code: 500, message: "An error occured while validating partner request headers: " + error });
		}
		PostResponseInterceptor.processOne(request, response, next);
	}
}
const JWT = require("jsonwebtoken");

module.exports = {
	isBase64: isBase64,
	isNumeric: isNumeric,
	isNumericAndPositive: isNumericAndPositive,
	isInteger: isInteger,
	isIntegerAndPositive: isIntegerAndPositive,
	isAlphaNumeric: isAlphaNumeric,
	isAlphaNumericWithUnderscore: isAlphaNumericWithUnderscore,
	isAlphaNumericWithUnderscoreDash: isAlphaNumericWithUnderscoreDash,
	isAlphaNumericWithFwdSlashUnderscore: isAlphaNumericWithFwdSlashUnderscore,
	isAlphaNumericWithSpace: isAlphaNumericWithSpace,
	isAlphaNumericWithSpaceDot: isAlphaNumericWithSpaceDot,
	isAlphaNumericWithDot: isAlphaNumericWithDot,
	isAlphaNumericWithDotUnderscore: isAlphaNumericWithDotUnderscore,
	isAlphaNumericWithSpaceUnderscore: isAlphaNumericWithSpaceUnderscore,
	isAlphaNumericWithSpecial: isAlphaNumericWithSpecial,
	isBlankString: isBlankString,
	isString: isString,
	isEqualStrings: isEqualStrings,
	isEqualStringsIgnoreCase: isEqualStringsIgnoreCase,
	isBoolean: isBoolean,
	isBooleanString: isBooleanString,
	isNonEmptyObject: isNonEmptyObject,
	isNonEmptyArray: isNonEmptyArray,
	isNonEmptySet: isNonEmptySet,
	isValidPhoneCountryCode: isValidPhoneCountryCode,
	isValidPhoneNumber: isValidPhoneNumber,
	isValidTimezone: isValidTimezone,
	isValidEmail: isValidEmail,
	isValidJson: isValidJson,
	isValidPassword: isValidPassword,
	isSuccessResponse: isSuccessResponse,
	isSuccessResponseAndNonEmptyData: isSuccessResponseAndNonEmptyData,
	isSuccessResponseAndNonEmptyDataArray: isSuccessResponseAndNonEmptyDataArray,
	isValidDob: isValidDob,
	isValidUTCTimestamp: isValidUTCTimestamp,
	isValidObject: isValidObject,
	isValidJwt: isValidJwt,
	isValidSubscriptionStatus: isValidSubscriptionStatus,
};

/**
 * Check if given string is base64
 * @param {*} str 
 */
function isBase64(str) {
	if (this.isString(str)) {
		return !!str.match(/^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/);
	} else {
		return false;
	}
}

/**
 * Check if numeric
 * @param n 
 */
function isNumeric(n) {
	return !isNaN(parseFloat(n)) && isFinite(n);
}

/**
 * Check if Number and Positive
 * @param {*} n 
 */
function isNumericAndPositive(n) {
	return !isNaN(parseFloat(n)) && isFinite(n) && (parseFloat(n) >= 0);
}

/**
 * Check if Integer
 * @param {*} n 
 */
function isInteger(n) {
	return !isNaN(parseInt(n)) && isFinite(n);
}

/**
 * Check if Integer and Positive
 * @param {*} n 
 */
function isIntegerAndPositive(n) {
	return !isNaN(parseInt(n)) && isFinite(n) && (parseInt(n) >= 0);
}

/**
 * Check if alpha numeric
 * @param {*} str 
 */
function isAlphaNumeric(str) {
	if (this.isString(str)) {
		return !!str.match(/^[a-zA-Z0-9]+$/i);
	} else {
		return false;
	}
}

/**
 * Check if alpha numeric with underscore
 * @param {*} str 
 */
function isAlphaNumericWithUnderscore(str) {
	if (this.isString(str)) {
		return !!str.match(/^[\w]+$/i);
	} else {
		return false;
	}
}

/**
 * Check if alpha numeric with underscore dash
 * @param {*} str 
 */
function isAlphaNumericWithUnderscoreDash(str) {
	if (this.isString(str)) {
		return !!str.match(/^[\w-]+$/i);
	} else {
		return false;
	}
}

/**
 * Check if alpha numeric with forward slash
 * @param {*} str 
 */
function isAlphaNumericWithFwdSlashUnderscore(str) {
	if (this.isString(str)) {
		// eslint-disable-next-line no-useless-escape
		return !!str.match(/^[\w\/]+$/i);
	} else {
		return false;
	}
}

/**
 * Check if alpha numeric with space
 * @param {*} str 
 */
function isAlphaNumericWithSpace(str) {
	if (this.isString(str)) {
		return !!str.match(/^[a-zA-Z0-9 ]+$/i);
	} else {
		return false;
	}
}

/**
 * Check if alpha numeric with space, dot
 * @param {*} str 
 */
function isAlphaNumericWithSpaceDot(str) {
	if (this.isString(str)) {
		return !!str.match(/^[a-zA-Z0-9. ]+$/i);
	} else {
		return false;
	}
}

/**
 * Check if alpha numeric with dot
 * @param {*} str 
 */
function isAlphaNumericWithDot(str) {
	if (this.isString(str)) {
		return !!str.match(/^[a-zA-Z0-9.]+$/i);
	} else {
		return false;
	}
}

/**
 * Check if alpha numeric with dot, underscore
 * @param {*} str 
 */
function isAlphaNumericWithDotUnderscore(str) {
	if (this.isString(str)) {
		return !!str.match(/^[\w.]+$/i);
	} else {
		return false;
	}
}

/**
 * Check if alpha numeric with space, underscore
 * @param {*} str 
 */
function isAlphaNumericWithSpaceUnderscore(str) {
	if (this.isString(str)) {
		return !!str.match(/^[\w ]+$/i);
	} else {
		return false;
	}
}

/**
 * Check if alpha numeric with special characters
 * @param {*} str 
 */
function isAlphaNumericWithSpecial(str) {
	if (typeof str === "string") {
		// return !!str.match(/^[\w !@#$%^&*(),."':{}\\[\]\/\-]+$/i);
		// eslint-disable-next-line no-useless-escape
		return !!str.match(/^[\w !@#$%^&*(),.?="':{}\\[\]\/\-]+$/i);
	} else {
		return false;
	}
}

/**
 * Check if blank string
 * @param {*} str 
 */
function isBlankString(str) {
	if (str) {
		return false;
	} else {
		return true;
	}
}

/**
 * Check if string
 * @param {*} value 
 */
function isString(value) {
	if ((typeof value === "string" || value instanceof String) && (value != "null" && value != null)) {
		return true;
	} else {
		return false;
	}
}

/**
 * Check if two strings are equal
 * @param {*} value 
 */
function isEqualStrings(str1, str2) {
	if (this.isString(str1) && this.isString(str2) && (str1 === str2)) {
		return true;
	} else {
		return false;
	}
}

/**
 * Check if two strings are equal with case insensitive
 * @param {*} value 
 */
function isEqualStringsIgnoreCase(str1, str2) {
	if (this.isString(str1) && this.isString(str2) && (str1.toLowerCase() === str2.toLowerCase())) {
		return true;
	} else {
		return false;
	}
}

/**
 * Check if Boolean
 * @param {*} value 
 */
function isBoolean(value) {
	if (typeof value === "boolean" || value instanceof Boolean) {
		return true;
	} else {
		return false;
	}
}

/**
 * Check if Boolean string
 * @param {*} value 
 */
function isBooleanString(value) {
	if (this.isString(value) && (value == "true" || value == "false")) {
		return true;
	} else {
		return false;
	}
}

/**
 * Check if non-empty object
 * @param {*} obj 
 */
function isNonEmptyObject(obj) {
	if (obj && Object.keys(obj).length > 0) {
		return true;
	} else {
		return false;
	}
}

/**
 * Check if non-empty array
 * @param {*} arr 
 */
function isNonEmptyArray(arr) {
	if (arr && Array.isArray(arr) && arr.length > 0) {
		return true;
	} else {
		return false;
	}
}

/**
 * Check if non-empty set
 * @param {*} val 
 */
function isNonEmptySet(val) {
	// eslint-disable-next-line no-undef
	if (val && val instanceof Set && val.size > 0) {
		return true;
	} else {
		return false;
	}
}

/**
 * Check if valid phone country code
 * @param {*} str 
 */
function isValidPhoneCountryCode(code) {
	if (code) {
		return !!code.match(/^(\+?\d{1,7}|\d{1,8})$/i);
	} else {
		return false;
	}
}

/**
 * Validate phone number
 * @param {*} number 
 */
function isValidPhoneNumber(number) {
	if (number) {
		number = number.toString();
		if (this.isNumericAndPositive(number) && number.length == 10) {
			return true;
		} else {
			return false;
		}
	} else {
		return false;
	}
}

/**
 * Check if valid timezone
 * @param {*} str 
 */
function isValidTimezone(str) {
	// Initialize
	let isValid = false;

	if (this.isString(str)) {
		// Format +05:30
		// eslint-disable-next-line no-useless-escape
		isValid = !!str.match(/^([\+\-]{1}(\d{1,2}){1}:{1}(\d{2}){1})+$/i);
		if (!isValid) {
			// Format 'Europe/Isle_of_Man'
			isValid = !!str.match(/^([a-zA-Z]+(\/){1}[a-zA-Z_]+)+$/i);
		}
	}

	return isValid;
}

/**
 * Check if valid email
 * @param {*} email 
 */
function isValidEmail(email) {
	if (this.isString(email)) {
		// eslint-disable-next-line no-useless-escape
		return !!email.match(/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/i);
	} else {
		return false;
	}
}

/**
 * Check if valid json
 * @param {*} json 
 */
function isValidJson(json) {
	try {
		if (this.isValidObject(json)) {
			JSON.parse(JSON.stringify(json));
		} else {
			JSON.parse(json);
		}
	} catch (error) {
		return false;
	}
	return true;
}

/**
 * Check if valid password
 * @param {*} password 
 */
function isValidPassword(password) {
	try {
		if (this.isString(password)) {
			// Initialize
			let isMinLength = false;
			let isMaxLength = false;
			let hasUpperCase = false;
			let hasLowerCase = false;
			let hasNumber = false;
			let hasSpecialChar = false;

			isMinLength = (password.length >= 8) ? true : false;
			isMaxLength = (password.length <= 16) ? true : false;

			// Check for atleast one
			hasUpperCase = /[A-Z]/.test(password);
			hasLowerCase = /[a-z]/.test(password);
			hasNumber = /\d/.test(password);
			hasSpecialChar = /[!@#$%^&*()_\-+=]+/.test(password);

			// Check if any invalid special character
			hasSpecialChar = !!password.match(/^[\w!@#$%^&*()_\-+=]+$/i);

			if (isMinLength && isMaxLength && hasUpperCase && hasLowerCase && hasNumber && hasSpecialChar) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	} catch (error) {
		return false;
	}
}

/**
 * Check if success response
 * @param {*} response 
 */
function isSuccessResponse(response) {
	if (this.isNonEmptyObject(response)
        && response.code == 200) {
		return true;
	} else {
		return false;
	}
}

/**
 * Check if success response with non empty data
 * @param {*} response 
 */
function isSuccessResponseAndNonEmptyData(response) {
	if (this.isSuccessResponse(response) && this.isNonEmptyObject(response.data)) {
		return true;
	} else {
		return false;
	}
}

/**
 * Check if success response with non empty data array
 * @param {*} response 
 */
function isSuccessResponseAndNonEmptyDataArray(response) {
	if (this.isSuccessResponse(response) && this.isNonEmptyArray(response.data)) {
		return true;
	} else {
		return false;
	}
}

/**
 * Verify dob
 * @param {*} dob 
 */
function isValidDob(dob) {
	if (this.isString(dob)) {
		return !!dob.match(/^(\d{4})-(\d{2})-(\d{2})$/);
	} else {
		return false;
	}
}

/**
 * Verify if valid UTC timestamp
 * @param {*} value 
 */
function isValidUTCTimestamp(value) {
	try {
		if (this.isNumericAndPositive(value)) {
			return new Date(value).getTime() > 0;
		} else {
			return false;
		}
	} catch (error) {
		return false;
	}
}

/**
 * Verify if valid object
 * @param {*} value 
 */
function isValidObject(value) {
	if (typeof value === "object" || value instanceof Object) {
		return true;
	} else {
		return false;
	}
}

/**
 * Verify if valid JWT
 * @param {*} token 
 */
function isValidJwt(token, secret) {
	try {
		if (this.isString(token)) {
			let isValid = false;
			JWT.verify(token, secret, (error) => {
				if (error) {
					isValid = false;
				} else {
					isValid = true;
				}
			});
			return isValid;
		} else {
			return false;
		}
	} catch (error) {
		return false;
	}
}

/**
 * Validate subscription status
 * @param value 
 */
function isValidSubscriptionStatus(value) {
	if (this.isEqualStrings(value, "renew") || this.isEqualStrings(value, "cancel")) {
		return true;
	} else {
		return false;
	}
}
const moment = require("moment");

const TIME_OFFSET = "+05:30";

/**
 * Can be used for dd-mm-yyyy to yyyy-mm-dd conversion or vice versa
 * @param {String} word 
 * @param {String} delimiter Defaults to -
 * @returns {String}
 */
const reverseOrder = function (word, delimiter = "-") {
	if (typeof word !== "string") return "";
	return word.split(delimiter)
		.reverse()
		.join(delimiter);
};

/**
 * @param {Object} dateOptions
 * @param {String} dateOptions.dateFormat eg: DD-MM-YYYY
 * @param {Array<String>} dateArr Array of date String of provided format
 * @returns {Number} Index of first line item which is not a valid date format
 */
const getInvalidDateIndex = function (dateOptions, dateArr) {
	const {
		dateFormat = "DD-MM-YYYY",
	} = dateOptions;
	const dateValidityList = dateArr.map(date => moment(date, dateFormat).isValid());
	return dateValidityList.indexOf(false);
};

/**
 * @param {Object} dateOptions 
 * @param {String} dateOptions.dateFormat eg: DD-MM-YYYY
 * @param {String} startDate
 * @param {String} endDate
 * @returns {Boolean} Denotes if provided startDate is before endDate
 */
const isBefore = function (dateOptions = {}, startDate, endDate) {
	const {
		dateFormat = "DD-MM-YYYY",
	} = dateOptions;
	const datesArr = [startDate, endDate];
	const [fromDate, tillDate] = datesArr.map(date => moment(date, dateFormat));
	return fromDate.isBefore(tillDate);
};

/**
 * @param {Object} options
 * @param {String} options.offset eg: +05:30
 * @param {String} date yyyy-mm-dd format
 * @returns {String} ISO Date String with offset 
 */
const getDateString = function (options, date) {
	const {
		offset = TIME_OFFSET
	} = options;
	return `${date}T00:00:00${offset}`;
};

/**
 * @param {String} dateString yyyy-mm-dd format
 * @param {Number} days number of days to be incremented
 * @returns {String} updated date in yyyy-mm-dd format
 */
const addDays = function (dateString, days = 0) {
	const curDate = new Date(dateString);
	const newDate = new Date(
		curDate.setDate(curDate.getDate() + days)
	).toISOString();
	return newDate.split("T")[0];
};

module.exports = {
	reverseOrder,
	getInvalidDateIndex,
	isBefore,
	getDateString,
	addDays,
};
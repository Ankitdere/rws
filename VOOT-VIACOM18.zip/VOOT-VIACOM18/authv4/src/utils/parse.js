module.exports = {
	fromStringifiedJsonToObject: fromStringifiedJsonToObject,
};

/**
 * Convert strigified JSON to object
 * @param stringifiedJson 
 */
async function fromStringifiedJsonToObject(stringifiedJson) {
	try {
		// Initialize
		let decoded = null;

		// Decode
		try {
			decoded = JSON.parse(stringifiedJson);
		} catch (error) {
			decoded = JSON.parse(JSON.stringify(stringifiedJson));
		}

		// Response
		// eslint-disable-next-line no-undef
		return Promise.resolve({ code: 200, message: "Successfully converted strigified JSON to Object.", data: decoded });
	} catch (error) {
		// eslint-disable-next-line no-undef
		return Promise.reject({ code: 500, message: "An error occured while converting stringified JSON to Object: " + error });
	}
}
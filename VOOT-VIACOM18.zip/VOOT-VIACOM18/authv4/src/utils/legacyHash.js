"use strict";

const config = require("../config").configuration;
const crypto = require("crypto");

module.exports = {
	getSha1Hash,
	getSha256Hash
};

async function getSha1Hash(password) {
	console.debug("legacy service getSha1Hash");
	return crypto.createHmac("sha1", config.loginRadius.hashKey).update(password).digest().toString();
}

async function getSha256Hash(password) {
	console.debug("legacy service getSha256Hash");
	return crypto.createHash("sha256").update(password).digest("hex");

}
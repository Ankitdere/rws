const Crypto = require("crypto");
const ModuleError = require("../errors/module");

module.exports = {
	string: string,
	numeric: numeric,
	alphabet: alphabet,
	getRandomIntWithinMax: getRandomIntWithinMax,
};

/**
 * Generates a random string
 * @param {*} size 
 */
function string(size) {
	try {
		return Crypto.randomBytes(size).toString("hex").slice(0, size);
	} catch (error) {
		throw new ModuleError(500, "An error occured while generating random alphanumerics.", null);
	}
}

/**
 * Generates a random number
 * @param {*} size 
 */
function numeric(size) {
	try {
		return parseInt(Crypto.randomBytes(size).readUInt32BE(size).toString().slice(0, size));
	} catch (error) {
		throw new ModuleError(500, "An error occured while generating random numerics.", null);
	}
}

/**
 * Generates a random string using alphabets
 */
function alphabet(size) {
	try {
		return Crypto.randomBytes(size).toString("hex").slice(0, size);
	} catch (error) {
		throw new ModuleError(500, "An error occured while generating random alphabets.", null);
	}
}

/**
 * Generates a random integer less than a maximum
 * @param {*} max 
 */
function getRandomIntWithinMax(max) {
	return Math.floor(Math.random() * Math.floor(max));
}
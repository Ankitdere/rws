module.exports = {
	mongoToPartnerUser: mongoToPartnerUser,
};

/**
 * Convert mongo details to partner user format
 * @param {*} mongoUser 
 */
function mongoToPartnerUser(mongoUser) {
	try {
		let partnerUser = {
			id: mongoUser.uid,
			uid: mongoUser.uid,
			email: mongoUser.email,
			mobile: mongoUser.phoneNumber,
		};

		if (mongoUser.profile) {
			partnerUser.tempEmail = mongoUser.profile.tempEmail;
			partnerUser.partnerType = mongoUser.profile.partnerType;
			partnerUser.externalId = mongoUser.profile.externalId;
			partnerUser.deviceId = mongoUser.profile.deviceId;
			partnerUser.uniqueId = mongoUser.profile.uniqueId;
			partnerUser.isActive = mongoUser.profile.isActive;
			partnerUser.kUserId = mongoUser.profile.kUserId;
			partnerUser.renewedAt = mongoUser.profile.renewedAt;
			partnerUser.cancelledAt = mongoUser.profile.cancelledAt;
			partnerUser.entitlementStatus = mongoUser.profile.entitlementStatus;

			if (mongoUser.profile.subscription) {
				partnerUser.subscription = {
					activationDate: mongoUser.profile.subscription.activationDate,
					startDate: mongoUser.profile.subscription.startDate,
					endDate: mongoUser.profile.subscription.endDate,
					transactionId: mongoUser.profile.subscription.transactionId,
				};
			}
		}

		return partnerUser;
	} catch (error) {
		return mongoUser;
	}
}
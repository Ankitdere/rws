"use strict";
const mixpanelService = require("../services/mixpanelService");
const _ = require("lodash");
module.exports = {
	success,
	error
};
function success(message = null, data = null, code = 200,eventName = "", input = [], distinctId= "",isAuthProject=true) {
	let outputData = data;
	const status = {
		code: code,
		message: message
	};
	if (!message) status.message = "OK";
	if (typeof message === "object") {
		status.message = "OK";
		outputData = message;
	}
	// Send Event to mixpanel
	console.debug("Message................",message);
	if(eventName){
		try{
			let messageToPass = (status.message == "OK" && code != 200)? outputData:status.message;
			if(messageToPass && messageToPass.status && messageToPass.status.message){
				messageToPass = messageToPass.status.message;
			}
			let ErrorCode={};
			if(code != 200) {
				ErrorCode={ErrorCode :_.get(message.status,"code",status.code)};
			}
			let eventProps = {userInput: input,input, Message: messageToPass, StatusCode: _.get(message,"code",code),ErrorCode, distinct_id: distinctId/*, outputData: outputData*/};
			mixpanelService(eventName, eventProps, distinctId, null, null, isAuthProject);
		}catch(err){
			console.error("Error in sending mixpanel Event",err);
		}
	}
	console.info("Final Response", outputData);
	return { ...outputData };
}

function error(message = null, code = 400, eventName = "", input = [], distinctId= "",httpCode = 400,isAuthProject=true) {
	const status = {
		code: code,
		message: message
	};
	if (message.code)
		status.code = message.code; //TODO: remove it later, upon better implementation (need to send error code along with message)
	if (message.message)
		status.message = message.message; //TODO: remove it later, upon better implementation (need to send error code along with message)
	if (!message)
		status.message = "ERROR";

	// Send Event to mixpanel
	if(eventName){
		try{
			let eventProps = {userInput: input,input:_.get(input,"input",input), Message: status.message, ErrorCode: _.get(message,"code",code), distinct_id: distinctId, StatusCode :httpCode};
			mixpanelService(eventName, eventProps, distinctId, null, null, isAuthProject);
		}catch(err){
			console.error("Error in sending mixpanel error API.error",err);
		}
        
	}
   
	console.error("Final Error Is ", status);
	return {
		status
	};
}
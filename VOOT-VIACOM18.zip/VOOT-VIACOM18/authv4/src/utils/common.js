"use strict";

const moment = require("moment");
const _ = require("lodash");
const errorConfig = require("../config/errorConfig");
const configuration = require("../config").configuration;
// const otpServiceName= require('../services').otpService.FORGOT_PASSWORD_EMAIL_REQUEST;
const apiResponse = require("./apiResponse");
const userService = require("./../services/users");
const phoneUtil = require("google-libphonenumber").PhoneNumberUtil.getInstance();
const mixpanelConfig = require("../config/mixPanelConfig");

module.exports = {
	loginTypes: ["traditional", "facebook", "google", "mobile", "apple", "amazon"],
	signUpTypes: ["traditional", "mobile"],
	randomString,
	formatValidationErrors,
	isEmail,
	getNestedValue,
	isValidDate,
	responseFormatter,
	getLastLoggedInType,
	dateFormat,
	logVitalHeaders,
	isPasswordUser,
	DbTemplateforVerifyOtpForgetPassword,
	otpMessageFormater,
	formatValidationForPartnerErrors,
	createTempEmail,
	getDummyEmail,
	maskEmail,
	maskMobileNumber,
	logErrorMsgForPartners,
	updateAtTimestamp,
	getUserAuthPasswordProvider,
	splitMobileWithCountryCode,
	tokenDateCalculator,
	customKsmDevicePlatformValidator,
	isMobileNumberValid,
	preparePartnerEventName,
	countCharacterOccurenceInAString,
	getPositionOfSubstringOccurence,
	returnDeviceAndPlatformsList,
	reverse,
	getAge,
	isKidProfile,
	//  setDocumentTimeStamp
	notallowedSignupMethod,
	blockByProvider,
	blockByPlatform

};

function randomString(length) {
	let text = "";
	const possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	for (let i = 0; i < length; i++) {
		text += possible.charAt(Math.floor(Math.random() * possible.length));
	}
	return text;
}

function formatValidationErrors(errors) {
	let messageString = "";
	const error = {
		invalidActionPlateform: "Please provide a valid action plateform",
		invalidCountryCode: "countryCode must be in correct format e.g. +91",
		invalidEmail: "Invalid email.",
		leastFavourites: "Please select at least 5 favourites.",
		invalidProfileName: "Invalid profile name.",
		invalidDOB: "Please provide a valid dob.",
		invalidPartnerCredentials: "Please Provide an Valid apiKey",
		invalidClientId: "Please Provide an Valid ClientId",
		ksmObjectInclude: "KidSafeMode must have at least one more children from ['status','contentRestriction','recovery','pin']",
		emptyRequestBody:"Request Body can't be empty",
		parentPinObjectInclude: "parentPinMode must have at least one children from ['deviceId','isParentPinStatus','recovery','pin']",
		invalidLanguages: "Please provide valid Languages"
	};
	let code;
	let key = _.get(errors, "details[0]", null);
	if (key.message !== undefined && key.message !== undefined && key.message !== "") {
		const fieldError = `${key.context.key}_${key.type}`;
		console.log(JSON.stringify(key));
		switch (fieldError) {
		case "countryCode_string.regex.base":
			messageString = error.invalidCountryCode;
			break;
		case "mobileOrEmail_string.email":
			messageString = error.invalidEmail;
			break;
		case "characters_array.min":
			messageString = error.leastFavourites;
			break;
		case "name_string.regex.base":
			messageString = error.invalidProfileName;
			break;
		case "dob_date.min":
		case "dob_date.max":
		case "birthdate_string.regex.base":
		case "birthdate_date.base":
		case "birthdate_date.format":
		case "birthdate_date.max":
			messageString = errorConfig.invalidDOB.description;
			break;
		case "mobile_string.regex.base":
			messageString = errorConfig.invalidMobile.description;
			break;
		case "tncVersion_string.regex.base":
			messageString = errorConfig.invalidTncVersion.description;
			break;
		case "tncAcceptTime_date.max":
			messageString = errorConfig.invalidTncAcceptTime.description;
			break;
		case "newPassword_any.invalid":
			messageString = errorConfig.invalidPassword.description;
			break;
		case "apiKey_any.allowOnly":
			messageString = error.invalidPartnerCredentials;
			break;
		case "clientId_any.allowOnly":
			messageString = error.invalidClientId;
			break;
		case "kidSafeMode_object.min":
			messageString = error.ksmObjectInclude;
			break;
		case "undefined_object.min":
			messageString = error.emptyRequestBody;
			break;
			// case 'otp_string.regex.base':
			//     messageString = errorConfig.invalidOtp.description;
			//     break;
		case "parentPinMode_object.min":
			messageString = error.parentPinObjectInclude;
			break;
		case "languages_array.min":
			messageString = error.invalidLanguages;
			break;	
		default:
			// eslint-disable-next-line no-useless-escape
			messageString = (key.message.replace(/\".*\"/m, `${key.context.key}`));
			break;
		}
		code = `${key.context.label}`;
	}
	// remove last comma, quotation marks and whitespaces
	return { message: messageString.charAt(0).toUpperCase() + messageString.slice(1), code: Number(code) };
}

function isEmail(text) {
	// eslint-disable-next-line no-useless-escape
	const regExp = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	return regExp.test(String(text).toLowerCase());
}

function getNestedValue(object, pathToProperty) {
	try {
		return eval(`object.${pathToProperty}`);
	} catch (error) {
		return null;
	}
}

function isValidDate(dateString) {
	return moment(dateString).isValid();
}

function responseFormatter(result) {
	let responseCode = (_.get(result, "status.code") ? _.get(result, "status.code") : 200);
	if (responseCode == 400 && _.get(result, "status.message") == errorConfig.requestFailed)
		return {
			httpCode: 500,
			responseData: result
		};
	if (responseCode > 1800)
		responseCode = 400;
	return {
		httpCode: responseCode,
		responseData: result
	};
}

async function getLastLoggedInType(syncedData, lastLoggedInType) {
	if (lastLoggedInType)
		return lastLoggedInType;

	let types = [
		{ type: "facebook", date: _.get(syncedData, "data.FacebookUser.LastLoginDate") },
		{ type: "google", date: _.get(syncedData, "data.GmailUser.LastLoginDate") },
		{ type: "traditional", date: _.get(syncedData, "data.NormalUser.LastLoginDate") }
	];
	types = await _.orderBy(types, function (o) { return moment(o.date); }, ["desc"]);
	return types[types.length - 1].type;
}

function dateFormat(birthdate) {
	if (_.isEmpty(birthdate))
		return birthdate;
	let dd, mm, yyyy;
	if (birthdate.match("/")) {
		let lrDate = birthdate.split("/");
		dd = lrDate[1];
		mm = lrDate[0];
		yyyy = lrDate[2];
	} else {
		let splitDate = birthdate.split("-");
		dd = splitDate[0];
		mm = splitDate[1];
		yyyy = splitDate[2];
	}
	if (dd.length === 1) {
		dd = "0" + dd;
	}
	if (mm.length === 1) {
		mm = "0" + mm;
	}

	if (Number(mm) > 12) {
		let tempdd = dd;
		dd = mm;
		mm = tempdd;
	}
	return dd + "-" + mm + "-" + yyyy;
}

function logVitalHeaders(headers) {
	const requestHeaders = []; // TODO: extract custom header keys to be defined from config
	const keysToKeep = ["appversion", "devicetype", "platform", "user-agent", "cache-control", "content-type",
		"x-appengine-city", "x-appengine-citylatlong", "x-appengine-country", "x-appengine-https", "x-appengine-region", "x-appengine-user-ip", "connection",];
	keysToKeep.forEach(key => {
		if (headers[key]) requestHeaders[key] = headers[key];
	});
	console.info({ requestHeaders });
	return requestHeaders;
}

function isPasswordUser(providerData) {
	let isPasswordUser = false;
	if (providerData.length > 0) {
		for (let i = 0; i < providerData.length; i++) {
			if (providerData[i].providerId == "password") {
				isPasswordUser = true;
				break;
			}
		}
	}
	return isPasswordUser;
}
function DbTemplateforVerifyOtpForgetPassword(data, serviceName, viaMobile, isOtpVerify) {

	let otpVerified = {
		otp: _.get(data, "_system." + serviceName + ".otp", "1234"),
		createdAt: _.get(data, "_system." + serviceName + ".createdAt", moment().format("MMMM Do YYYY, h:mm:ss a")),
		updatedAt: _.get(data, "_system." + serviceName + ".updatedAt", moment().format("MMMM Do YYYY, h:mm:ss a")),
		attempts: _.get(data, "_system." + serviceName + ".attempts", 5),
		viaMobile: viaMobile,
		isOtpVerify: isOtpVerify
	};
	return otpVerified;
}
function otpMessageFormater(Config, textToSend, destinationNumber) {
	let params = {
		ApplicationId: Config.AWS1.applicationId,
		MessageRequest: {
			Addresses: {
				[destinationNumber]: {
					ChannelType: "SMS"
				}
			},
			MessageConfiguration: {
				SMSMessage: {
					Body: textToSend,
					Keyword: "VKIDS",
					MessageType: Config.AWS1.PinPoint.attributes.DefaultSMSType,
					SenderId: "VKIDS",
				}
			}
		}
	};
	return params;
}

function formatValidationForPartnerErrors(errors) {
	console.log("My Errors", errors);
	let messageString = "";
	const error = {
		invalidMobileNumber: "Please provide a valid mobile",
		invalidCountryCode: "countryCode must be in correct format e.g. +91",
		invalidEmail: "Invalid email.",
		leastFavourites: "Please select at least 5 favourites.",
		invalidProfileName: "Invalid profile name.",
		invalidDOB: "Please provide a valid dob.",
		invalidEndDate: "endDate should be greater than startDate.",
		invalidStartDate: "Please provide a valid date e.g. 31-01-2001.",
		invalidData: "data must be an object",
	};
	let code;
	let key = _.get(errors, "details[0]", null);
	if (key.message !== undefined && key.message !== undefined && key.message !== "") {
		const fieldError = `${key.context.key}_${key.type}`;
		switch (fieldError) {
		case "countryCode_string.regex.base":
			messageString = error.invalidCountryCode;
			break;
		case "mobileOrEmail_string.email":
			messageString = error.invalidEmail;
			break;
		case "mobile_string.regex.base":
			messageString = error.invalidMobileNumber;
			break;
		case "characters_array.min":
			messageString = error.leastFavourites;
			break;
		case "name_string.regex.base":
			messageString = error.invalidProfileName;
			break;
		case "dob_date.min":
		case "dob_date.max":
		case "birthdate_string.regex.base":
		case "birthdate_date.base":
		case "birthdate_date.format":
		case "birthdate_date.max":
			messageString = errorConfig.invalidDOB.description;
			break;
		case "tncVersion_string.regex.base":
			messageString = errorConfig.invalidTncVersion.description;
			break;
		case "tncAcceptTime_date.max":
			messageString = errorConfig.invalidTncAcceptTime.description;
			break;
		case "endDate_date.greater":
			messageString = error.invalidEndDate;
			break;
		case "endDate_string.regex.base":
			messageString = error.invalidStartDate; //msg same for end date & start date
			break;
		case "startDate_string.regex.base":
			messageString = error.invalidStartDate;
			break;
		case "data_object.base":
			messageString = error.invalidData;
			break;
		default:
			// eslint-disable-next-line no-useless-escape
			messageString = (key.message.replace(/\".*\"/m, `${key.context.key}`));
			break;
		}
		code = `${key.context.label}`;
	}
	// remove last comma, quotation marks and whitespaces
	return { message: messageString, code: Number(code) };
}

function getDummyEmail(emailpart) {
	return emailpart + "@voot.com";
}
function maskEmail(myemailId) {
	if (myemailId == undefined || _.isEmpty(myemailId)) {
		return "";
	}
	let maskid = "";
	let prefix = myemailId.substring(0, myemailId.lastIndexOf("@"));
	let postfix = myemailId.substring(myemailId.lastIndexOf("@"));
	let domain_name = postfix.substring(0, postfix.lastIndexOf("."));
	let domain = postfix.substring(postfix.lastIndexOf("."));

	for (let i = 0; i < prefix.length; i++) {
		if (i == 0 || i == 1 || i == prefix.length - 1) {
			maskid = maskid + prefix[i].toString();
		}
		else {
			maskid = maskid + "*";
		}
	}
	for (let i = 0; i < domain_name.length; i++) {
		if (i == 0 || i == 1 || i == domain_name.length - 1) {
			maskid = maskid + domain_name[i].toString();
		}
		else {
			maskid = maskid + "*";
		}
	}
	maskid = maskid + domain;

	return maskid;
}
function maskMobileNumber(mobileNumber, countryCode) {
	if (_.isEmpty(countryCode)) {
		let maskid = "";
		for (let i = 0; i < mobileNumber.length; i++) {
			if (i == 0 || i == 1 || i == 2 || i == mobileNumber.length - 4 || i == mobileNumber.length - 3 || i == mobileNumber.length - 2 || i == mobileNumber.length - 1) {
				maskid = maskid + mobileNumber[i].toString();
			}
			else {
				maskid = maskid + "*";
			}
		}
		return maskid;
	} else {
		let maskid = "";
		for (let i = 0; i < mobileNumber.length; i++) {
			if (i == mobileNumber.length - 2 || i == mobileNumber.length - 1) {
				maskid = maskid + mobileNumber[i].toString();
			}
			else {
				maskid = maskid + "*";
			}
		}
		return countryCode + maskid;
	}
}
function logErrorMsgForPartners(input, partner_name, error_msg, partner_msg, userData, partnerData) {
	let logError = {};
	logError = {
		uid: _.get(userData, "uid", ""),
		partner_name: partner_name ? partner_name : _.get(userData, "partnerType", ""),
		error_message: error_msg ? error_msg : "",
		partner_message: partner_msg ? partner_msg : "",
		partnerToken: _.get(input.data, "token", _.get(input, "token", "")),
	};
	if (partner_name == configuration.jioSubscription.partnerType) {
		logError.mobile_number = _.get(partnerData, "mobile", ""),
		logError.externalId = _.get(input.data, "externalId", _.get(partnerData, "externalId", ""));
	} else if (partner_name == configuration.TSKYDetails.partnerType) {
		logError.uniqueId = _.get(partnerData, "uniqueId", ""),
		logError.dsn = _.get(input, "dsn", _.get(input.data, "dsn", "")),
		logError.token = _.get(partnerData, "x-partner-key", _.get(input, "token", ""));
	}

	console.log("Partner Error Response", logError);
}
function updateAtTimestamp(mongoTimestamp, firestoreTimestamp) {
	if (mongoTimestamp > firestoreTimestamp) {

		return { dbName: "mongodb" };
	} else {
		return { dbName: "firestore" };
	}
}

async function getUserAuthPasswordProvider(userAuth, isLogin = false) {
	if (!_.has(userAuth, "status")) {
		for (let i = 0; i < userAuth.length; i++) {
			let providerDataCheck = _.get(userAuth[i], "providerData");
			// Check if provider data is empty and login true then 
			if (_.isEmpty(providerDataCheck) && isLogin) {
				// Preapare data if not Exist
				if (!_.isEmpty(userAuth[i].uid)) {
					let providerData = [{
						uid: userAuth[i].uid,
						displayName: "",
						email: userAuth[i].email,
						photoURL: "",
						providerId: "password"
					}];
					try {
						//        providerData =  await getUserByUIdInFirebase(userAuth[i].uid);
						if (!_.isEmpty(providerData)) {
							userAuth[i].providerData = providerData;
							providerDataCheck = _.get(userAuth[i], "providerData");
							await userService.updateOrInsertUser({ uid: userAuth[i].uid }, userAuth[i]);
						}
					} catch (err) {
						console.error("Error While updating the Profile", err);
					}
				}
			}
			if (isPasswordUser(providerDataCheck)) {
				return userAuth[i];
			}
		}
		return { status: 1799, message: "Auth password provider not found" };
	}
}

function splitMobileWithCountryCode(mobile) {
	try {
		const number = phoneUtil.parseAndKeepRawInput(mobile);
		return { CountryCode: `+${number.getCountryCode()}`, Mobile: `${number.getNationalNumber()}` };
	}
	catch (err) {
		console.log(`error in splitMobileWithCountryCode : ${mobile} :`, err, err.stack);
		if (mobile.length > 10) {
			let mobile_number = mobile.substring(mobile.length - 10);
			let countryCode = mobile.substr(0, mobile.length - 10);
			return { CountryCode: countryCode, Mobile: mobile_number };
		} else {
			return { Mobile: mobile };
		}
	}
}
function tokenDateCalculator(endDate) {

	const formatedEndDate = moment(new Date(endDate), "YYYY-MM-DD");
	//const formatedEndDate = moment(new Date('2020-11-20T22:06:42'), 'YYYY-MM-DD')
	const currentDate = moment(new Date(), "YYYY-MM-DD");
	let days = formatedEndDate.diff(currentDate, "days");
	console.log("Number of Days to validate", days);

	if (days > configuration.jwt.accessTokenExpiresInDays) { //If no of days left is greater than 10 then no change in validatity 
		return false;
	} else if (days > 0) { //If no of days left is less than 10 then their is change in validatity 
		return `${days} days`;
	} else if (days == 0) { //If no of days left is less than 10 then their is change in validatity 
		const formillisec = moment(new Date(endDate), "YYYY-MM-DD:HH-MM-SS");
		console.log("Number of millisec to validate", formillisec);
		const currentDate2 = moment(new Date(), "YYYY-MM-DD:HH-MM-SS").utcOffset("+05:30");
		console.log("Number of millisev current date  to validate", currentDate2);
		let millisec = formillisec.diff(currentDate2);
		console.log("MILL Sec", millisec);
		if (millisec <= 0) {
			throw ({ code: "partner/user-plan-expired" });
		} else {
			return `${millisec} ms`;
		}
	}
	else {    //If user is Expired then their throw err 
		throw ({ code: "partner/user-plan-expired" });
	}
}

async function customKsmDevicePlatformValidator(headers) {
	let typeArr = [];
	let results = [];
	let finalJson = {};
	for (let device in configuration.ksmPlatformAndDeviceConfig.ksm) {
		if (configuration.ksmPlatformAndDeviceConfig.ksm.hasOwnProperty(device)) {
			console.log(device + " -> " + configuration.ksmPlatformAndDeviceConfig.ksm[device]);
			let jsonObject = {};
			jsonObject[device] = device;
			jsonObject[device] = {};
			for (let platform in configuration.ksmPlatformAndDeviceConfig.ksm[device]) {
				typeArr.push(platform);
			}
			jsonObject[device] = typeArr;
			typeArr = [];
			results.push(jsonObject);
			Object.assign(finalJson, ...results);
		}
	}

	if (!_.includes(_.get(finalJson, _.get(headers, "device")), _.get(headers, "platform"))) {
		console.log("_.get(headers.platform)", _.get(headers.platform));
		throw apiResponse.error(errorConfig.invalidDeviceAndPlatformMissMatch.description, errorConfig.invalidDeviceAndPlatformMissMatch.code);
	} else {
		return true;
	}
}
// Old code 
// function tokenDateCalculator2(endDate) {
//     const formatedEndDate = moment(new Date(endDate), 'YYYY-MM-DD')
//     //const formatedEndDate = moment(new Date('2020-11-20T22:06:42'), 'YYYY-MM-DD')
//     const currentDate = moment(new Date(), 'YYYY-MM-DD')
//     let days = formatedEndDate.diff(currentDate, 'days');
//     console.log("Number of Days to validate", days)

//     if (days > configuration.jwt.accessTokenExpiresInDays) { //If no of days left is greater than 10 then no change in validatity 
//         return false
//     } else if (days >= 0) { //If no of days left is less than 10 then their is change in validatity 
//         return days
//     } else {    //If user is Expired then their throw err 
//         throw ({ code: 'partner/user-plan-expired' })
//     }
// }
function isMobileNumberValid(mobile) {
	try {
		const mobileDetails = splitMobileWithCountryCode(mobile);
		const region = configuration.amazonValidMobile.validCountryCodeAndCountryNameMap[mobileDetails.CountryCode];
		if (region) {
			const number = phoneUtil.parseAndKeepRawInput(mobile);
			return phoneUtil.isValidNumber(number) && phoneUtil.isValidNumberForRegion(number, region);
		}
		return false;
	} catch (err) {
		console.log("Errror in isMobileNumberValid", err, err.stack);
		return false;
	}
}
async function preparePartnerEventName(method, path, serverValidation_Error, clientValidation_Error, others) {
	let eventName;
	if (method == "GET" && path == "/purchases/status") {
		eventName = mixpanelConfig.getStatus + mixpanelConfig.yuppTv;
		if (serverValidation_Error) eventName += mixpanelConfig.serverValidation_Error;
		if (clientValidation_Error) eventName += mixpanelConfig.clientValidation_Error;
		if (others) eventName += others;
	}
	else if (method == "PUT" && path == "/purchases/status") {
		eventName = mixpanelConfig.updateStatus + mixpanelConfig.yuppTv;
		if (serverValidation_Error) eventName += mixpanelConfig.serverValidation_Error;
		if (clientValidation_Error) eventName += mixpanelConfig.clientValidation_Error;
		if (others) eventName += others;
	}
	else if (method == "POST" && path == "/login") {
		eventName = mixpanelConfig.partnerLogin + mixpanelConfig.yuppTv;
		if (serverValidation_Error) eventName += mixpanelConfig.serverValidation_Error;
		if (clientValidation_Error) eventName += mixpanelConfig.clientValidation_Error;
		if (others) eventName += others;
	}

	else if (method == "POST" && path == "/tokens/refresh") {
		eventName = mixpanelConfig.refreshToken + mixpanelConfig.yuppTv;
		if (serverValidation_Error) eventName += mixpanelConfig.serverValidation_Error;
		if (clientValidation_Error) eventName += mixpanelConfig.clientValidation_Error;
		if (others) eventName += others;
	}
	else if (method == "POST" && path == configuration.pXApiDetails.partnerOrderSrvice) {
		eventName = mixpanelConfig.pxCall;
		if (serverValidation_Error) eventName += mixpanelConfig.serverValidation_Error;
		if (clientValidation_Error) eventName += mixpanelConfig.clientValidation_Error;
		if (others) eventName += others;
	}
	else if (method == "GET" && path == configuration.pXApiDetails.billingHistory) {
		eventName = mixpanelConfig.pxCall;
		if (serverValidation_Error) eventName += mixpanelConfig.serverValidation_Error;
		if (clientValidation_Error) eventName += mixpanelConfig.clientValidation_Error;
		if (others) eventName += others;
	}
	else if (method == "POST" && path == "/purchases") {
		eventName = mixpanelConfig.purchase;
		if (serverValidation_Error) eventName += mixpanelConfig.serverValidation_Error;
		if (clientValidation_Error) eventName += mixpanelConfig.clientValidation_Error;
		if (others) eventName += others;
	}
	return eventName;
}

function countCharacterOccurenceInAString(string, char) {
	let res = 0;

	for (let i = 0; i < string.length; i++) {
		// checking character in string
		if (string.charAt(i) == char) {
			res++;
		}
	}
	return res;
}
function getPositionOfSubstringOccurence(string, subString, index) {
	return string.split(subString, index).join(subString).length;
}
async function returnDeviceAndPlatformsList() {
	// Retrive All Devices &  Platform from Configuration for Validation Purpose
	let devicesList = [];
	let platformList = [];
	for (let device in configuration.ksmPlatformAndDeviceConfig.ksm) {
		devicesList.push(device);
		if (configuration.ksmPlatformAndDeviceConfig.ksm.hasOwnProperty(device)) {
			console.debug(device + " -> " + configuration.ksmPlatformAndDeviceConfig.ksm[device]);
			devicesList.push(device);
			for (let platform in configuration.ksmPlatformAndDeviceConfig.ksm[device]) {
				platformList.push(platform);
			}
		}
	}
	// eslint-disable-next-line no-undef
	console.debug("DeviceList", [...new Set(devicesList)]);
	// eslint-disable-next-line no-undef
	console.debug("PlatformList", [...new Set(platformList)]);
	// eslint-disable-next-line no-undef
	return ({ "DeviceList": [...new Set(devicesList)], "PlatformList": [...new Set(platformList)] });
}

function reverse(s) {
	return s.split("-").reverse().join("-");
}

function getAge(dateString) {
	let ageInMilliseconds = new Date() - new Date(dateString);
	return Math.floor(ageInMilliseconds / 1000 / 60 / 60 / 24 / 365);
}

//Temp Email is used in kaltura Registration in Tata-Sky/JIO
async function createTempEmail(uId, input) {
	let domainName = _.get(input, "partnerType") ? _.get(input, "partnerType") : configuration.tSkyDetails.partnerType;
	if (domainName == (configuration.tSkyDetails.partnerType)) { domainName = configuration.tSkyDetails.staticEmail; }
	const tempEmail = `${uId}@${domainName.toLowerCase()}.com`;
	return tempEmail;
}


/**
 * @param {String} BirthDate 
 * @param {Bolean} region 
 * @returns {Bolean}
 */
function isKidProfile(BirthDate, region){
	const birthDate = dateFormat(BirthDate);
	const ageCalculation = _.isEmpty(birthDate)?0: getAge(reverse(birthDate));
	if(ageCalculation<configuration.kidProfileAgeLimit[region] ) return true;
	return false;
}

/**
 * @param {String} userAgent 
 * @returns {Bolean}
 */
function blockByPlatform(userAgent){
	const signupPlatform = configuration.limitConfig.platformList;
	//['okhttp', 'CFNetwork', 'HttpClient','HTML','postman','Chrome','Mozilla','Safari','Windows'];
	const foundPlatform = signupPlatform.find(element => {
		return userAgent.toLowerCase().includes(element.toLowerCase());
	});
	return foundPlatform;
}

/**
 * @param {String} method 
 * @returns {Bolean}
 */
function blockByProvider(provider){
	const signupMethods = configuration.limitConfig.signupMethods;
	const foundSignupMethod = signupMethods.find(element => {
		return provider.toLowerCase().includes(element.toLowerCase());
	});
	return foundSignupMethod;
}

/**
 * @param {String} provider 
 * @param {String} userAgent 
 * @returns {Object}
 */
function notallowedSignupMethod(provider,userAgent=null){
	const tvMsgflag = configuration.limitConfig.tvMsgflag;
	const obj=errorConfig.notallowedSignupMethod(provider);
	if(tvMsgflag)
		obj.description=obj.description+configuration.limitConfig.tvMsg;
	if(userAgent && userAgent.match("CFNetwork"))
		obj.code=configuration.limitConfig.tvMsgCode;
	return obj;
}

module.exports = {
	encode: encode,
	decode: decode,
};

/**
 * Encode to Base64
 * @param {*} decoded 
 */
async function encode(decoded) {
	try {
		// Initialize
		let encoded = null;

		// Decode
		encoded = Buffer.from(decoded).toString("base64");

		// eslint-disable-next-line no-undef
		return Promise.resolve({ code: 200, message: "Successfully encoded string to Base64.", data: encoded });
	} catch (error) {
		// eslint-disable-next-line no-undef
		return Promise.reject({ code: 409, message: "An error occured while encoding to Base64: " + error });
	}
}

/**
 * Decode from Base64
 * @param encoded 
 */
async function decode(encoded) {
	try {
		// Initialize
		let decoded = null;

		// Decode
		decoded = Buffer.from(encoded, "base64").toString("ascii");

		// eslint-disable-next-line no-undef
		return Promise.resolve({ code: 200, message: "Successfully decoded Base64 string.", data: decoded });
	} catch (error) {
		// eslint-disable-next-line no-undef
		return Promise.reject({ code: 409, message: "An error occured while decoding from Base64: " + error });
	}
}
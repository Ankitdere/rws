const log = require("logger");

log.init({
	json: JSON.parse(process.env.LOG_JSON || false), service: "auth-v4", tags: ["auth"], level: process.env.LOG_LEVEL || "log",
});

const { logger } = log;

module.exports = logger;

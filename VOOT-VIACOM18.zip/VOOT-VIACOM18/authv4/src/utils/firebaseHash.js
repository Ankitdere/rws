
const crypto = require("crypto");
const config = require("../config").configuration;
module.exports = { firebaseHash, generateHash };

const hashConfig = config.hashConfig;

async function generateHash(password, salt) {
	const bSalt = Buffer.concat([
		Buffer.from(salt, "base64"),
		Buffer.from(hashConfig.saltSeparator, "base64")
	]);
	const iv = Buffer.alloc(hashConfig.IV_LENGTH, 0);
	console.debug("HashConfig",hashConfig);
	try {
		let derivedKey = crypto.scryptSync(
			password,
			bSalt,
			hashConfig.KEYLEN,
			hashConfig.params
		);
		const cipher = await crypto.createCipheriv(hashConfig.ALGORITHM, derivedKey, iv);
		const hash = Buffer.concat([
			cipher.update(Buffer.from(hashConfig.signerKey, "base64")),
			cipher.final()
		]).toString("base64");
		return hash;

	} catch (error) {
		console.log(error);
	}
}

async function firebaseHash(password, salt, passwordHash) {
	let isSuccess = false;
	let hashGenrate = await generateHash(password, salt);
	console.debug("Firebase Password hash and salt and generatedHash", passwordHash, salt,hashGenrate);
   
	if (passwordHash == hashGenrate) {
		isSuccess = true;
	} else {
		passwordHash = passwordHash.replace(/[^a-zA-Z0-9]/g, "");
		hashGenrate = hashGenrate.replace(/[^a-zA-Z0-9]/g, "");
		if (passwordHash == hashGenrate)
			isSuccess = true;
	}
	return isSuccess;
}
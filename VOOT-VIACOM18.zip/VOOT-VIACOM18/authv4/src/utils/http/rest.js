const Request = require("request");

module.exports = {
	get: get,
	post: post,
	put: put,
};

/**
 * 
 * @param url 
 * @param requestHeaders 
 * @param params 
 * @param flags 
 */
async function get(url, requestHeaders, params, flags) {
	// eslint-disable-next-line no-undef
	return new Promise((resolve, reject) => {
		// Initialize
		let request = {};

		if (!params) {
			params = {};
		}
		if (!flags) {
			flags = {};
		}

		// Construct request
		request = {
			headers: requestHeaders,
			uri: url,
			json: true
		};

		// Get
		// Since "Request" doesn't support promises inherently, can't "await"
		Request.get(request, (error, response) => {
			if (error) {
				if (error.code && error.message) {
					console.log(error);
					reject(error);
				} else {
					reject({ code: 409, message: "Error while processing GET method: " + error });
				}
			} else if (response.body && Object.keys(response.body).includes("code") && response.body.code != 200) {
				reject(response.body);
			} else {
				if (response.body) {
					if (response.body.message) {
						if (response.body.message == "success") {
							resolve({ code: response.statusCode, message: response.body.message, data: response.body });
						} else {
							reject({ code: response.statusCode, message: response.body.message, data: response.body });
						}
					} else if (response.statusCode) {
						if (response.statusCode == 200) {
							if (response.body.message) {
								resolve({ code: response.statusCode, message: response.body.message, data: response.body });
							} else {
								resolve({ code: response.statusCode, message: response.body.msg, data: response.body });
							}
						} else {
							reject({ code: response.statusCode, message: response.body.message, data: response.body });
						}
					} else {
						resolve(response.body);
					}
				} else {
					let resolveResult = { code: response.statusCode, message: response.statusMessage, data: null };
					if (flags.isHeaderRequired) {
						resolve({ ...resolveResult, headers: response.headers });
					}
					resolve(resolveResult);
				}
			}
		});
	});
}

/**
 * POST
 * @param {*} url 
 * @param {*} requestHeaders 
 * @param {*} requestBody 
 */
// Since "Request" doesn't support promises inherently, can't "async/await"
async function post(url, requestHeaders, requestBody, flags) {
	// eslint-disable-next-line no-undef
	return new Promise((resolve, reject) => {
		// Initialize
		let request = {};

		if (!flags) {
			flags = {};
		}

		// Construct request
		request = {
			headers: requestHeaders,
			uri: url,
			body: requestBody,
			json: true
		};

		// Post
		Request.post(request, (error, response) => {
			if (error) {
				if (error.code && error.message) {
					console.log(error);
					reject(error);
				} else {
					reject({ code: 409, message: "Error while processing POST method: " + error });
				}
			} else if (response.body && Object.keys(response.body).includes("code") && response.body.code != 200) {
				reject(response.body);
			} else {
				if (response.body) {
					if (response.body.message) {
						if (response.body.message == "success") {
							resolve({ code: response.statusCode, message: response.body.message, data: response.body });
						} else {
							reject({ code: response.statusCode, message: response.body.message, data: response.body });
						}
					} else if (response.statusCode) {
						if (response.statusCode == 200) {
							if (response.body.message) {
								resolve({ code: response.statusCode, message: response.body.message, data: response.body });
							} else {
								resolve({ code: response.statusCode, message: response.body.msg, data: response.body });
							}
						} else {
							reject({ code: response.statusCode, message: response.body.message, data: response.body });
						}
					} else {
						resolve(response.body);
					}
				} else {
					let resolveResult = { code: response.statusCode, message: response.statusMessage, data: null };
					if (flags.isHeaderRequired) {
						resolve({ ...resolveResult, headers: response.headers });
					}
					resolve(resolveResult);
				}
			}
		});
	});
}

/**
 * PUT
 * @param {*} url 
 * @param {*} requestHeaders 
 * @param {*} requestBody 
 */
// Since "Request" doesn't support promises inherently, can't "async/await"
async function put(url, requestHeaders, requestBody, flags) {
	// eslint-disable-next-line no-undef
	return new Promise((resolve, reject) => {
		// Initialize
		let request = {};

		if (!flags) {
			flags = {};
		}

		// Construct request
		request = {
			headers: requestHeaders,
			uri: url,
			body: requestBody,
			json: true
		};

		// Put
		Request.put(request, (error, response) => {
			if (error) {
				if (error.code && error.message) {
					console.log(error);
					reject(error);
				} else {
					reject({ code: 409, message: "Error while processing PUT method: " + error });
				}
			} else if (response.body && Object.keys(response.body).includes("code") && response.body.code != 200) {
				reject(response.body);
			} else {
				if (response.body) {
					if (response.body.message) {
						if (response.body.message == "success") {
							resolve({ code: response.statusCode, message: response.body.message, data: response.body });
						} else {
							reject({ code: response.statusCode, message: response.body.message, data: response.body });
						}
					} else if (response.statusCode) {
						if (response.statusCode == 200) {
							if (response.body.message) {
								resolve({ code: response.statusCode, message: response.body.message, data: response.body });
							} else {
								resolve({ code: response.statusCode, message: response.body.message, data: response.body });
							}
						} else {
							reject({ code: response.statusCode, message: response.body.message, data: response.body });
						}
					} else {
						resolve(response.body);
					}
				} else {
					let resolveResult = { code: response.statusCode, message: response.statusMessage, data: null };
					if (flags.isHeaderRequired) {
						resolve({ ...resolveResult, headers: response.headers });
					}
					resolve(resolveResult);
				}
			}
		});
	});
}
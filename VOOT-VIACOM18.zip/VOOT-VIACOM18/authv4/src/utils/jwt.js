const JWT = require("jsonwebtoken");
const ModuleError = require("../errors/module");

module.exports = {
	createOneTemporary: createOneTemporary,
};

/**
 * Generates a temporary JWT access token
 * @param {*} size 
 */
async function createOneTemporary(content) {
	try {
		// Initialize
		let token = null;
		let result = {};
		let currSecs = Math.ceil(new Date().getTime() / 1000);
		let signatureBody = {
			uid: content.userId,
			email: content.email,
			kUserId: content.kUserId,
			iss: content.issuer,
			iat: currSecs,
			exp: currSecs + content.expiryDurationInSecs,
		};

		if (content.deviceId) {
			signatureBody.deviceId = content.deviceId;
		}
		if (content.partnerType) {
			signatureBody.partnerType = content.partnerType;
		}

		// Generate token
		token = await JWT.sign(
			signatureBody,
			content.jwt.secret
		);

		// Response
		result = {
			token: token,
			expiry: currSecs + content.expiryDurationInSecs
		};
		// eslint-disable-next-line no-undef
		return Promise.resolve({ code: 200, message: "One temporary token generated successfully.", data: result });
	} catch (error) {
		console.error(error);
		throw new ModuleError(500, "An error occured while generating one temporary token.", null);
	}
}
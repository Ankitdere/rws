module.exports = {
	PARTNER: {
		YUPPTV: {
			NAME: "Yupp TV",
			CODE: "yupptv"
		},
		FLIPKART: {
			NAME: "Flipkart",
			CODE: "flipkart"
		},

	},
	BILLING: {
		PAYMENT_DETAILS: {
			MODE: {
				PARTNER: "partner"
			}
		}
	},
	VALID_OTP_VERSION: {
		v1: "v1",
		v2: "v2"
	},
	"USER_STATUS": {
		LOCKED: "locked",
		ACTIVE:"active"
	},
	PARTNER_TYPES: {
		JIO: "JIO"
	},
	PASSWORD_CHANGE_AUDIT:{
		FROM:"PASSWORD CHANGED",
		TO:"PASSWORD CHANGED"
	},
	VOOT: "voot",
	userLoginBlockTypes: [ "traditional", "mobile" ],
	VALID_REGIONS_FOR_AMAZON_LOGIN:["UK","IN"],
	REGEX_EXPRESSION: {
		PASSWORD_POLICY: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#$@~+!()%<>{}&*?_])[A-Za-z\d#$@~+!()%<>{}&*?_]{8,30}$/
	},
	typeInPartnerSignInRequest: "Partner",
	typeInVerifyCode: "TV Login",
	PARTNER_TYPES_FOR_CHECK_KALTURA_ACCOUNT:["Tata-Sky", "JIO"],
	PRIORITY:{
		SMS:"sms",
		EMAIL:"email",
		DEFAULT:"default"
	},
	DUMMY_EMAIL_CHECK:["@voot.com","+91"],
	USER_LOGIN_TYPES:{
		mobile:"mobile",
		traditional:"traditional"
	},
	BLOCK_DEVICEID_LLR: ["Windows NT 10.0", "Linux"],
	NO_UID_FOUND : 1701,
	SUCCESS_STATUS : 200,
	FAILURE_STATUS : 400,
	UID_NOT_FOUND_MODEL : { status: 1701, message: "No Uid Found", data:[] },
	SOMETHING_WENT_WRONG : "Something Went Wrong !!",
	DeviceIdLoginDetailsStatus: {
		ACTIVATE:1,
		DEACTIVATE:0
	},
	PINDETAILS:{
		TYPE:{
			kID_SAFE_MODE:"kidSafeMode",
			PARENT_PIN_MODE:"parentPinMode"
		}
	},
	SMS: {
		HEADER: "VOOTIN",
		TYPE: {
			OTP: "OTP"
		},
		TEMPLATE: {
			RECOVERY: {
				TEMPLATEID: 1107165052755374952
			}
		}
	},
	RESTRICT: {
		ACTION: {
			LOGIN: "login"
		}
	},
	NOTIFICATION: {
		ACTION: {
			UPDATEREGION:"regionUpdateQuery"
		},
		CODE:"auth_v4"
	},
	API_VERSION: {
		"4@0": "4.0"
	},
	TATASKYSOURCE:{
		TSATV: "TSATV"
	}
};
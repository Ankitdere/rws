const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const _ = require("lodash");
const { v4: uuidv4 } = require("uuid");
const tokenValidator = require("./helper").tokenValidator;
const searchTokenValidator = require("./helper").searchTokenValidator;
const forgotPasswordTokenValidator = require("./helper").forgotPasswordTokenValidator;
const partnerTokenValidator = require("./helper").partnerTokenValidator;
const apiResponse = require("./utils").apiResponse;
const AuthInterceptor = require("./interceptors/auth");
const RequestValidatorInterceptor = require("./interceptors/request-validator");
const PreRequestInterceptor = require("./interceptors/pre-request");
const PostResponseInterceptor = require("./interceptors/post-response");
const Config = require("./config/configuration");
// const LoginApiRateLimiter = RateLimit({
//     windowMs: 5 * 60 * 1000, // 5 minutes
//     max: 5,
//     message: "Too many login attempts.",
//     statusCode: 429,
//     handler: async (request, response, next) => {
//         try {
//             let error, result;
//             let requestIp = request.headers['x-voot-forwarded-for'] || request.headers['true-client-ip'] || request.headers['True-Client-IP'] || request.headers['x-appengine-user-ip'];

//             console.log("Too many login attempts from:", requestIp);
//             [error, result] = await To(RatelimitBusiness.createOne(
//                 {
//                     requestIp: requestIp
//                 },
//                 null,
//                 null
//             ));

//             request.rateLimit = {
//                 current: 0,
//                 limit: 5,
//                 remaining: 5
//             };
//         } catch (error) {
//             next();
//         }

//         // Response
//         response.status(429).send({ code: 429, message: "Too many login attempts." });
//     }
// });

const apikeyValidator = require("./helper").apikeyValidator.apiKeyvalidator;
const { blockUser } = require("./helper").blockUser;
const blockPartnerMiddleware = require("./helper/blockPartner");
// const changePasswordHandler =  './handlers/changePassword';
// const loginHandler =  './handlers/login';
// const forgotPasswordHandler =  './handlers/forgotPassword';
// const updateAccountHandler =  './handlers/updateAccount';
// const refreshKsHandler =  './handlers/refreshKs';
// const ApiResponse =  './decorators/ApiResponse';
// const testHandler =  './handlers/Handler';
// const verifyEmail =  './handlers/verifyEmail';
// const configurations =  './config/configurations';
// const tokenValidator =  './middlewares/tokenValidator';
// const signUpHandler =  './handlers/signUp';
// const getTokenInfo =  './handlers/getTokenInfo';
// const getProfileByAccessToken =  './handlers/getProfileByAccessToken'
// const kalturaRegTest =  './handlers/kalturaRegTest';
// const updateAccessToken =  './handlers/updateAccessToken';
// const refreshAccessToken =  './handlers/refreshAccessToken';
// const loginCode =  './handlers/loginCode';
// const activate =  './handlers/activate';
// const verifyCode =  './handlers/verifyCode';
// const getAuthKey =  './handlers/getAuthKey';
// const forgotPassHandler =  './handlers/forgotPass';
// const resetPassHandler =  './handlers/resetPassword';
// const forgotPasswordTokenValidator =  './middlewares/forgotPasswordTokenValidator';
// const getRemoteConfig =  './handlers/getRemoteConfig';
// const deleteUser =  './handlers/deleteUser';
// const jioSubscriptionHandler =  './handlers/jioSubscription';
// const jioEntitlementHandler =  './handlers/jioEntitlement';

const swaggerJSDoc = require("swagger-jsdoc");
const swaggerUi = require("swagger-ui-express");
const envConfig = require("./config").configuration;

const routes = require("./routes");
const app = express();
const authRouter = express.Router();
const partnerRouter = express.Router();
app.disable("x-powered-by");
app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies

app.use((err, req, res, next) => {
	if (err instanceof SyntaxError && err.status === 400 && "body" in err) {
		if (err.type === "entity.parse.failed") {
			return res.status(400).send({ status: 400, message: "Bad Request" });
		}            
	}
	next();
});

let uId, email = "", uniqueId = "", dsn = "", mobile = "", externalId = "", trueClientIp = "", xAppengineUserIp = "", xForwardedFor = "", requestId, host = "";
// Console request name, UID and deviceId
app.use(function (req, res, next) {
	host = _.get(req, "path");
	requestId = uuidv4();
	uId = _.get(req.body, "uid", _.get(req.headers, "uid"));
	email = _.get(req.body, "email", _.get(req.headers, "email", _.get(req.body.data, "email")));
	uniqueId = _.get(req.body, "uniqueId", _.get(req.headers, "uniqueId", _.get(req.body.data, "uniqueId")));
	dsn = _.get(req.body, "dsn", _.get(req.headers, "dsn", _.get(req.body.data, "dsn")));
	mobile = _.get(req.body, "mobile", _.get(req.headers, "mobile", _.get(req.body.data, "mobile")));
	externalId = _.get(req.body, "externalId", _.get(req.headers, "externalId", _.get(req.body.data, "externalId")));
	trueClientIp = _.get(req.headers, "true-client-ip", _.get(req.headers, "True-Client-IP"));
	xAppengineUserIp = _.get(req.headers, "x-appengine-user-ip");
	xForwardedFor = _.get(req.headers, "x-forwarded-for");
	next();
});
(function () {
	const { createLogger, transports } = require("winston");
	//const { prettyPrint,format, errors } = format;
	//LogLevel = { level: 'info' };
	const logger = createLogger({
        
		transports: [
			new transports.Console({
				level: envConfig.logEnable.level,
			}),
		]

	});
  
	if (global.console && console.log) {
		console.log = function () {
			logger.info(this, logFormate(arguments));
		};
	}
	if (global.console && console.warn) {
		console.warn = function () {
			logger.warn(this, logFormate(arguments));
		};
	}
	if (global.console && console.error) {
		console.error = function () {
			logger.error(this, logFormate(arguments));
		};
	}
	if (global.console && console.info) {
		console.info = function () {
			logger.info(this, logFormate(arguments));
		};
	}
	if (global.console && console.debug) {
		console.debug = function () {
			logger.debug(this, logFormate(arguments));
		};
	}
})();

function logFormate(arguments) {
	let RequestDetails="";

	if (uId) {
		RequestDetails+= `Uid: ${uId} ` ;
		//Array.prototype.unshift.call(arguments, `${uId}`);
		// arguments['uId'] = uId;
	}
	if (email) {
		RequestDetails+=`Email: ${email} `;
		//Array.prototype.unshift.call(arguments, `${email}`);
		//arguments['email'] = email;
	}
	if (uniqueId) {
		RequestDetails+=`UniqueId: ${uniqueId} `;
		//Array.prototype.unshift.call(arguments, `${uniqueId}`);
		//arguments['uniqueId'] = uniqueId;
	}
	if (dsn) {
		RequestDetails+=`DSN: ${dsn} `;
		//Array.prototype.unshift.call(arguments, `${dsn}`);
		//arguments['dsn'] = dsn;
	}
	if (mobile) {
		RequestDetails+=`Mobile: ${mobile} `;
		//Array.prototype.unshift.call(arguments, `${mobile}`);
		//arguments['mobile'] = mobile;
	}
	if (externalId) {
		RequestDetails+=`Externald: ${externalId} `;
		// Array.prototype.unshift.call(arguments, `${externalId}`);
		//arguments['externalId'] = externalId;
	}
	if (trueClientIp) {
		RequestDetails+=`TrueClientIp: ${trueClientIp} `;
		//Array.prototype.unshift.call(arguments, `${trueClientIp}`);
		//arguments['trueClientIp'] = trueClientIp;
	}
	if (xAppengineUserIp) {
		RequestDetails+=`xAppengineUserIp: ${xAppengineUserIp} `;
		//Array.prototype.unshift.call(arguments, `${xAppengineUserIp}`);
		//arguments['xAppengineUserIp'] = xAppengineUserIp;
	}
	if (xForwardedFor) {
		RequestDetails+=`xForwardedFor: ${xForwardedFor} `;
		//Array.prototype.unshift.call(arguments, `${xForwardedFor}`);
		//arguments['xForwardedFor'] = xForwardedFor;
	}
	if (host) {
		RequestDetails+=`Path: ${host} `;
		//Array.prototype.unshift.call(arguments, `[${host}]`);
		//arguments['path'] = host;
	}
	if (requestId) {//Array.prototype.unshift.call(arguments, `RequestId: ${requestId}`);
		//RequestDetails+=`RequestId:${requestId} `;
		arguments["requestId"] = requestId;
	}
	// } return arguments;
	arguments["requestDetails"]=RequestDetails;
	return arguments;
}


let swaggerDefinition = require("./config/swaggerAPI.json");
swaggerDefinition.host = envConfig.swaggerHost;
const options = {
	swaggerDefinition,
	apis: ["./v4/login.js"],
};
const swaggerSpec = swaggerJSDoc(options);
app.get("/swagger.json", (req, res) => {
	res.setHeader("Content-Type", "application/json");
	res.send(swaggerSpec);
});


let corsOptions = function (req, callback) {
	const { corsOrigin = [] } = Config;
	const origin = corsOrigin.indexOf(req.header("Origin")) !== -1;
	let options = {};
	if (origin === false) {
		console.log(`CORS error ${req.header("Origin")}`);
		options = (corsOrigin.length==0)?{ origin }:{origin:corsOrigin};
	} else {
		options = { origin, credentials: true, optionsSuccessStatus: 200};
	}
	callback(null, options);
};

app.use(cors(corsOptions));
app.use(function (req, res, next) {
	const { corsOrigin = [] } = Config;
	const origin = corsOrigin.indexOf(req.header("Origin")) !== -1;
	if (origin != false) { 
		console.log(`CORS allow ${req.header("Origin")}`);
		res.setHeader("Access-Control-Allow-Origin", `${req.header("Origin")}`);
		res.setHeader("Access-Control-Allow-Credentials", true);
	}
	next();
});

app.set("trust proxy", 1);

app.use("/v4/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));
app.use("/usersV3/v3/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));
// authRouter.post('/test-form-data', testHandler);
// authRouter.post('/sign-up', signUpHandler); //Voot-Kids
// authRouter.post('/create', signUpHandler); //Voot
// authRouter.post('/login', loginHandler);
// authRouter.post('/update-account', tokenValidator, updateAccountHandler);
// authRouter.get('/loginCode', routes.loginCode);
// authRouter.get('/activate', tokenValidator, routes.activateCode);
// authRouter.get('/verifyCode', routes.verifyCode);
// authRouter.post('/forgot-password', forgotPasswordHandler);
// authRouter.post('/password-change', tokenValidator, changePasswordHandler);
// authRouter.post('/forgotPassword', forgotPassHandler);
// authRouter.post('/resetPassword', forgotPasswordTokenValidator, resetPassHandler);
// authRouter.get('/getAuthKey', tokenValidator, getAuthKey);
// authRouter.get('/profiles-access-token', tokenValidator, getProfileByAccessToken);
// authRouter.get('/refresh-access-token', refreshAccessToken);
// authRouter.get('/get-access-token', tokenValidator, getTokenInfo);
// authRouter.delete('/delete-user', deleteUser);
// authRouter.post('/refresh-ks', tokenValidator, refreshKsHandler);

// // used by tv apps (android and ios)


// authRouter.post('/jioSubscription', jioSubscriptionHandler);
// authRouter.get('/jioEntitlement', tokenValidator, jioEntitlementHandler);
// authRouter.get('/v2ToV3UpgradeAPI', updateAccessToken);
// authRouter.get('/getRemoteConfig', getRemoteConfig);

authRouter.post("/login",  blockUser, routes.login);
authRouter.post("/sign-up", blockUser, routes.signUp);
authRouter.post("/update-account", tokenValidator, routes.updateAccount);
authRouter.post("/check-email", routes.checkEmail);
// used by tv apps (android and ios)
authRouter.get("/loginCode", routes.loginCode);
authRouter.get("/activate", tokenValidator, routes.activateCode);
authRouter.get("/verifyCode", routes.verifyCode);
authRouter.post("/forgot-password", routes.forgotPassword);
authRouter.post("/password-change", tokenValidator, routes.passwordChange);
authRouter.get("/profiles-access-token", tokenValidator, routes.profileAccessToken);
authRouter.get("/refresh-access-token", routes.refreshAccessToken);
authRouter.post("/refresh-ks", tokenValidator, routes.refreshKs);
authRouter.get("/getAuthKey", tokenValidator, routes.authKey);
authRouter.post("/jioSubscription", routes.jioSubscription);
authRouter.get("/jioEntitlement", tokenValidator, routes.jioEntitlement);
authRouter.get("/deltaMigration", routes.deltaMigration);
authRouter.post("/update-profile", tokenValidator, routes.updateProfile);
authRouter.get("/get-profile", tokenValidator, routes.getUserProfile);
authRouter.post("/delete-profile", tokenValidator, routes.deleteProfile);
authRouter.post("/postMigration", routes.postMigration);
authRouter.post("/checkUser", routes.checkUser);
authRouter.post("/resendOtp", routes.resendOtp);//resend OTP
authRouter.post("/verifyOtp", routes.verifyOtp);//verify OTP
authRouter.post("/resetPassword", forgotPasswordTokenValidator, routes.resetPassword);//old
authRouter.post("/changePasswordWithLogin", tokenValidator, routes.changePasswordWithLogin);
authRouter.post("/resetPasswordWithLogin", forgotPasswordTokenValidator, routes.resetPasswordWithLogin);//New reset password which is sending token to frontend for auto login
authRouter.post("/verifyOtpForgotPassword", routes.verifyOtpForgotPassword);
authRouter.post("/appleRedirect", routes.appleRedirect);
authRouter.post("/appleRedirect-app", routes.appleRedirect);
authRouter.get("/getRemoteConfig", routes.remoteConfig);
authRouter.get("/get-access-token", tokenValidator, routes.getAccessToken);
authRouter.get("/getPartnerDetails", routes.partnerDetails);
authRouter.post("/otpRetrive", routes.getOtpDetails);
authRouter.post("/search",searchTokenValidator,routes.searchDetails);//api for searching data of user.
authRouter.post("/checkKalturaAccount", routes.checkKalturaAccountRoute);
authRouter.post("/insertKalturaBuildUser", routes.kalturaBuildRoute);

//internal API for subscription send offer
authRouter.post("/sendMessage", routes.sendMessage);

// AnonymousToken Token api
authRouter.post("/token", apikeyValidator, routes.anonymousTokeRoute.createAndValidateToken);
authRouter.post("/token/verify", apikeyValidator, routes.anonymousTokeRoute.verifyToken);
authRouter.post("/token/refresh", apikeyValidator, routes.anonymousTokeRoute.createAndValidateToken);

// Kids safe mode 
authRouter.post("/auths/tokens", tokenValidator, routes.authsTokensRoute);

//internal purpose 
authRouter.get( "/internal/profiles-access-token", tokenValidator, routes.profileAccessToken );
//internal API for SMS estimates initiated via notifcations microservice
authRouter.post("/internal/smsData", routes.smsData);

//S
authRouter.get( "/device/loginDetail", routes.loginInfoByDeviceId );

//Data sync API
authRouter.post( "/syncData", routes.synchCrmData );

//Mobile Authentication//
authRouter.post("/partner/sign-in", routes.partnerSignIn);
authRouter.post("/partner/notification", partnerTokenValidator, blockPartnerMiddleware.blockPartner, routes.partnerNotification);// Partner APIs


//parent-child functionality
authRouter.post("/create-sub-profile",tokenValidator, routes.createSubProfile);
authRouter.get("/get-sub-profiles",tokenValidator, routes.getSubProfiles);
authRouter.post("/get-sub-profile-access-token",tokenValidator, routes.getSubProfilesAccessToken);
authRouter.post("/delete-sub-profile",tokenValidator, routes.deleteSubProfile);
authRouter.post("/update-sub-profile",tokenValidator, routes.updateSubProfile);

partnerRouter.post(
	"/login",
	RequestValidatorInterceptor.partnerRequestHeaders,
	AuthInterceptor.verifyPartnerToken,
	PreRequestInterceptor.verifyRequestBodyForOnePatner,
	PreRequestInterceptor.verifyIp,
	routes.V_1_5_PartnerLogin,
	PostResponseInterceptor.processOne
);
partnerRouter.post(
	"/tokens/refresh",
	RequestValidatorInterceptor.partnerRequestHeaders,
	AuthInterceptor.verifyPartnerToken,
	PreRequestInterceptor.verifyRequestBodyForOnePatner,
	PreRequestInterceptor.verifyIp,
	routes.V_1_5_PartnerRefreshToken,
	PostResponseInterceptor.processOne
);
partnerRouter.post(
	"/purchases",
	RequestValidatorInterceptor.partnerRequestHeaders,
	AuthInterceptor.verifyPartnerToken,
	PreRequestInterceptor.verifyRequestBodyForOnePatner,
	PreRequestInterceptor.verifyIp,
	routes.V_1_5_PartnerPurchase,
	PostResponseInterceptor.processOne
);
partnerRouter.get(
	"/purchases/status",
	RequestValidatorInterceptor.partnerRequestHeaders,
	AuthInterceptor.verifyPartnerToken,
	PreRequestInterceptor.verifyRequestBodyForOnePatner,
	PreRequestInterceptor.verifyIp,
	routes.V_1_5_PartnerGetStatus,
	PostResponseInterceptor.processOne
);
partnerRouter.put(
	"/purchases/status",
	RequestValidatorInterceptor.partnerRequestHeaders,
	AuthInterceptor.verifyPartnerToken,
	PreRequestInterceptor.verifyRequestBodyForOnePatner,
	PreRequestInterceptor.verifyIp,
	routes.V_1_5_PartnerUpdateStatus,
	PostResponseInterceptor.processOne
);

app.use("/v4", authRouter);

// Version v1.5 partner APIs
app.use("/v1.5/partners", partnerRouter);

app.use("/usersV3/v3", authRouter);//for achamai testing 
// Api to be used for health check.
app.get("/", async (req, res) => {
	res.status(200).send("Auth V4 Server is up...");
});

app.get("*", async (req, res) => {
	res.status(404).send(apiResponse.error("Service not found."));
});

module.exports = app;

const mongoose = require("mongoose");
//Define a schema
const Schema = mongoose.Schema;

const userSchema = new Schema(
	{
		uid: String,
		email: String,
		phoneNumber:String,
		emailVerified: Boolean,
		providerData: [],
		customClaims: Object,
		metadata: Object,
		passwordHash: String,
		passwordSalt: String,
		fbuid: String,
		guid: String,
		appleid:String
	});
module.exports = mongoose.model("usersauths", userSchema);   
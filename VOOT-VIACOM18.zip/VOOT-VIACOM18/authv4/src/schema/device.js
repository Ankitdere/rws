const mongoose = require("mongoose");
//Define a schema
const Schema = mongoose.Schema;

const deviceSchema = new Schema(
	{
		deviceId: String,
		email: String,
		mobile: String,
		password: String,
		brand: String,
		type: String,
		requestIp: String,
	},{ timestamps: true });
module.exports = mongoose.model("devices", deviceSchema);
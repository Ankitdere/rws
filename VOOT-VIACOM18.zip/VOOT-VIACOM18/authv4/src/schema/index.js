"use strict";

const users = require("./users");
const usersProfile = require("./usersProfile");
const deviceActivationCode = require("./deviceActivationCode");
const adminToken = require("./adminToken");
const appleUnverifiedUsers = require("./appleUnverifiedUsers");
const unVerifiedUser =require("./unVerifiedUser");
const ksmuserdevices =require("./userDevices");
const device = require("./device");
const ratelimit = require("./ratelimit");
const deviceIdLoginDetails = require( "./deviceIdLoginDetails" );
const kalturaOldBuild = require("./kalturaBuildUsers");
const smsData = require("./smsData");
const subProfile = require("./subProfile");
const unVerifiedImsUser =require("./unVerifiedImsUser");

module.exports = {
	users,
	usersProfile,
	deviceActivationCode,
	adminToken,
	appleUnverifiedUsers,
	unVerifiedUser,
	ksmuserdevices,
	device,
	ratelimit,
	deviceIdLoginDetails,
	kalturaOldBuild,
	smsData,
	subProfile,
	unVerifiedImsUser
};
const mongoose = require("mongoose");
//Define a schema
const Schema = mongoose.Schema;

const appleUnverifiedUserSchema = new Schema(
	{
		state : String,
		code : String,
		id_token : String,
		firstName :  String,
		lastName :  String,
		email :  String,
		originalUrl: String ,
		uid: String,
		lastLoginDate: String
	});
module.exports = mongoose.model("appleUnverifedUsers", appleUnverifiedUserSchema);   
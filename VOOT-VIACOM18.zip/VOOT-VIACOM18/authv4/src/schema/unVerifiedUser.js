const mongoose = require("mongoose");
//Define a schema
const Schema = mongoose.Schema;

const unVerifiedUserSchema = new Schema(
	{
		email: String,
		profileData: Object,
		_system: Object,
		mobile: String,
		countryCode: String,
		isOtpVerify:Boolean,
		type: String,
		preferences: Object,
		loginStatus: String 

	});
module.exports = mongoose.model("unVerifiedUser", unVerifiedUserSchema);  
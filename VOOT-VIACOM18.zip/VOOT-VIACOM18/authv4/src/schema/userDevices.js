const mongoose = require("mongoose");
//Define a schema
const Schema = mongoose.Schema;

const userDevicesSchema = new Schema(
	{
		uid: String,
		deviceId: String,
		contentRestriction: Number,
		status: String,
		device:String,
		platform:String,
		activationTime: Number,
		createdAt:Number,
		updatedAt: Number
	});
module.exports = mongoose.model("userdevices", userDevicesSchema);  
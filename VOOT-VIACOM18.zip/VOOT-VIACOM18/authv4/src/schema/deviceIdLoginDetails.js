const mongoose = require( "mongoose" );
//Define a schema
const Schema = mongoose.Schema;

const deviceIdLoginDetailsSchema = new Schema(
	{
		"deviceId": { type: String, required: true, index: true },
		"uid": { type: String, required: true, index: true },
		"type": { type: String, required: true },
		"email": String, // It will be there only when type is traditional
		"mobile": String, // It will be there only when type is mobile
		"countryCode": String, // It will be there only when type is mobile
		"deviceBrand": String,
		"platform": String,
		ipAddress: [String],
		status: Number,
		suid: String,// It will be there only when type is social login
		userAgent: String
	}, { timestamps: true } );
module.exports = mongoose.model( "deviceIdlogindetails", deviceIdLoginDetailsSchema );   
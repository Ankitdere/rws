const mongoose = require("mongoose");
//Define a schema
const Schema = mongoose.Schema;

const rateLimitSchema = new Schema(
	{
		requestIp: String,
	});
module.exports = mongoose.model("ratelimits", rateLimitSchema);
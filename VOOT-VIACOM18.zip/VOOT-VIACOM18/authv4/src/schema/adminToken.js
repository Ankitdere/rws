const mongoose = require("mongoose");
//Define a schema
const Schema = mongoose.Schema;

const adminTokenSchema = new Schema(
	{
		adminKsToken: String
	});
module.exports = mongoose.model("admin-ks", adminTokenSchema);   
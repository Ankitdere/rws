const mongoose = require("mongoose");
//Define a schema
const Schema = mongoose.Schema;

const subProfileSchema = new Schema(
	{
		uid: { type: String, index: true },
		childUid: { type: String, index: { unique: true } },
		ProfileName: String,
		BirthDate: String,
		languages : [],
		Gender: String,
		deviceId: String	
	}, { timestamps: true });
module.exports = mongoose.model("subprofiles", subProfileSchema);   

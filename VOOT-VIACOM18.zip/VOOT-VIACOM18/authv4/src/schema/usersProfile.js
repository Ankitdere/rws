const mongoose = require("mongoose");
//Define a schema
const Schema = mongoose.Schema;

const usersProfileSchema = new Schema(
	{
		email: String,
		mobile: String,
		profileData: Object,
		status:String,
		_system: Object,
		uid: String,
		lastLoginCount:Number,
		lastLoginDate:String,
		tempEmail:String,
		partnerType:String,
		externalId:String,
		deviceId:String,
		uniqueId:String,
		isActive:Boolean,
		subscription: Object,
		kUserId:String,
		updatedAt:Number,
		createdAt:Number,
		renewedAt:Number,
		cancelledAt:Number,
		entitlementStatus:String,
		kidSafeMode:Object,
		parentPinMode:Object,
		loginStatus:String,
		state:String,
		loginAttempt: Number,
		region: { type: String, index: true },
		country:{ type: String, index: true }
		
	});
module.exports = mongoose.model("userprofiles_v1", usersProfileSchema);   
const mongoose = require("mongoose");

const definition = {
	email: String,
	profileData: Object,
	_system: Object,
	mobile: String,
	countryCode: String,
	isOtpVerify:Boolean,
	type: String,
	preferences: Object,
	loginStatus: String 
};

const schema = new mongoose.Schema(definition);
const model = mongoose.model("unVerifiedImsUser", schema);

module.exports = model;

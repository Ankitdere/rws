const mongoose = require("mongoose");
//Define a schema
const Schema = mongoose.Schema;

const deviceActivationCodes = new Schema(
	{
		deviceBrand: String,
		deviceId: String,
		expiresAt: Number,
		code: String,
		accessToken: String
	});
module.exports = mongoose.model("device-activation-codes", deviceActivationCodes);   
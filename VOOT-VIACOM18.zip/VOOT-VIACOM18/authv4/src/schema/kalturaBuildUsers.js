const mongoose = require("mongoose");
//Define a schema
const Schema = mongoose.Schema;

const kalturaOldBuildUserSchema = new Schema(
	{
		uid: { type: String, index: { unique: true } },
		email: { type: String, index: { unique: true } },
		kalturaBuildNo: String,
		platform: String

	});
module.exports = mongoose.model("user_kalturabuilds", kalturaOldBuildUserSchema);
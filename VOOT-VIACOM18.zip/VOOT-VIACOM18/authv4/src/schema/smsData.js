const mongoose = require("mongoose");

const options = {
	timestamps: {
		createdAt: "createdDate",
	},
};
const definition = {
	vendor: {
		type: String,
		required: true,
		enum: ["SNS", "KARIX", "KARIXOTP"],
	},
	sentDate: {
		type: Date,
		required: true,
	},
	type: {
		type: String,
		required: true,
	},
	templateId: {
		type: String,
		required: true,
	},
	successCount: {
		type: Number,
		required: true,
	},
	failedCount: {
		type: Number,
		required: true,
	},
};

const schema = new mongoose.Schema(definition, options);
const model = mongoose.model("smsdata", schema);

module.exports = model;

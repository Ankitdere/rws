const deviceIdLoginDetails = require( "../schema" ).deviceIdLoginDetails;
const _ = require( "underscore" );
const commonUtil = require( "../utils" ).common;
const constant=require("../utils/constant/generic");

module.exports = { getDataFromDeviceIdLoginDetails, initDeviceIdLoginDetails, updateOneDeviceIdLoginDetails };

/**
 * 
 * @param {*} query query object.
 * @param {*} requestedData obejct contain the field required.
 * @param {*} sortObejct object to sort
 * @param {*} limit limit
 * @returns 
 */
async function getDataFromDeviceIdLoginDetails ( query, requestedData, sortObject,limit ) {
	try {
		const data = await deviceIdLoginDetails.find( query, requestedData ).sort(sortObject).limit(limit);
		if ( _.isEmpty( data ) ) throw { status: 1701, message: "Record does not exits" };
		return data;
	}
	catch ( err ) {
		throw { status: 1701, message: "Record does not exits" };
	}
}
async function updateOneDeviceIdLoginDetails ( query, data, flagObject ) {
	try {

		const dataRecord = await deviceIdLoginDetails.updateOne( query, data, flagObject );
		if ( _.isEmpty( dataRecord ) ) throw { status: 1701, message: "Record does not exits" };
		return data;
	}
	catch ( err ) {
		throw { status: 1701, message: "Record does not exits" };
	}
}
/**
 * Function to get the init object for deviceIdLoginDetails.
 * @param {Object} requestBody {Object} request body.
 * @param {Object} userProfileData {Object} userprofile record.
 * @param {String} email {String} email of the user.
 * @param {String} mobile {String} mobile number of the user.
 * @param {String} countryCode {String} countryCode of the user
 * @param {int} status {int} 0 or 1(value from constant.DeviceIdLoginDetailsStatus).
 * @param {Object} usersAuthsData {Object} usersauths record.
 * @param {Object} extraPrams {Object} extraPrams.
 * @returns Object
 */
async function initDeviceIdLoginDetails ( requestBody, userProfileData, email, mobile, countryCode, status=1, usersAuthsData, extraPrams={} ) {
	requestBody = JSON.parse( JSON.stringify( requestBody ) );
	userProfileData = JSON.parse( JSON.stringify( userProfileData ) );
	const data = {
		type: _.get( requestBody, "type" ),
		deviceId: _.get( requestBody, "deviceId" ),
		deviceBrand: _.get( requestBody, "deviceBrand", "" ),
		status:status
	};
	if ( requestBody && requestBody.data && requestBody.data.email ) data.email = _.get( requestBody, "data.email", undefined );
	if ( requestBody && requestBody.data && requestBody.data.mobile ) data.mobile = _.get( requestBody, "data.mobile", undefined );
	if ( requestBody && requestBody.data && requestBody.data.countryCode ) data.countryCode = _.get( requestBody, "data.countryCode", undefined );
	if ( !data.email && !data.mobile && mobile ) data.mobile = mobile;
	if ( !data.email && data.mobile && countryCode ) data.countryCode = countryCode;
	if ( !data.mobile && !data.email && userProfileData.mobile && ( userProfileData.mobile.indexOf( "+" ) >= 0 ) ) {
		if ( userProfileData.mobile.indexOf( "+" ) >= 0 ) {
			const { Mobile, CountryCode } = await commonUtil.splitMobileWithCountryCode( userProfileData.mobile );
			data.mobile = Mobile;
			data.countryCode = CountryCode;
		}
	}
	data.uid = _.get( userProfileData, "uid", _.get( userProfileData, "uId" ) );
	if(!data.uid && userProfileData && userProfileData.profileData){
		data.uid = _.get( userProfileData.profileData, "uid", _.get( userProfileData.profileData, "uId" ) );
	}
	if(constant.USER_LOGIN_TYPES.mobile!=data.type && !data.mobile){
		data["$unset"]={mobile:1, countryCode:1};
	}

	if ( !data.email && !data.email && !data.countryCode ) data.email = _.get( userProfileData, "email" );
	if (usersAuthsData.guid) data.suid=usersAuthsData.guid;
	if (usersAuthsData.fbuid) data.suid=usersAuthsData.fbuid;
	if (usersAuthsData.appleid) data.suid=usersAuthsData.appleid;
	if (extraPrams.platform) data.platform= extraPrams.platform;
	if (extraPrams.userAgent) data.userAgent= extraPrams.userAgent;
	return data;
}


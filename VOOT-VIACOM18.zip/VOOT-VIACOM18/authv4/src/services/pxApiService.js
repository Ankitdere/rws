"use strict";

const _ = require("lodash");
const rp = require("request-promise");
// const envConfig = require("../config").envConfig;
const config = require("../config").configuration;
const axios = require("axios");
const userProfile=require("./usersProfile");
const mixpanelService=require("./mixpanelService");
const mixpanelConfig=require("../config/mixPanelConfig");
module.exports = {
	callPX,
	callRenewCancelPxApi,
	checkEntitlementStatus,
	pxOptions,
	updateEntitlementStatus,
	checkSubscription
    

};

async function callPX(input, userData, partnerDetails, accesstoken, PXAction) {
	try {
		console.log("================call px Api ================");
		console.log("User data subscription", userData);
		console.log("User data subscription", partnerDetails);
		console.log("accesstoken", accesstoken);
		let startTime;
		let endTime;
		if (userData.subscription && userData.subscription.activationDate)
			startTime = Math.round(new Date(userData.subscription.activationDate).getTime() / 1000);
		console.log("Start Date ", startTime);
		if (userData.subscription && userData.subscription.endDate)
			endTime = Math.round(new Date(userData.subscription.endDate).getTime() / 1000);
		console.log("End Date ", endTime);
		// call cancel Api if end time is expire

		let currentTimeStamp = Math.round(new Date().getTime() / 1000);
		console.log("Current time Stamp", currentTimeStamp);

		const pxOption = await pxOptions(accesstoken, "POST", {
			details: {
				device: {
					brand: _.get(input, "deviceBrand", config.tSkyDetails.deviceBrand),
					id: _.get(input, "deviceId", userData.deviceId),
				},
				platform: partnerDetails.platform,
				subStartDate: startTime,
				subEndDate: endTime,
				partnerName: partnerDetails.partnerName
			}
		});
		if (PXAction == config.pXApiDetails.newSubcriptionAction) {
			const pxApiResponse = await rp(pxOption);
			console.log("PxApiResponse", pxApiResponse);
			await callMixPanelEventServiceForPx(input,userData,userData.uid,pxApiResponse,mixpanelConfig.partnerOrderPost);
			await updateEntitlementStatus(accesstoken,userData);
			return pxApiResponse;
		}
		else if (PXAction == config.pXApiDetails.renewSubcriptionAction) {
			const renewresponse = await callRenewCancelPxApi(userData.uid, accesstoken, endTime, config.pXApiDetails.renewSubcriptionAction,mixpanelConfig.partnerOrderPut,input);
			console.log("PxApiResponse for renewal", renewresponse);
			await callMixPanelEventServiceForPx(input,userData,userData.uid,renewresponse,mixpanelConfig.partnerOrderPut);
			await updateEntitlementStatus(accesstoken,userData);
			return renewresponse;
		}
		else if (PXAction == config.pXApiDetails.cancelSubcriptionAction) {
			const cancelresponse = await callRenewCancelPxApi(userData.uid, accesstoken, endTime, config.pXApiDetails.cancelSubcriptionAction,input);
			await callMixPanelEventServiceForPx(input,userData,userData.uid,cancelresponse,mixpanelConfig.partnerOrderPut);
			console.log("PxApiResponse for renewal", cancelresponse);
			await updateEntitlementStatus(accesstoken,userData);
			return cancelresponse;
		}
	} catch (error) {
		console.error("PXApi calling Error: ", error);
		mixpanelService(mixpanelConfig.pxCallError+_.get(input, "partnerType",_.get(input, "partnerName" ),
			{distinct_id: _.get(userData,"uid"),UID: _.get(userData,"uid"),uniqueId: _.get(input.data,"uniqueId",_.get(userData,"uniqueId")),error},
			_.get(input.data,"uniqueId"),null,null,false));
		await updateEntitlementStatus(accesstoken,userData);
		return error;
	}
}
function pxOptions(accesstoken, method, payload) {
	let options = {
		url: `https://${config.pXApiDetails.host}/${config.pXApiDetails.partnerOrderSrvice}`,
		method: method,
		headers: {
			"accesstoken": accesstoken,
			"Content-Type": "application/json"
		},
		body: payload,
		json: true
	};
	return options;
}

async function  callRenewCancelPxApi(uid, accesstoken, subEndDate, action ,input="") {
	//action must be 'renew' or 'cancel'
	let pxApiResponse;
	try {
		const options = pxOptions(accesstoken, "PUT", {
			userId: uid,
			subEndDate: subEndDate,
			action: action
		});
		pxApiResponse = await rp(options);
       
		console.log("calling renew/cancelPxAPI", pxApiResponse);
		return pxApiResponse;
	} catch (error) {
		mixpanelService(mixpanelConfig.pxCall + "PartnerOrderPut" + _.get(input, "partnerType", _.get(input, "partnerName")),
			{ distinct_id:_.get(input.data,"uniqueId",_.get(input.data,"externalId",uid)), UID: uid, uniqueId: _.get(input.data, "uniqueId"),pxApiResponse },
			_.get(input.data,"uniqueId",_.get(input.data,"externalId")),
			uid,
			null, 
			false);
		console.log("calling renew/cancelPxAPI error", error);
	}
}
async function _getHeaders(accesstoken) {
	return {
		"Content-Type": "application/json",
		"accesstoken": accesstoken,
	};
}
async function checkEntitlementStatus(accessToken){
	try {
		const headers =await _getHeaders(accessToken);   
		const pxApiResponse = await axios.get(`https://${config.pXApiDetails.host}/${config.pXApiDetails.userEntilementStatus}`,  { headers: headers });
		console.log("checkEntilement Status", pxApiResponse.data);
		return pxApiResponse.data;
	} catch (error) {
		console.error("checkEntilement Status error", error);
		mixpanelService(mixpanelConfig.pxCall+mixpanelConfig.checkEntitlement+mixpanelConfig.error,
			accessToken
			,error,null,null,false);
	}
}

async function updateEntitlementStatus(accesstoken,userData) {
	try {
		let status = await checkEntitlementStatus(accesstoken);
		let isActive;
		mixpanelService(mixpanelConfig.pxCall+mixpanelConfig.checkEntitlement+mixpanelConfig.success,
			status
			,_.get(userData,"uniqueId",userData.uid),null,null,false);
		if (_.get(status, "status", _.get(status[0], "status"))) {
			let entitlementStatus = _.get(status, "status", _.get(status[0], "status"));
			console.debug("EntitlementStatus", entitlementStatus);
			if (entitlementStatus == "active") { isActive = true; }
			if (entitlementStatus == "new" || entitlementStatus == "expired") { isActive = false; }
			await userProfile.updateUserInformation({ "uid": userData.uid }, { "entitlementStatus": _.get(status, "status", _.get(status[0], "status")), "isActive": isActive });
		} else {
			console.log("We are not able to get Subsciption Node");
		}
	} catch (err) {
		console.log("Error Occured While updating",err);
	}

}

async function callMixPanelEventServiceForPx(input, userData, uid, response,eventType) {
	try {
		let eventName;
		console.log("Response of PX", response);
		if (response.result.errno == 1048 || _.get(response.error, "id") == "V500" || _.get(response.error, "id") == "NS400" || _.get(response.error, "id") == "V502") {
			eventName = mixpanelConfig.pxCallError + eventType + _.get(input, "partnerType", _.get(input, "partnerName"));
		}
		else if (response.result) {
			eventName = mixpanelConfig.pxCallSuccess + eventType + _.get(input, "partnerType", _.get(input, "partnerName"));
		} else {
			eventName = mixpanelConfig.pxCall + eventType + _.get(input, "partnerType", _.get(input, "partnerName"));
		}
		let distinct_id = _.get(input.data, "uniqueId",_.get(input.data,"externalId",_.get(input.data,"dsn",_.get(userData,"uniqueId"))));
		mixpanelService(eventName,
			{ distinct_id:distinct_id, UID: _.get(userData, "uid", uid), uniqueId: _.get(input.data, "uniqueId", _.get(userData, "uniqueId"), response) },
			distinct_id,
			_.get(userData, "uid",uid), 
			null, 
			false);
		return true;
	} catch (e) {
		console.log("Error in triggering Mixpanel Service", e);
	}
}

async function checkSubscription(accesstoken, userData) {
	try {
		let status = await checkEntitlementStatus(accesstoken);
		let isActive;
		mixpanelService(mixpanelConfig.pxCall + mixpanelConfig.checkEntitlement + mixpanelConfig.success,
			status
			, _.get(userData, "uniqueId", userData.uid), null, null, false);
		if (_.get(status, "status", _.get(status[0], "status"))) {
			let entitlementStatus = _.get(status, "status", _.get(status[0], "status"));
			console.debug("EntitlementStatus", entitlementStatus);
			if (entitlementStatus == "active") { isActive = true; }
			if (entitlementStatus == "new" || entitlementStatus == "expired") { isActive = false; }
			return ({ "currentEntitlementStatus": entitlementStatus, "isActive": isActive });
		} else {
			console.log("We are not able to get Subsciption Node");
		}
	} catch (err) {
		console.log("Error Occured While updating", err);
		return ({ "currentEntitlementStatus": "new", "isActive": false });

	}

}
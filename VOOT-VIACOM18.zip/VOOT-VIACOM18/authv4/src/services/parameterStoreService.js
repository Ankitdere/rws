const { parameterStoreConnection } = require("../config/AWSConnection");
const basicConfig = require("../config/basicConfig");
module.exports={ getAllParameterStoreValues,getParameterStoreValue};
async function getAllParameterStoreValues() {
	try {
		let completeResult = [];
		let nameList = basicConfig.nameOFSSM;
		let limit = 10;
		let iteration = Math.ceil(basicConfig.nameOFSSM.length / 10);  
		for (let i = 0; i < iteration; i++){
			const options = {
				Names: nameList.splice(0, limit), // required /
				WithDecryption: true,
			};
			const result = await parameterStoreConnection.getParameters(options).promise();
			completeResult=completeResult.concat(result.Parameters);
		}
		return completeResult;
	}
	catch (err) {
		console.log(err);
		throw err;
	}
}
async function getParameterStoreValue(key) {
	try {
		const options = {
			Name: `${key}`, // required /
			WithDecryption: true,
		};
		const result = await parameterStoreConnection.getParameter(options).promise();
		return result.Parameter;
	}
	catch (err) {
		console.log(err);
		throw err;
	}
}
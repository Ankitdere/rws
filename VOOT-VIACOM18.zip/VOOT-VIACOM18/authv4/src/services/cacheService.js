const cache = require("../config/cacheConnection");
cache.on("expired", async function (key) {
	try {
		console.log("expired",key);
		const cacheBusiness = require("../business/cacheBusiness");
		await cacheBusiness.settingCache(key);
	}
	catch (err) {
		console.log("error while getting value from ssm for ",key,"  error is",err);
	}
});

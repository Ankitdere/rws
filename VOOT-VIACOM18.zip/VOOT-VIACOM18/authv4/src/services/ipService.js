"use strict";

const requestIp = require("request-ip");
const iplocation = require("geoip-lite");
const _ = require("lodash");
const userProfileService = require("./usersProfile");

/**
 * Function for getting region & country from request IP
 * @param {Object} request 
 * @returns { region: String, country: String}
 */
async function getRegionFromIpAddress(request) { 
	try {
		let region = "NA", country= "NA";
		const ipAddress = requestIp.getClientIp(request);
		region = country= _.get(iplocation.lookup(ipAddress), "country", "NA");
		return { "region": region, "country": country};
	} catch (error) { 
		console.error("Error in getRegionFromIpAddress/Catch block ", error);
		return { region: "NA", country: "NA" };
	}
	
}
/**
 * Function to fetch region and Country details from headers
 * @param {Object} request 
 * @returns 
 */
async function getCountryAndRegionDetails(request) {
	let result = {
		region: "NA",
		country:"NA"
	};
	try {
		console.info(`getCountryAndRegionDetails is being called for request parameter ${request.headers}`);
		let clientRegion = request.header("client-region");
		if (
			!_.has(request.headers, "client-region")
			|| _.isEmpty(clientRegion)
			|| clientRegion === undefined
			|| clientRegion === null
			|| !clientRegion.includes("Country")
			|| !clientRegion.includes("Region")
		){
			result = await getRegionFromIpAddress(request);
		} else {
			result = await fetchHeaderInfo(clientRegion);
		}
		return result;

	} catch (error) {
		console.error(`Error in addRegionFromAkamai/Catch block: ${error}`);
		return result;
	}
}

/**
 * Function to store region and country into userProfile collection
 * @param {Object} user 
 * @param {Object} regionInfo 
 */
async function updateRegionAndCountryCode(user, regionInfo) {
	let response = {
		isDataUpdate :false,
		updateData :{}
	};
	try {
		const region = _.get(regionInfo,"region","NA");
		const countryCode = _.get(regionInfo,"country","NA");
		if ( (user.region !== region) || (user.country !== countryCode) ) {
			const query = { "uid": _.get(user, "uid",_.get(user,"uId")) };
			const updateQuery = { "region": region, "country": countryCode };
			const updatedData = await userProfileService.updateUserInformation(query, updateQuery);
			if (_.get(updatedData, "status") === 1703) {
				return response;
			} 
			response.isDataUpdate = true;
			response.updateData = updatedData;
		} 
		return response;
	} catch (err) { 
		console.error(`Error in updateRegionAndCountryCode/Catch block ${err}`);
		return response;
	}
}

/**
 * Function for spiliting a String:
 * @param {String} clientRegion 
 */
async function fetchHeaderInfo(clientRegion) { 
	try {
		const segments = clientRegion.split(";");
		const response = {};
		for (let index = 0; index < segments.length; index++) {
			const [key,value] = segments[index].split(":");
			response[key.trim().toLowerCase()] = value.trim();
		}
		return response;
	} catch (error) { 
		console.error("Error in Catch block/prepareSplitData", error);
		throw error;
	}
	
}
module.exports = {
	getCountryAndRegionDetails,
	updateRegionAndCountryCode
};
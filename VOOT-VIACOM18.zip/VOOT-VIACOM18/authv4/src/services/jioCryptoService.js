
const crypto = require("crypto");
const envConfig = require("../config").configuration;
module.exports = {
	decrypt
};
function getAlgorithm(keyBase64) {
	const key = Buffer.from(keyBase64, "base64");
	console.log("Key Length :::: ", key.length);
	switch (key.length) {
	case 16:
		return "aes-128-cbc";
	case 32:
		return "aes-256-cbc";
	}
	throw new Error("Invalid key length: " + key.length);
}

async function decrypt(messagebase64, ssoToken) {
	// JIO API- Upgradation V3API-218
	// const secertKey = (ssoToken.split('.')[2]).substring(0, 8);
	// Revert Security changes 
	const secertKey  = ssoToken.substring(0, 8);//Need Confirmation from JIO Team
	const keyBase64 = Buffer.from(envConfig.jioSubscription.secertKey + secertKey).toString("base64");
	const key = Buffer.from(keyBase64, "base64");
	const iv = Buffer.from(keyBase64, "base64");
	const decipher = await crypto.createDecipheriv(getAlgorithm(keyBase64), key, iv);
	let decrypted = await decipher.update(messagebase64, "base64");
	decrypted += decipher.final();
	return decrypted;
}

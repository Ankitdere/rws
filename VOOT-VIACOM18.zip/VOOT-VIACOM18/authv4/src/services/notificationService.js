const { v4: uuidv4 } = require("uuid");
const _ = require("lodash");
const constant = require("../utils/constant/generic");
async function getfinalNotificationObj(userProfileData, requestBody) {
	const notificationObj = {
		type: "create",
		product: "select",
		data: {
			partnerCode: _.get(requestBody,"partnerType",_.get(requestBody,"partnerName","yupptv")),
			referenceId: uuidv4().substr(0, 20),
			partnerReferenceId: (requestBody.partnerReferenceId)?requestBody.partnerReferenceId:"",
			uniqueId: userProfileData.uniqueId || userProfileData.externalId,
			deviceId: userProfileData.deviceId,
			status: "success",
			processingStatus: "processed",
			product: "select",
			stage: {
				validation: {
					status: "success",
					retries: [],
					success: {
						message: "Validation Successful",
						code: "200",
						subCode: "",
						data: "",
					},
				},
				auth: {
					status: "success",
					retries: [],
					success: {
						message: "Auth Successful",
						code: "200",
					},
				},
				subscription: {
					status: "success",
					retries: [],
					success: {
						message: "Subscription Successful",
						code: "200",
						subCode:
							"1 (in case if user already has an existing subscription) | empty",

					},
				},
				entitlement: {
					status: "success",
					retries: [],
					success: {
						message: "Entitlement Successful",
						code: "200",
					},
				},
			},
			notification: requestBody,
		},
	};
	return notificationObj;
}
async function getInitialNotificationObj(requestBody,status="success",processingStatus="processed") {
	const notificationObj = {
		type: "create",
		product: "select",
		data: {
			partnerCode: _.get(requestBody,"partnerType",_.get(requestBody,"partnerName","yupptv")),
			referenceId: uuidv4().substr(0, 20),
			partnerReferenceId: (requestBody.partnerReferenceId)?requestBody.partnerReferenceId:"",
			uniqueId: _.get(requestBody, "uniqueId", _.get(requestBody.data, "uniqueId", _.get(requestBody.data, "externalId", ""))),
			deviceId: _.get(requestBody,"deviceId",_.get(requestBody.data,"deviceId","")),
			status: status,
			processingStatus: processingStatus,
			product: "select",
			stage: {
			},
			notification: requestBody,
		},
	};
	return notificationObj;
}
async function updateNotificationStage(notificationObj, isSuccess, stageName, data = null, status = "success") {
	notificationObj = JSON.parse(JSON.stringify(notificationObj));
	notificationObj.data.status = (isSuccess) ? "success" : "error";
	let success = {};
	let error = {};
	let message = `${ stageName } ${ (isSuccess) ? "SuccessFul" : "Error" }`;
	const validationObj = {
		status:(status!="success")?status: (isSuccess) ? "success" : "error",
		retries: [],
	};

	if (isSuccess) {
		success = { message: message, code: "200", subCode: "", data: data };
		validationObj.success = success;
	}
	else {
		error = { message: message, code: "400", subCode: "", data: data };
		validationObj.error = error;
	}
	notificationObj.data.stage[stageName] = validationObj;
	notificationObj = await removeEmpty(notificationObj);
	return notificationObj;
}
async function updateBasicInfo(notificationObj, userProfileData) {
	notificationObj = JSON.parse(JSON.stringify(notificationObj));
	notificationObj.data.partnerCode = userProfileData.partnerType;
	notificationObj.data.uniqueId = userProfileData.uniqueId || userProfileData.externalId;
	notificationObj.data.deviceId = userProfileData.deviceId;
	return notificationObj;
}
async function updateReconInfo(notificationObj, Data) {
	notificationObj = JSON.parse(JSON.stringify(notificationObj));
	notificationObj.initialAction = Data.initialAction;
	notificationObj.currentAction=  Data.currentAction;
	return notificationObj;
}
//for auth notifications
async function reconIntitialNotificationObj(requestBody, metaData) {
	const notificationObj = {
		initialAction: "all",
		currentAction: "all",
		metaData: {
			function: metaData.function,
			error: metaData.error
		},
		data: {
			email: _.get(requestBody, "email",_.get(requestBody.data,"email",`+91${ _.get(requestBody, "mobile",_.get(requestBody.data,"mobile",""))}@voot.com`)),
			mobile:  _.get(requestBody, "mobile",_.get(requestBody.data,"mobile","")),
			status: "success",
			processingStatus: "yet_to_start",
			product: "select",
			stage: {
			},
			notification: requestBody,
		}
	};
	console.log("notification object from inside", notificationObj);
	return notificationObj;
}
async function reconfinalNotificationObj(userProfileData, requestBody, reconObject) {
	const notificationObj = {
		type: "auth_create",
		product: "select",
		initialAction: _.get(reconObject, "initialAction", "all"),
		currentAction: _.get(reconObject, "currentAction", "all"),
		metaData: {
			function: _.get(reconObject, "function"),
			error: _.get(reconObject, "error") ? _.get(reconObject, "error") : {}
		},
		data: {
			uid: _.get(userProfileData, "uid"),
			email: _.get(userProfileData, "email"),
			status: "success",
			processingStatus: "processed",
			product: "select",

			stage: {
				validation: {
					status: "success",
					retries: [],
					success: {
						message: "Validation Successful",
						code: "200",
						subCode: "",
						data: "",
					},
				},
				sync: {
					status: "success",
					retries: [],
					success: {
						message: "Sync Successful",
						code: "200",
						subCode: "",
						data: ""
					}
				},
				kaltura: {
					status: "success",
					retries: [],
					success: {
						message: "Kaltura Successful",
						code: "200"
					}
				},
				subscription: {
					status: "success",
					retries: [],
					success: {
						message: "Subscription Successful",
						code: "200",
						subCode: ""
					}
				},
				entitlement: {
					status: "success",
					retries: [],
					success: {
						message: "Entitlement Successful",
						code: "200"
					}
				}
			}
		}
	};
	return notificationObj;
}
async function createMetaDataForRecon(functionName, error = {}) {
	let metaData = {};
	metaData.function = functionName;
	metaData.error = error;
	return metaData;
}

async function createNotificationObject(type,partnerName,requestObject,plancode=""){
	try {
		//conversion
		if (requestObject.data.startDate && requestObject.data.endDate) {
			let startDate = requestObject.data.startDate.split("-");
			let endDate = requestObject.data.endDate.split("-");
			requestObject.data.startDate = new Date(Date.UTC(+startDate[2], startDate[1] - 1, +startDate[0]));
			requestObject.data.endDate = new Date(Date.UTC(+endDate[2], endDate[1] - 1, +endDate[0]));
			requestObject.data.startDate = requestObject.data.startDate.getTime()/1000;
			requestObject.data.endDate = requestObject.data.endDate.getTime()/1000;
			console.log("startDate", requestObject.data.startDate);
			console.log("endDate", requestObject.data.endDate);
		}
		let notificationObj = {
			type: type,
			subType: _.toLower(_.get(requestObject,"action")=="Register"?"":_.get(requestObject,"action")),
			product: "select",
			partner: {
				code: partnerName
			},
		

			referenceId: uuidv4().substr(0, 20),
			device: {
				id: _.get(requestObject.data,"deviceId",""),
				brand: _.get(requestObject.data,"deviceBrand",""),
				dsn:_.get(requestObject.data,"dsn",""),
				type:_.get(requestObject.data,"deviceType","")
			},
			user:{
				uniqueId: _.get(requestObject.data,"uniqueId",""),
				mobile: _.get(requestObject.data,"mobile",""),
				password: _.get(requestObject.data,"password",""),
				externalId:_.get(requestObject.data,"externalId","")
			},
			subscription: {
				planCode: plancode,
				startDate:_.get(requestObject.data,"startDate",""),
				endDate:_.get(requestObject.data,"endDate",""),
				source:_.get(requestObject.data,"source",""),
				transactionId:_.get(requestObject.data,"transactionId","")
			},
			user_meta:{}		  
		};
		if (!_.isEmpty(requestObject.data.activationType)) {
			notificationObj.user_meta.state = _.get(requestObject.data,"activationType");
		}
		if(_.isEmpty(notificationObj.user_meta)){
			_.unset(notificationObj,"user_meta");
		}
		console.log("Before notification",notificationObj);
		notificationObj=await removeEmpty(notificationObj);
		console.log("After notification",notificationObj); 
		return notificationObj;
	}catch(e){
		console.log("My error Stack",e,e.stack);
	}
}
async function createNotificationObjectForYuppTV(type,partnerName,requestObject){
	try {
		console.debug("body-----".requestObject);
		let notificationObj = {
			type: type,
			subType: _.toLower(_.get(requestObject.subscription, "status","")),
			product: "select",
			partner: {
				code: partnerName
			},
			referenceId: uuidv4().substr(0, 20),
			device: {
				id: _.get(requestObject.device, "id", "")
			},
			user: {
				uniqueId: _.get(requestObject.user, "uniqueId", ""),
				mobile: _.get(requestObject.user, "mobile", "")

			},
			subscription: {
				planCode: _.get(requestObject.subscription, "planCode", ""),
			}
		};
		console.log("Before notification", notificationObj);
		notificationObj = await removeEmpty(notificationObj);
		console.log("After notification", notificationObj);
		return notificationObj;
	} catch (e) {
		console.log("My error Stack", e, e.stack);
	}
}

async function removeEmpty(notificationObj) {	
	// eslint-disable-next-line no-undef
	return new Promise((resolve) => {
	
		Object.keys(notificationObj).forEach(function (key) {
			(notificationObj[key] && typeof notificationObj[key] === "object") && removeEmpty(notificationObj[key]) ||
				(notificationObj[key] === "" || notificationObj[key] === null) && delete notificationObj[key];
		});
		resolve(notificationObj);
	});
}

/**
 * function for preparing a notification object 
 * @param {Object} user 
 * @param {Object} regionInfo 
 * @param {Object} payload 
 * @returns 
 */
async function createRegionNotification(user, regionInfo) { 
	let notificationObj = {};
	try {
		notificationObj = {
			application: {
				code: constant.NOTIFICATION.CODE
			},
			action: constant.NOTIFICATION.ACTION.UPDATEREGION,
			performedBy: _.get(user, "uid", _.get(user, "uId")),
			filter: {
				uid: _.get(user, "uid", _.get(user, "uId"))
			},
			updateFilter: {
				region: _.get(regionInfo,"region","NA"),
				country:_.get(regionInfo,"country","NA")
			}
		};
		return notificationObj;
	} catch (error) { 
		console.error("Error in createRegionNotification/Catch Block", error);
		notificationObj = {};
		return notificationObj;
	}
	
}


module.exports = { getfinalNotificationObj, getInitialNotificationObj, updateNotificationStage, updateBasicInfo, reconIntitialNotificationObj, reconfinalNotificationObj, createMetaDataForRecon, updateReconInfo, createNotificationObject, createNotificationObjectForYuppTV,createRegionNotification };


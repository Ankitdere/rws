
"use strict";
const { redis_client } = require("../config/redisConnection");
const Configuration = require("../config").configuration;

const { IS_LOCAL: isLocal } = process.env.IS_LOCAL === "true";

module.exports = {
	saveUserIntoRedis,
	delUserIntoRedis,
	setifnotExistUserIntoRedis,
	getAlreadyRegisteredUser
};

/**
 * @param {String} uid 
 * @param {Number} timestamp 
 * @returns {String}
 */
async function saveUserIntoRedis(uid, timestamp) {
	if (isLocal) return "No redis in local instance";
	const ttl = 2.592e+9;//30days into milli seconds
	const key = `${Configuration.redis.redisEnv}:${uid}`;
	const { redisEnable: isEnabled } = Configuration.redis;
	return isEnabled == true ? redis_client.setex(key, ttl, timestamp) : "Please enable Redis";
}

/**
 * @param {String} uid 
 */
async function delUserIntoRedis(uid) {
	if (isLocal) return;
	redis_client.del(uid);
}

/**
 * @param {String} uid 
 * @param {Number} timestamp 
 */
async function setifnotExistUserIntoRedis(uid, timestamp) {
	if (isLocal) return;
	redis_client.setnx(uid, timestamp);
}

/**
 * @param {String} uid 
 * @param {Number} iatOfToken 
 * @returns {Boolean}
 */
async function getAlreadyRegisteredUser(uid, iatOfToken) {
	console.debug("getAlreadyRegisteredUser from Redis:", uid);
	if (isLocal) return false;
	
	//check if redis is disable.
	if (Configuration.redis.redisEnable !== true) {
		console.log("Please Enable the Redis Configuration");
		return false;
	}

	const key = `${Configuration.redis.redisEnv}:${uid}`;
	// eslint-disable-next-line no-undef
	return new Promise((resolve, reject) => {
		redis_client.get(key, function (err, redisResetPasswordTime) {
			if (err) {
				console.log(err);
				reject(false);
			}
			if (redisResetPasswordTime) {
				if (redisResetPasswordTime > iatOfToken) {
					resolve(true);
				} else {
					resolve(false);
				}
			} else {
				console.log("user not found in redis", key);
				resolve(false);
			}
		});
	});
}

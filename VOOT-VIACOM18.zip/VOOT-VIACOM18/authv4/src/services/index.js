"use strict";

const userService = require("./users");
const tokenService = require("./tokenService");
const userProfileService = require("./usersProfile");
const deviceActivationCode = require("./deviceActivationCode");
const kalturaService = require("./kalturaService");
const jioCryptoService = require("./jioCryptoService");
const jioSubscriptionService = require("./jioSubscriptionService");
const mailService = require("./mailService");
const otpService =require("./otpService");
const redisService=require("./redisService");
const appleService=require("./appleService");
const unverifiedUser =require("./unverifiedUser");
const sqsService = require("./sqsService");
const pxApiService = require("./pxApiService");
const { jioUserDetails,checkSSOAndJioSub } = require("./jioSTBService");
const { tataSkyNotification, tSkyUserDetails,getTskyCollectionDetails } = require("./tSKyService");
const anonymousTokenService = require("./AnonymousTokenService");
const SettingCache = require("./cacheService");
const parameterStoreService = require("./parameterStoreService");
const notificationService = require("./notificationService");
const kalturaOldBuildService = require("./kalturaOldBuildUsers");

const ksmUserDeviceService =require("./ksmUserDevice");
const userKsmEncrptedService=require("./userDeviceEncriptionService");
const auditLogNotificationservice = require("./auditLogNotificationService");
const kafkaService = require("./kafkaService");
const loginInfoByDeviceIdService = require( "./LoginInfoByDeviceIdService" );
const subProfile = require( "./subProfile" );


const sendMessageService = require("./sendMessageService");
const smsDataService = require("./smsData");

const ipService = require("./ipService");
const unVerifiedImsUser =require("./unVerifiedImsUser");
module.exports = {
	userService,
	tokenService,
	userProfileService,
	deviceActivationCode,
	kalturaService,
	jioCryptoService,
	jioSubscriptionService,
	mailService,
	otpService,
	redisService,
	appleService,
	unverifiedUser,
	jioUserDetails,
	tataSkyNotification,
	tSkyUserDetails,
	getTskyCollectionDetails,
	pxApiService,
	checkSSOAndJioSub,
	anonymousTokenService,
	SettingCache,
	parameterStoreService,
	sqsService,
	notificationService,
	ksmUserDeviceService,
	userKsmEncrptedService,
	auditLogNotificationservice,
	kafkaService,
	loginInfoByDeviceIdService,
	kalturaOldBuildService,
	sendMessageService,
	subProfile,
	smsDataService,
	ipService,
	unVerifiedImsUser
};
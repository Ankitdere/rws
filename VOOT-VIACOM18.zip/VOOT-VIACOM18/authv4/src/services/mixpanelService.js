
const config  = require("../config/configuration");
const axios = require("axios");
const _  = require("lodash");
module.exports  =  pushToMixPanel;

let processedData, userProperties = {};

async function  pushToMixPanel(eventName, eventData,distinctId = "",userProps,referring_domain="",isAuthProject=true) {
	try{
		if(_.isUndefined(eventName)){
			return true;
		}
		console.debug("config.mpPartnerApiSwitch in mixpanel", config.mpPartnerApiSwitch);//true allow to push 
		console.debug("config.mpAuthApiSwitch in mixpanel", config.mpAuthApiSwitch);
		if(isAuthProject && !config.mpAuthApiSwitch){
			console.debug("NOT Pushing any event in Mixpanel for Auth Service");
			return true; 
		}
		if(!config.mpPartnerApiSwitch){
			console.debug("NOT Pushing any event in Mixpanel for Partner Service");
			return true; 
		}
		processedData = {};
		// return true;
		let data  = await processEventData(eventData);
		data.Env = process.env.VOOT_ENV;
		if(!_.isEmpty(data)) data.distinct_id= distinctId;
		data.RequestBody  = _.get(eventData,"input");
		data.Error        = _.get(eventData,"error");
		//console.log(JSON.stringify(data))
		let mpApiEndpoint = config.mpApiEndPoint;
		let mpApiToken = (isAuthProject) ? config.mpAuthApiToken : config.mpPartnerApiToken;
		// console.log('mp token', mpApiToken);
		// console.log('mp endtime', mpApiEndpoint);
		console.debug(`Inside sendEventToMixpanel for event : ${eventName}`, JSON.stringify(data));
		console.debug(referring_domain);
		const mpResponse = {};
		const mpConfig = {
			baseURL: mpApiEndpoint,
			timeout: 6000,
		};
        
		// eslint-disable-next-line no-param-reassign
		data.token = mpApiToken;
		const eventJsonData = { event: eventName, properties: data };
		const content = Buffer.from(JSON.stringify(eventJsonData)).toString("base64");
		const userUpdateData = {
			$token: mpApiToken,
			$distinct_id: distinctId,
			$set: userProperties,
			// $referring_domain :referring_domain
		};
		// if(!_.isEmpty(referring_domain))_.set(userUpdateData,'$referring_domain',referring_domain);
		const userProfileDataInBase64 = Buffer.from(JSON.stringify(userUpdateData)).toString("base64");
		// logger.info(`sending event ${eventName} : - ${content}`);
		const mpAxiosClient = axios.create(mpConfig);
		// eslint-disable-next-line no-undef
		const [trackResp, updateResp] = await Promise.all([
			mpAxiosClient.get("/track", { params: { data: content, verbose: 1, ip: 0 } }),
			mpAxiosClient.get("/engage", { params: { data: userProfileDataInBase64, verbose: 1 } }),
		]);
    
		mpResponse.track = trackResp.status;
		mpResponse.profileUpdate = updateResp.status;
		console.debug(`Response from mixpanel for event ${eventName} : - `, JSON.stringify(mpResponse));
		return true;
      
	}catch(err){
		console.error("Error in sending mixpanel event", err,err.stack);
		return false;
	}
      
}
async function processEventData(eventData){
	try{
		// eslint-disable-next-line no-undef
		return new Promise(async(resolve)=>{
			try{
				for (let propName in eventData) {
					if (eventData[propName] === null || eventData[propName] === undefined || eventData[propName]  === "" || propName  === "password" || propName === "otp" || propName === "newPassword" || propName === "oldPassword") {
						delete eventData[propName];
					}
					if(propName == "email" || propName == "uid"){
						userProperties[propName] = eventData[propName] ;
					}
					if(typeof eventData[propName] === "object" && propName != "languages"){
						processedData  = await  processEventData(eventData[propName]);
					}else{
						processedData[propName] = eventData[propName];
					}
                
				}
				return resolve(processedData);
			}catch(err){
				console.error("Error in formatting data ", err);
				return resolve(false);
			}
		});
	}catch(err){
		console.log("error in formatting data",err);
		return false;
	}
    
}

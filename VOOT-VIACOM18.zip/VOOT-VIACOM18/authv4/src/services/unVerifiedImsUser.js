const unVerifiedImsUser = require("../schema").unVerifiedImsUser;
const _ = require("lodash");
module.exports = {
	updateUnverifiedImsUserInformation,
	_getUnverifiedImsUserData,
	storeUnverifiedImsUserWithOTP,
	getUserInformationByMobileCountryCode
};
// eslint-disable-next-line no-unused-vars
async function _getUnverifiedImsUserData(mobile, countryCode) {
	try {
		let result = await getUserInformationByMobileCountryCode(mobile, countryCode);
		console.debug("Unverified Ims User Collection ", result);
		if (_.has(result,"status")) {
			return false;
		}
		return result;
	} catch (error) {
		console.log("Error in Sending Message to Ims User Mobile",error);
		return false;
	}
}

function getUserInformationByMobileCountryCode(mobile, countryCode) {
	// eslint-disable-next-line no-undef
	return new Promise((res, rej) => {
		unVerifiedImsUser.find({ "mobile": mobile, "countryCode": countryCode }, function (err, data) {
			if (!err) {
				if (data.length > 0)
					res(data[0]);
				else
					res({ status: 1792, message: "No Mobile Found" });
			} else {
				rej({ status: 1702, message: "No Mobile Found" });
			}
		});
	});
}

function updateUnverifiedImsUserInformation(query, updateQuery) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		unVerifiedImsUser.updateOne(query, { $set: updateQuery }, { upsert: true, useFindAndModify: false }, function (err, data) {
			if (err) {
				console.log(err);
				res({ status: 1703, message: "Ims User profile not added or updated" });
			} else
				res(data);
		});
	});
}

async function storeUnverifiedImsUserWithOTP(user, imsRequest,action,failedAttempt=null) {
	const phoneNumber = user.countryCode + user.mobile;
	console.log("phoneNumber: " + phoneNumber);
	const userData = await _getImsRequestDataFormat(user, imsRequest);
	let userDataFormated = JSON.stringify(userData);
	userDataFormated = JSON.parse(userDataFormated);
	if (failedAttempt) { userDataFormated._system.failedAttempt = failedAttempt;}
	const updatedData = await updateUnverifiedImsUserInformation({ "mobile": user.mobile, "countryCode": user.countryCode }, userDataFormated);
	if (_.has(updatedData, "status")) {
		return updatedData;
	}
	console.debug("Inserted into unVerifiedImsUser collection SuccessFully", updatedData);
}

async function _getImsRequestDataFormat(user, imsRequest) {
	return { //TODO: get this from AccountService as getDefaultPreferences
		...user,
		preferences: {
			language: "English"
		},
		_system: { imsRequest: imsRequest } // identifies private system only data, must not be visible to end user
	};
}

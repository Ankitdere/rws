module.exports = {
	createOne: createOne
};

// Imports
const Ratelimit = require("../schema").ratelimit;

/**
 * Create one
 * @param {*} ratelimit 
 * @param {*} params 
 * @param {*} flags 
 */
async function createOne(ratelimit) {
	try {
		const ratelimitObj = new Ratelimit(ratelimit);
		await ratelimitObj.save();

		// eslint-disable-next-line no-undef
		return Promise.resolve({ code: 200, message: "Ratelimit created successfully." });
	} catch (error) {
		// eslint-disable-next-line no-undef
		return Promise.reject(error);
	}
}
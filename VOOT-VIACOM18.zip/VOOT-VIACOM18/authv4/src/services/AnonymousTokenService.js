const jwt = require("jsonwebtoken");
const Config = require("../config").configuration;
const errorConfig = require("../config").errorConfig;
const { apiResponse } = require("../utils");
const errorUtilities = require("../config").errorConfig;
const _ = require("lodash");
const mixPanelConfig = require("../config/mixPanelConfig");

async function createAccessAndRefreshToken(payload, accessSecret, refreshSecret, accessTokenExpiresIn, refreshTokenExpiresIn, clientId,baseEventName,issuer) {
	try {
		console.log(`AnonymousTokenService.createAccessTokenAndRefreshToken() with payload: ${ JSON.stringify(payload) }`);
		const access_token = jwt.sign(payload, accessSecret, { expiresIn: accessTokenExpiresIn, issuer, subject: `Access token for ${ clientId }`, audience: `${ clientId }` });
		const refresh_token = jwt.sign(payload, refreshSecret, { expiresIn: refreshTokenExpiresIn, issuer, subject: `Refresh token is provided for ${ clientId }`, audience: `${ clientId }` });
		const accessTokenDecoded = jwt.decode(access_token);
		return ({
			accessToken: access_token,
			refreshToken: refresh_token,
			expirationTime: accessTokenDecoded["exp"]
		});
	} catch (error) {
		console.log(`AnonymousTokenService.createAccessTokenAndRefreshToken() error in creating tokens ${ error }`);
		throw apiResponse.error(errorConfig.requestFailed, 400, baseEventName+mixPanelConfig.internalServerError,payload,(payload.uid)?payload.uid:payload.clientId,500);
	}
}
async function refreshAccessToken(refreshToken, secret,clientId,baseEventName,issuer) {
	try {
		console.log(`AnonymousTokenService.refreshAccessToken() with refreshToken ${ refreshToken }`);
		const decoded = await verifyToken(refreshToken, secret,clientId,baseEventName);
		let secretKey=decoded.clientId;
		if (decoded) {
			// let payload = { grantType: decoded.grantType, partnerName: decoded.partnerName, code: decoded.code, clientId: decoded.clientId };
			_.pullAt(decoded, "exp");
			_.pullAt(decoded, "iss");
			_.pullAt(decoded, "iat");
			_.pullAt(decoded, "sub");
			_.pullAt(decoded, "aud");
			let accessSecret = Config.AnonymousToken.jwt.secret.access[secretKey];
			let rehreshSecret = Config.AnonymousToken.jwt.secret.refresh[secretKey];
			let accessExpiry = Config.AnonymousToken.jwt.expiry.access[secretKey];
			let refreshExpiry = Config.AnonymousToken.jwt.expiry.refresh[secretKey];
			return await createAccessAndRefreshToken(decoded, accessSecret, rehreshSecret, accessExpiry, refreshExpiry, decoded.clientId,baseEventName,issuer);
		}
	} catch (error) {
		console.error(`AnonymousTokenService.refreshAccessToken() with ${error}`);
		throw error;
	}
}
async function verifyToken(token, secret,clientId=null,baseEventName,issuer) {
	try {
		let aud = {
			issuer: issuer
		};
		if (clientId) {
			aud.audience = `${clientId}`;
		}
		
		console.log(`AnonymousTokenService.verifyToken() is called with token ${token}`);
		
		//let decoded = jwt.verify(token, secret, { issuer: Config.AnonymousToken.jwt.issuer, audience: `${clientId}` });
		let decoded = jwt.verify(token, secret, aud);
		console.log(`decoded ${ JSON.stringify(decoded) }`);
		return decoded;
	} catch (error) {
		console.log(`AnonymousTokenService.verifyToken() error in verifying token ${ error }`);
		if (error.name === undefined || error.message === undefined) throw apiResponse.error(error.message.requestFailed, 400, baseEventName + mixPanelConfig.internalServerError, {accessToken:token},clientId,500);
		switch (error.message) {
		case "jwt expired":
			throw apiResponse.error(errorUtilities.expiredAnonymosToken.description, errorUtilities.expiredAnonymosToken.code,baseEventName + mixPanelConfig.serverValidation_Error, {accessToken:token},clientId,400);
		case `jwt audience invalid. expected: ${clientId}`:
			throw apiResponse.error(errorUtilities.invalidAnonymosTokenClientId.description, errorUtilities.invalidAnonymosTokenClientId.code,baseEventName + mixPanelConfig.serverValidation_Error, {accessToken:token},clientId,400);
		case "jwt invalid":
		case "jwt malformed":
		case "jwt not active":
		case "jwt signature is required":
		case "invalid signature":
		case "auth/user-not-found":
			throw apiResponse.error(errorUtilities.invalidAccessToken.description, errorUtilities.invalidAccessToken.code,baseEventName + mixPanelConfig.serverValidation_Error, {accessToken:token},clientId,400);
		case "invalid token":
			throw apiResponse.error(errorUtilities.invalidAccessToken.description, errorUtilities.invalidAccessToken.code,baseEventName + mixPanelConfig.serverValidation_Error, {accessToken:token},clientId,400);
		default:
			throw apiResponse.error(errorConfig.requestFailed,400,baseEventName + mixPanelConfig.internalServerError, {accessToken:token},clientId,500);
		}
	}
}


module.exports = {
	createAccessAndRefreshToken,
	refreshAccessToken,
	verifyToken,
};
const mailService = require("../services/mailService");
const otpService = require("../services/otpService");
const Config = require("../config/configuration");

module.exports = {
	prepareAndSendEmail,
	prepareAndSendSMS
};
async function prepareAndSendEmail(emailBody,email){
	try{
		const emailSubject = emailBody.subject;
		const emailBodyFormat = emailBody.body;
		await mailService.sendMail(email, emailSubject, emailBodyFormat);
		return {"isPosted":true};
	}catch(err){
		console.error("error in sendMessageService/Catch",err);
		throw err;
	}
	
}
async function prepareAndSendSMS(smsBody,phoneNumber){
	try {
		const { sms: smsConfig } = Config;
		const peID = smsConfig.peID.VOOT;
		const { smsVendor: vendor } = Config.sms;
		const smsV2Params = {
			destination: phoneNumber,
			message: smsBody.body,
			peID: peID,
			templateId: smsBody.templateId,
			header:smsBody.header,
			vendor: vendor,
			type: smsBody.type
		};
		await otpService.handleSmsEvent(smsV2Params);
		return {"isPosted":true};
	}catch (err) {
		console.error("error in sendMessageService/Catch", err);
		throw err;
	}
}
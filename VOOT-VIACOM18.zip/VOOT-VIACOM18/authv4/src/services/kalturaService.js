
"use strict";
const kaltura = require("kaltura-ott-client/KalturaClient");
const crypto = require("crypto");

const config = require("../config").configuration;
// const ErrorService = require("../services").ErrorServicexx;
const errorUtils = require("../config").errorConfig;
const _ = require("lodash");
const envConfig = require("../config").configuration;
const requestPromise = require("request-promise");
const ApiResponse = require("../utils").apiResponse;
const adminTokenService = require("./adminToken");
const mixpanelService = require("../services/mixpanelService");
const mixPanelConfig = require("../config/mixPanelConfig");
let _partnerID, _client;
const kalturaClientConfiguration = new kaltura.Configuration();
kalturaClientConfiguration.serviceUrl = config.kaltura.url;
_client = new kaltura.Client(kalturaClientConfiguration);
_client.shouldLog = true;
_partnerID = config.kaltura.partnerID;

module.exports = {
	register,
	setupHouseholdDevice,
	deleteUser,
	login,
	createHousehold,
	startSession,
	getAppToken,
	getAppTokenByUserId,
	addDeviceToUserHousehold,
	removeDeviceFromHousehold,
	getHouseholdDeviceList,
	regenerateSession,
	getUserByUsername,
	getUserByKs,
	_getAnonymousKs,
	_getSHA1,
	getStatus,
	addUserToExistingHousehold,
	_generateAdminKs,
	multiRequestUserRegistration,
	getHousehold,
	deleteUserByUserName,
	getUserByUsernameOrExternalId,
	getUserByUsernameOrExternalIdNew,
	garntSubscription,
	isSubscribedUser,
	cancelSubscription,
	updateKalturaUser,
	updateKalturaUserPassword,
	getUserByUsernameOrExternalIdOrLrId,
	updatePasswordAndLogin,
	revokeKs
};

async function register(email, userID) {
	const username = email;
	const password = userID;
	const userObject = {
		username: username,
		externalId: userID,
	};
	const kalturaUser = new kaltura.objects.OTTUser(userObject);
	console.log("Kaltura | Kaltura User Model: ", kalturaUser);
	// eslint-disable-next-line no-undef
	return new Promise((resolve, reject) => {
		kaltura.services.ottUser.register(_partnerID, kalturaUser, password)
			.completion((success, result) => {
				if (!success) {
					console.error("Kaltura: User registration failed");
					return reject(result);
				}
				console.debug("KalturaOttRegisterResponse: ", result);
				return resolve(result);
			}).execute(_client);
	});
}

async function setupHouseholdDevice(deviceId, deviceBrandName) {
	const brandName = deviceBrandName.toLowerCase().trim();
	// There is a dedicated API in kaltura to get all available deviceBrands, this is just taken from "auth-voot" code
	const deviceBrands = config.deviceBrands;

	// lower case all array keys so that we can match with lower_case passed brandName
	const deviceBrandsTemp = {};
	// eslint-disable-next-line no-undef
	return new Promise((resolve, reject) => {
		try {
			Object.keys(deviceBrands).forEach(function (key) {
				deviceBrandsTemp[key.toLowerCase()] = deviceBrands[key];
				if (Object.keys(deviceBrandsTemp).length === Object.keys(deviceBrands).length) {
					const device = new kaltura.objects.HouseholdDevice({
						name: brandName,
						udid: deviceId,
						brandId: 32
					});
					if (deviceBrandsTemp.hasOwnProperty(brandName)) {
						device.brandId = deviceBrandsTemp[brandName];
					}
					console.debug("=========Kaltura Household device has been setup=========");
					// console.log(device);
					return resolve(device);
				}
			});
		} catch (error) {
			// User does not exist, maybe kaltura signup failed
			if (error.result.error.code === "2000") {
				return reject(error.result);
			}
			return reject(error);
		}
	});
}

async function deleteUser(householdUserId, householdMasterUserKs) {
	_client.setUserId(householdUserId);
	_client.setKs(householdMasterUserKs);
	// eslint-disable-next-line no-undef
	return new Promise(((resolve) => {
		return resolve({
			"result": true
		});
		// kaltura.services.ottUser.deleteAction().completion((success, result) => {
		//     //TODO: Getting HTML instead of proper exception when passing invalid KS (update VKIDS-415 with logs)
		//     console.log(result);
		//     if (!success) {
		//         const kalturaErrorCode = commonUtils.getNestedValue(result, 'result.error.code');
		//         if (kalturaErrorCode) return reject({ code: kalturaErrorCode.toString() });
		//         return reject({ code: 'kaltura/internal-error' });
		//     }
		//     return resolve(success);
		// }).execute(_client);
	}));
}

async function login(email, uid, deviceId) {
	console.debug("inside the kaltura login functions");
	console.debug("Client before unset ks in Login",_client);
	if(!_.isEmpty(_client,"requestData.ks")){
		_.unset(_client,"requestData.ks");
	}
	console.debug("Client after unset ks in Login",_client);
	// eslint-disable-next-line no-undef
	return new Promise((resolve, reject) => {
		console.log(email + "\n\n" + uid + "\n\n" + deviceId);
		kaltura.services.ottUser.login(_partnerID, email, uid, null, deviceId)
			.completion((success, result) => {
				if (!success) {
					console.error("Kaltura: User login failed", result);
					return reject(result);
				}
				console.debug("*******KalturaOttLoginResponse********: ", result);
				return resolve(result);
			}).execute(_client);
	});
}


async function createHousehold(userID, UserKalturaSession,uid="",email="",mixPanelPartner=true) {
	const householdPrefix = "Voot_Household_";
	const householdIdentifier = householdPrefix + userID;
	const household = new kaltura.objects.Household({
		name: householdIdentifier,
		description: householdIdentifier,
		externalId: householdIdentifier
	});

	_client.setKs(UserKalturaSession);
	// eslint-disable-next-line no-undef
	return new Promise((resolve, reject) => {
		kaltura.services.household.add(household)
			.completion((success, result) => {
				if (!success) {
					console.log("Kaltura: Household creation failed");
					mixpanelService(mixPanelConfig.externalCallKaltura+"CreateHousehold"+mixPanelConfig.success, {uid:uid,distinct_id:email,input:UserKalturaSession,error:result},email,null,null,mixPanelPartner);
					return reject(result);
				}
				console.debug("KalturaHouseholdResponse: ", result);
				mixpanelService(mixPanelConfig.externalCallKaltura+"CreateHousehold"+mixPanelConfig.success, {uid:uid,distinct_id:email,input:UserKalturaSession,result:result},email,null,null,mixPanelPartner);
				return resolve(result);
			}).execute(_client);
	});
}

async function startSession(userId) {
	const type = kaltura.enums.SessionType.USER;
	const expiry = null;
	const privileges = null;
	// eslint-disable-next-line no-undef
	return new Promise((resolve, reject) => {
		const secret = 225;
		kaltura.services.session.start(secret, userId, type, _partnerID, expiry, privileges)
			.completion((success, ks) => {
				if (!success) {
					reject(ks.message);
					return;
				}
				_client.setKs(ks);
				console.log("Seesion started: " + ks);
				resolve();
			})
			.execute(_client);
	});
}

async function getAppToken(ks) {
	_client.setKs(ks);
	const appToken = new kaltura.objects.AppToken({
		hashType: kaltura.enums.AppTokenHashType.SHA1,
	});

	// eslint-disable-next-line no-undef
	return new Promise((resolve, reject) => {
		kaltura.services.appToken.add(appToken).completion((success, result) => {
			if (!success) {
				console.log("Kaltura: app token failed");
				return reject(result);
			}
			return resolve(result);
		}).execute(_client);
	});
}

async function getAppTokenByUserId(kUserId) {
	// eslint-disable-next-line no-undef
	return new Promise(async (resolve, reject) => {
		const appToken = new kaltura.objects.AppToken({
			hashType: kaltura.enums.AppTokenHashType.SHA1,
		});
		const adminKs = await _getAdminKs();
		_client.setKs(adminKs);
		kaltura.services.appToken.add({ appToken, kUserId }).completion((success, result) => {
			if (!success) {
				console.log("Kaltura: app token failed");
				return reject(result);
			}
			return resolve(result);
		}).execute(_client);
	});
}

async function addDeviceToUserHousehold(device, kalturaUser, householdId = 0, uid ="",email="",mixPanelPartner=true) {
	console.debug("Inside the addDeviceToUserHousehold:", householdId);
	const ks = kalturaUser.loginSession.ks;
	//const householdId: number = kalturaUser.user.householdId;        
	_client.setKs(ks);
	// eslint-disable-next-line no-undef
	return new Promise(async (resolve, reject) => {
		kaltura.services.householdDevice.add(device).completion(async (success, result) => {
			try {
				let deviceAdded;
				console.log(result);
				if (success) {
					mixpanelService(mixPanelConfig.externalCallKaltura+"AddDeviceToHousehold"+mixPanelConfig.success, {uid:uid,distinct_id:email,input:device,householdId:householdId},email,mixPanelPartner);
					return resolve(true);} // device added successfully
				console.debug("Kaltura API error: ", result);
				mixpanelService(mixPanelConfig.externalCallKaltura+"AddDeviceToHousehold"+mixPanelConfig.error, {uid:uid,distinct_id:email,input:device,householdId:householdId,error:result},email,mixPanelPartner);
				switch (result.result.error.code) {
				case "1016": // Device exists in other households
				{
					const deviceRemoved = await removeDeviceFromHousehold(device,uid,email);
					if (!deviceRemoved) return reject(false);
					deviceAdded = await addDeviceToUserHousehold(device, kalturaUser,householdId,uid,email);
					return resolve(deviceAdded);
				}
				case "1015": // Device already exists in the same household
					return resolve(true);
				case "1001": // Exceeded limit for adding device into a household
				{
					const deviceList = await getHouseholdDeviceList(householdId,uid,email);
					let oldestDevice = deviceList[0]; // VKIDS-107
					oldestDevice = await setupHouseholdDevice(oldestDevice.udid, oldestDevice.name);
					const oldestDeviceRemoved = await removeDeviceFromHousehold(oldestDevice,uid,email);
					if (!oldestDeviceRemoved) return reject(false);
					deviceAdded = await addDeviceToUserHousehold(device, kalturaUser,householdId,uid,email);
					return resolve(deviceAdded);
				}
				case "1002":
					// Particular Device Not Allowed, making it default to Android
					device.brandId = 32; device.name = "android";
					deviceAdded = await addDeviceToUserHousehold(device, kalturaUser,householdId,uid,email);
					return resolve(deviceAdded);
				default:
					return reject(result);
                    // TODO: Handle other exception if necessary, else it will always return false if found any Kaltura Exceptions
				}
			} catch (error) {
				console.error(error);
				return resolve(false); // failed silently but log the error
			}
		}).execute(_client);
	});
}

async function removeDeviceFromHousehold(device,uid="",email="") {
	// eslint-disable-next-line no-undef
	return new Promise(async (resolve, reject) => {
		const adminKs = await _getAdminKs();
		_client.setKs(adminKs);
		kaltura.services.householdDevice.deleteAction(device.udid).completion((success, result) => {
			console.log(result);
			if (success){
				mixpanelService(mixPanelConfig.externalCallKaltura+"RemoveDeviceFromHousehold"+mixPanelConfig.success, {uid:uid,distinct_id:email,input:{device : device}},email);
				return resolve(true);
			}
			mixpanelService(mixPanelConfig.externalCallKaltura+"RemoveDeviceFromHousehold"+mixPanelConfig.error, {uid:uid,distinct_id:email,input:{device : device},error:result},email);
			return reject(false);
		}).execute(_client);
	});
}

async function getHouseholdDeviceList(householdId,uid="",email="") {
	let list = [];
	// eslint-disable-next-line no-undef
	return new Promise(async (resolve, reject) => {
		try {
			const adminKs = await _getAdminKs();
			_client.setKs(adminKs);
			const filter = new kaltura.objects.HouseholdDeviceFilter({ householdIdEqual: householdId });
			kaltura.services.householdDevice.listAction(filter).completion((success, result) => {
				console.log(result);
                
				if (!success || result.result.objects === undefined){ 
					mixpanelService(mixPanelConfig.externalCallKaltura+"GetHouseholdList"+mixPanelConfig.error, {uid:uid,distinct_id:email,input:{householdId : householdId},error:result},email);
					return reject({ code: "kaltura/device-list-failed" });
				}
				list = result.result.objects;
				mixpanelService(mixPanelConfig.externalCallKaltura+"GetHouseholdList"+mixPanelConfig.success, {uid:uid,distinct_id:email,input:{householdId : householdId},result},email);
				return resolve(list);
			}).execute(_client);
		} catch (error) {
			console.log(error);
			return reject({ code: "kaltura/device-list-failed" });
		}
	});
}

async function regenerateSession(kTokenId, kToken, deviceId) {
	console.debug("Inside the regenerateSession", deviceId);
	// eslint-disable-next-line no-undef
	return new Promise((resolve, reject) => {
		_getAnonymousKs().then((anonymousKsResponse) => {
			const ks = anonymousKsResponse;
			_client.setKs(ks);
			const shaHash = _getSHA1(ks + kToken);
			kaltura.services.appToken.startSession(kTokenId, shaHash, "", 0, deviceId)
				.completion((success, result) => {
					if (!success) {
						console.log("Kaltura: refresh token error");
						switch (result.result.error.code) {
						case "500055": // wrong token id
							return reject("Invalid kTokenId");
						case "50022": // wrong token id
							return reject("Invalid kToken");
						default:
							return reject(result);
						}
					}

					console.debug("Kaltura: refresh token success: ", result);
					return resolve(result);
				}).execute(_client);
		}).catch((error) => {
			console.log("Kaltura: refresh token error output ");
			console.log(error);
			reject(error);
		});
	});
}

async function getUserByUsername(username) {
	// eslint-disable-next-line no-undef
	return new Promise((resolve, reject) => {
		const filter = new kaltura.objects.OTTUserFilter({
			//'externalIdEqual': username
			"usernameEqual": username
		});
		_getAdminKs().then((adminKs) => {
			_client.setKs(adminKs);
			kaltura.services.ottUser.listAction(filter).completion((success, result) => {
				if (!success) {
					switch (result.result.error.code) {
					case "2000": // UserDoesNotExist
						return reject(result.result.error);
					default:
						return reject(result);
					}
				}
				console.log("KalturaOttUserListResponse: ", result);
				return resolve(result.result.objects[0]);
			}).execute(_client);
		}).catch((error) => {
			console.error(error);
			reject(error);
		});
	});
}

async function getUserByKs(kalturaSession) {
	// eslint-disable-next-line no-undef
	return new Promise((resolve, reject) => {
		_client.setKs(kalturaSession);
		kaltura.services.ottUser.get().completion((success, result) => {
			if (!success) return reject(result.result.error);
			console.debug("KalturaGetUserByKs:", result);
			return resolve(result.result);
		}).execute(_client);
	});
}

async function _getAdminKs() {
	//if(ks !== '') return _generateAdminKs(ks);
	//TODO: Store AdminKS somewhere so we don't need to regenerate again and again to avoid kaltura exceeding database storage limit
	// eslint-disable-next-line no-undef
	return new Promise(async (resolve, reject) => {
		let globalInfo = await adminTokenService.getAdminToken() || {};
		const tokenService = require("./tokenService");
		try {
			if (!_.get(globalInfo, "adminKsToken", undefined)) {
				const anonymousKs = await _getAnonymousKs();
				const adminKs = await _generateAdminKs(anonymousKs);
				const adminKsToken = await tokenService.createAccessTokenForAdminKs({ adminKs });
				let updateToken = await adminTokenService.updateAdminToken(adminKsToken);
				console.debug("Token Updated ========= ", updateToken);
				globalInfo = { adminKsToken };
			}
			let decoded = await tokenService.verifyAccessTokenForAdminKs(globalInfo.adminKsToken);
			resolve(decoded.adminKs);
		} catch (err) {
			if (err.expired) {
				const anonymousKsData = await _getAnonymousKs();
				const adminKsData = await _generateAdminKs(anonymousKsData);
				const adminKsTokenData = await tokenService.createAccessTokenForAdminKs({ "adminKs": adminKsData });
				let updateToken = await adminTokenService.updateAdminToken(adminKsTokenData);
				console.debug("Expired Token Updated ========= ", updateToken);
				resolve(adminKsData);
			}
			reject(err);
		}
	});
}

async function _getAnonymousKs() {
	// eslint-disable-next-line no-undef
	return new Promise((resolve, reject) => {
		kaltura.services.ottUser.anonymousLogin(config.kaltura.partnerID).completion((success, result) => {
			if (!_.has(result, "result.ks")) {
				reject(ApiResponse.error(errorUtils.requestFailed, 500));
			}
			if (!success) {
				console.error("Kaltura: Anonymous KS generation failed.");
				/* To send notification on mail */
				//ErrorService.errorLogMail('Kaltura: Anonymous KS generation failed. ', 'Kaltura: Anonymous KS generation failed.');

				return reject(result);
			}
			console.debug("KalturaAnonymousKS: ", result);
			const ks = result.result.ks;
			console.debug(ks);
			return resolve(ks); //TODO: if ks doesn't exist reject with error
		}).execute(_client);
	});
}

function _getSHA1(input) {
	return crypto.createHash("sha1").update(input).digest("hex");
}

async function getStatus() {
	// eslint-disable-next-line no-undef
	return new Promise((resolve, reject) => {
		console.debug("ping to kaltura");
		kaltura.services.system.ping().completion((success, result) => {
			console.debug(success);
			console.debug(result);
			if (!success) {
				return reject(result);
			}
			return resolve(result);
		}).execute(_client);
	});
}

async function addUserToExistingHousehold(householdId, userIdToAdd, householdMasterUsername) {
	// eslint-disable-next-line no-undef
	return new Promise((resolve, reject) => {
		//return resolve(123);

		_getAdminKs().then((adminKs) => {
			_client.setKs(adminKs);
			const householdUser = new kaltura.objects.HouseholdUser({
				userId: userIdToAdd,
				householdMasterUsername: householdMasterUsername,
				householdId: householdId,
			});

			kaltura.services.householdUser.add(householdUser).completion((success, result) => {
				if (!success) {
					console.error("Kaltura: AddUserToExistingHousehold failed.");
					switch (result.result.error.code) {
					case "1022": // 'Exceeded user limit
						return reject(result.result.error);
					default:
						return reject(result);
					}
				}
				console.debug("KalturaAddUserToExistingHousehold: ", result.result);
				return resolve(result);
			}).execute(_client);
		}).catch((error) => {
			console.error(error);
			return reject(error);
		});
	});
}

async function _generateAdminKs(ks) {
	//TODO: Should always check on Cache/Redis and only generate one time to update it on the cache. Handle expiredKS cases as well.
	// eslint-disable-next-line no-undef
	return new Promise((resolve, reject) => {
		_client.setKs(ks);
		const tokenHash = _getSHA1(ks + config.kaltura.adminToken);
		console.log("ks: ", ks);
		console.log("tokenHash: ", tokenHash);
		kaltura.services.appToken.startSession(config.kaltura.adminID, tokenHash).completion((success, result) => {
			if (!success) {
				/* To send notification on mail */
				//ErrorService.errorLogMail('Kaltura: Admin KS generation failed. ', 'Kaltura: Admin KS generation failed.');
				console.log("Kaltura: Admin KS generation failed.");
				return reject(result);
			}
			console.log("KalturaAdminKS: ", result.result);
			return resolve(result.result.ks);
		}).execute(_client);
	});
}

// Attempt MultiRequest
async function multiRequestUserRegistration(userID, deviceId) {

	// eslint-disable-next-line no-undef
	return new Promise((resolve, reject) => {
		const username = userID;
		const password = userID;

		const kalturaUser = new kaltura.objects.OTTUser({
			username: username,
			externalId: userID,
		});

		const householdPrefix = "Voot_Household_";
		const householdIdentifier = householdPrefix + userID;

		const household = new kaltura.objects.Household({
			name: householdIdentifier,
			description: householdIdentifier,
			externalId: householdIdentifier,
			ks: "{2:result:loginSession:ks}" // Extra parameter, since no option to set ks during multiRequest
		});


		console.log("Getting to kalturaMultiRequest registration...");

		try {
			kaltura.services.ottUser.register(_partnerID, kalturaUser, password)
				.add(kaltura.services.ottUser.login(_partnerID, username, password, null, deviceId))
			//.add(_client.setKs('{2:result:loginSession:ks}'))
				.add(kaltura.services.household.add(household))
				.execute(_client)
				.then((results) => {
					console.log("composite result:");
					console.log(results);
					return resolve(results);
				});
		} catch (error) {
			return reject(error);
		}
	});
}

async function getHousehold(id) {
	try {
		const adminKs = await _getAdminKs();
		_client.setKs(adminKs);
		const household = await kaltura.services.household.get(id).execute(_client);
		console.info("household:", household);
		return household.result;
	} catch (error) {
		throw error;
	}
}

async function deleteUserByUserName(username) {
	try {
		const adminKs = await _getAdminKs();
		_client.setKs(adminKs);
		const filter = new kaltura.objects.OTTUserFilter({
			"usernameEqual": username
		});
		const householdUser = await kaltura.services.ottUser.listAction(filter).execute(_client);
		const houseHoldId = _.get(householdUser, "result.objects[0].householdId", false);
		if (!houseHoldId) {
			throw { code: errorUtils.kalturaUserDoesNotExist.code, message: errorUtils.kalturaUserDoesNotExist.description };
		}
		const isDeleted = await kaltura.services.household.deleteAction(houseHoldId).execute(_client);
		return isDeleted.result;
	} catch (error) {
		throw error;
	}
}
/*** Not use this function for now */
async function getUserByUsernameOrExternalId(username, externalId) {
	// eslint-disable-next-line no-undef
	return new Promise(async (resolve, reject) => {
		const filterExternalId = new kaltura.objects.OTTUserFilter({
			"externalIdEqual": externalId
		});
		const filterUsernameEqual = new kaltura.objects.OTTUserFilter({
			"usernameEqual": username
		});
		let adminKs = await _getAdminKs(); //.then((adminKs) => {
		_client.setKs(adminKs);
		try {
			let userbyUsername = await kaltura.services.ottUser.listAction(filterUsernameEqual).execute(_client);
			resolve(_.get(userbyUsername, "result.objects[0]"));
		} catch (error) {
			try {
				let userbyExternalID = await kaltura.services.ottUser.listAction(filterExternalId).execute(_client);
				resolve(_.get(userbyExternalID, "result.objects[0]"));
			} catch (err) {
				reject(err);
			}
		}
	});
}
async function updatePasswordAndLogin(user) {
	console.debug("==========Multirequest for Update Password=============");
	// eslint-disable-next-line no-undef
	return new Promise((resolve, reject) => {
		const filter = new kaltura.objects.OTTUserFilter({
			"usernameEqual": user.email
		});
		const userObject = {
			externalId: user.uid,
		};
		const kalturaUser = new kaltura.objects.OTTUser(userObject);

		try {
			console.debug("******************");       
			_getAdminKs().then((adminKs) => {
				_client.setKs(adminKs);
				kaltura.services.ottUser.listAction(filter)
					.add(kaltura.services.ottUser.updatePassword("{1:result:objects:0:id}",user.uid))
					.add(kaltura.services.ottUser.update(kalturaUser,"{1:result:objects:0:id}"))
				//.add(kaltura.services.ottUser.login(this._partnerID, user.email, user.uid, null, udid))
					.execute(_client)
					.then((results) => {
						console.debug("composite result for update password:",results);
						return resolve(true);
					});
			}).catch((error) => {
				console.log("error 1 in update password by mutlirequest",error);
				return reject(error);
			});
		} catch (error) {
			console.log("error 2 in update password by mutlirequest",error);
			return reject(error);
		}
	});
}
async function getUserByUsernameOrExternalIdNew(username, externalId) {
	// eslint-disable-next-line no-undef
	return new Promise(async (resolve, reject) => {
		let adminKs = await _getAdminKs();
		const filterBody = {
			0: {
				"filter": {
					"usernameEqual": username,
					"objectType": "KalturaOTTUserFilter"
				},
				"format": 1,
				"service": "ottuser",
				"action": "list"
			},
			1: {
				"filter": {
					"externalIdEqual": externalId,
					"objectType": "KalturaOTTUserFilter"
				},
				"format": 1,
				"service": "ottuser",
				"action": "list"
			},
			ks: adminKs
		};
		const option = {
			method: "POST",
			url: `${config.kaltura.url}/api_v3/service/multirequest`,
			body: filterBody,
			json: true
		};

		try {
			let userbyUsername = await requestPromise(option);
			let response = _.get(userbyUsername, "result[0].objects[0]") ? _.get(userbyUsername, "result[0].objects[0]") : _.get(userbyUsername, "result[1].objects[0]");
			if (response)
				resolve(response);
			else
				reject({
					result: _.get(userbyUsername, "result[0]")
				});
		} catch (error) {
			reject(error);
		}
	});
}

async function garntSubscription(kUserId) {
	// eslint-disable-next-line no-undef
	return new Promise(async (resolve, reject) => {
		const adminKs = await _getAdminKs();
		_client.setKs(adminKs);
		_client.setUserId(kUserId);
		try {
			let premiumResult = await kaltura.services.entitlement.grant(envConfig.productId, "SUBSCRIPTION", true).execute(_client);
			resolve(_.get(premiumResult, "result"));
		} catch (error) {
			reject(error);
		}
	});
}

async function isSubscribedUser(ks, filterExpression) {
	// eslint-disable-next-line no-undef
	return new Promise(async (resolve, reject) => {
		const filter = new kaltura.objects.EntitlementFilter({
			"isExpiredEqual": filterExpression,
			"productTypeEqual": "SUBSCRIPTION"
		});
		_client.setKs(ks);
		try {
			let premiumResult = await kaltura.services.entitlement.listAction(filter).execute(_client);
			resolve(_.get(premiumResult, "result.totalCount"));
		} catch (error) {
			reject(error);
		}
	});
}

async function cancelSubscription(kUserId) {
	// eslint-disable-next-line no-undef
	return new Promise(async (resolve, reject) => {
		const adminKs = await _getAdminKs();
		_client.setKs(adminKs);
		_client.setUserId(kUserId);
		try {
			let premiumResult = await kaltura.services.entitlement.forceCancel(envConfig.productId, "SUBSCRIPTION").execute(_client);
			resolve(_.get(premiumResult, "result"));
		} catch (error) {
			if (_.get(error, "result.error.code") == 3000) {
				resolve({
					expired: true
				});
			}
			reject(error);
		}
	});
}

async function updateKalturaUser(username, externalId, kUserId) {
	// eslint-disable-next-line no-undef
	return new Promise(async (resolve, reject) => {
		let adminKs = await _getAdminKs();
		const bodyParams = {
			"user": {
				"objectType": "KalturaOTTUser",
				"username": username,
				"email": username,
				"externalId": externalId,
				"userType": {
					"objectType": "KalturaOTTUserType"
				}
			},
			"id": kUserId,
			"ks": adminKs
		};
		const option = {
			method: "POST",
			url: `${config.kaltura.url}/api_v3/service/ottuser/action/update`,
			body: bodyParams,
			json: true
		};

		try {
			let updateUser = await requestPromise(option);
			let response = _.get(updateUser, "result.externalId");
			if (response)
				resolve(response);
			else
				reject({
					result: _.get(updateUser, "result.error")
				});
		} catch (error) {
			reject(error);
		}
	});
}

async function updateKalturaUserPassword(externalId, kUserId) {
	// eslint-disable-next-line no-undef
	return new Promise(async (resolve, reject) => {
		let adminKs = await _getAdminKs();
		const bodyParams = {
			"password": externalId,
			"userId": kUserId,
			"ks": adminKs
		};
		const option = {
			method: "POST",
			url: `${config.kaltura.url}/api_v3/service/ottuser/action/updatePassword`,
			body: bodyParams,
			json: true
		};

		try {
			let updateUserPassword = await requestPromise(option);
			let response = _.get(updateUserPassword, "result.externalId");
			if (response)
				resolve(response);
			else
				reject({
					result: _.get(updateUserPassword, "result.error")
				});
		} catch (error) {
			reject(error);
		}
	});
}
async function getUserByUsernameOrExternalIdOrLrId(username, externalId, lrId) {
	console.log("inside the multiReqiest getUserByUsernameOrExternalIdOrLrId");
	// eslint-disable-next-line no-undef
	return new Promise(async (resolve, reject) => {
		let adminKs = await _getAdminKs();
		const filterBody = {
			0: {
				"filter": {
					"usernameEqual": username,
					"objectType": "KalturaOTTUserFilter"
				},
				"format": 1,
				"service": "ottuser",
				"action": "list"
			},
			1: {
				"filter": {
					"externalIdEqual": externalId,
					"objectType": "KalturaOTTUserFilter"
				},
				"format": 1,
				"service": "ottuser",
				"action": "list"
			},
			2: {
				"filter": {
					"externalIdEqual": lrId,
					"objectType": "KalturaOTTUserFilter"
				},
				"format": 1,
				"service": "ottuser",
				"action": "list"
			},
			ks: adminKs
		};
		const option = {
			method: "POST",
			url: `${config.kaltura.url}/api_v3/service/multirequest`,
			body: filterBody,
			json: true
		};

		try {
			console.log("kl multirequest format", option, "filterBody", filterBody);
			let userbyUsername = await requestPromise(option);
			console.log("multirequest Response", userbyUsername);
			let response = _.get(userbyUsername, "result[0].objects[0]") ? _.get(userbyUsername, "result[0].objects[0]") : _.get(userbyUsername, "result[1].objects[0]");
			let lrRes = _.get(userbyUsername, "result[2].objects[0]");
			if (lrRes && !response) {
				// eslint-disable-next-line no-undef
				await Promise.all([updateKalturaUser(username, externalId, lrRes.id), updateKalturaUserPassword(externalId, lrRes.id)]);
			}
			if (response)
				resolve(response);
			else
				reject({
					result: _.get(userbyUsername, "result[0]")
				});
		} catch (error) {
			console.log("Failure multirequest Response", error);
			reject(error);
		}
	});
}
async function revokeKs(ks) {
	// eslint-disable-next-line no-undef
	return new Promise((resolve, reject) => {
		try {
			_client.setKs(ks);
			kaltura.services.session.revoke().completion((success, result) => {
				if (!success) {
					console.error("Kaltura: User Revoke Session");
					return reject(result);
				}
				console.log("Kaltura Revoke Session Response: ", result);
				return resolve(result);
			}).execute(_client);
		} catch (error) {
			console.log("Error in Kaltura Api Revoke Action", error);
			return reject(error);
		}
	});
}

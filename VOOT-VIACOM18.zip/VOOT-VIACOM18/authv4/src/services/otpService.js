
"use strict";

const moment = require("moment");
const _ = require("lodash");
const errorConfig = require("../config/errorConfig");
const Config = require("../config/configuration");
const utility = require("../utils");
const common = require("../utils/common");
const unverifiedUser = require("./unverifiedUser");
const responseFormat = require("../format").responseFormat;
const ApiResponse = require("../utils").apiResponse;
const pinpoint = require("../config/pinpoint").default;
const template = require("../config/forgotPasswordTemplate");
const Karix = require("./../config/karix");
const configuration = require("../config/configuration");
const mixPanelConfig = require("../config/mixPanelConfig");
const mixpanelService = require("../services/mixpanelService");
const constant = require("../utils/constant/generic");
const { sendMessage: sendMessageSQS } = require("./sqsService");
// const { CouponsGroupListResponse } = require("kaltura-ott-client/KalturaModel");
module.exports = {
	"SIGNUP_REQUEST": "signUpRequest",
	"FORGOT_PASSWORD_REQUEST": "forgotPasswordMobile",
	"FORGOT_PASSWORD_EMAIL_REQUEST": "forgotPasswordEmail",
	"IMS_REQUEST": "imsRequest",
	checkOtpAttempts,
	_processOtpAttempts,
	generate,
	_getRandomOTP,
	verifyOtp,
	sendOtp,
	send,
	getDummyEmail,
	otpVerificationFailed,
	isUserBlocked,
	sendPin,
	sendSMS,
	handleSmsEvent
};




/**
 * Use ProcessOtpAttempts for signUp Request
 */
async function checkOtpAttempts(userDetails, action, viaMobile = true) {
	try {
		return await _processOtpAttempts(userDetails, action, viaMobile);
	} catch (error) {
		console.error("OTP error: ", error);
		return error;
	}
}
async function _processOtpAttempts(userDetails, action, viaMobile = true) {
	console.log("Inside the function _processOtpAttempts=", action);
	const otpRequest = eval("userDetails._system." + action); // userDetails is being used inside eval
	const otpValidationData = otpRequest !== undefined ? otpRequest : null;
	if (!otpValidationData) throw { code: "otp/record-not-found" };
	const otpTimestamp = moment(otpValidationData.updatedAt, "MMMM Do YYYY, h:mm:ss a");
	const currentTimestamp = moment();
	const elapsedMinutes = currentTimestamp.diff(otpTimestamp, "minutes");
	console.debug("OTP was generated", elapsedMinutes, "minutes ago");
	const minutesInADay = Config.Otp.mobileBlockLimit;
	if (elapsedMinutes > minutesInADay) otpValidationData.attempts = 0;
	if (parseInt(otpValidationData.attempts) >= Config.Otp.maxAttempts) throw { code: "otp/exceededMaxGenerationLimit" };
	otpValidationData.attempts++;
	otpValidationData.viaMobile = viaMobile;
	otpValidationData.isOtpVerify = false;
	otpValidationData.updatedAt = moment().format("MMMM Do YYYY, h:mm:ss a");
	/* 15 min otp same send check */
	const minutesFifteen = Config.Otp.sameOTPLimit;
	if (elapsedMinutes > minutesFifteen) { // if difference is greater then 15 then only otp change
		//otpValidationData.otp = action === this.FORGOT_PASSWORD_REQUEST ? utility.randomString(6) : this._getRandomOTP(); // since password is minimum 6 characters in length
		otpValidationData.otp = _getRandomOTP(); // since password is minimum 6 characters in length
	}
	return otpValidationData;
}
async function generate(OTP = _getRandomOTP(), viaMobile = true) {
	//TODO: Process resend-otp attempts if the same API is called
	const currentTime = moment().format("MMMM Do YYYY, h:mm:ss a");
	const otpData = {
		otp: OTP,
		createdAt: currentTime,
		updatedAt: currentTime,
		attempts: 1,
		viaMobile: viaMobile,
		isOtpVerify: false
	};
	console.debug("Generated OTP:", OTP);
	return otpData;
}

function _getRandomOTP(length = 4) {
	if (length == 6) {
		return String(Math.floor(100000 + Math.random() * 900000));
	} else
		return String(Math.floor(1000 + Math.random() * 9000));

}
async function verifyOtp(otp, userDetails, action) {
	const otpData = common.getNestedValue(userDetails, "_system." + action);
	if (!otpData) throw { code: "otp/invalid-request" }; // can substitute 'otp/expired' also;
	if ((otpData.otp !== undefined && otpData.otp !== otp) || otpData.createdAt === undefined) throw { code: "otp/invalid" };
	//const expiryMinutes: number = (otpData.viaMobile !== undefined && otpData.viaMobile === false) ? 1440 : 100;
	const expiryMinutes = Config.Otp.OTPExpiredTime;
	console.debug("expiryMinutes===========", expiryMinutes, "minutes ago");
	const otpTimestamp = moment(otpData.updatedAt, "MMMM Do YYYY, h:mm:ss a"); // TODO: user moment().timezone(IST)
	const currentTimestamp = moment();
	const elapsedMinutes = currentTimestamp.diff(otpTimestamp, "minutes");
	console.debug("OTP was generated", elapsedMinutes, "minutes ago"); // minutes as negative numbers will be also valid e.g. -53 minutes ago
	if (elapsedMinutes >= expiryMinutes) throw { code: "otp/expired" };
	if (otpData.otp === otp) return true;
	throw { code: "otp/invalid" };
}

async function sendOtp(userInput, service = null,otpVersion=constant.VALID_OTP_VERSION.v1) {
	// eslint-disable-next-line no-undef
	return new Promise(async (resolve, reject) => {
		try {
			const phoneNumber = userInput.countryCode + userInput.mobile; // mobile
			userInput.email = await getDummyEmail(phoneNumber); // change for removing email address    
			userInput.isOtpVerify = false;
			const userDetails = await unverifiedUser._getUnverifiedUserData(userInput.mobile, userInput.countryCode, phoneNumber);
			console.debug("userDetails._system",userDetails._system);
			if (configuration.Otp.isUserBlockEnableForSignUp && userDetails._system && userDetails._system.failedAttempt && userDetails._system.failedAttempt.signUp) {
				const isUserBlockedResult = await isUserBlocked(userDetails, "signUp", configuration.Otp.maxNumberOfWrongOtpSignUp, configuration.Otp.blockDurationSignUp);
				console.debug(isUserBlockedResult, "isUserBlockedResult");
				if (isUserBlockedResult) {
          
					return resolve(ApiResponse.error(errorConfig.userlocked.description, errorConfig.userlocked.code));
				}
			}
			let signUpRequest = await generate();
			if (userDetails.mobile) {
				signUpRequest = await checkOtpAttempts(userDetails, "signUpRequest", true);
				if (signUpRequest.code !== undefined && signUpRequest.code === "otp/exceededMaxGenerationLimit") {
					return resolve(ApiResponse.error(errorConfig.otpLimitExceeded.description, errorConfig.otpLimitExceeded.code));
				}
			}
			const updatedData = await unverifiedUser.storeUnverifiedUserWithOTP(userInput, signUpRequest,configuration.actionList.resendOtp,(userDetails._system && userDetails._system.failedAttempt)?userDetails._system.failedAttempt:null);
			if (_.has(updatedData, "status")) {
				return reject(ApiResponse.error(errorConfig.requestFailed, 400));
			}
			const { otp } = signUpRequest;
			const { sms: smsConfig } = Config;
			const { properties: smsProps } = smsConfig;
			const peID = smsConfig.peID.VOOT;
			if (otpVersion === constant.VALID_OTP_VERSION.v1) {
				const { templateId, header } = smsProps.signUp;
				const otpV1Params = {
					destination: phoneNumber,
					otp,
					messageTemplate: template.signUp,
					peID,
					templateId,
					header,
				};
				sendSMS(otpV1Params); // not waiting for it's result
			} else if (otpVersion === constant.VALID_OTP_VERSION.v2) {
				const messageTemplate = template.signUpHashCode.replace("{HASHCODE}", configuration.Otp.otpHashCode);
				console.debug("new temp", messageTemplate);
				const { templateId, header } = smsProps.signUpHashCode;
				const otpV2Params = {
					destination: phoneNumber,
					otp,
					messageTemplate,
					peID,
					templateId,
					header,
				};
				sendSMS(otpV2Params);
			}
			const response = {
				attempts: signUpRequest.attempts,
				maxAttempts: Config.Otp.maxAttempts
			};
			const sendOTPResponse = await responseFormat.phoneNumberResponse(false, response, service);
			return resolve(ApiResponse.success(sendOTPResponse));

		} catch (error) {
			if (!error.code) {
				console.error("No Error Code ", error);
				return reject(ApiResponse.error(errorConfig.requestFailed, 400));
			}
			switch (error.code) {
			//case 'auth/insufficient-permission: // when firebase auth credentials are not provided correctly
			case "otp/exceededMaxGenerationLimit":
				return resolve(ApiResponse.error(errorConfig.otpLimitExceeded.description, errorConfig.otpLimitExceeded.code));
			default:
				console.error("New Error Code, which is not handled: ", error.code);
				return reject(ApiResponse.error(errorConfig.requestFailed, 400));
			}
		}
	});
}

async function getDummyEmail(emailpart) {
	return emailpart + "@voot.com";
}

/**
 * Drops event to message queue to initate SMS
 * @param {object} params 
 * @returns {boolean}
 */
async function handleSmsEvent(params) {
	console.info("Initiating sms via handleSmsEvent");
	const { destination, message, peID, templateId, header, vendor, type = "OTP"} = params;
	const event = {
		eventType: "SEND/NOTIFICATIONS",
		medium: "SMS",
		vendor,
		destination,
		message,
		peID,
		templateId,
		header,
		type
	};
	const { sms: smsConfig } = Config;
	const { sqsQueueUrl: QueueUrl } = smsConfig;
	const messageOptions = {
		QueueUrl,
		MessageBody: JSON.stringify(event),
	};
	await sendMessageSQS(messageOptions);
	return true;
}

/**
 * @param {object} params 
 * @returns 
 */
async function handleKarix(params) {
	console.log("Sending Message from Karix");
	const { destination } = params;
	const sanitizedMobile = destination.replace("+", "");
	const { externalCall, success } = mixPanelConfig;
	const eventName = `${externalCall}OTP_Mobile${success}`;
	const eventData = { mobile: params.phone, distinct_id: params.phone };
	mixpanelService(eventName, eventData, params.phone)
		.catch(err => {
			console.log("Error in sending response to mixpanel from MobileOTP service", err);
		});
	return Karix.sendSMS(sanitizedMobile, params.message);
}

/**
 * @param {object} smsParams 
 */
async function sendSMS(smsParams) {
	try {
		let { destination, otp, messageTemplate, phone = "", peID, templateId, header } = smsParams;
		const message = messageTemplate.replace(/{OTP}/g, otp);
		console.log("Sending OTP: ", otp, " to ", destination);
		console.log("My Destination No", destination);
		const { smsVendor:vendor, smsVersion } = Config.sms;

		if (smsVersion === "V2") {
			const smsV2Params = { destination, message, peID, templateId, header, vendor };
			await handleSmsEvent(smsV2Params);
			return true;
		}

		const { isKarixEnabled } = Config;
		if (isKarixEnabled) {
			const karixParams = { destination, phone };
			await handleKarix(karixParams);
			return true;
		}
		return false;
	} catch (error) {
		console.log("OTP error: ", error.stack);
		const { phone = "" } = smsParams;
		const eventName = `${mixPanelConfig.externalCall}OTP_Mobile${mixPanelConfig.error}`;
		const eventData = {
			mobile: phone,
			distinct_id: phone,
			error: JSON.stringify(error),
			phone
		};
		mixpanelService(eventName, eventData, phone)
			.catch(err => {
				console.log("Error in sending response to mixpanel from MobileOTP service", err);
			});
		return error;
	}
}

async function send(mobile, OTP, messageTemplate,phone="") { // OTP is string so that we can send 0123 also
	try {
		const textToSend = messageTemplate.replace("{OTP}", OTP);
		console.log("Sending OTP: ", OTP, " to ", mobile);
		const sanitizedMobile = mobile.replace("+", ""); // Remove + symbol from country code (e.g +91 = 91)
		let destinationNumber = mobile;
		console.log("My Destination No", destinationNumber);
		// Karix 
		if(Config.isKarixEnabled){
			console.log("Sending Message from Karix");
			mixpanelService(mixPanelConfig.externalCall+"OTP_Mobile"+mixPanelConfig.success,{"mobile":phone,distinct_id:phone },phone).catch(err=>{console.log("Error in sending response to mixpanel from MobileOTP service",err);});
			return await Karix.sendSMS(sanitizedMobile, textToSend);
		}else{
			console.log("My Destination Application Id ", Config.AWS1.applicationId);
			const params = await utility.common.otpMessageFormater(Config, textToSend, destinationNumber);
			await pinpoint.sendMessages(params, function (err, data) {
				// If something goes wrong, print an error message.
				if (err) {
					console.error(err.message);
					mixpanelService(mixPanelConfig.externalCall+"OTP_Mobile"+mixPanelConfig.error,{"mobile":phone,distinct_id:phone, error: JSON.stringify(err), phone }, phone).catch(err=>{console.log("Error in sending response to mixpanel from MobileOTP service",err);});
					// Otherwise, show the unique ID for the message.
				} else {
					console.debug("data", data);
					mixpanelService(mixPanelConfig.externalCall+"OTP_Mobile"+mixPanelConfig.success,{"mobile":phone,distinct_id:phone, phone },phone).catch(err=>{console.log("Error in sending response to mixpanel from MobileOTP service",err);});
					console.log("Message sent! "
            + data["MessageResponse"]["Result"][destinationNumber]["StatusMessage"]);
				}
			});
		}
	} catch (error) {
		console.error("OTP error: ", error);
		mixpanelService(mixPanelConfig.externalCall+"OTP_Mobile"+mixPanelConfig.error,{"mobile":phone,distinct_id:phone, error: JSON.stringify(error), phone }, phone).catch(err=>{console.log("Error in sending response to mixpanel from MobileOTP service",err);}); 
		return error;

	}
}

/**
 * Function to calculate _system object.
 * @param {Object} dbDataObj 
 * @param {String} serviceName 
 * @returns {Object} new_SyetemObject
 */
async function otpVerificationFailed(dbDataObj,serviceName) {
	let newSystemData = {};
	try {
		console.log("dbDataObj", dbDataObj);
		let { _system: { failedAttempt },_system } = dbDataObj;
    
		if (_system) newSystemData = { ..._system };
		if (!newSystemData.failedAttempt) newSystemData.failedAttempt = {};
		if (!newSystemData.failedAttempt[serviceName]) newSystemData.failedAttempt[serviceName] = {};
		if (failedAttempt && failedAttempt[serviceName] && failedAttempt[serviceName].numberOfWrongAttempts) {
			newSystemData.failedAttempt[serviceName].numberOfWrongAttempts = failedAttempt[serviceName].numberOfWrongAttempts + 1;
			newSystemData.failedAttempt[serviceName].lastUpdatedAt= moment();
		}
		else {
			newSystemData.failedAttempt[serviceName].numberOfWrongAttempts = 1;
			newSystemData.failedAttempt[serviceName].lastUpdatedAt= moment();
		}
		return newSystemData;
	}
	catch (err) {
		console.log(err);
		newSystemData.failedAttempt = {};
		newSystemData.failedAttempt[serviceName] = {};
		newSystemData.failedAttempt[serviceName].numberOfWrongAttempts = 1;
		newSystemData.failedAttempt[serviceName].lastUpdatedAt= moment();
		return newSystemData;
		//throw err;
	}
}

function isUserBlocked(dbDataObj, serviceName,maxAttempts,blockDuration) {
	try {
		console.debug("parameter of isUserBlocked: ", serviceName, maxAttempts, blockDuration);
		let { _system: { failedAttempt } , loginStatus } = dbDataObj;
		if (failedAttempt && failedAttempt[serviceName]) {
			const { lastUpdatedAt, numberOfWrongAttempts } = failedAttempt[serviceName];
			const timeDifference = moment().diff(lastUpdatedAt, "seconds", true);
			console.log(timeDifference, "timeDifference");
			console.debug("Status of user", loginStatus);
			console.log(`Conditon is ${timeDifference > blockDuration && (!loginStatus || loginStatus == constant.USER_STATUS.LOCKED)} for auto unlocking.`);
			if (timeDifference > blockDuration && (!loginStatus || loginStatus==constant.USER_STATUS.LOCKED)) {
				delete dbDataObj._system.failedAttempt[serviceName];
				return false;
			}
			if (numberOfWrongAttempts >= maxAttempts) {
				console.debug("user is blocaked");
				return true;
			}
		}
	} catch (err) {
		throw err;
	}
	return false;
}

//need to add new sms template here 
/**
 * send PIN function on mobile
 * @param {String} destinationNumber 
 * @param {String} PIN 
 * @param {String} messageTemplate 
 * @returns 
 */
async function sendPin(destinationNumber, PIN, messageTemplate) { // OTP is string so that we can send 0123 also
	try {
		if(!Config.isKarixEnabled) { 
			console.info(`Config.isKarixEnabled is ${Config.isKarixEnabled}`);
			return false;
		}
		const message = messageTemplate.replace("{OTP}", PIN);
		console.log("messgae",message);
		console.log("Sending PIN: ", PIN, " to ", destinationNumber);
		const { smsVendor:vendor} = Config.sms;
		// Karix 
		const { sms: smsConfig } = Config;
		const peID = smsConfig.peID.VOOT;
		const smsV2Params = {
			destination: destinationNumber,
			message,
			phone: destinationNumber,
			peID,
			templateId: constant.SMS.TEMPLATE.RECOVERY.TEMPLATEID,
			header: constant.SMS.HEADER,
			vendor:vendor,
			type: constant.SMS.TYPE.OTP
		};
		await handleSmsEvent(smsV2Params);
		return true;
	} catch (error) {
		console.log("OTP error: ", error);
		return error;
	}
}

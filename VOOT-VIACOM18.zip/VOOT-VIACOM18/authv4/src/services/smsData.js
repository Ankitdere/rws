const { smsData } = require("../schema");

/**
 * @param {Object} query Query to filter smsdata
 * @returns {{status: Boolean, data: Array}} success status and filtered data
 */
const getData = async function (query = {}) {
	try {
		const data = await smsData.find(query);
		return {
			status: true,
			data,
		};
	} catch (error) {
		console.error("Error in smsData Service", error, error.stack);
		return {
			status: false,
			data: [],
		};
	}
};

module.exports = {
	getData,
};
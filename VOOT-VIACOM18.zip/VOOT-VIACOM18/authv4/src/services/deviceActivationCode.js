const deviceActivationCodeModel = require("../schema").deviceActivationCode;
const config = require("../config").configuration;

module.exports = {
	insertDeviceCode,
	updateDeviceCode,
	deleteDeviceCode,
	getDeviceCode
};

async function insertDeviceCode(deviceId, deviceBrand, code) {
	// eslint-disable-next-line no-undef
	return new Promise(async (res) => {
		const expiresAt = Date.now() + (config.deviceActivation.codeExpirationInSeconds * 1000);
		deviceActivationCodeModel.findOneAndUpdate({ "deviceBrand": deviceBrand, "deviceId": deviceId }, { "code": code, "expiresAt": expiresAt, "deviceId": deviceId, "deviceBrand": deviceBrand, accessToken: "" }, { upsert: true }, function (err, data) {
			if (!err) {
				if (data) {
					data.expiresAt = config.deviceActivation.codeExpirationInSeconds;
					data.code = code;
					res(data);
				} else {
					let expiresAt = config.deviceActivation.codeExpirationInSeconds;
					res({
						expiresAt,
						code
					});
				}
			} else {
				res({ status: 1751, message: "Code not added or updated" });
			}
		});
	});
}

async function getDeviceCode(code) {
	// eslint-disable-next-line no-undef
	return new Promise(async (res) => {
		deviceActivationCodeModel.find({ "code": code }, function (err, data) {
			if (!err) {
				if (data.length > 0)
					res(data[0]);
				else
					res({ status: 1752, message: "Code not found" });
			} else {
				res({ status: 1752, message: "Code not found" });
			}
		});
	});
}

async function updateDeviceCode(code, token) {
	// eslint-disable-next-line no-undef
	return new Promise(async (res) => {
		deviceActivationCodeModel.findOneAndUpdate({ "code": code }, { "accessToken": token }, function (err, data) {
			if (!err) {
				res(data);
			} else {
				res({ status: 1753, message: "Token not updated" });
			}
		});
	});
}

async function deleteDeviceCode(code) {
	// eslint-disable-next-line no-undef
	return new Promise(async (res) => {
		deviceActivationCodeModel.findOneAndDelete({ "code": code }, function (err, data) {
			if (!err) {
				res(data);
			} else {
				res({ status: 1754, message: "Code not deleted" });
			}
		});
	});
}
const ksmUserDevicesCodeModel = require("../schema").ksmuserdevices;

module.exports = {
	insertDeviceCode,
	updateDeviceCode,
	deleteDeviceCode,
	getKSMDevicesByUidAnddeviceId,
	getKSMDevicesByUidAnddeviceIdPrimary
};

async function insertDeviceCode(uid, updateQuery ) {
	// eslint-disable-next-line no-undef
	return new Promise(async (res) => {
		ksmUserDevicesCodeModel.findOneAndUpdate({ "uid": uid },updateQuery, { upsert: true }, function (err, data) {
			if (!err) {
				if (data) {
                
					res(data);
				} else {
					res({ status: 1771, message: "Code not added or updated" });  
				}
			} else {
				res({ status: 1771, message: "Code not added or updated" });
			}
		});
	});
}

async function getKSMDevicesByUidAnddeviceId(uid ,deviceId) {
	// eslint-disable-next-line no-undef
	return new Promise(async (res) => {
		ksmUserDevicesCodeModel.find({ "uid": uid,"deviceId":deviceId }, function (err, data) {
			if (!err) {
				if (data.length > 0)
					res(data[0]);
				else
					res({ status: 1752, message: "Kids Safe Mode Details Not Found" });
			} else {
				res({ status: 1752, message: "Kids Safe Mode Details Not Found" });
			}
		});
	});
}

async function updateDeviceCode(uid, deviceId, updateQuery ,upsert=true) {
	// eslint-disable-next-line no-undef
	return new Promise(async (res) => {
        
		ksmUserDevicesCodeModel.findOneAndUpdate({ "uid": uid,"deviceId":deviceId }, updateQuery, {upsert: upsert ,new :true},function (err, data) {
			console.log("datatat",data);
			console.log("erroror",err);
			if (err){
				console.log("Error in updating userProfile",err);
				res({ status: 1703, message: "User profile not added or updated" });
			}
                
			else{
				console.log("Data after updating userprofile",data);
				res(data);
			}
		});
	});
}

async function deleteDeviceCode(code) {
	// eslint-disable-next-line no-undef
	return new Promise(async (res) => {
		ksmUserDevicesCodeModel.findOneAndDelete({ "code": code }, function (err, data) {
			if (!err) {
				res(data);
			} else {
				res({ status: 1754, message: "Code not deleted" });
			}
		});
	});
}

async function getKSMDevicesByUidAnddeviceIdPrimary(uid ,deviceId) {
	try {
		const data = await ksmUserDevicesCodeModel.find({ "uid": uid,"deviceId":deviceId }).read("primaryPreferred");
		if (data.length > 0) return data[0];
		else return { status: 1752, message: "Kids Safe Mode Details Not Found" };
	}
	catch (err) {
		console.log("Error while data from getUserInformationByIdFromPrimaryPre: ",err);
		return { status: 1752, message: "Kids Safe Mode Details Not Found" };
	}
}
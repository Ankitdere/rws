
"use strict";

const jwt = require("jsonwebtoken");
const _ = require("lodash");
const config = require("../config").configuration;
const errorConfig = require("../config").errorConfig;
// const envConfig = require('../config').envConfig;
const commonUtils = require("../utils").common;
const userService = require("./usersProfile");
const redisService = require("./redisService");
const jwksClient = require("jwks-rsa-promisified");
const crypto = require("crypto");
const moment = require("moment");
const axios = require("axios");
const qs = require("querystring");
const  userProfileService  = require("../services/usersProfile");
const pxApiService= require("../services/pxApiService");
const rp = require("request-promise");
const kafkaService = require("../services/kafkaService");
const notificationService = require("../services/notificationService");
const Constant = require( "../utils/constant/generic" );
const subProfile  = require("../services/subProfile");

// import WDService from "./WDService";
// import LRService from "./LRService";
// import Kaltura from "../repositories/Kaltura";

module.exports = {
	verifyToken,
	createAccessTokenAndRefreshToken,
	refreshAccessToken,
	verifyAuthFirebaseToken,
	accessTokenFromLR,
	//verifyWDAccessToken,
	createAccessTokenForDeleteUser,
	decodeAccessTokenForDeleteUser,
	createAccessTokenForScreenz,
	verifyForgotpasswordToken,
	createAccessTokenForAdminKs,
	verifyAccessTokenForAdminKs,
	validateAppleIdToken,
	validateAppleCode,
	verifyPartnerToken,//TataSky Notification API
	validateAmazoneToken
    
};

/**
 * @param {String} token 
 * @returns {Object}
 */
async function verifyToken(token) {
	try {
		console.debug(`TokenService.verifyToken() is called with token ${token}`);
		const decoded = jwt.verify(token, config.jwt.secret);
		const { 
			uid, iat,childUid = null 
		} = decoded;
		console.info(`decoded ${JSON.stringify(decoded)}`);
		const isPasswordReset = await redisService.getAlreadyRegisteredUser(uid, iat);
		console.debug("redisCheck", isPasswordReset);
		
		if (isPasswordReset == true) {
			console.debug("Invalid Token Due to Password reset in other plateform");
			throw new Error(errorConfig.invalidResetPasswordAccessToken.description);
		}

		if (childUid && childUid !== uid) {
			const redisCheck = await redisService.getAlreadyRegisteredUser(childUid, iat);
			if (redisCheck == true) {
				console.debug("Invalid Token Due to Sub Profile Deleted in other platform");
				throw new Error(errorConfig.invalidTokenAccessToken.description);
			}
		}

		/**
		 * Check if user exists
		 */
		const user = await userService.getUserInformationById(uid);
		if (_.has(user, "status") && user.status === Constant.NO_UID_FOUND) {
			console.log("TokenService.verifyToken() invalid token");
			throw new Error(errorConfig.invalidResetPasswordAccessToken.description);
		}
		console.debug("User exists with uid", decoded.uid);
		decoded.TncAgreement = _.get(user.profileData, "TncAgreement", "");

		/**
		 * Check if non-primary subProfile exists
		 */
		if (childUid && childUid !== uid) {
			const filter={
				childUid:childUid
			};
			const subProfileData = await subProfile.getAllSubProfilesInformation(filter);
			if (subProfileData.status === Constant.NO_UID_FOUND) {
				console.log("TokenService.verifyToken() invalid token");
				throw new Error(errorConfig.invalidTokenAccessToken.description);
			}
			return { decoded, user, subProfileData : subProfileData.data };
		}

		return { decoded, user };
	} catch (error) {
		console.log(`TokenService.verifyToken() error in verifying token ${error}`,error.stack);
		if (error.name === undefined || error.message === undefined) throw (new Error(errorConfig.requestFailed));
		switch (error.message) {
		case "jwt expired":
			throw (new Error(errorConfig.expiredProfileToken.description));
		case "jwt invalid":
		case "jwt malformed":
		case "jwt not active":
		case "jwt signature is required":
		case "invalid signature":
		case "auth/user-not-found":
			throw (new Error(errorConfig.invalidAccessToken.description));
		case "invalid token":
			throw (new Error(errorConfig.invalidAccessToken.description));
		case "Invalid Token Due to Password reset in other plateform":
			throw (new Error(errorConfig.invalidResetPasswordAccessToken.description));
		case "Invalid Token Due to Delete Sub Profile in other platform":
			throw (new Error(errorConfig.invalidTokenAccessToken.description));	
		default:
			throw (new Error(errorConfig.requestFailed));
		}
	}
}

async function createAccessTokenAndRefreshToken(payload, input = false,days=false,partnerData=false,user) {
	try {
		console.log(`TokenService.createAccessTokenAndRefreshToken() with payload: ${JSON.stringify(payload)}`);
		let accessTokenExpiresIn = config.jwt.accessTokenExpiresIn;
		let refreshTokenExpiresIn = config.jwt.refreshTokenExpiresIn;
		if(input){
			accessTokenExpiresIn = config.jwt.accessTokenExpiresIn;
			refreshTokenExpiresIn = config.jwt.refreshTokenExpiresIn;
			payload.identifier = "apple";
		}
		if(days){   
			accessTokenExpiresIn = `${days}`;
			refreshTokenExpiresIn = config.jwt.refreshTokenExpiresIn;
		}
        
    
		const access_token = jwt.sign(payload, config.jwt.secret, { expiresIn: accessTokenExpiresIn, issuer: config.jwt.issuer });
		const refresh_token = jwt.sign(payload, config.jwt.secret, { expiresIn: refreshTokenExpiresIn, issuer: config.jwt.issuer });
		const accessTokenDecoded = jwt.decode(access_token);
		if(partnerData){
			if (_.get(payload, "partnerType") == config.jioSubscription.partnerType && partnerData.endDate) {
				let entitlementstatus = await pxApiService.checkEntitlementStatus(access_token);
				let PXAction=false;
				console.log("entitlementstatus",entitlementstatus);
				if ((new Date(partnerData.endDate).getTime()/1000) < new Date().getTime()/1000) {
					PXAction = config.pXApiDetails.cancelSubcriptionAction;
				}
               
				if (entitlementstatus && entitlementstatus.activeTillDate && entitlementstatus.activeTillDate.timeStamp && _.get(entitlementstatus,"activeTillDate.timeStamp") < (new Date(partnerData.endDate).getTime()/1000)) {
					PXAction = config.pXApiDetails.renewSubcriptionAction;
				}
				if (entitlementstatus && entitlementstatus.lastActiveSubDate && entitlementstatus.lastActiveSubDate.timeStamp && _.get(entitlementstatus,"lastActiveSubDate.timeStamp") < (new Date(partnerData.endDate).getTime()/1000)) {
					PXAction = config.pXApiDetails.renewSubcriptionAction;
				}
				if (_.get(entitlementstatus,"status") == config.pXApiDetails.newSubcriptionAction) {
					PXAction = config.pXApiDetails.newSubcriptionAction;
				}
				console.log("PxAction....",PXAction);
              
				//TODO :after Some Time we will update this into PX condition when our Data is fully Updated
				_.pullAt(partnerData,"externalId");
				_.pullAt(partnerData,"mobileNumber");
				userProfileService.updateUserInformation({uid:_.get(payload,"uid")},{"subscription":partnerData});
				if (PXAction) {
					//Backup case for jio 
					if(PXAction == config.pXApiDetails.newSubcriptionAction){
						let startTime;
						let endTime;
						if (partnerData.activationDate)
							startTime = Math.round(new Date(partnerData.activationDate).getTime() / 1000);
						console.log("Start Date ", startTime);
						if (partnerData.endDate)
							endTime = Math.round(new Date(partnerData.endDate).getTime() / 1000);
						console.log("endTime", endTime);

						let details ={
							details: {
								device: {
									brand: _.get(payload, "deviceBrand", "JIOSTB"),
									id: _.get(payload, "deviceId", user.deviceId),
                                   
								},
								platform: config.jioSubscription.platform,
								subStartDate: startTime,
								subEndDate: endTime,
								partnerName: config.jioSubscription.partnerName
							}};
						console.log("Send details",details);
						const pxOption = await pxApiService.pxOptions(access_token, "POST", details);
						const pxApiResponse = await rp(pxOption);
						console.log("PxApiResponse", pxApiResponse); 
					}else{
						let pxresponse = await pxApiService.callRenewCancelPxApi(_.get(payload,"uid"), access_token, Math.round(new Date(partnerData.endDate).getTime()/1000), PXAction,payload);
						console.log("Px response", pxresponse);
					}
				}
			}
		}
		return ({
			accessToken: access_token,
			refreshToken: refresh_token,
			expirationTime: accessTokenDecoded["exp"]
		});
	} catch (error) {
		console.error(`TokenService.createAccessTokenAndRefreshToken() error in creating tokens ${error}`,error.stack);
		throw (new Error(errorConfig.requestFailed));
	}
}

async function refreshAccessToken(refreshToken, deviceId,partnerData=false,regionInfo="") {
	try {
		const kalturaService = require("./kalturaService");
		console.log(`TokenService.refreshAccessToken() with refreshToken ${refreshToken}`);
		const { decoded ,user} = await verifyToken(refreshToken);
		if (config.kafkaConfig.enable.isUpdateAuth && regionInfo &&
			((regionInfo.region !== user.region) || (regionInfo.country !== user.country))
		) { 
			const regionNotificationObj = await notificationService.createRegionNotification(
				user,
				regionInfo
			);
			kafkaService.pushEventToKafka(config.kafkaConfig.topic.updateAuthData, regionNotificationObj);
		}
		
		if (decoded) {
			let kUserId = _.get(decoded, "kUserId", "");
			let kUserInfo = { id: kUserId };
			deviceId = (deviceId) ? deviceId : _.get(decoded, "deviceId", "");
			if (kUserId.length == 0 || kUserId.length > 8 || kUserId == 0) {
				kUserInfo = await kalturaService.getUserByUsernameOrExternalIdNew(decoded["email"], decoded["uid"]);
			}
			// If identifier is apple then set access tokena validatiy to 1 day and refresh to 30 days, and also validate the refresh token of Apple
			let identifierApple   = _.get(decoded,"identifier","");
			let refreshTokenApple;
			let days=false;
			let partnerType= _.get(decoded,"partnerType");
			let refreshTokenCheck  = false;
			if(identifierApple === "apple"){
				const user   =  await userProfileService.getUserInformationById(decoded.uid);
				const appleUserData    = _.get(user,"profileData");
				refreshTokenApple =  _.get(appleUserData, "AppleUser.appleRefreshToken");
				const aud =  _.get(appleUserData, "AppleUser.aud");
				//    Now verify the apple refresh Token
				await this.validateAppleCode(refreshTokenApple, aud, "refresh_token");
				refreshTokenCheck = true;
			}
			if(partnerType==="JIO"&& partnerData){
				if(_.has(partnerData,"endDate")){
					console.log("Subscription End date",_.get(partnerData,"endDate"));
					days = commonUtils.tokenDateCalculator(_.get(partnerData,"endDate"));
					console.log("No. of Days need to change the Tokentime",days);
				}
			} 
			return await createAccessTokenAndRefreshToken({ uid: decoded["uid"], email: decoded["email"], kUserId: _.get(kUserInfo, "id"), deviceId: deviceId,partnerType:_.get(decoded,"partnerType","")},refreshTokenCheck,days,partnerData,user);
		}
	} catch (error) {
		console.error(`TokenService.getAccessToken() with ${error}`);
		throw error;
	}
}

function verifyAuthFirebaseToken(authToken) {
	let decoded = jwt.decode(authToken);
	let expTime = _.get(decoded, "exp", 0);
	// console.log('expTime ::: =========== ', expTime);
	if (expTime === 0) {
		return false;
	}
	let currentTime = Math.floor(new Date().getTime() / 1000);
	if (expTime > currentTime) {
		return decoded;
	}
	return false;
}

async function accessTokenFromLR(acceessToken) {
	if (acceessToken.length === 36) {
		console.info("TokenService.getAccessToken() calling WD");
		let decoded = await this.verifyWDAccessToken(acceessToken);

		// if token is expired  then call refresh accessToken API.           
		if (!_.has(decoded, "Uid") && _.get(decoded, "errorCode") == 906) {
			// eslint-disable-next-line no-undef
			const refreshToken = await LRService.apiRequest(acceessToken);

			if (_.has(refreshToken, "access_token")) {
				decoded = await this.verifyWDAccessToken(_.get(refreshToken, "access_token"));
			}
		}

		if (!_.has(decoded, "Uid") && _.has(decoded, "errorCode"))
			throw (new Error(_.get(decoded, "message", errorConfig.invalidAccessToken.description)));
		return decoded;
	}
	throw (new Error(errorConfig.invalidAccessToken.description));
}

/* async function verifyWDAccessToken(accessToken) {
    try {
        const result = await WDService.getProfileByAccessToken(accessToken);

        if (!_.has(result, 'Uid') && _.has(result, 'errorCode'))
            return result;
        if (result && _.get(result, 'Uid') && _.get(result, 'Email')) {
            let emails;
            if (_.get(result, 'Email', []).length > 0) {
                emails = _.filter(result.Email, { 'Type': 'Primary' });
            } else if (_.get(result, 'Identities', []).length > 0) {
                emails = _.filter(result.Identities[0].Email, { 'Type': 'Primary' });
            }
            const decoded = {
                uid: _.get(result, 'Uid'),
                email: emails[0].Value
            }
            return decoded;
        }
        else {
            if (result && (result['message'] === errorconfig.wdTokenExpired)) {
                throw (new Error(errorconfig.expiredProfileToken));
            }
            else {
                throw (new Error(errorconfig.invalidAccessToken));
            }
        }
    } catch (err) {
        return (err);
    }
}
 */
async function createAccessTokenForDeleteUser() {
	try {
		const tokenDeleteUser = jwt.sign({ "email": "vootbackendtest@voot.com" }, config.jwtDeleteUser.secret, { expiresIn: config.jwtDeleteUser.tokenexpiresin, issuer: config.jwtDeleteUser.issuer });
		return tokenDeleteUser;
	} catch (error) {
		console.log(`TokenService.createAccessTokenForDeleteUser() error in creating tokens ${error}`);
		throw (new Error(errorConfig.requestFailed));
	}
}

async function decodeAccessTokenForDeleteUser(token) {
	try {
		const decoded = jwt.verify(token, config.jwtDeleteUser.secret);
		console.log(`decoded ${JSON.stringify(decoded)}`);
		return decoded;
	} catch (error) {
		console.log(`TokenService.decodeAccessTokenForDeleteUser() error in creating tokens ${error}`);
		return false;
	}
}

async function createAccessTokenForScreenz(lastLoginProvider, profileId, decoded, userDetails) {
	try {
		let birthDate = commonUtils.dateFormat(_.get(userDetails, "profileData.BirthDate", "").split("/").join("-"));
		//let ageCalculation = new Date().getFullYear() - Number(birthDate.split('-')[2]);
		birthDate = String(birthDate);
		if (_.isEmpty(birthDate)) {
			birthDate = undefined;
		}
		let screenzPayload = {
			UID: decoded.uid,
			userName: _.get(userDetails, "profileData.FirstName") ? _.get(userDetails, "profileData.FirstName") : _.get(userDetails, "profileData.ProfileName"),
			loginProvider: lastLoginProvider,
			socialId: profileId ? profileId : undefined,
			socialProfileLink: _.get(userDetails, "profileData.ProfileUrl") ? _.get(userDetails, "profileData.ProfileUrl") : undefined,
			imageUrl: _.get(userDetails, "profileData.ImageUrl") ? _.get(userDetails, "profileData.ImageUrl") : undefined,
			gender: _.get(userDetails, "profileData.Gender") ? _.get(userDetails, "profileData.Gender") : undefined,
			age: birthDate,
			name: _.get(userDetails, "profileData.FirstName") ? _.get(userDetails, "profileData.FirstName") : _.get(userDetails, "profileData.ProfileName"),
			email: _.get(userDetails, "email") ? _.get(userDetails, "email") : _.get(decoded, "email"),
			UDID: decoded.uid,
			sex: _.get(userDetails, "profileData.Gender") ? _.get(userDetails, "profileData.Gender") : undefined,
			extraData: "voot"
		};
		const screenzToken = await jwt.sign(screenzPayload, config.jwtScreenzUser, { expiresIn: config.jwt2.accessTokenExpiresIn });
		return { accessToken: screenzToken };
	} catch (error) {
		console.log(`TokenService.createAccessTokenForScreenz() error in creating tokens ${error}`);
		throw (new Error(errorConfig.requestFailed));
	}
}

async function verifyForgotpasswordToken(token) {
	try {
		console.log(`Forgot Password TokenService.verifyToken() is called with token ${token}`);
		const decoded = jwt.verify(token, config.jwtForgotPassword.secret);
		console.log(`decoded ${JSON.stringify(decoded)}`);
		const user = await userService.getUserInformationById(decoded.uid);
		// if(_.get(user,'status')){
		//     console.log(`TokenService.verifyForgotpasswordToken() user not foundWith that uid`);
		//     throw (new Error(message.invalidAccessToken));
		// }
		if (user) {
			console.log("User exists with uid", decoded.uid);
			return { decoded, user };
		} else {
			console.log("TokenService.verifyForgotpasswordToken() invalid token");
			throw (new Error(errorConfig.invalidAccessToken));
		}
	} catch (error) {
		console.log(`TokenService.verifyForgotpasswordToken() error in verifying token ${error}`);
		if (error.name === undefined || error.message === undefined) throw (new Error(errorConfig.requestFailed));
		switch (error.message) {
		case "jwt expired":
			throw (new Error(errorConfig.expiredProfileToken.description));
		case "jwt invalid":
		case "jwt malformed":
		case "jwt not active":
		case "jwt signature is required":
		case "invalid signature":
		case "auth/user-not-found":
			throw (new Error(errorConfig.invalidAccessToken.description));
		case "invalid token":
			throw (new Error(errorConfig.invalidAccessToken.description));
		default:
			throw (new Error(errorConfig.requestFailed));
		}
	}
}

async function createAccessTokenForAdminKs(payload) {
	try {
		const tokenDeleteUser = jwt.sign(payload, config.jwtadminKsToken.secret, { expiresIn: config.jwtadminKsToken.tokenexpiresin, issuer: config.jwtadminKsToken.issuer });
		return tokenDeleteUser;
	} catch (error) {
		console.log(`TokenService.createAccessTokenForDeleteUser() error in creating tokens ${error}`);
		throw (new Error(errorConfig.requestFailed));
	}
}

async function verifyAccessTokenForAdminKs(token) {
	try {
		const decoded = jwt.verify(token, config.jwtadminKsToken.secret);
		console.log(`decoded ${JSON.stringify(decoded)}`);
		return decoded;
	} catch (error) {
		console.log(`TokenService.decodeAccessTokenForDeleteUser() error in creating tokens ${error}`);
		switch (error.message) {
		case "jwt expired": throw { expired: true };
		}
	}
}

/**
 * Function  used to validate Apple Id token with following conditions
 * Verify the JWS E256 signature using the server’s public key
 *   Verify the nonce for the authentication
 *   Verify that the iss field contains https://appleid.apple.com
 *   Verify that the aud field is the developer’s client_id
 *   Verify that the time is earlier than the exp value of the token
 *
 * @param idToken Apple Id Token.
 * @param rawNonce Raw Nonce value used while sign in to Apple
 * @return  
 */
async function validateAppleIdToken(idToken, rawNonce) {
	try {
		console.debug("Dao Validating Apple Id Token ");
		const jwtDecoded = jwt.decode(idToken, { complete: true });
		const kId = jwtDecoded.header.kid;
		const client = jwksClient({
			jwksUri: config.ApppleSignIn.appleApiKeys
		});
		const key = await client.getSigningKeyAsync(kId);
		const signingKey = key.publicKey || key.rsaPublicKey;
		const hashedNonceHex = crypto.createHash("sha256").update(rawNonce).digest().toString("hex");
		return await jwt.verify(idToken, signingKey,
			{
				"nonce": hashedNonceHex,
				"issuer": config.ApppleSignIn.aud,
				"audience": config.ApppleSignIn.audienceArr
			});

	} catch (error) {
		console.log(`TokenService.validateAppleIdToken() error in creating tokens ${error}`,error.stack);
		// error.message = "jwt nonce invalid. expected: 052db1c4d02533";
		if (error.message.match(/jwt nonce invalid/g)) {
			throw { code: "apple/invalid-nonce" };
		}
		switch (error.message) {
		case "jwt expired": throw { code: "apple/token-expired" };
		}
		throw { code: "apple/invalid-id-token" };
	}

}

/**
 * Static Function  used to validate Apple Auth Code
 *   It generate client_secret
 *
 * @param authCode Apple auth Code
 * @return  
 */
async function validateAppleCode(authCode = "", audience, grantType = "authorization_code", redirectUrl = config.ApppleSignIn.redirectURL) {
	try {
		// Secret Can be stored in DB as we can set its validity to max 6 months
		const secret = await get_client_secret(audience);
		let requestToken;
		if (grantType === "authorization_code") {
			requestToken = {
				grant_type: grantType,
				code: authCode,
				client_secret: secret,
				client_id: audience,
				redirect_uri: redirectUrl,
			};
		} else if (grantType === "refresh_token") {
			requestToken = {
				grant_type: grantType,
				refresh_token: authCode,
				client_secret: secret,
				client_id: audience,
				redirect_uri: config.ApppleSignIn.redirectURL,
			};
		}
		let result = await axios.post(
			config.ApppleSignIn.tokenAPI,
			qs.stringify(requestToken),
			{
				headers: {
					"Content-Type": "application/x-www-form-urlencoded",
				},
			});
		return result.data;
	} catch (errorApple) {
		console.log("Error getting apple access and refresh token", errorApple,errorApple.stack);
		throw { code: "apple/invalid-id-token" };
	}

}
/**
 *  Function  used to geneerate the client secret for apple token API 
 *   It generate client_secret
 *
 * @param audience Web Service Id or App bundle Id
 * @return  Client Secret
 */
async function get_client_secret(isrn) {
	try {
		const claims = {
			"iss": config.ApppleSignIn.teamId,
			"aud": config.ApppleSignIn.aud,
			"exp": parseInt(moment().add(5, "months").format("X")),
			"iat": moment().unix(),
			"sub": isrn
		};
		const options = {
			algorithm: "ES256",
			keyid: config.ApppleSignIn.keyId
		};
		return jwt.sign(claims, config.ApppleSignIn.applePrivateKey, options);

	} catch (err) {
		console.log("Error generating client secret", err);
	}

}
async function verifyPartnerToken(token,partnerType) {
	let decoded;
	try {
		switch (partnerType) {
		case (config.tSkyDetails.partnerType):
			console.log(`TokenService.verifyPartnerToken() is called with token ${token}`);
			decoded= jwt.verify(token, config.tSkyDetails.jwtPartnerNotification);
			console.log(`decoded ${JSON.stringify(decoded)}`);
			break;
		case (config.M2MITDetails.partnerName):
			console.debug("Is Certificate Enabled for M2MIT",config.M2MITDetails.certificationEnable);
			console.debug("type Of certificate enable",typeof config.M2MITDetails.certificationEnable);
			if (process.env.VOOT_ENV=="prod") {
				console.log(`TokenService.verifyPartnerM2MITToken() with ceritficate is called with token ${token}`);
				let cert = config.M2MITDetails.certificate;
				console.log("Cerificate Loaded...",!_.isEmpty(cert));
				decoded= jwt.verify(token, cert, { algorithms: ["RS256"] });
				console.log(`decoded ${JSON.stringify(decoded)}`);
			} else {
				console.log(`TokenService.verifyPartnerM2MITToken() without cerificate is called with token ${token}`);
				decoded = jwt.verify(token, config.M2MITDetails.jwtPartnerNotification);
				console.log(`decoded ${JSON.stringify(decoded)}`);
			}
			break;
		}
		return decoded;
       
	} catch (error) {
		console.error(`TokenService.verifyPartnerToken() error in verifying token ${error}`);
		if (error.name === undefined || error.message === undefined) throw (new Error(error.message.requestFailed));
		switch (error.message) {
		case "jwt expired":
			throw (new Error(errorConfig.invalidPartnerToken.description));
		case "jwt invalid":
		case "jwt malformed":
		case "jwt not active":
		case "jwt signature is required":
		case "invalid signature":
		case "invalid algorithm":
		case "auth/user-not-found":
			throw (new Error(errorConfig.invalidAccessToken.description));
		case "invalid token":
			throw (new Error(errorConfig.invalidPartnerToken.description));
		default:
			throw (new Error(errorConfig.requestFailed));
		}
	}
}
/**
     * Static Function  used to Get Information From Amazon Auth Token
     *   It return token Information
     *
     * @param amazonToken Amazon auth Code
     * @return  
     */
async function validateAmazoneToken(amazonToken) {
        
	try{  
            
		let result =   await axios.get(
			config.AmazonDetails.getTokenInfoUrl,
			{
				params: {
					"access_token": amazonToken,
				},
			});
		console.log("Result of Amazon Token",result.data);
		return result.data;
	}catch(errorAmazon){
		console.log("Error getting Amazon Details",errorAmazon);
		throw { code: "amazon/invalid-id-token" };
	}
        
}

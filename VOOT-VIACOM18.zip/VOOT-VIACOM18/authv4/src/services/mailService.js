"use strict";
const mailer = require("nodemailer");
const config = require("../config").configuration;

const mixpanelService = require("../services/mixpanelService");
const mixPanelConfig = require("../config/mixPanelConfig");

/**
 * @param {Boolean} hasPassed checking whether mailService working successfully or not
 * @param {Object} mixpanelEventData
 * @param {String} distinctId emailAddress
 */
async function dropToMixpanel(hasPassed, mixpanelEventData, distinctId) {
	try{
		const mixpanelEventName = {
			success: mixPanelConfig.externalCall + "Mail" + mixPanelConfig.success,
			failure: mixPanelConfig.externalCall + "Mail" + mixPanelConfig.error,
		};
		const eventName = hasPassed ? mixpanelEventName.success : mixpanelEventName.failure;
		await mixpanelService(eventName, mixpanelEventData, distinctId);
	} catch(error) {
		console.error("Error in sending response to mixpanel from mail service", error);
	}
}

/**
 * @param {String} emailAddress 
 * @param {String} subject 
 * @param {String} emailBody 
 * @returns {string} messageId
 */
async function sendMail(emailAddress, subject, emailBody) {
	// setup email data with unicode symbols
	const mailOptions = {
		from: `"${config.Mailer.fromName}" ${config.Mailer.fromEmail}`,
		// cc: cc,
		to: emailAddress,
		subject: subject,
		html: emailBody
	};
	let mixPanelEventData = {};
	try {
		const transporter = mailer.createTransport(config.Mailer.credential);
		const info = await transporter.sendMail(mailOptions);
		const {
			messageId
		} = info;
		console.log("info.messageId: ", messageId);
		mixPanelEventData = {
			email: emailAddress,
			distinct_id: emailAddress,
			messageId,
		};
		dropToMixpanel(true, mixPanelEventData, emailAddress);
		return messageId;
	} catch (error) {
		mixPanelEventData = {
			input: mailOptions,
			distinct_id: emailAddress,
			error: error.message
		};
		dropToMixpanel(false, mixPanelEventData, emailAddress);
		console.error("Error in send mail", error.message);
		throw error;
	}
}

module.exports = {
	sendMail,
};
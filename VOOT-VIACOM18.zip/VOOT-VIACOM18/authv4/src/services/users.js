const users = require("../schema").users;

module.exports = {
	getUserById,
	getUserByEmail,
	insertUser,
	updateOrInsertUser,
	updateUser,
	getUserByFbUid,
	getUserByGUid,
	getUsersByEmail,
	getUserByPhone,
	setCustomUserClaims,
	getAllUserRecordsByEmail,
	getUserByIdFromPrimaryPre

};

async function getUserById(uid) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		users.find({ "uid": uid }, function (err, data) {
			if (!err) {
				if (data.length > 0)
					res(data[0]);
				else
					res({ status: 1799, message: "Auth Uid not found" });
			} else {
				res({ status: 1799, message: "Auth Uid not found" });
			}
		});
	});
}

async function getUserByEmail(email) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		users.find({ "email": email }, function (err, data) {
			if (!err) {
				if (data.length > 0)
					res(data[0]);
				else
					res({ status: 1798, message: "Auth Email not found" });
			} else {
				res({ status: 1798, message: "Auth Email not found" });
			}
		}).limit(5);
	});
}

async function getUserByFbUid(id) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		users.find({ "fbuid": id }, function (err, data) {
			if (!err) {
				if (data.length > 0)
					res(data[0]);
				else
					res({ status: 1796, message: "Auth FB not found" });
			} else {
				res({ status: 1796, message: "Auth FB not found" });
			}
		}).limit(5);
	});
}

async function getUserByGUid(id) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		users.find({ "guid": id }, function (err, data) {
			if (!err) {
				if (data.length > 0)
					res(data[0]);
				else
					res({ status: 1795, message: "Auth Google not found" });
			} else {
				res({ status: 1795, message: "Auth Google not found" });
			}
		}).limit(5);
	});
}

async function insertUser(userInput) {
	try {
		const user = new users(userInput);
		return await user.save();
	} catch (err) {
		throw err;
	}
}

async function updateOrInsertUser(query, updateQuery) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		users.findOneAndUpdate(query, updateQuery, { upsert: true }, function (err, data) {
			if (err)
				res({ status: 1794, message: "User not added or updated"});
			else
				res(data);
		});
	});
}

async function getUsersByEmail(email) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		users.find({ "email": email }, function (err, data) {
			if (!err) {
				if (data.length > 0)
					res(data);
				else
					res({ status: 1793, message: "Auth Email not found" });
			} else {
				res({ status: 1793, message: "Auth Email not found" });
			}
		}).limit(5);
	});
}

async function setCustomUserClaims(userUid, linkedUserId){
	// eslint-disable-next-line no-undef
	return await Admin.auth().setCustomUserClaims(userUid, { customUid: linkedUserId });
}

async function getUserByPhone(mobile) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		users.find({ "phoneNumber": mobile }, function (err, data) {
			if (!err) {
				console.debug(data);
				if (data.length > 0)
					res(data);
				else
					res({ status: 1792, message: "Auth mobile not found" });
			} else {
				res({ status: 1792, message: "Auth mobile not found" });
			}
		}).limit(5);
	});
}

async function getAllUserRecordsByEmail(email) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		users.find({ "email": email }, function (err, data) {
			if (!err) {
				if (data.length > 0)
					res(data);
				else
					res({ status: 1798, message: "Auth Email not found" });
			} else {
				res({ status: 1798, message: "Auth Email not found" });
			}
		}).limit(5);
	});
}

async function getUserByIdFromPrimaryPre(uid) {
	try {
		const data = await users.find({uid}).read("primaryPreferred");
		if (data.length > 0) return data[0];
		else return { status: 1799, message: "Auth Uid not found" };
	}
	catch (err) {
		console.log("Error while data from getUserInformationByIdFromPrimaryPre: ",err);
		return { status: 1799, message: "Auth Uid not found" };
	}
}

async function updateUser(query, updateQuery) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		users.findOneAndUpdate(query, updateQuery, { new: true , useFindAndModify: true}, function (err, data) {
			if (err)
				res({ status: 1794, message: "User not added or updated"});
			else
				res(data);
		});
	});
}

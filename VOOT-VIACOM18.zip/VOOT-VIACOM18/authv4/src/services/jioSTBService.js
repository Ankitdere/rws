"use strict";

const _ = require("lodash");
const rp = require("request-promise");
const envConfig = require("../config").configuration;
const apiResponse = require("../utils").apiResponse;
const { errorConfig } = require("../config");
const jioCryptoService = require("./jioCryptoService");
const { getSha256Hash } = require("../utils").legacyHash;
const usersProfileService = require("./usersProfile");
const mixpanelEvent=require("./mixpanelService");
const mixpanelEventConfig=require("../config/mixPanelConfig");

module.exports = {
	jioUserDetails,
	checkSSOAndJioSub
};

async function jioUserDetails(input) {
	try {
		let { isPremium, partnerDetails } = await checkSSOAndJioSub(input);
		// let isPremium = true
		// const partnerDetails = { 'mobileNumber': '+917388882222', 'externalId': '1372860654', 'serviceType': 'Z0075', 'planId': '1115392', 'planName': 'Voot Select And Voot kids', 'startDate': '2020-12-15T21:38:47', 'endDate': '2021-12-15T21:38:47', 'activationDate': '2020-08-12T00:43:57' }

		const partnerData = await getJioPartnerInfo(partnerDetails);
		// firebase to be called here if data not found in mongo
		const promiseResolution  = await usersProfileService.getPartnerDetailsByExternalId(partnerData.externalId, input.partnerType);
		console.log("promise........",promiseResolution);
		let userData= _.get(promiseResolution,"userData","");
		let dbName= _.get(promiseResolution,"dbName","");
		console.debug("promise........",userData);
		console.debug("promise........",dbName);
		const uid =_.get(userData,"uid");
		mixpanelEvent(mixpanelEventConfig.partnerSignIn+_.get(input,"partnerType")+mixpanelEventConfig.partnerCall_Success,
			partnerData,
			_.get(input.data,"externalId"),
			_.get(input.data,"externalId"),null,false);
		if ((uid == null) && new Date(partnerData.subscription.endDate).getTime() < new Date().getTime()) {
			throw { code: "partner/user-plan-expired" };
		}
		return { uid,userData , partnerData, isPremium ,dbName};
	} catch (error) {
		if (error.code) throw error;
		if (_.has(error, "error.errors[0]")) {
			throw apiResponse.error(errorConfig.partnerInvalidToken.description, errorConfig.partnerInvalidToken.code);
		}
		throw apiResponse.error(errorConfig.partnerInvalidToken.description, errorConfig.partnerInvalidToken.code);
	}
}

function createOptionsForJioSubscription(input, tokenHashInfo) {
	let options = {
		method: "POST",
		url: `https://${envConfig.jioSubscription.sslHost}/partner/ott/ftth/v1/subscription/details`,
		headers: {
			"x-api-key": envConfig.jioSubscription.xAPIkey,
			"app-name": envConfig.jioSubscription.appName,
			"sso-token": input.data.token
		},
		body: tokenHashInfo,
		json: true
	};
	if (envConfig.jioSubscription.certificationEnable) {
		options.agentOptions = {
			cert: envConfig.jioSubscription.certificate,
			key: envConfig.jioSubscription.key,
			passphrase: envConfig.jioSubscription.passphrase
		};
	}
	return options;
}
async function checkSSOAndJioSub(input) {
	let jioSubscriptionResult;
	try {
		let isPremium = true;
		let tokenHashInfo = await getHashAndDateTime(input.data.token);
		let optionsSubscriptionInfo = createOptionsForJioSubscription(input, tokenHashInfo);
		jioSubscriptionResult = await rp(optionsSubscriptionInfo);
		console.log("JIO Request Sent:", optionsSubscriptionInfo);
		console.log("JIO API Response:", jioSubscriptionResult);
		if (!jioSubscriptionResult || jioSubscriptionResult.success == "false") {
            
			mixpanelEvent(mixpanelEventConfig.partnerSignIn+_.get(input,"partnerType")+mixpanelEventConfig.partnerCall_Error,
				jioSubscriptionResult,
				_.get(input.data,"externalId"),
				_.get(input.data,"externalId"),null,false);
			console.log("JIO Sub Error:", jioSubscriptionResult);
			if (jioSubscriptionResult.errors && jioSubscriptionResult.errors[0] && jioSubscriptionResult.errors[0].code === "NO_DATA_FOUND") 
			{ 
				await checkErrorTypeToSendIntoMP(jioSubscriptionResult.errors[0].code,input);
				throw { code: "partner/user-not-subscribed" };
			}
			if (jioSubscriptionResult.errors && jioSubscriptionResult.errors[0] && jioSubscriptionResult.errors[0].code === "NO_DATA_FOUND" && jioSubscriptionResult.errors[0].reason == "No Subscription IDs Found for given customer id and service type")
			{
				throw { code: "partner/user-not-subscribed" };
			}
			throw { code: "partner/invalid-token" };
		}
		const partnerDetails = await getJioSubscriptionInfo(jioSubscriptionResult, input.data);
		console.log("partnerDetails", partnerDetails);
		return { isPremium, partnerDetails };
	} catch (error) {
		console.error("JIO Sub Error2:", error);
		await checkErrorTypeToSendIntoMP(error,input);
        
        
		if (error.message == errorConfig.partnerInvalidToken.description) {
			throw apiResponse.error(errorConfig.partnerInvalidToken.description, errorConfig.partnerInvalidToken.code);
		}
		throw apiResponse.error(errorConfig.partnerInvalidToken.description, errorConfig.partnerInvalidToken.code);
	}
}
async function getJioSubscriptionInfo(jioSubscriptionResponse, input) {
	try {
		const decryptedMobileNumber = await jioCryptoService.decrypt(_.get(jioSubscriptionResponse, "mobileNumber", ""), input.token);
		return {
			mobileNumber: decryptedMobileNumber,
			externalId: _.get(input, "externalId"),
			serviceType: jioSubscriptionResponse.planOfferings[0].digitalServices[0].serviceType ? jioSubscriptionResponse.planOfferings[0].digitalServices[0].serviceType : "",
			planId: jioSubscriptionResponse.planOfferings[0].digitalServices[0].planSpecification.id,
			planName: jioSubscriptionResponse.planOfferings[0].digitalServices[0].planSpecification.name ? jioSubscriptionResponse.planOfferings[0].digitalServices[0].planSpecification.name : "",
			startDate: jioSubscriptionResponse.planOfferings[0].digitalServices[0].startDate ? jioSubscriptionResponse.planOfferings[0].digitalServices[0].startDate : "",
			endDate: jioSubscriptionResponse.planOfferings[0].digitalServices[0].endDate ? jioSubscriptionResponse.planOfferings[0].digitalServices[0].endDate : "",
			activationDate: jioSubscriptionResponse.planOfferings[0].digitalServices[0].activationDate ? jioSubscriptionResponse.planOfferings[0].digitalServices[0].activationDate : ""
		};

	} catch (err) {
		return {
			externalId: _.get(input, "externalId")
		};
	}
}

async function getJioPartnerInfo(partnerData) {
	try {
		return {
			mobile: _.get(partnerData, "mobileNumber", ""),
			externalId: _.get(partnerData, "externalId", ""),
			subscription: {
				serviceType: _.get(partnerData, "serviceType", ""),
				planId: _.get(partnerData, "planId", ""),
				planName: _.get(partnerData, "planName", ""),
				startDate: _.get(partnerData, "startDate", ""),
				endDate: _.get(partnerData, "endDate", ""),
				activationDate: _.get(partnerData, "activationDate", "")
			}
		};
	} catch (error) {
		throw { code: "partner/user-not-subscribed" };
	}
}

async function getHashAndDateTime(ssoToken) {
	let today = new Date();
	let date = `${today.getFullYear()}-${(today.getMonth() + 1)}-${today.getDate()}`;
	let time = `${today.getHours()}:${today.getMinutes()}:${today.getSeconds()}.${today.getMilliseconds()}`;
	let dateTime = `${date}T${time}`;
	let hashData = `${envConfig.jioSubscription.xAPIkey}~${ssoToken}~${dateTime}`;
	let token = await getSha256Hash(hashData);
	return {
		checksum: token,
		timestamp: dateTime
	};
}
async function checkErrorTypeToSendIntoMP(error, input) {
	console.log("statusCode", _.get(error, "statusCode"));
	console.log("error.message", _.get(error, "message"));
	try {
		if (_.get(error, "statusCode") == 400) {
			mixpanelEvent(mixpanelEventConfig.partnerSignIn + _.get(input, "partnerType") + mixpanelEventConfig.partnerCall_Error,
				{ ErrorMessage: _.get(error, "message") },
				_.get(input.data, "externalId"),
				_.get(input.data, "externalId"),
				null,
				false
			);
		} else if (_.get(error, "statusCode") == 500) {
			mixpanelEvent(mixpanelEventConfig.partnerSignIn + _.get(input, "partnerType") + mixpanelEventConfig.partnerCall_Error,
				{ ErrorMessage: _.get(error, "message") },
				_.get(input.data, "externalId"),
				_.get(input.data, "externalId"),
				null,
				false
			);}
		else if (_.has(error, "reason")) {
			mixpanelEvent(mixpanelEventConfig.partnerSignIn + _.get(input, "partnerType") + mixpanelEventConfig.partnerCall_Error,
				{ ErrorMessage: _.get(error, "reason")},
				_.get(input.data, "externalId"),
				_.get(input.data, "externalId"),
				null,
				false
			);
		}
	} catch (err){
		console.log("Error in Sending the Mixpanel",err);
	}
}

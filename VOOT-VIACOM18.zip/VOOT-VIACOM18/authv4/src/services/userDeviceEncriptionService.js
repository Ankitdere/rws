let crypto = require("crypto");
const configuration = require("../config").configuration;
const _ = require("lodash");
const ksmUserDeviceService = require("./ksmUserDevice");
module.exports = {
	encryptStringWithSymmetricKey,
	decryptStringWithSymmetricKey,
	syncListBetweenThePlatform
};

async function encryptStringWithSymmetricKey(toEncrypt, device, plateform) {
	console.log("Device and Plate form", device, plateform);
	let algorithm = configuration.ksmPlatformAndDeviceConfig["ksm"][device][plateform]["algorithm"];
	let privateKey = configuration.ksmPlatformAndDeviceConfig["ksm"][device][plateform]["privateKey"];
	let publicKey = configuration.ksmPlatformAndDeviceConfig["ksm"][device][plateform]["publicKey"];
	let outputEncoding = configuration.ksmPlatformAndDeviceConfig["ksm"][device][plateform]["outputEncoding"];

	let cipher = crypto.createCipheriv(algorithm, Buffer.from(privateKey), Buffer.from(publicKey));
	let encrypted = cipher.update(toEncrypt);
	encrypted = Buffer.concat([encrypted, cipher.final()]);
	return encrypted.toString(outputEncoding);
	//return ciphertext
}

async function decryptStringWithSymmetricKey(toDecrypt, device, plateform) {
	try {
		let ksm_private_Key = configuration.ksmPlatformAndDeviceConfig["ksm"][device][plateform]["privateKey"];
		let algorithm = configuration.ksmPlatformAndDeviceConfig["ksm"][device][plateform]["algorithm"];
		let publicKey = configuration.ksmPlatformAndDeviceConfig["ksm"][device][plateform]["publicKey"];
		let outputEncoding = configuration.ksmPlatformAndDeviceConfig["ksm"][device][plateform]["outputEncoding"];
		//let inputEncoding = configuration.ksmPlatformAndDeviceConfig['ksm'][device][plateform]['inputEncoding'];
		//let bufferEncoding = configuration.ksmPlatformAndDeviceConfig['ksm'][device][plateform]['bufferEncoding'];
		let encryptedText = Buffer.from(toDecrypt, outputEncoding);
		let decipher = crypto.createDecipheriv(algorithm, Buffer.from(ksm_private_Key), Buffer.from(publicKey));
		let decrypted = decipher.update(encryptedText);
		decrypted = Buffer.concat([decrypted, decipher.final()]);
		return decrypted.toString();
		//return deciphered;

	} catch (e) {
		console.log("Error in decryption", e);
	}
}

async function syncListBetweenThePlatform(platform, device, uid, ksmDetailsObject, upsert) {
	// Retrive All Devices &  Platform from Configuration for Validation Purpose
	try {
		//Check platform is Present to Sync Between tooo
		console.log("My Platform.......", platform);
		console.log("My device.......", device);
		if (_.get(configuration.ksmConfig.platformSync, `${device}:${platform}`)) {


			for (let platformTo in configuration.ksmConfig.platformSync[`${device}:${platform}`]) {
				console.log("PlatformTOO ", platformTo);
				let SyncTO =_.split(platformTo,":");
				let syncDeviceTo = {"device":SyncTO[0],"platform":SyncTO[1]};
				console.log("PlatformTOO33 ", platformTo);
				console.log("PlatformTOOOOOO ", configuration.ksmConfig.platformSync[`${device}:${platform}`][platformTo]);
				let isEnableSyncValue = _.get(configuration.ksmConfig.platformSync[`${device}:${platform}`][platformTo], "isEnable");
				let filterObject = {};
				if (isEnableSyncValue) {
					for (let key in configuration.ksmConfig.platformSync[`${device}:${platform}`][platformTo]) {

						if (_.get(configuration.ksmConfig.platformSync[`${device}:${platform}`][platformTo], key) == true) {
							filterObject[key] = ksmDetailsObject[key];
						}
						//  console.log("filterObject[key]", filterObject[key]);
					}
				}
				console.log("filterObject[key]1234", configuration.ksmConfig.staticDataSync[`${device}:${platform}`][platformTo]);
				if (configuration.ksmConfig.staticDataSync && configuration.ksmConfig.staticDataSync[`${device}:${platform}`] && configuration.ksmConfig.staticDataSync[`${device}:${platform}`][platformTo] && configuration.ksmConfig.staticDataSync[`${device}:${platform}`][platformTo]) {
					let staticData = configuration.ksmConfig.staticDataSync[`${device}:${platform}`][platformTo];
					console.log("............", staticData.isEnable);
					if (staticData.isEnable) {
						delete staticData.isEnable;
					}
					filterObject = { ...staticData, ...filterObject };
					filterObject = { ...filterObject, ...syncDeviceTo};
				}
				console.log("filterObject[key]2", filterObject);
				console.log("ksmUserDeviceService", ksmUserDeviceService);
				await ksmUserDeviceService.updateDeviceCode(uid, _.get(filterObject, "deviceId"), filterObject, upsert);
			}

			return true;
		} else {
			return true;
		}
	}
	catch (e) {
		console.log("Error in platform Updatation", e, e.stack);
	}
}


const Moment = require("moment");
const To = require("../utils/to");
const ModuleError = require("../errors/module");
const RandomUtil = require("../utils/random");
const GenericValidationUtil = require("../utils/validate/generic");
const MongoUserFormatter = require("../format/mongoUser");
const MongoUserProfileFormatter = require("../format/mongoUserProfile");
const UserSchema = require("../schema").users;
const UserProfileSchema = require("../schema").usersProfile;

module.exports = {
	getOneFromMongo: getOneFromMongo,
	getOne: getOne,
	createOneInMongo: createOneInMongo,
	createOne: createOne,
	updateOneInMongo: updateOneInMongo,
	updateOne: updateOne,
};

/**
 * Get one partner user from Mongo
 * @param authUser 
 * @param user 
 * @param params 
 * @param flags 
 */
async function getOneFromMongo(authUser, user) {
	try {
		// Initialize
		let userResult, userProfileResult, partnerUser;
		let userQuery = {};
		let userProfileQuery = {};

		// Prepare
		if (user.uniqueId) {
			userProfileQuery.uniqueId = user.uniqueId;
		} else if (user.uid) {
			userQuery.uid = user.uid;
			userProfileQuery.uid = user.uid;
		} else if (user.mobile) {
			userQuery.phoneNumber = user.mobile;
		} else if (user.email) {
			userQuery.email = user.email;
		}

		console.log("userQuery: ", userQuery);
		console.log("userProfileQuery: ", userProfileQuery);
		if (!GenericValidationUtil.isNonEmptyObject(userQuery) && !GenericValidationUtil.isNonEmptyObject(userProfileQuery)) {
			throw new ModuleError(400, "No keys found to retrieve one user.", null);
		} else if (GenericValidationUtil.isNonEmptyObject(userQuery)) {
			// Get
			userResult = await UserSchema.findOne(userQuery);

			if (!userResult) {
				throw new ModuleError(404, "User not found.", null);
			} else {
				// Clone
				partnerUser = JSON.parse(JSON.stringify(userResult));
			}

			// Get UserProfile
			userProfileResult = await UserProfileSchema.findOne({ uid: partnerUser.uid });
			if (!userProfileResult) {
				throw new ModuleError(404, "User profile not found for user with uid: " + partnerUser.uid, null);
			} else {
				partnerUser.profile = JSON.parse(JSON.stringify(userProfileResult));
			}
		} else if (GenericValidationUtil.isNonEmptyObject(userProfileQuery)) {
			// Get UserProfile
			userProfileResult = await UserProfileSchema.findOne(userProfileQuery);
			if (!userProfileResult) {
				throw new ModuleError(404, "User profile not found.", null);
			}

			// Get
			userResult = await UserSchema.findOne({ uid: userProfileResult.uid });

			if (!userResult) {
				throw new ModuleError(404, "User not found.", null);
			} else {
				// Clone
				partnerUser = JSON.parse(JSON.stringify(userResult));
				partnerUser.profile = JSON.parse(JSON.stringify(userProfileResult));
			}
		}

		// Response
		// eslint-disable-next-line no-undef
		return Promise.resolve({ code: 200, message: "Successfully retrieved one partner user.", data: { user: partnerUser, db: "mongo" } });
	} catch (error) {
		if (error && error.code && error.message) {
			// eslint-disable-next-line no-undef
			return Promise.reject({ code: !GenericValidationUtil.isNumericAndPositive(error.code) ? 500 : error.code, message: error.message, data: error.data });
		} else {
			// eslint-disable-next-line no-undef
			return Promise.reject({ code: 500, message: "An error occured while retrieving one partner user: " + error });
		}
	}
}

/**
 * Get one partner user
 * @param authUser 
 * @param user 
 * @param params 
 * @param flags 
 */
async function getOne(authUser, user, params, flags) {
	try {
		console.log("Start - PartnerUser Service -> getOne");

		// Initialize
		let mongoResult,resultFromDb,error;
		let isMongoResult = true;

		console.log("Partner Type: ", authUser.partner.code);

		// Retrieve user from Mongo
		console.log("Calling getOneFromMongo.");
		[error, mongoResult] = await To(getOneFromMongo(authUser, user, params, flags));
		if (error) {
			console.log("Error while executing getOneFromMongo.");
			if (error.code != 404) {
				throw new ModuleError(error.code, error.message, error.data);
			} 
			else {
				console.log("User not found in Mongo. Checking if user is found in Firestore.");
				throw new ModuleError(404, "User not found.", null);
			}
		} else {
			console.log("User found in Mongo.");
			resultFromDb = mongoResult.data.user;
			isMongoResult = true;
		}

		// Response
		console.log("End - PartnerUser Service -> getOne");
		// eslint-disable-next-line no-undef
		return Promise.resolve({ code: 200, message: "Successfully retrieved one partner user.", data: { user: resultFromDb, db: (isMongoResult) ? "mongo" : "firestore" } });
	} catch (error) {
		console.log("Error - PartnerUser Service -> getOne");
		console.error(error);
		if (error && error.code && error.message) {
		// eslint-disable-next-line no-undef
			return Promise.reject({ code: !GenericValidationUtil.isNumericAndPositive(error.code) ? 500 : error.code, message: error.message, data: error.data });
		} else {
			// eslint-disable-next-line no-undef
			return Promise.reject({ code: 500, message: "An error occured while retrieving one partner user: " + error });
		}
	}
}

/**
 * Create one partner user
 * @param authUser 
 * @param user 
 * @param params 
 * @param flags 
 */
async function createOneInMongo(authUser, user) {
	try {
		// Initialize
		let mongoUser, mongoUserProfile;

		// Create User
		mongoUser = await new UserSchema(user).save();

		// Create User Profile
		console.log("User Profile is being created with: ", user.profile);
		mongoUserProfile = await new UserProfileSchema(user.profile).save();

		// Response
		// eslint-disable-next-line no-undef
		return Promise.resolve({ code: 200, message: "Successfully created one partner user.", data: { user: mongoUser, userProfile: mongoUserProfile } });
	} catch (error) {
		if (error && error.code && error.message) {
			// eslint-disable-next-line no-undef
			return Promise.reject({ code: !GenericValidationUtil.isNumericAndPositive(error.code) ? 500 : error.code, message: error.message, data: error.data });
		} else {
			// eslint-disable-next-line no-undef
			return Promise.reject({ code: 500, message: "An error occured while creating one partner user: " + error });
		}
	}
}

/**
 * Create one partner user
 * @param {*} authUser 
 * @param {*} user 
 * @param {*} params 
 * @param {*} flags 
 */
async function createOne(authUser, user, params, flags) {
	try {
		// Initialize
		let error;
		let mongoUser, firestoreUser;

		if (!flags) {
			flags = {};
		}

		// Check if email/mobile user
		if (flags.isEmailUser) {
			mongoUser = await MongoUserFormatter.initFormatTraditionalUser({
				data: {
					email: user.email,
					password: user.password || RandomUtil.string(12)
				}
			});
		} else {
			mongoUser = await MongoUserFormatter.initFormatMobileUser({
				mobile: user.mobile,
				email: user.email,
				password: user.password || RandomUtil.string(12)
			});
		}

		// Prepare userprofile
		mongoUser.profile = MongoUserProfileFormatter.initFormatUserProfileTraditional(
			{
				uid: mongoUser.uid,
				email: mongoUser.email,
				phoneNumber: mongoUser.phoneNumber
			},
			{
				firstname: (user.profileData && user.profileData.FirstName) ? user.profileData.FirstName : "",
				lastname: (user.profileData && user.profileData.LastName) ? user.profileData.LastName : "",
				fullname: (user.profileData && user.profileData.FullName) ? user.profileData.FullName : ""
			},
			authUser.partner.default.phone.countryCode
		);
		mongoUser.profile.uniqueId = user.uniqueId;
		mongoUser.profile.tempEmail = user.tempEmail;
		mongoUser.profile.partnerType = user.partnerType;
		mongoUser.profile.externalId = user.externalId;
		mongoUser.profile.deviceId = user.deviceId;
		mongoUser.profile.isActive = user.isActive;
		mongoUser.profile.subscription = {
			activationDate: user.subscription.activationDate,
			startDate: user.subscription.startDate,
			endDate: user.subscription.endDate,
			transactionId: user.subscription.transactionId,
			source: user.subscription.source,
			deviceType: user.subscription.deviceType
		};

		// Prepare
		mongoUser.id = mongoUser.uid;
		user.uid = mongoUser.uid;

		console.log("Creating mongo user with: ", mongoUser);

		// Create Mongo User
		[error] = await To(createOneInMongo(authUser, mongoUser, params, flags));
		if (error) {
			console.error("An error occured while creating a partner user in Mongo:");
			console.error(error);
			throw new ModuleError(error.code, error.message, error.data);
		} else {
			console.log("Partner user created successfully in Mongo.");
		}

		// Response
		// eslint-disable-next-line no-undef
		return Promise.resolve({ code: 200, message: "Partner user created successfully.", data: { mongo: mongoUser, firestore: firestoreUser } });
	} catch (error) {
		if (error && error.code && error.message) {
			// eslint-disable-next-line no-undef
			return Promise.reject({ code: !GenericValidationUtil.isNumericAndPositive(error.code) ? 500 : error.code, message: error.message, data: error.data });
		} else {
			// eslint-disable-next-line no-undef
			return Promise.reject({ code: 500, message: "An error occured while creating one partner user: " + error });
		}
	}
}

/**
 * Update one partner user
 * @param authUser 
 * @param user 
 * @param params 
 * @param flags 
 */
async function updateOneInMongo(authUser, user, params, flags) {
	try {
		// Initialize
		let updateObj = {
			updatedAt: Moment()
		};
		let updateProfileObj = {
			updatedAt: Moment()
		};

		if (!flags) {
			flags = {};
		}

		// Prepare
		if (user.deviceType) {
			updateProfileObj.deviceType = user.deviceType;
		}
		if (GenericValidationUtil.isBoolean(user.isActive)) {
			updateProfileObj.isActive = user.isActive;
		}
		if (user.kUserId) {
			updateProfileObj.kUserId = user.kUserId;
		}
		if (user.uniqueId) {
			updateProfileObj.uniqueId = user.uniqueId;
		}
		if (user.partnerType) {
			updateProfileObj.partnerType = user.partnerType;
		}
		if (user.entitlementStatus) {
			updateProfileObj.entitlementStatus = user.entitlementStatus;
		}
		if (user.cancelledAt) {
			updateProfileObj.cancelledAt = user.cancelledAt;
		}
		if (user.renewedAt) {
			updateProfileObj.renewedAt = user.renewedAt;
		}
		if (GenericValidationUtil.isNonEmptyObject(user.subscription)) {
			if (user.subscription.activationDate) {
				updateProfileObj["subscription.activationDate"] = user.subscription.activationDate;
			}
			if (user.subscription.startDate) {
				updateProfileObj["subscription.startDate"] = user.subscription.startDate;
			}
			if (user.subscription.endDate) {
				updateProfileObj["subscription.endDate"] = user.subscription.endDate;
			}
			if (user.subscription.source) {
				updateProfileObj["subscription.source"] = user.subscription.source;
			}
			if (user.subscription.transactionId) {
				updateProfileObj["subscription.transactionId"] = user.subscription.transactionId;
			}
		}


		// Update User
		if (!flags.isUpdateOnlyUserProfile) {
			await UserSchema.updateOne({ uid: user.uid }, updateObj);
		}

		console.log("User profile being updated: ", updateProfileObj);

		// Update UserProfile
		if (user.uid) {
			await UserProfileSchema.updateOne({ uid: user.uid }, updateProfileObj);
		} else {
			await UserProfileSchema.updateOne({ uniqueId: user.uniqueId }, updateProfileObj);
		}

		// Response
		// eslint-disable-next-line no-undef
		return Promise.resolve({ code: 200, message: "Successfully updated one partner user.", data: null });
	} catch (error) {
		console.error(error);
		if (error && error.code && error.message) {
			// eslint-disable-next-line no-undef
			return Promise.reject({ code: !GenericValidationUtil.isNumericAndPositive(error.code) ? 500 : error.code, message: error.message, data: error.data });
		} else {
			// eslint-disable-next-line no-undef
			return Promise.reject({ code: 500, message: "An error occured while updating one partner user: " + error });
		}
	}
}

/**
 * Update one partner user
 * @param {*} authUser 
 * @param {*} user 
 * @param {*} params 
 * @param {*} flags 
 */
async function updateOne(authUser, user, params, flags) {
	try {
		// Initialize
		let error;
		let mongoUser, firestoreUser;

		// Update Mongo User
		[error] = await To(updateOneInMongo(authUser, user, params, flags));
		if (error) {
			console.error("An error occured while updating a partner user in Mongo:");
			console.error(error);
			throw new ModuleError(error.code, error.message, error.data);
		} else {
			console.log("Partner user updated successfully in Mongo.");
		}

		// Response
		// eslint-disable-next-line no-undef
		return Promise.resolve({ code: 200, message: "Partner user updated successfully.", data: { mongo: mongoUser, firestore: firestoreUser } });
	} catch (error) {
		if (error && error.code && error.message) {
			// eslint-disable-next-line no-undef
			return Promise.reject({ code: !GenericValidationUtil.isNumericAndPositive(error.code) ? 500 : error.code, message: error.message, data: error.data });
		} else {
			// eslint-disable-next-line no-undef
			return Promise.reject({ code: 500, message: "An error occured while updating one partner user: " + error });
		}
	}
}
const unVerifiedUser = require("../schema").unVerifiedUser;
const _ = require("lodash");
module.exports = {
	insertUserInformation,
	updateUnverifiedUserInformation,
	getUserInformationById,
	_getUnverifiedUserData,
	getUserInformationByMobile,
	getUserInformationByEmail,
	storeUnverifiedUserWithOTP,
	getUserInformationByMobileCountryCode,
	deleteField
};
// eslint-disable-next-line no-unused-vars
async function _getUnverifiedUserData(mobile, countryCode, phoneNumber) {
	try {
		let result = await getUserInformationByMobileCountryCode(mobile, countryCode);
		console.debug("Unverified User Collection ", result);
		if (_.has(result,"status")) {
			return false;
		}
		return result;
	} catch (error) {
		console.log("Error in Sending Message to Mobile",error);
		return false;
	}
}

function getUserInformationById(uid) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		unVerifiedUser.find({ "uid": uid }, function (err, data) {
			if (!err) {
				if (data.length > 0)
					res(data[0]);
				else
					res({ status: 1701, message: "No Uid Found" });
			} else {
				res({ status: 1701, message: "No Uid Found" });
			}
		});
	});
}

function getUserInformationByMobile(mobile) {
	// eslint-disable-next-line no-undef
	return new Promise((res, rej) => {
		unVerifiedUser.find({ "mobile": mobile }, function (err, data) {
			if (!err) {
				if (data.length > 0)
					res(data[0]);
				else
					res({ status: 1792, message: "No Mobile Found" });
			} else {
				rej({ status: 1702, message: "No Mobile Found" });
			}
		});
	});
}

function getUserInformationByMobileCountryCode(mobile, countryCode) {
	// eslint-disable-next-line no-undef
	return new Promise((res, rej) => {
		unVerifiedUser.find({ "mobile": mobile, "countryCode": countryCode }, function (err, data) {
			if (!err) {
				if (data.length > 0)
					res(data[0]);
				else
					res({ status: 1792, message: "No Mobile Found" });
			} else {
				rej({ status: 1702, message: "No Mobile Found" });
			}
		});
	});
}

function getUserInformationByEmail(email) {
	// eslint-disable-next-line no-undef
	return new Promise((res, rej) => {
		unVerifiedUser.find({ "email": email }, function (err, data) {
			if (!err) {
				if (data.length > 0)
					res(data[0]);
				else
					res({ status: 1792, message: "No Email Found" });
			} else {
				rej({ status: 1702, message: "No Email Found" });
			}
		});
	});
}

async function insertUserInformation(userInput) {
	try {
		const unverified = new unVerifiedUser(userInput);
		console.log("UnVerifiedUser..", unverified);
		return await unverified.save();
	} catch (err) {
		throw err;
	}
}

function updateUnverifiedUserInformation(query, updateQuery) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		unVerifiedUser.updateOne(query, { $set: updateQuery }, { upsert: true, useFindAndModify: false }, function (err, data) {
			if (err) {
				console.log(err);
				res({ status: 1703, message: "User profile not added or updated" });
			} else
				res(data);
		});
	});
}
function deleteField(query, updateQuery) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		// db.getCollection('myDatabaseTestCollectionName').update({"FieldToDelete": {$exists: true}}, {$unset:{"FieldToDelete":1}}, false, true);
		unVerifiedUser.updateOne(query, updateQuery, { upsert: true, useFindAndModify: true }, function (err, data) {
			if (err) {
				res({ status: 1703, message: "User profile field are deleted or updated" });
			} else
				res(data);
		});
	});
}
async function storeUnverifiedUserWithOTP(user, signUpRequest,action,failedAttempt=null) {
	const phoneNumber = user.countryCode + user.mobile;
	console.log("phoneNumber: " + phoneNumber);
	const userData = await _getSignUpRequestDataFormat(user, signUpRequest);
	let userDataFormated = JSON.stringify(userData);
	userDataFormated = JSON.parse(userDataFormated);
	if (failedAttempt) { userDataFormated._system.failedAttempt = failedAttempt;}
	const updatedData = await updateUnverifiedUserInformation({ "mobile": user.mobile, "countryCode": user.countryCode }, userDataFormated);
  
	if (_.has(updatedData, "status")) {
		return updatedData;
	}
	console.debug("Inserted into db SuccessFully", updatedData);
  
	// var  result=await getUserInformationByMobile(user.mobile);
	// console.log("Inserted into db SuccessFully",result);


}
async function _getSignUpRequestDataFormat(user, signUpRequest) {
	return { //TODO: get this from AccountService as getDefaultPreferences
		...user,
		preferences: {
			language: "English"
		},
		_system: { signUpRequest: signUpRequest } // identifies private system only data, must not be visible to end user
	};
}


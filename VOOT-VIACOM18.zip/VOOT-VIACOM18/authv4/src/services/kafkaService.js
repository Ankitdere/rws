const kafkaConnection = require("../config/kafkaConnection");
/**
 * function to push the data to the MSK.
 * @param { string } topicName, topicName on which the message will be pushed. 
 * @param { object } data, Json object to push to MSK. 
 */
async function pushEventToKafka(topicName, data) {
	try {
		const kafkaProducer = await kafkaConnection.getkafkaProducer();
		console.log("data, to push",JSON.stringify(data));
		//let payload = [{topic: topicName,messages: JSON.stringify(data)},];
		console.log("create payload ",{
			topic: topicName,
			messages: [
				{ value: JSON.stringify(data) }
			]
		});
		let payload = {
			topic: topicName,
			messages: [
				{ value: JSON.stringify(data) }
			]
		};
		const result= await kafkaProducer.send(payload);
		console.log("Kafka response", result);
	} catch (err){
		console.error("error in kafka service push", err);
	}
}

module.exports = { pushEventToKafka };

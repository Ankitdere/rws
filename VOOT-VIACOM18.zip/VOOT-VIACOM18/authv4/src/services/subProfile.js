const { subProfile } = require("../schema");
const Constant = require("../utils/constant/generic");


module.exports = {
	insertSubProfileInformation,
	getCountUid,
	getAllSubProfilesInformation,
	deleteSubProfileInformation,
	updateSubProfileInformation
};

/**
 * @param {Object} userInput 
 * @returns {Object}
 */
async function insertSubProfileInformation(userInput) {
	try {
		const subProfiles = new subProfile(userInput);
		const res = await subProfiles.save();
		return {
			status: Constant.SUCCESS_STATUS,
			message: res
		};
	}
	catch (err) {
		console.error("Error in insertSubProfileInformation subProfile", err);
		return {
			status: Constant.FAILURE_STATUS,
			message: Constant.SOMETHING_WENT_WRONG,
		};
	}
}

/**
 * @param {Object} filter 
 * @returns {Object}
 */
async function getCountUid(filter) {
	try {
		const data = await subProfile.find(filter).countDocuments();
		if (data) return { status: Constant.SUCCESS_STATUS, data };
		return Constant.UID_NOT_FOUND_MODEL;
	} catch (err) {
		console.error("Error in getCountUid subProfile", err);
		return Constant.UID_NOT_FOUND_MODEL;
	}
}

/**
 * 
 * @param {Object} filter
 * @returns {Object}
 */
async function getAllSubProfilesInformation(filter) {
	try {
		const data = await subProfile.find(filter);
		if (data) return { status: Constant.SUCCESS_STATUS, data: data };
		return Constant.UID_NOT_FOUND_MODEL;
	}
	catch (err) {
		console.error("Error in getAllSubProfilesInformation subProfile", err);
		return Constant.UID_NOT_FOUND_MODEL;
	}
}

async function deleteSubProfileInformation(filter) {
	try {
		const data = await subProfile.deleteOne(filter);
		if (data) return { status: Constant.SUCCESS_STATUS, data: data };
		return Constant.UID_NOT_FOUND_MODEL;
	}
	catch (err) {
		console.error("Error in deleteSubProfileInformation", err);
		return Constant.UID_NOT_FOUND_MODEL;
	}
}

async function updateSubProfileInformation(filter, userInput, params) {
	try {
		const data = await subProfile.findOneAndUpdate(filter, userInput, params);
		if (data) return { status: Constant.SUCCESS_STATUS, data: data };
		return Constant.UID_NOT_FOUND_MODEL;
	}
	catch (err) {
		console.error("Error in updateSubProfileInformation", err);
		return Constant.UID_NOT_FOUND_MODEL;
	}
}
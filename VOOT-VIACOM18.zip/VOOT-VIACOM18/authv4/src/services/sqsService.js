const Config = require("../config/configuration");
const SQS = require("../config/sqs").default;
// console.log("AWS consolde::: ", AWS.config.getCredentials());
module.exports = { sendEmailToSQS, sendMessage };

async function sendEmailToSQS(email, isEmail, customCheck = false, uid = "") {
	try {
		let params;
		console.log("User email in SQS", email, isEmail);
		console.debug(Config.SQS.QueueUrl, "SQS link");
		params = {
			DelaySeconds: 10,
			MessageAttributes: {},
			MessageBody: JSON.stringify({ email: email, isEmail: isEmail  , customCheck: customCheck, uid:uid }),
			QueueUrl: Config.SQS.QueueUrl
		};

		SQS.sendMessage(params, function (err, data) {
			console.debug("Sending Data into Queue", params);
			if (err) {
				console.error("Error in Sending Message into Queue", err);
				return true;
			} else {
				console.log("Success in Sending Message into Queue", data.MessageId);
				return true;
			}
		});
	}
	catch (error) {
		console.error("SQS Eror", error);
		return true;

	}
}

/**
 * @param {object} params 
 */
async function sendMessage(params = {}) {
	try {
		const mandatoryParams = ["MessageBody", "QueueUrl"];
		mandatoryParams.forEach((item) => {
			const hasKey = Object.prototype.hasOwnProperty.call(params, item);
			if (!hasKey) throw new Error(`Pass ${item} to SQS sendMessage`);
		});
		const response = await SQS.sendMessage(params).promise();
		return response;
	} catch (error) {
		console.log({ service: "SQS", method: "sendMessage", error: error.message, message: "sendMessage failed" });
		return false;
	}
}
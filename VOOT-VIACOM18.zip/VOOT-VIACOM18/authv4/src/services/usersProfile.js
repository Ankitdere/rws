const usersProfile = require("../schema").usersProfile;
module.exports = {
	insertUserInformation,
	updateUserInformation,
	getUserInformationById,
	getUserInformationByEmail,
	deleteField,
	getAppleUserById,
	getUserInformationByMobile,
	getUsersInformationByEmail,
	getPartnerDetailsByExternalId,
	getPartnerDetailsByUniqueId,
	getPartnerTransactionId,
	getUserInformationByMobileWithCountryCode,
	getAmazonDetailsByExternalId,
	getUserInformationByIdFromPrimaryPre,
	getUserEmailAndUidById,
	getUserInformationByUid
};

async function getUserEmailAndUidById(uid) {
	try {
		const data = await usersProfile.find({uid},{ "uid":1, "email": 1, "partnerType":1,"tempEmail":1});//take an input only uid and take 
		if (data.length > 0) return data[0];
		else return { status: 1701, message: "No Uid Found" };
	}
	catch (err) {
		console.log("Error while data from getUserInformationByIdFromPrimaryPre: ",err);
		return { status: 1701, message: "No Uid Found" };
	}
}

function getUserInformationById(uid) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		usersProfile.find({ "uid": uid }, function (err, data) {
			if (!err) {
				if (data.length > 0)
					res(data[0]);
				else
					res({ status: 1701, message: "No Uid Found" });
			} else {
				res({ status: 1701, message: "No Uid Found" });
			}
		});
	});
}

function getUserInformationByEmail(email) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		usersProfile.find({ "email": email }, function (err, data) {
			if (!err) {
				if (data.length > 0)
					res(data[0]);
				else
					res({ status: 1702, message: "No Email Found" });
			} else {
				res({ status: 1702, message: "No Email Found" });
			}
		});
	});
}

function getUserInformationByMobile(mobile) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		usersProfile.find({ "profileData.Mobile": mobile }, function (err, data) {
			if (!err) {
				if (data.length > 0)
					res(data[0]);
				else
					res({ status: 1702, message: "No Mobile Number Found" });
			} else {
				res({ status: 1702, message: "No Mobile Number Found" });
			}
		});
	});
}
function getUserInformationByMobileWithCountryCode(mobile) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		usersProfile.find({ "mobile": mobile }, function (err, data) {
			if (!err) {
				if (data.length > 0)
					res(data[0]);
				else
					res({ status: 1702, message: "No Mobile Number Found" });
			} else {
				res({ status: 1702, message: "No Mobile Number Found" });
			}
		});
	});
}
async function insertUserInformation(userInput) {
	try {
		const usersProfile = new usersProfile(userInput);
		return await usersProfile.save();
	} catch (err) {
		throw err;
	}
}

function updateUserInformation(query, updateQuery) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		usersProfile.findOneAndUpdate(query, updateQuery, { upsert: true, useFindAndModify: false ,new:true }, function (err, data) {
			if (err){
				console.error("Error in updating userProfile",err);
				res({ status: 1703, message: "User profile not added or updated" });
			}
                
			else{
				console.debug("Data after updating userprofile",data);
				res(data);
			}
                
		});
	});
}
function deleteField(query, updateQuery) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		// db.getCollection('myDatabaseTestCollectionName').update({"FieldToDelete": {$exists: true}}, {$unset:{"FieldToDelete":1}}, false, true);
		usersProfile.updateOne(query, updateQuery, { upsert: true, useFindAndModify: true }, function (err, data) {
			if (err) {
				res({ status: 1703, message: "User profile field are deleted or updated" });
			} else
				res(data);
		});
	});
}

function getPartnerDetailsByExternalId(externalId, partnerType) {
// eslint-disable-next-line no-undef
	return new Promise((res) => {
		usersProfile.find({ "externalId": externalId, "partnerType": partnerType }, async function (err, data) {
			if (!err) {
				if (data.length > 0) {
					let promiseResolution = {
						userData: data[0],
						dbName: "mongoDb",
					};
					res(promiseResolution);
				} else {

					res({ status: 1702, message: "No Partner Found" });

				}

			} else {
				res({ status: 1702, message: "No Partner Found" });
			}
		});
	});
}

function getPartnerDetailsByUniqueId(uniqueId, partnerType) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		usersProfile.find({ "uniqueId": uniqueId, "partnerType": partnerType }, function (err, data) {
			if (!err) {
				if (data.length > 0)
					res(data[0]);
				else
					res({ status: 1702, message: "No Partner Found" });
			} else {
				res({ status: 1702, message: "No Partner Found" });
			}
		});
	});
}

function getUsersInformationByEmail(email) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		usersProfile.find({ "email": email }, function (err, data) {
			if (!err) {
				if (data.length > 0)
					res(data);
				else
					res({ status: 1702, message: "No Email Found" });
			} else {
				res({ status: 1702, message: "No Email Found" });
			}
		});
	});
}

function getPartnerTransactionId(partnerType, transactionId) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		usersProfile.find({ "partnerType": partnerType, "subscription.transactionId": transactionId }, function (err, data) {
			if (!err) {
				if (data.length > 0)
					res(data[0]);
				else
					res({ status: 1702, message: "No Partner Found" });
			} else {
				res({ status: 1702, message: "No Partner Found" });
			}
		});
	});
}

function getAppleUserById(AppleId) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		usersProfile.find({ "profileData.AppleUser.AppleId": AppleId }, function (err, data) {
			if (!err) {
				if (data.length > 0)
					res(data[0]);
				else
					res({ status: 1701, message: "No Apple Uid Found" });
			} else {
				res({ status: 1701, message: "No Apple Uid Found" });
			}
		});
	});
}
function getAmazonDetailsByExternalId(externalId) {
   
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		usersProfile.find({ "profileData.AmazonDetails.externalId": externalId }, async function (err, data) {
			if (!err) {
				if (data.length > 0){
					res(data[0]);
				}else {
					res({ status: 1702, message: "No Partner Found" });
				}

			} else {
				res({ status: 1702, message: "No Partner Found" });
			}
		});
	});
}


/**
 * Function to getUserProfile from primary Preferred
 * @param {String} uid 
 */
async function getUserInformationByIdFromPrimaryPre(uid) {
	try {
		const data = await usersProfile.find({uid}).read("primaryPreferred");
		if (data.length > 0) return data[0];
		else return { status: 1701, message: "No Uid Found" };
	}
	catch (err) {
		console.log("Error while data from getUserInformationByIdFromPrimaryPre: ",err);
		return { status: 1701, message: "No Uid Found" };
	}
}
/**
 * function to get record form userprofile with custom filed.
 * @param {Obejct} query 
 * @param {object} requiredFiled 
 * @returns userprofile object 
 */
async function getUserInformationByUid(query, requiredFiled={}) {
	try {
		const data = await usersProfile.find(query,requiredFiled);
		if (data.length > 0) return data[0];
		else return { status: 1701, message: "No Uid Found" };
	}
	catch (err) {
		console.log("Error while data from getUserInformationByIdFromPrimaryPre: ",err);
		return { status: 1701, message: "No Uid Found" };
	}
}
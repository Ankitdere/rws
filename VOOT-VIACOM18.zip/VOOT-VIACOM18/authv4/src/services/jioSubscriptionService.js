"use strict";

const _ = require("lodash");
const rp = require("request-promise");
const envConfig = require("../config").configuration;
const apiResponse = require("../utils").apiResponse;
const errorConfig = require("../config").errorConfig;
const jioCryptoService = require("./jioCryptoService");
const kalturaService = require("./kalturaService");
const { getSha256Hash } = require("../utils").legacyHash;
const userService = require("./users");
const usersProfileService = require("./usersProfile");
const responseFormat = require("../format").responseFormat;
const mongoUser = require("../format").mongoUser;
const mongoUserProfile = require("../format").mongoUserProfile;

module.exports = {
	doSubscribeVootUser,
	loginOrRegisterJioSubscription,
	getSubscriberVootUser,
	newUserFlow,
	existingUserFlow,
	kalturaRegistration,
	kalturalogin,
	createOptionsForJioSubscription,
	getHashAndDateTime,
	parseJioSubscriptionInfo,
	getEntitleMentStatus,
	genrateEntitlementStatus,
	reVerifySubscriptionDetails
};

async function doSubscribeVootUser(input) {
	let jioSubscriptionResult, jioData, userRecord, userData, isPremium = false;
	let tokenHashInfo = await getHashAndDateTime(input.ssoToken);
	let optionsSubscriptionInfo = createOptionsForJioSubscription(input, tokenHashInfo);
	try {
		jioSubscriptionResult = await rp(optionsSubscriptionInfo);
		if (_.get(jioSubscriptionResult, "success") == "false") {
			// create error and return error
			if (_.get(jioSubscriptionResult, "errors[0].reason") == errorConfig.invalidSubscription.description) {
				isPremium = false;
			}
		}
		jioData = await parseJioSubscriptionInfo(jioSubscriptionResult, input);
		let tempEmail;
		if (!jioData.mobileNumber) {
			isPremium = false;
		} else {
			isPremium = true;
		}
		tempEmail = `${jioData.subscriberId}@jio.com`;
		jioData.kUserName = tempEmail;
		jioData.kExternalId = tempEmail;
		try {
			userData = await userService.getUserByEmail(tempEmail);
			if (_.get(userData, "status") !== 1798) {
				userRecord = await usersProfileService.getUserInformationById(userData.uid);
				return await existingUserFlow(tempEmail, userData, userRecord, input, jioData);
			} else {
				return await newUserFlow(tempEmail, jioData, input, isPremium);
			}
		} catch (err) {
			switch (err.code) {
			case "auth/wrong-password":
				return apiResponse.error(errorConfig.wrongPassword.description, errorConfig.wrongPassword.code);
			case "auth/user-not-found":
				return await newUserFlow(tempEmail, jioData, input, isPremium);
			case "auth/invalid-email":
				return apiResponse.error(errorConfig.invalidEmail.description, errorConfig.invalidEmail.code);
			case "auth/invalid-uid":
				return apiResponse.error(errorConfig.invalidUid.description, errorConfig.invalidUid.code);
			case "auth/invalid-credential":
				return apiResponse.error(errorConfig.invalidAccessToken.description, 1907);
			case "auth/too-many-requests":
				return apiResponse.error(errorConfig.tooManyAttempts.description, errorConfig.tooManyAttempts.code);
			default:
				throw apiResponse.error(errorConfig.requestFailed, 400);
			}
		}
	} catch (error) {
		if (_.has(error, "error.errors[0]")) {
			return apiResponse.error(errorConfig.invalidSsoToken.description, errorConfig.invalidSsoToken.code);
		}
		return error;
	}
}

async function loginOrRegisterJioSubscription(input) {
	if (input.accessToken) {
		return await getSubscriberVootUser(input);
	} else {
		return await doSubscribeVootUser(input);
	}
}

async function getSubscriberVootUser(input, decoded, userRecord) {
	try {
		let tempEmail = `${_.get(input, "subscriberId")}@jio.com`;
		return await existingUserFlow(tempEmail, {}, userRecord, input, {});
	} catch (err) {
		if (err.message == errorConfig.invalidAccessToken.description) {
			return apiResponse.error(errorConfig.invalidAccessToken.description, errorConfig.invalidAccessToken.code);
		}
		if (err.message == errorConfig.expiredProfileToken.description) {
			return apiResponse.error(errorConfig.expiredProfileToken.description, errorConfig.expiredProfileToken.code);
		}
		switch (err.code) {
		case "auth/wrong-password":
			return apiResponse.error(errorConfig.wrongPassword.description, errorConfig.wrongPassword.code);
		case "auth/invalid-email":
			return apiResponse.error(errorConfig.invalidEmail.description, errorConfig.invalidEmail.code);
		case "auth/invalid-uid":
			return apiResponse.error(errorConfig.invalidUid.description, errorConfig.invalidUid.code);
		case "auth/invalid-credential":
			return apiResponse.error(errorConfig.invalidAccessToken.description, 1907);
		case "auth/too-many-requests":
			return apiResponse.error(errorConfig.tooManyAttempts.description, errorConfig.tooManyAttempts.code);
		default:
			throw apiResponse.error(errorConfig.requestFailed, 400);
		}
	}
}

async function newUserFlow(tempEmail, jioData, input, isPremium) {
	let userData = await mongoUser.initFormatTraditionalUser({
		data : {
			email: tempEmail,
			password: jioData.subscriberId
		}
	});
	jioData.uid = userData.uid;
	let userProfileData = await mongoUserProfile.initFormatUserProfileTraditional(userData, _.get(input, "data", {}), input.countryCode);
	_.set(userProfileData, "profileData", jioData);
	// eslint-disable-next-line no-undef
	await Promise.all([userService.insertUser(userData), usersProfileService.updateUserInformation({ uid: _.get(userData, "uid") }, userProfileData)]);    
	let userRecord = { profileData: jioData };
	return await kalturaRegistration(tempEmail, input, userRecord, userData, isPremium);
}

async function existingUserFlow(tempEmail, userData, userRecord, input, jioData) {
	return await kalturalogin(input, tempEmail, userRecord, userData, jioData);
}

async function kalturaRegistration(email, input, userRecord, userData, isPremium) {
	try {
        
		try {
			await kalturaService.register(email, email);
		} catch (error) {
			return apiResponse.error(error);
		}
		const kalturaUserLoginResult = await kalturaService.login(email, email, input.deviceId);
		// eslint-disable-next-line no-undef
		const [kalturaHousehold, device, kalturaAppTokenResponse] = await Promise.all([
			kalturaService.createHousehold(email, kalturaUserLoginResult.result.loginSession.ks),
			kalturaService.setupHouseholdDevice(input.deviceId, input.deviceName),
			kalturaService.getAppToken(kalturaUserLoginResult.result.loginSession.ks)
		]);
		if (kalturaUserLoginResult.result.user.householdId !== 0)
			kalturaService.addDeviceToUserHousehold(device, kalturaUserLoginResult.result); // not waiting for response
		let entitlementStatus;
		if (isPremium)
			entitlementStatus = await kalturaService.garntSubscription(_.get(kalturaUserLoginResult, "result.user.id"));
		else
			entitlementStatus = false;
		return await responseFormat.jioSubscriptionResponse(_.get(kalturaHousehold, "result.id"), kalturaUserLoginResult, kalturaAppTokenResponse, userData, userRecord, entitlementStatus, input);
	}
	catch (error) {
		throw error;
	}
}

async function kalturalogin(input, tempEmail, userRecord, userData, jioData) {
	try {
		let entitlementStatus, isExpired = false;
		const device = await kalturaService.setupHouseholdDevice(input.deviceId, input.deviceName); // Not an API but a promise, do we need to await here?
		console.log("====== Device ==========: ", device);
		let kalturaUserLoginResult;
		try {
			kalturaUserLoginResult = await kalturaService.login(tempEmail, tempEmail, device.udid);
		} catch (error) {
			if (!_.has(error.result.error, "code")) {
				return error;
			}
		}
		const kalturaAppTokenResponse = await kalturaService.getAppToken(kalturaUserLoginResult.result.loginSession.ks);
		if (jioData.endDate) {
			let expireDate = new Date(jioData.endDate);
			if (expireDate.getTime() < new Date().getTime()) {
				isExpired = true;
				await kalturaService.cancelSubscription(_.get(kalturaUserLoginResult, "result.user.id"));
				entitlementStatus = false;
			}
		}
		if (!isExpired) {
			let subscriptionCount = await kalturaService.isSubscribedUser(_.get(kalturaUserLoginResult, "result.loginSession.ks"), false);
			if (subscriptionCount > 0) {
				entitlementStatus = true;
			} else {
				entitlementStatus = false;
			}
		}
		return await responseFormat.jioSubscriptionResponse(_.get(kalturaUserLoginResult, "result.user.householdId"), kalturaUserLoginResult, kalturaAppTokenResponse, userData, userRecord, entitlementStatus, input);
	}
	catch (error) {
		console.error("Error in kaltura login:", error);
		throw error;
	}
}

function createOptionsForJioSubscription(input, tokenHashInfo) {
	// JIO Security Changes
	return {
		method: "POST",
		// url: `https://${envConfig.jioSubscription.host}/partner/ott/ftth/v1/subscription/details`,
		url: `https://${envConfig.jioSubscription.host}/partner/ott/v1/subscription/details`,
		headers: {
			"x-api-key": envConfig.jioSubscription.xAPIkey,
			"app-name": envConfig.jioSubscription.appName,
			"sso-token": input.ssoToken
		},
		// agentOptions: {
		//     cert: envConfig.jioSubscription.certificate,
		//     key: envConfig.jioSubscription.key,
		//     passphrase: 'seco@123#'
		// },
		body: tokenHashInfo,
		json: true
	};
}

async function getHashAndDateTime(ssoToken) {
	let today = new Date();
	let date = `${today.getFullYear()}-${(today.getMonth() + 1)}-${today.getDate()}`;
	let time = `${today.getHours()}:${today.getMinutes()}:${today.getSeconds()}.${today.getMilliseconds()}`;
	let dateTime = `${date}T${time}`;
	let hashData = `${envConfig.jioSubscription.xAPIkey}~${ssoToken}~${dateTime}`;
	let token = await getSha256Hash(hashData);
	return {
		checksum: token,
		timestamp: dateTime
	};
}

async function parseJioSubscriptionInfo(input, inputPayload) {
	try {
		let decryptedMobileNumber = await jioCryptoService.decrypt(_.get(input, "mobileNumber", ""), inputPayload.ssoToken);
		return {
			mobileNumber: decryptedMobileNumber,
			serviceType: _.get(input, "planOfferings[0].digitalServices[0].serviceType", ""),
			planId: _.get(input, "planOfferings[0].digitalServices[0].planSpecification.id"),
			planName: _.get(input, "planOfferings[0].digitalServices[0].planSpecification.name", ""),
			startDate: _.get(input, "planOfferings[0].digitalServices[0].startDate", ""),
			endDate: _.get(input, "planOfferings[0].digitalServices[0].endDate", ""),
			activationDate: _.get(input, "planOfferings[0].digitalServices[0].activationDate", ""),
			subscriberId: _.get(inputPayload, "subscriberId")
		};
	} catch (err) {
		return {
			subscriberId: _.get(inputPayload, "subscriberId")
		};
	}
}

async function getEntitleMentStatus(ks, ssoToken, decoded, userRecord) {
	try {
		//const tokenService = require("./tokenService");
		// eslint-disable-next-line no-undef
		let entitlementStatus = await await Promise.all([kalturaService.isSubscribedUser(ks, false), kalturaService.isSubscribedUser(ks, true)]);
		let endDate = _.get(userRecord, "profileData.endDate");
		let subscriberId = _.get(userRecord, "profileData.subscriberId");
		if (entitlementStatus[0] > 0) {
			if (new Date(endDate).getTime() < new Date().getTime()) {
				await kalturaService.cancelSubscription(_.get(decoded, "kUserId"));
				return genrateEntitlementStatus("expired", null);
			}
			return genrateEntitlementStatus("active", endDate);
		} else if (entitlementStatus[1] > 0) {
			return await reVerifySubscriptionDetails(ssoToken, "expired", subscriberId, decoded.uid, decoded.kUserId);
		} else if (entitlementStatus[1] == 0 && entitlementStatus[0] == 0) {
			return await reVerifySubscriptionDetails(ssoToken, "new", subscriberId, decoded.uid, decoded.kUserId);
		}
	} catch (err) {
		if (_.get(err, "result.error.code") == "500016") {
			return apiResponse.error(errorConfig.expiredKs.description, errorConfig.expiredKs.code);
		} else if (_.get(err, "result.error.code") == "500015") {
			return apiResponse.error(errorConfig.invalidKs.description, errorConfig.invalidKs.code);
		} else {
			return apiResponse.error(errorConfig.requestFailed);
		}
	}
}

function genrateEntitlementStatus(statusValue, endDate) {
	let activeTillDate;
	if (endDate) {
		let dateValue = new Date(endDate);
		activeTillDate = {
			gmtDate: dateValue.toUTCString(),
			timeStamp: Math.round(dateValue.getTime() / 1000)
		};
	}
	return {
		status: statusValue,
		activeTillDate: activeTillDate
	};
}

async function reVerifySubscriptionDetails(ssoToken, status, subscriberId, uid, kUserId) {
	try {
		let tempEmail;
		let tokenHashInfo = await getHashAndDateTime(ssoToken);
		let optionsSubscriptionInfo = createOptionsForJioSubscription({ ssoToken: ssoToken }, tokenHashInfo);
		let jioSubscriptionResult = await rp(optionsSubscriptionInfo);
		jioSubscriptionResult = await rp(optionsSubscriptionInfo);
		if (_.get(jioSubscriptionResult, "success") == "false") {
			// create error and return error
			if (_.get(jioSubscriptionResult, "errors[0].reason") == errorConfig.invalidSubscription.description) {
				return genrateEntitlementStatus(status, null);
			}
		}
		let jioData = parseJioSubscriptionInfo(jioSubscriptionResult, {
			subscriberId: subscriberId,
			ssoToken: ssoToken
		});

		if (!jioData.mobileNumber) {
			return genrateEntitlementStatus(status, null);
		}
		tempEmail = `${jioData.subscriberId}@jio.com`;
		jioData.kUserName = tempEmail;
		jioData.kExternalId = tempEmail;
        
		if (jioData.endDate && jioData.activationDate) {
			let expireDate = new Date(jioData.endDate);
			if (expireDate.getTime() < new Date().getTime()) {
				await kalturaService.cancelSubscription(kUserId);
				return genrateEntitlementStatus(status, null);
			}
			// eslint-disable-next-line no-undef
			await Firestore.updateAccountData(uid, jioData);
			await kalturaService.garntSubscription(kUserId);
			return genrateEntitlementStatus("active", jioData.endDate);
		} else {
			return genrateEntitlementStatus(status, null);
		}
	} catch (error) {
		if (_.has(error, "error.errors[0]")) {
			return apiResponse.error(errorConfig.invalidSsoToken.description, errorConfig.invalidSsoToken.code);
		}
		return error;
	}
}

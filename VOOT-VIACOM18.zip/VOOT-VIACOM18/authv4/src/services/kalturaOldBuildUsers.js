const kalturaOldBuild = require("../schema").kalturaOldBuild;
module.exports = {
	getKalturaOldBuildUser,
	insertKalturaBuildData
};

async function getKalturaOldBuildUser(query, fetchUserQuery) {
	try {
		const data = await kalturaOldBuild.find(query, fetchUserQuery);
		if (data.length > 0) return data[0];
		else return { status: 1704, message: "No old build User Found" };
	}
	catch (err) {
		console.log("Error while getting data from getKalturaOldBuildUser/catch", err);
		return { status: 1704, message: "No old build User Found" };
	}
}
async function insertKalturaBuildData(input) {
	try {
		const kalturaBuild = new kalturaOldBuild(input);
		return await kalturaBuild.save();
	} catch (err) {
		throw err;
	}
}


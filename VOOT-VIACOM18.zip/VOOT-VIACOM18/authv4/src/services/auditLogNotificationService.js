const _= require("lodash");
module.exports = {
	getAuditNotificationObj,
};
// notification structure for audit purpose

async function getAuditNotificationObj(request,subAction,value,response){
	const notificationObj = {
		application: {
			code: "auth_v4"
		},
		action: "update",
		subAction:subAction?subAction:"" ,
		performedBy: value.uid,
		performedRole: "user",
		entity: "users",
		httpMethod: request.methodType,
		ip: request.ipAddress,
		value: {
			from: value.from,
			to: value.to
			
		},
		response: {
			status: (_.has(response,"error"))?response.error.code:200,
			error: {
				code: (_.has(response,"error"))?response.error.code:""
			}
		}
	};
	return notificationObj;
}


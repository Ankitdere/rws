module.exports = {
	createOne: createOne
};

// Imports
const Device = require("../schema").device;

/**
 * Create one
 * @param {*} device 
 * @param {*} params 
 * @param {*} flags 
 */
async function createOne(device) {
	try {
		const deviceObj = new Device(device);
		await deviceObj.save();

		// eslint-disable-next-line no-undef
		return Promise.resolve({ code: 200, message: "Device created successfully." });
	} catch (error) {
		// eslint-disable-next-line no-undef
		return Promise.reject(error);
	}
}
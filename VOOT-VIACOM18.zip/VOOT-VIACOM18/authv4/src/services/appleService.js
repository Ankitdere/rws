
const appleUnverifiedUsers = require("../schema").appleUnverifiedUsers;

module.exports = {
	setAppleUnverifiedUser,
	getUnverifiedAppleUser,
	deleteUnverfiedAppleuser
};

async function getUnverifiedAppleUser(uid) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		appleUnverifiedUsers.find({ "uid": uid }, function (err, data) {
			if (!err) {
				if (data.length > 0)
					res(data[0]);
				else
					res(false);
			} else {
				res(false);
			}
		}).limit(5);
	});
}
async function setAppleUnverifiedUser(query, updateQuery) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		appleUnverifiedUsers.findOneAndUpdate(query, updateQuery, { upsert: true }, function (err, data) {
			if (err)
				res({ status: 1794, message: "User not added or updated"});
			else
				res(data);
		});
	});
}

async function deleteUnverfiedAppleuser(query) {
	// eslint-disable-next-line no-undef
	return new Promise((res) => {
		appleUnverifiedUsers.deleteOne(query, { justOne: true }, function (err, data) {
			if (err)
				res({ status: 1794, message: "User not added or updated"});
			else
				res(data);
		});
	});
}
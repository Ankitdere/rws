"use strict";

const _ = require("lodash");
const axios = require("axios");
// const envConfig = require("../config").envConfig;
const apiResponse = require("../utils").apiResponse;
const config = require("../config").configuration;
const errorConfig = require("../config").errorConfig;
const usersProfileService = require("./usersProfile");
const pxApiService =require("./pxApiService");
const kalturaService =require("./kalturaService");
const tokenService = require("./tokenService");
const mixpanelEventConfig = require("../config").mixpanelEvent;
const mixpanelEvent = require("../services/mixpanelService");
const commonUtils = require("../utils").common;
const constant = require("../utils/constant/generic");
module.exports = {
	tataSkyNotification,
	tSkyUserDetails,
	getTskyCollectionDetails
};

async function tataSkyNotification(input) {
	try {
		let partnerData,callPx;
		let { uid, userData, dbName } = await getTskyCollectionDetails(input.data.uniqueId, input.data.transactionId);
		const deviceDetails = { deviceId: input.data.dsn, deviceBrand: config.tSkyDetails.deviceBrand, partnerType: config.tSkyDetails.partnerType };
		const pxpartnerDetails = {};
		let currentEntitlementStatus="new";
		let isActive=false;
		let accessToken;
		pxpartnerDetails.platform = config.pXApiDetails.stbPlatform;
		pxpartnerDetails.partnerName = config.pXApiDetails.tSkyPartnerName;
		if(uid){
			const tempEmail = await commonUtils.createTempEmail(uid, input);
			// const userrData = await userService.getUserById(uid);
			// const userProfile = await userProfileService.getUserInformationById(uid)
			const userProfile = userData;
			if(_.isEmpty(_.get(userData, "kUserId"))){
				try{
					let response = await  kalturaService.getUserByUsername(tempEmail);
					userProfile.kUserId = _.get(response, "id");
					// eslint-disable-next-line no-undef
					await storeKUserId(userData.kUserId, uid, _.get(input, "deviceId", ""));
				}catch(err){
					console.error("Error in getting kuser id from kaltura",err);
				}
			}
			accessToken = await tokenService.createAccessTokenAndRefreshToken({ uid: uid, email: tempEmail, kUserId: _.get(userProfile, "kUserId"), deviceId: _.get(deviceDetails, "deviceId"),partnerType:_.get(input,"partnerName",_.get(userData,"partnerType","")) });
			let subscriptionDetails=await pxApiService.checkSubscription(_.get(accessToken,"accessToken"),userData);
			isActive =subscriptionDetails.isActive;
			currentEntitlementStatus=subscriptionDetails.currentEntitlementStatus;
		}
		switch (input.action) {
		case "Register":
			if (userData && (currentEntitlementStatus=="active"  ||isActive==true)) {
				throw { code: "partner/user-already-registered",uid:_.get(userData,"uniqueId",input.data.uniqueId) };
			}
			partnerData = await tskyRegistrationInfo(input);
			partnerData = JSON.parse(JSON.stringify(partnerData)); // To Remove any undefined Value Key.
			break;
		case "Cancel":
			if (!uid) {
				throw { code: "partner/user-not-found", };
			}
			if (userData && (currentEntitlementStatus == "expired"||isActive==false))
				throw { code: "partner/user-already-inactive" ,uid:_.get(userData,"uniqueId",input.data.uniqueId)};
			partnerData = await tskyRegistrationInfo(input);
			//partnerData.isActive = false;
			partnerData = JSON.parse(JSON.stringify(partnerData));
			break;
		case "Renew":
			if (userData && (currentEntitlementStatus=="active"||isActive==true))
				throw { code: "partner/user-already-active" ,uid:_.get(userData,"uniqueId",input.data.uniqueId) };
			partnerData = await tskyRegistrationInfo(input);
			partnerData = JSON.parse(JSON.stringify(partnerData));
			break;
		case "Trial_Period":
			if (userData && (currentEntitlementStatus=="active"  ||isActive==true)) {
				callPx = false;
				//  throw { code: "partner/user-already-registered",uid:_.get(userData,'uniqueId',input.data.uniqueId) };
			} else {
				callPx = true;
			}
			partnerData = await tskyRegistrationInfo(input);
			partnerData = JSON.parse(JSON.stringify(partnerData));
			break;// To Remove any undefined Value Key.
		case "Grace_Period":
			if (userData && (currentEntitlementStatus=="active"  ||isActive==true)) {
				callPx = false;
				//throw { code: "partner/user-already-registered",uid:_.get(userData,'uniqueId',input.data.uniqueId) };
			} else {
				callPx = true;
			}
			partnerData = await tskyRegistrationInfo(input);
			partnerData = JSON.parse(JSON.stringify(partnerData));
			break; // To Remove any undefined Value Key.

		}
		return { uid, userData, partnerData, deviceDetails, pxpartnerDetails,dbName ,accessToken,currentEntitlementStatus ,callPx };
	} catch (e) {
		console.log("Error in TSKY Controller",e,e.stack);
		throw e;
	}
}

async function tSkyUserDetails(input) {
	let partnerData = {};
	if (input.data && _.get(input.data, "source") === "TSMOBILE") {
		try {
			let decodedData = await tokenService.verifyPartnerToken(_.get(input.data, "token"), _.get(input, "partnerType", "Tata-Sky"));
			console.log("Decoded Data", decodedData);
			partnerData.uniqueId = _.get(decodedData, "uniqueId", _.get(decodedData, "subscriberId", ""));
			partnerData.email = _.get(decodedData, "email", "");
			partnerData.deviceId = _.get(input.data, "dsn");
		} catch (error) {
			console.error(error.message);
			if (error.message == errorConfig.invalidPartnerToken.description) {
				throw apiResponse.error(errorConfig.invalidPartnerToken.description, errorConfig.invalidPartnerToken.code);
			}
			else if (error.message == errorConfig.partnerInvalidToken.description) {
				throw apiResponse.error(errorConfig.partnerInvalidToken.description, errorConfig.partnerInvalidToken.code);
			}
			throw apiResponse.error(errorConfig.invalidPartnerToken.description, errorConfig.invalidPartnerToken.code);
		}
	} else {
		const partnerDetail = await tskyPartnerData(input);
		partnerData = await tskySubscriptionInfo(partnerDetail);
	}
	const { uid, userData, dbName } = await getTskyCollectionDetails(partnerData.uniqueId);

	if (uid) {
		return { uid, userData, partnerData, dbName: dbName };
	}
	throw { code: "partner/user-not-found" };
}

async function tskyPartnerData(input) {
	const options = optionsTSky(input);
	const TSKYSubscriptionResult = await tskySubscriptionRequest(options); //TODO: confirm the dsn value comes in deviceId or some other.
	if (TSKYSubscriptionResult.data && TSKYSubscriptionResult.data.SubscriberId && TSKYSubscriptionResult.data.DSN) // TODO: Need to add|| TSKYSubscriptionResult.data.DSN !== input.deviceId
	{
		mixpanelEvent(mixpanelEventConfig.partnerSignIn + "Tata-Sky" + mixpanelEventConfig.partnerCall_Success
			, TSKYSubscriptionResult.data
			, _.get(input.data, "dsn")
			, _.get(input.data, "dsn")
			, null
			, false);
		return TSKYSubscriptionResult;
	}
	throw { code: "partner/user-not-subscribed", uid: _.get(input.data, "dsn") };
}

async function tskyRegistrationInfo(input) {
	console.log("My End Daatedddd ....", input);
	try {
		let startDate = input.data.startDate.split("-");
		let endDate = input.data.endDate.split("-");
		input.data.startDate = new Date(Date.UTC(+startDate[2], startDate[1] - 1, +startDate[0]));
		input.data.endDate = new Date(Date.UTC(+endDate[2], endDate[1] - 1, +endDate[0]));
		let state = _.get(input, "action", input.action).toLowerCase();
		return {
			externalId: _.get(input, "externalId", input.data.externalId),
			deviceId: _.get(input, "deviceId", input.data.dsn),
			uniqueId: _.get(input, "uniqueId", input.data.uniqueId),
			dns: _.get(input, "dns", input.data.dns),
			//  isActive: true,
			subscription: {
				startDate: _.get(input.data, "startDate", ""),
				endDate: _.get(input.data, "endDate", ""),
				activationDate: _.get(input.data, "startDate"),
				transactionId: _.get(input.data, "transactionId", input.data.transactionId),
				source: _.get(input, "source", input.data.source),
				deviceType: _.get(input, "deviceType", input.data.deviceType),
				state: state ? state : ""
			}
		};
	}
	catch (e) {
		console.error("Storage error", e, e.stack);
		throw e;
	}
}

async function tskySubscriptionInfo(TSKYSubscriptionResult) {
	try {
		return {
			email: TSKYSubscriptionResult.data.email ? TSKYSubscriptionResult.data.email : "",
			uniqueId: TSKYSubscriptionResult.data.SubscriberId,
			deviceId: TSKYSubscriptionResult.data.DSN,
		};
	} catch (error) {
		throw { code: "partner/user-not-subscribed" };
	}
}

function optionsTSky(input) {
	let options = {
		url: `https://${config.tSkyDetails.host}${config.tSkyDetails.secureLoginAPI}`,
		method: "POST",
		headers: {
			"authorization": input.data.token,
			"partner": config.tSkyDetails.partner,
			"x-partner-key": config.tSkyDetails.partnerKey
		},
		body: {
			dsn: input.data.dsn
		},
		json: true
	};
	if (_.get(input.data, "source") === constant.TATASKYSOURCE.TSATV) {
		options.headers.source = `${input.data.source}`;
	}
	return options;
}

async function tskySubscriptionRequest(optionsSubscriptionInfo) {
	try {
		// const tSKYSubscriptionResponse = await rp(optionsSubscriptionInfo);
		const tSKYSubscriptionResponse = await axios.post(optionsSubscriptionInfo.url, optionsSubscriptionInfo.body, {
			headers: optionsSubscriptionInfo.headers
		});

		if (tSKYSubscriptionResponse.data.code == "22002") {
			throw { code: "partner/invalid-dsn" };
		} else if (tSKYSubscriptionResponse.data.code == "3") {
			throw { code: "partner/invalid-source" };
		}
		return tSKYSubscriptionResponse.data;

	} catch (error) {
		console.error("Errror in Sending the request", error);
		if (error.response && error.response.data) {
			console.error("TSKY Request Error: ", error.response.data);
			mixpanelEvent(mixpanelEventConfig.partnerSignIn + "Tata-Sky" + mixpanelEventConfig.partnerCall_Error
				, error.response.data
				, _.get(optionsSubscriptionInfo.body, "dsn")
				, _.get(optionsSubscriptionInfo.body, "dsn")
				, null
				, false);
			throw apiResponse.error(errorConfig.invalidPartnerToken.description, errorConfig.invalidPartnerToken.code); //R15 TODO: Update the message.    
		} else {
			console.error("TSKY Request Error: Blank Response");
		}
		throw { code: "partner/user-not-subscribed" };
	}
}
async function getTskyCollectionDetails(uniqueId) {
	// let transactionIdUserUid;
	let userData;
	let uid;
	let dbName;
	let result = await usersProfileService.getPartnerDetailsByUniqueId(uniqueId, config.tSkyDetails.partnerType);
	if (_.has(result, "status")) {
		return false;
	}
	else {   //Document Present in mongoDB return this
		if (!_.has(result, "status")) {
			uid = _.get(result, "uid");
			userData = result,
			dbName = "mongoDb";
		}
		return { uid: uid, userData: userData, dbName: dbName };
	}
}



const adminToken = require("../schema").adminToken;

module.exports = {
	updateAdminToken,
	getAdminToken
};

async function updateAdminToken(newToken) {
	// eslint-disable-next-line no-undef
	return new Promise(async (res) => {
		adminToken.update(null, { "adminKsToken": newToken}, { upsert: true, useFindAndModify: false }, function (err, data) {
			if (!err) {
				res(data);
			} else {
				res({ status: 1761, message: "Token not updated" });
			}
		});
	});
}

async function getAdminToken() {
	// eslint-disable-next-line no-undef
	return new Promise(async (res) => {
		adminToken.find(null, function (err, data) {
			if (!err) {
				res(data[0]);
			} else {
				res({ status: 1762, message: "Not able to get token" });
			}
		});
	});
}
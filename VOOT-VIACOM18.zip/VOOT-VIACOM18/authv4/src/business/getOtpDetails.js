const { errorConfig } = require("../config");
const usersProfile = require("../services/usersProfile");
const unVerifiedUser = require("../services/unverifiedUser");
const unVerifiedImsUser = require("../services/unVerifiedImsUser");
const _ = require("lodash");
const apiResponse = require("../utils/apiResponse");
const { responseFormat} = require("../format");
module.exports = getOtpDetails;

async function getOtpDetails(input) {
	let response;
	if (_.has(input, "email")) {
		response = await emailFlow(input);
		return response;
	} else if (_.has(input, "mobile")) {
		response = await mobileFlow(input);
		return response;
	}
}
async function emailFlow(input) {

	try {
		let type, email;
		email = _.get(input, "email", "").toLowerCase();
		type = _.get(input, "type", "").toLowerCase();
		let usersData;
		switch (type) {
		case "forgotpassword":
			usersData = await usersProfile.getUserInformationByEmail(email);
			break;
		case "signup":
			usersData = await unVerifiedUser.getUserInformationByEmail(email);
			break;
		}
		if (_.has(usersData, "status")) {
			return apiResponse.error(errorConfig.checkEmailSocialLogin.description, errorConfig.checkEmailSocialLogin.code);
		} else {
			const successMessage = await responseFormat.OtpRetriveFormate(usersData, type);
			return apiResponse.success(successMessage);
		}
	} catch (error) {
		if (!error.code) {
			console.error("No Error Code ", error);
			return apiResponse.error(errorConfig.requestFailed, 400);
		}
		switch (error.code) {
		case "auth/user-not-found":
			// NOT_FOUND, document related to uId but user might exist in firebase auth | TODO: fix it
			return apiResponse.error(errorConfig.checkEmailSocialLogin.description, errorConfig.mobileNotRegistered.code);
		case "otp/data-not-found":
			return apiResponse.error(errorConfig.getOtpDataNotFound.description, errorConfig.getOtpDataNotFound.code);
		default:
			console.log("New Error Code, which is not handled: ", error.code);
			return apiResponse.error(errorConfig.requestFailed);
		}
	}

}
async function mobileFlow(input) {
	try {
		let type, mobile,countryCode;
		mobile = _.get(input, "mobile", "").toLowerCase();
		type = _.get(input, "type", "").toLowerCase();
		countryCode = _.get(input, "countryCode", "").toLowerCase();
		let usersData;
		switch (type) {
		case "forgotpassword":
			usersData = await usersProfile.getUserInformationByEmail(`${ _.get(input, "countryCode", "+91").toLowerCase()}${ mobile }@voot.com`);
			break;
		case "signup":
			usersData = await unVerifiedUser.getUserInformationByMobileCountryCode(mobile, countryCode);
			break;
		case "ims":
			usersData = await unVerifiedImsUser.getUserInformationByMobileCountryCode(mobile, countryCode);	
		}

		if (_.has(usersData, "status")) {
			return apiResponse.error(errorConfig.mobileNotRegistered.description, errorConfig.mobileNotRegistered.code);
		} else {


			const successMessage = await responseFormat.OtpRetriveFormate(usersData, type);
			return apiResponse.success(successMessage);
		}

	} catch (error) {
		if (!error.code) {
			console.error("No Error Code ", error);
			return apiResponse.error(errorConfig.requestFailed, 400);
		}
		switch (error.code) {
		case "auth/user-not-found":
			// NOT_FOUND, document related to uId but user might exist in firebase auth | TODO: fix it
			return apiResponse.error(errorConfig.mobileNotRegistered.description, errorConfig.mobileNotRegistered.code);
		case "otp/data-not-found":
			return apiResponse.error(errorConfig.getOtpDataNotFound.description, errorConfig.getOtpDataNotFound.code);
		default:
			console.log("New Error Code, which is not handled: ", error.code);
			return apiResponse.error(errorConfig.requestFailed);
		}
	}
}

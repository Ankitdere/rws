const { smsDataService } = require("../services");
const { dateTime } = require("../utils");

/**
 * @param {Object} options
 * @param {Date} options.from
 * @param {Date} options.till 
 * @returns {Object} Query
 */
const populateQuery = function (options = {}) {
	const { from, till } = options;
	return {
		sentDate: {
			$gte: from,
			$lt: till
		}
	};
};

/**
 * @param {Object} input 
 * @param {String} input.startDate yyyy-mm-dd format
 * @param {String} input.endDate yyyy-mm-dd format
 */
const smsData = async function (input = {}) {
	let { startDate: fromDate, endDate } = input;
	const tillDate = dateTime.addDays(endDate, 1);
	const dateStringList = [fromDate, tillDate];
	const dateArr = dateStringList.map(date => new Date(dateTime.getDateString({}, date)));
	const [from, till] = dateArr;
	const queryOptions = {
		from,
		till,
	};
	const query = populateQuery(queryOptions);
	console.info({ source: "smsData Business", query });
	return smsDataService.getData(query);
};

module.exports = smsData;
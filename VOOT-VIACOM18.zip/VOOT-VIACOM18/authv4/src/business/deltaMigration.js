"use strict";
const { userService, userProfileService } = require("../services");
const { generateHash } = require("../utils");
const randomId = require("randomstring");
const _ = require("lodash");

module.exports = {
	importOrUpdateAccountData,
	importOrUpdateAuth,
	updateAuthPassword,
	updateUserSystemData,
	importSocailAuth
};

async function importOrUpdateAuth(userAuth, userProfile, password) {
	let uid, salt, passwordHash, response = {
		status: "importOrUpdateAuth failure"
	};
	salt = randomId.generate({
		length: 8,
		charset: "alphanumeric"
	});
	passwordHash = await generateHash(password, salt);
	userAuth.passwordHash = passwordHash;
	userAuth.passwordSalt = salt;
	let authInsert = await userService.updateOrInsertUser({ "uid": userAuth.uid }, userAuth);
	uid = _.get(userAuth, "customClaims.customUid", _.get(userAuth, "uid"));
	let profileInsert = await userProfileService.updateUserInformation({ uid: uid}, userProfile);
	if (_.get(authInsert, "status", 0) == 0 && _.get(profileInsert, "status", 0) == 0) {
		response = {
			status: "importOrUpdateAuth success"
		};
	}
	return response;
}

async function importOrUpdateAccountData(userProfile) {
	let response = {
		status: "importOrUpdateAccountData failure"
	};
	let userProfileInfo = await userProfileService.updateUserInformation({ uid: userProfile.uid }, userProfile);
	if (_.get(userProfileInfo, "status", 0) == 0) {
		response = {
			status: "importOrUpdateAccountData success"
		};
	}
	return response;
}

async function updateAuthPassword(userAuth, password) {
	let response = {
		status: "updateAuthPassword failure"
	};
	let salt = randomId.generate({
		length: 8,
		charset: "alphanumeric"
	});
	let passwordHash = await generateHash(password, salt);
	let passwordUpdate = await userService.updateOrInsertUser({ "uid": userAuth.uid }, { "passwordHash": passwordHash, "passwordSalt": salt });
	if (_.get(passwordUpdate, "status", 0) == 0) {
		response = {
			status: "updateAuthPassword success"
		};
	}
	return response;
}

async function updateUserSystemData(uid, _systemData){
	let response = {
		status: "updateUserSystemData failure"
	};
	let systemInfo = await userProfileService.updateUserInformation({ "uid": uid }, { _system: _systemData });
	if (_.get(systemInfo, "status", 0) == 0) {
		response = {
			status: "updateUserSystemData success"
		};
	}
	return response;
}

async function importSocailAuth(userAuth, userProfile){
	let response = {
		status: "importSocailAuth failure"
	};
	let authInsert = await userService.updateOrInsertUser({ "uid": userAuth.uid }, userAuth);
	let uid = _.get(userAuth, "customClaims.customUid", _.get(userAuth, "uid"));
	let profileInsert = await userProfileService.updateUserInformation({ uid: uid}, userProfile);
	if (_.get(authInsert, "status", 0) == 0 && _.get(profileInsert, "status", 0) == 0) {
		response = {
			status: "importSocailAuth success"
		};
	}
	return response;
}




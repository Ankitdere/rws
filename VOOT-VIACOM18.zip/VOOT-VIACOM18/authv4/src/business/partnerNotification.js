"use strict";

const commonUtils = require( "../utils" ).common;
const apiResponse = require( "../utils" ).apiResponse;
const config = require( "../config" ).configuration;
const mongoUser = require( "../format" ).mongoUser;
const moment = require( "moment" );
const kalturaBL = require( "./kalturaBL" );
const errorConfig = require( "../config" ).errorConfig;
const m2mitNotification = require( "./m2mit" );
const { tataSkyNotification, userProfileService, userService, pxApiService, tokenService, kalturaService } = require( "../services" );
const _ = require( "lodash" );
const commonHelperFunctions = require( "../helper" ).commonHelperFunctions;
const mixpanelService = require( "../services/mixpanelService" );
const notificationService = require( "../services/notificationService" );
const kafkaService = require( "../services/kafkaService" );
const mixPanelConfig = require( "../config/mixPanelConfig" );
const { processPartnerNotificaton } = require( "./asyncPartnerProcess" );
const storeKUserId = require("./partnerSignIn").storeKUserId;
module.exports = partnerNotification;

async function partnerNotification ( input ) {

	let notificationObj = await notificationService.getInitialNotificationObj( input );
	notificationObj = await notificationService.updateNotificationStage( notificationObj, true, "validation" );
	let response;
	try {
		//TODO: comman function will call after isEable is true
		console.debug( "Functionality call for Async Function", config[ `${input.partnerName}AsyncConfig` ] );
		let asyncFunctionPartnerName = _.get( input, "partnerName" ) == "Tata-Sky" ? "TataSky" : _.get( input, "partnerName" );
		console.debug( "Confguration Load for Async Function", asyncFunctionPartnerName );

		if ( config[ `${asyncFunctionPartnerName}AsyncConfig` ].ïsEnable ) {
			response = await processPartnerNotificaton( input );
			return response;
		}
		if ( input.partnerName == "M2MIT" ) {
			response = await m2mitNotification.m2mitNotification( input );
			return response;
		} else {
			const { uid, userData, partnerData, deviceDetails, pxpartnerDetails, accessToken,currentEntitlementStatus ,callPx } = await tataSkyNotification(input);
			console.log("tata-sky partner details", partnerData);
			let response;
			if ( uid ) {
				const tempEmail = await commonUtils.createTempEmail( uid, input );
				// const userrData = await userService.getUserById(uid);
				// const userProfile = await userProfileService.getUserInformationById(uid)
				const userProfile = userData;
				if ( !accessToken ) {
					if ( _.isEmpty( _.get( userData, "kUserId" ) ) ) {
						try {
							let response = await kalturaService.getUserByUsername( tempEmail );
							userProfile.kUserId = _.get( response, "id" );
							// eslint-disable-next-line no-undef
							await storeKUserId( userData.kUserId, uid, _.get( input, "deviceId", "" ) );
						} catch ( err ) {
							console.error( "Error in getting kuser id from kaltura", err );
						}
					}
					// eslint-disable-next-line no-const-assign
					accessToken = await tokenService.createAccessTokenAndRefreshToken( { uid: uid, email: tempEmail, kUserId: _.get( userProfile, "kUserId" ), deviceId: _.get( deviceDetails, "deviceId" ), partnerType: _.get( input, "partnerName", _.get( userData, "partnerType", "" ) ) } );
				}
				let PXAction;
				switch ( input.action ) {
				case "Cancel":
					PXAction = config.pXApiDetails.cancelSubcriptionAction;
					response = { "status": { "code": 200, "message": `${input.partnerName}${errorConfig.PartnerUserDataCancel}` } };
					break;
				case "Register":
				case "Renew":
					if ( currentEntitlementStatus == "new" ) {
						PXAction = config.pXApiDetails.newSubcriptionAction;
					} else {
						PXAction = config.pXApiDetails.renewSubcriptionAction;
					}
					response = { "status": { "code": 200, "message": `${input.partnerName}${errorConfig.PartnerUserDataRenew}` } };
					break;
				case "Grace_Period":
				case "Trial_Period":
				{
					let action = input.action.replace("_", " ");
					if (callPx) {
						PXAction = config.pXApiDetails.renewSubcriptionAction;
					} else {
						PXAction = false;
					}
					response = { "status": { "code": 200, "message": `${input.partnerName}${errorConfig.PartnerUserActivated}${action}.` } };
					break;
				}
				}
				await storePartnerData( userData, uid, partnerData, false, config.tSkyDetails.partnerType, parseInt( _.get( userData, "lastLoginCount" ), 10 ), tempEmail, input.action );
				// let userProfileData = await userProfileService.getUserInformationById(uid)
				let userProfileData = await userProfileService.getUserInformationByIdFromPrimaryPre( uid );
				console.debug( "UserProfile", userProfileData );
				userProfileData.subscription = partnerData.subscription;
				notificationObj = await notificationService.updateBasicInfo(notificationObj, userProfileData);
				notificationObj = await notificationService.updateNotificationStage(notificationObj, true, "auth", response);
				console.log("userProfileData After adding subscription from partnerData", userProfileData);
				if (PXAction) {
					let PXResponse = await pxApiService.callPX(input, userProfileData, pxpartnerDetails, _.get(accessToken, "accessToken"), PXAction);
					if (!PXResponse) {
						notificationObj = await notificationService.updateNotificationStage(notificationObj, false, "subscription", { code: "partner/subscription-fail", uid: _.get(input.data, "uniqueId") });
						throw { code: "partner/subscription-fail", uid: _.get(input.data, "uniqueId") };
					}
				}
				mixpanelService(mixPanelConfig.partnerNotification + _.get(input, "partnerName") + mixPanelConfig.success,
					response,
					_.get( input.data, "uniqueId", _.get( input.data, "dsn", uid ) ),
					null, null, false
				);
				notificationObj = await notificationService.updateNotificationStage( notificationObj, true, "subscription" );
				notificationObj = await notificationService.updateNotificationStage( notificationObj, true, "entitlement" );
				if (config.kafkaConfig.enable.processNotification) {
					kafkaService.pushEventToKafka(config.kafkaConfig.topic.partnerNotification, notificationObj);
				}
				return response;
			} else {//creating new User 
				let userAuthMongo = await mongoUser.initFormatForOtherPartner( input, ( _.get( input, "partnerName" ) ).toLowerCase() );
				const tempEmail = await commonUtils.createTempEmail( _.get( userAuthMongo, "uid" ), input );
				let userProfileData = await storePartnerData( userAuthMongo, _.get( userAuthMongo, "uid" ), partnerData, true, `${config.tSkyDetails.partnerType}`, 1, tempEmail, input.action );//TODO:apply check condition with partner name
				userService.insertUser( userAuthMongo );
				const kalturaRegistrationLogin = await kalturaRegistration( tempEmail, input, userProfileData, userAuthMongo, deviceDetails );
				const accessToken = await tokenService.createAccessTokenAndRefreshToken( { uid: _.get( userAuthMongo, "uid" ), email: tempEmail, kUserId: _.get( kalturaRegistrationLogin, "kUserId" ), deviceId: _.get( input.data, "dsn", "" ) } );
				await storeKUserIdInDb( userAuthMongo, _.get( kalturaRegistrationLogin, "kUserId" ) );
				let PXAction = config.pXApiDetails.newSubcriptionAction;
				// userProfileData = await userProfileService.getUserInformationById(_.get(userAuthMongo, 'uid'))
				userProfileData = await userProfileService.getUserInformationByIdFromPrimaryPre( _.get( userAuthMongo, "uid" ) );
				userProfileData.subscription = partnerData.subscription;
				notificationObj = await notificationService.updateBasicInfo( notificationObj, userProfileData );
				console.log( "Bring data form Primary Prefer :: UserProfile", userProfileData );
				let PXResponse = await pxApiService.callPX( input, userProfileData, pxpartnerDetails, _.get( accessToken, "accessToken" ), PXAction );
				if ( !PXResponse )
					throw { code: "partner/subscription-fail", uid: _.get( input.data, "uniqueId" ) };
				mixpanelService( mixPanelConfig.partnerNotification + _.get( input, "partnerName" ) + mixPanelConfig.success,
					response,
					_.get( input.data, "uniqueId", _.get( input.data, "dsn", uid ) ),
					null, null, false
				);
				response = { "status": { "code": 200, "message": `${input.partnerName}` + " user is Registered." } };
				notificationObj = await notificationService.updateNotificationStage( notificationObj, true, "auth", response );
				mixpanelService( mixPanelConfig.partnerNotification + _.get( input, "partnerName" ) + mixPanelConfig.success,
					{ response: response, requestBody: input },
					_.get( input.data, "uniqueId", _.get( input.data, "dsn", _.get( userAuthMongo, "uid" ) ) ),
					null, null, false
				);
				if (config.kafkaConfig.enable.processNotification) {
					kafkaService.pushEventToKafka(config.kafkaConfig.topic.partnerNotification, notificationObj);
				}
				return response;
			}
		}
	} catch ( error ) {
		console.log( "Main Notification Error", error, error.stack );
		if (error.basicNotification) {
			kafkaService.pushEventToKafka(config.kafkaConfig.topic.partnerNotification, error.basicNotification);
		}
		if (config.kafkaConfig.enable.processNotification && config.kafkaConfig.enable.processNotificationError) {
			kafkaService.pushEventToKafka(config.kafkaConfig.topic.partnerNotification, notificationObj);
		}
		switch ( error.code ) {
		case "partner/user-already-registered":
			return apiResponse.error( `${input.partnerName}${errorConfig.PartnerUserAlreadyReg}`,
				2100,
				mixPanelConfig.partnerNotification + _.get( input, "partnerName" ) + mixPanelConfig.serverValidation_Error,
				input,
				error.uid ? _.get( input.data, "uniqueId" ) : error.uid, 400, false );
		case "partner/user-not-found":
			return apiResponse.error( `${input.partnerName} ${errorConfig.userDoesNotExist.description}`, 2101, mixPanelConfig.partnerNotification + _.get( input, "partnerName" ) + mixPanelConfig.serverValidation_Error, input, error.uid ? _.get( input.data, "uniqueId" ) : error.uid, 400, false );
		case "partner/subscription-fail":
			return apiResponse.error( `${errorConfig.subscriptionfail}`, 2102, mixPanelConfig.partnerNotification + _.get( input, "partnerName" ) + mixPanelConfig.serverValidation_Error, input, error.uid ? _.get( input.data, "uniqueId" ) : error.uid, 400, false );
		case "partner/user-already-active":
			return apiResponse.error( `${input.partnerName}${errorConfig.PartnerUserAlreadyActive}`, 2102, mixPanelConfig.partnerNotification + _.get( input, "partnerName" ) + mixPanelConfig.serverValidation_Error, input, error.uid ? _.get( input.data, "uniqueId" ) : error.uid, 400, false );
		case "partner/user-already-inactive":
			return apiResponse.error( `${input.partnerName}${errorConfig.PartnerUserAlreadyCancel}`, 2103, mixPanelConfig.partnerNotification + _.get( input, "partnerName" ) + mixPanelConfig.serverValidation_Error, input, _.get( input.data, "uniqueId" ), 400, false );
		case "partner/user-already-active-m2mit":
			return apiResponse.error( `${errorConfig.m2mitUserActiveStatus}`, 2102, mixPanelConfig.partnerNotification + _.get( input, "partnerName" ) + mixPanelConfig.serverValidation_Error, input, error.uid ? _.get( input.data, "uniqueId" ) : error.uid, 400, false );
		}
		if ( !error.code ) throw apiResponse.error( errorConfig.requestFailed, 500 );
	}

}


async function storePartnerData ( monogoAuth, uId, partnerData, newUser, partnerType, lastLoginCount = 1, tempEmail = null, actionToStoreTime = "" ) {
	if ( tempEmail != null ) {
		//tempEmail = tempEmail;
	} else {
		tempEmail = `${uId}@${config.jioSubscription.partnerType.toLowerCase()}.com`;
	}
	let parTnerDataWithoOutSubscription = JSON.parse( JSON.stringify( partnerData ) );
	//delete parTnerDataWithoOutSubscription.subscription;
	let profileData;
	let lastLoginDate = moment().format( "MMMM Do YYYY, h:mm:ss a" );
	if ( !newUser ) {
		await commonHelperFunctions.setDocumentTimeStamp( uId, ( actionToStoreTime == "Register" ? "Renew" : actionToStoreTime ) );
		profileData = {
			partnerType: partnerType,

			...parTnerDataWithoOutSubscription,
			lastLoginDate: lastLoginDate,
			lastLoginCount: lastLoginCount + 1,


		};
	} else {
		await commonHelperFunctions.setDocumentTimeStamp( uId, actionToStoreTime );
		profileData = {
			tempEmail: tempEmail,
			partnerType: partnerType,
			...parTnerDataWithoOutSubscription,
			lastLoginDate: lastLoginDate,
			lastLoginCount: 1,
			profileData: {
				Preferences: { Languages: [ "Hindi", "English" ] },
				Gender: "U"
			},
			uid: uId


		};
	}
	await userProfileService.updateUserInformation( { uid: _.get( monogoAuth, "uid" ) }, profileData );

	return profileData;
}


/* async function kalturalogin ( input, tempEmail, userRecord, userData, jioData, partnerDetails ) {
	try {
		let uid = _.get( userRecord, "profileData.uid", _.get( userRecord, "uid", "" ) );

		if ( _.get( input, "partnerType" ) == Config.TSKYDetails.partnerType ) {
			input.deviceBrand = Config.TSKYDetails.deviceBrand;
			input.deviceId = input.data.dsn;
		}
		if ( _.get( input, "partnerType" ) == Config.jioSubscription.partnerType ) {
			input.deviceBrand = input.partnerType;
			input.deviceId = input.deviceId;
		}
		console.log( "Device id", input.deviceId );
		console.log( "DeviceBrand", input.deviceBrand );
		let device = await kalturaService.setupHouseholdDevice( input.deviceId, input.deviceBrand ); // Not an API but a promise, do we need to await here?
		console.log( "====== Device ==========: ", device );
		let kalturaUserLoginResult;
		try {
			kalturaUserLoginResult = await kalturaService.login( tempEmail, uid, device.udid );

		} catch ( error ) {
			switch ( _.get( error, "result.error.code", _.get( error, "code" ) ) ) {
			case Kaltura.errorCodes.USER_DOES_NOT_EXIST.code: // Kaltura user does not exists, register as new user

				kalturaRegistration( tempEmail, input, userRecord, userData );
				break;
			case Kaltura.errorCodes.USER_WRONG_USERNAME_OR_PASSWORD.code: // Kaltura user does not exists, register as new user
				//reject({code: Kaltura.errorCodes.USER_WRONG_USERNAME_OR_PASSWORD.code, message: Kaltura.errorCodes.USER_WRONG_USERNAME_OR_PASSWORD.message});
				break;
			case Kaltura.errorCodes.INSIDE_LOCK_TIME.code: // Kaltura user does not exists, register as new user
				apiResponse.error( Kaltura.errorCodes.INSIDE_LOCK_TIME.message, Kaltura.errorCodes.INSIDE_LOCK_TIME.code );
				break;
			default:
				apiResponse.error( "unknown error in kaltura login:", error );
			}
		}

		let kalturaHousehold;
		let kalturaHouseholdId;

		if ( kalturaUserLoginResult.result.user.householdId !== 0 ) {
			console.log( "add device in houseHold:", kalturaUserLoginResult.result.user.householdId );
			await kalturaService.addDeviceToUserHousehold( device, kalturaUserLoginResult.result, kalturaUserLoginResult.result.user.householdId, uid, tempEmail, false ); // not waiting for response
			kalturaHouseholdId = kalturaUserLoginResult.result.user.householdId;
		} else {
			console.log( "=================Kaltura HouseHold is 0 for===", tempEmail );
			kalturaHousehold = await kaltura.createHousehold( tempEmail, kalturaUserLoginResult.result.loginSession.ks );
			device = await kaltura.setupHouseholdDevice( input.deviceId, input.deviceBrand );
			await kaltura.addDeviceToUserHousehold( device, kalturaUserLoginResult.result, _.get( kalturaHousehold, "result.id" ) ); // not waiting for response
			kalturaHouseholdId = _.get( kalturaHousehold, "result.id" );

		}
		const kalturaAppTokenResponse = await kalturaService.getAppToken( kalturaUserLoginResult.result.loginSession.ks );
		return await responseFormatter.partnerapiResponse( _.get( kalturaUserLoginResult, "result.user.householdId" ), kalturaUserLoginResult, kalturaAppTokenResponse, userData, userRecord, tempEmail, input );
	}
	catch ( error ) {
		console.error( "Error in kaltura login:", error );
		if ( !error.code ) throw apiResponse.error( message.requestFailed, 500 );
	}
} */

async function kalturaRegistration ( email, input, userRecord, userData, deviceDetails = null ) {
	try {
		let uid = _.get( userRecord, "profileData.uid", _.get( userRecord, "uid", "" ) );
		//JIO Case 
		if ( _.get( input, "partnerType" ) == config.jioSubscription.partnerType ) {
			//input.deviceId = input.deviceId;
			input.deviceBrand = input.partnerType;
		}
		//TataSky Case 
		if ( _.has( deviceDetails, "deviceId" ) ) {
			input.deviceId = deviceDetails.deviceId;
		}
		if ( _.has( deviceDetails, "deviceBrand" ) ) {
			input.deviceBrand = deviceDetails.deviceBrand;//
		}
		console.log( "Device id", input.deviceId );
		console.log( "DeviceBrand", input.deviceBrand );

		try {
			let kalturaUserLoginResult = await kalturaBL.kalturaRegistration( email, uid, input, userRecord, userData, false );

			return kalturaUserLoginResult;
			// return await responseFormat.partnerapiResponse(_.get(kalturaUserLoginResult, 'result.id'), kalturaUserLoginResult, kalturaUserLoginResult, userData, userRecord, email);
		} catch ( error ) {
			return apiResponse.error( error );
		}

	}
	catch ( error ) {
		console.error( "Error in Kaltura", error );
		if ( !error.code ) throw apiResponse.error( errorConfig.requestFailed, 500 );
	}
}
async function storeKUserIdInDb ( mongoAuth, kUserId ) {
	let result = await userProfileService.updateUserInformation( { uid: _.get( mongoAuth, "uid" ) }, { kUserId: kUserId } );
	return result;
}

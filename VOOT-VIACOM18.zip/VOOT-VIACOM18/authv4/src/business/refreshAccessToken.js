"use strict";

const tokenService = require("../services").tokenService;
const _ = require("lodash");

module.exports = refreshAccessToken;

async function refreshAccessToken(accessToken, deviceId,partnerData=false,regionInfo) {
	console.log("Inside getTokenInfo() with parameter accessToken: ", accessToken);
	let refreshAccessToken = await tokenService.refreshAccessToken(accessToken, deviceId,partnerData,regionInfo);
	const tokenInfo = {
		access_token: _.get(refreshAccessToken, "accessToken"),
		refresh_token: _.get(refreshAccessToken, "refreshToken"),
		expires_in: _.get(refreshAccessToken, "expirationTime")
	};
	return tokenInfo;
}

const axios = require("axios");
const { google } = require("googleapis");
const _ = require("lodash");
const { configuration } = require("../config");

const CONFIG_JSON = configuration.serviceAccount;
const PROJECT_ID = CONFIG_JSON.project_id;
const HOST = "https://firebaseremoteconfig.googleapis.com";
const PATH = "/v1/projects/" + PROJECT_ID + "/remoteConfig";
const SCOPES = ["https://www.googleapis.com/auth/firebase.remoteconfig"];

/**
 * @returns {string} access_token
 */
async function getAccessToken() {
	const {
		client_email,
		private_key
	} = CONFIG_JSON;
	const jwtClient = await new google.auth.JWT(
		client_email,
		null,
		private_key,
		SCOPES,
		null
	);
	const tokens = await jwtClient.authorize();
	return tokens.access_token;
}

/**
 * Retrieve the current Firebase Remote Config template from the server.
 * @return {object} remoteConfigUpdateUser 
 */
async function getRemoteConfig() {
	try {
		const accessToken = await getAccessToken();
		const params = {
			method: "get",
			url: HOST + PATH,
			gzip: true,
			resolveWithFullResponse: true,
			headers: {
				"Authorization": "Bearer " + accessToken,
				"Accept-Encoding": "gzip",
			}
		};
		const {
			data
		} = await axios(params);
		const remoteConfigUpdateUser = JSON.parse(_.get(data, "parameters.TVConfiguration.defaultValue.value", {}));
		return remoteConfigUpdateUser;
	} catch (error) {
		console.error("Error in getRemoteConfig", error.message);
		return error;
	}
}

module.exports = {
	getRemoteConfig
};
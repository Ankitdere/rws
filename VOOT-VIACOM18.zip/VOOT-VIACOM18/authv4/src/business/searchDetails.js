"use strict";
module.exports = searchDetails;
const { userProfileService } = require("../services");
const responseFormat = require("../format").responseFormat;


const { checkEntitlementStatus } = require("../services/pxApiService");


module.exports = searchDetails;
async function searchDetails(input) {
	try {
		let result;

		if (input.mobile) {
			console.log("INSIDE BUSINESS ", input);
			let mobile = input.countryCode + input.mobile;
			result = await userProfileService.getUserInformationByMobileWithCountryCode(mobile);
		}
		else if (input.email) {
			let email = input.email;
			console.log("email", email);
			email = email.toLowerCase();
			result = await userProfileService.getUserInformationByEmail(email);
			console.log("result", result);
		} else if (input.uid) {
			//console.log("INSIDE BUSINESS ", input);
			let uid = input.uid;
			result = await userProfileService.getUserInformationById(uid);
		}

		let final = await responseFormat.v3SearchApiResponse(result, result);
		console.log("INSIDE RESULT", final);
		const subscription = await checkEntitlementStatus(final.data.authToken.accessToken);
		console.log("SUBSCRIPTION", subscription.status);


		final.data.entitlement = {
			householdId: final.data.householdId,
			kUserId: final.data.kUserId || "",
			kTokenId: final.data.kTokenId || "",
			kToken: final.data.kToken || "",
			ks: final.data.ks || "",
			parentKs: final.data.parentKs || "",
		};

		delete final.data.householdId;
		final.data.subscription = subscription.status;


		if (input.flags.subscription === false) {
			delete final.data.subscription;
		}
		if (input.flags.entitlement === false) {
			delete final.data.entitlement;
		}
		if (input.flags.authToken === false) {
			delete final.data.authToken;
		}
		if (input.flags.basic === false) {
			final.data = {
				"authToken": final.data.authToken,
				"entitlement": final.data.entitlement,
				"subscription": final.data.subscription
			};
		}

		if (input.flags["provider.amazon"] === false && input.flags["provider.all"] === false) {
			delete final.data.amazonDetails;
		}
		if (input.flags["provider.google"] === false && input.flags["provider.all"] === false) {
			delete final.data.googleDetails;
		}

		if (input.flags["provider.facebook"] === false && input.flags["provider.all"] === false) {
			delete final.data.facebookDetails;
		}
		if (input.flags["provider.apple"] === false && input.flags["provider.all"] === false) {
			delete final.data.appleDetails;
		}

		return final;






		// return final;

	}

	catch (error) {
		console.log(error);
	}
}

"use strict";
const { errorConfig, configuration } = require("../config");
const { otpService  } = require("../services");
const _ = require("lodash");
const ApiResponse = require("../utils").apiResponse;
const unverifiedUser = require("../services/unverifiedUser");
const unVerifiedImsUser = require("../services/unVerifiedImsUser");
const moment = require("moment");
const { phoneExists } = require("./checkUser");
const constant = require("../utils/constant/generic");

module.exports = {
	verifyOtp,
	checkMobileWithoutOtpSending,
	getDummyEmail
};
async function verifyOtp(input) {
	let mobile, finalMessage, userExists, userDetails, hasImsVerification;
	mobile = input.countryCode + input.mobile;
	try {
		userExists = await checkMobileWithoutOtpSending(input);
		if(input.action === "imsOtp") {
			hasImsVerification = 1;
			userDetails = await unVerifiedImsUser._getUnverifiedImsUserData(input.mobile, input.countryCode);//second parameter include with CountryCode
			console.debug("===============UnverifiedImsUser==============", userDetails);
			if (configuration.Otp.isUserBlockEnableForIms && userDetails && userDetails._system && userDetails._system.failedAttempt && userDetails._system.failedAttempt.ims) {
				const isUserBlocked = await otpService.isUserBlocked(userDetails, "ims", configuration.Otp.maxNumberOfWrongOtpIms, configuration.Otp.blockDurationIms);
				if (isUserBlocked) {
					console.log(userDetails._system, "unVerifiedImsUser._system");
					let _system = userDetails._system;
					console.debug(_system, "unVerifiedImsUser._system");
					if (_system.failedAttempt && _system.failedAttempt.ims && _system.failedAttempt.ims.lastUpdatedAt) {
						_system.failedAttempt.ims.lastUpdatedAt = moment();
					}
					await unVerifiedImsUser.updateUnverifiedImsUserInformation({ "mobile": input.mobile, "countryCode": input.countryCode }, { loginStatus: constant.USER_STATUS.LOCKED, _system });
					return ApiResponse.error(errorConfig.userlocked.description, errorConfig.userlocked.code);
				}
			}
		}
		else if (userExists === true) {
			//MobilNumber exist in DB
			return ApiResponse.error(errorConfig.mobileAlreadyExist.description, errorConfig.mobileAlreadyExist.code);
		} else {
		// Get unverified user data from firestore
			hasImsVerification = 0;
			userDetails = await unverifiedUser._getUnverifiedUserData(input.mobile, input.countryCode, mobile);//second parameter include with CountryCode
			console.debug("===============UnverifiedUser==============", userDetails);
			if (configuration.Otp.isUserBlockEnableForSignUp && userDetails && userDetails._system && userDetails._system.failedAttempt && userDetails._system.failedAttempt.signUp) {
				const isUserBlocked = await otpService.isUserBlocked(userDetails, "signUp", configuration.Otp.maxNumberOfWrongOtpSignUp, configuration.Otp.blockDurationSignUp);
				if (isUserBlocked) {
					console.log(userDetails._system, "unverifiedUser._system");
					let _system = userDetails._system;
					console.debug(_system, "new _system gg");
					if (_system.failedAttempt && _system.failedAttempt.signUp && _system.failedAttempt.signUp.lastUpdatedAt) {
						_system.failedAttempt.signUp.lastUpdatedAt = moment();
					}
					await unverifiedUser.updateUnverifiedUserInformation({ "mobile": input.mobile, "countryCode": input.countryCode }, { loginStatus: constant.USER_STATUS.LOCKED, _system });
					return ApiResponse.error(errorConfig.userlocked.description, errorConfig.userlocked.code);
				// return new Error(errorConfig.userlocked.description, errorConfig.userlocked.code);
				}
			}
		}
		// Verify OTP 
		let otpVerified = await otpService.verifyOtp(input.otp, userDetails, (hasImsVerification) ? otpService.IMS_REQUEST : otpService.SIGNUP_REQUEST);
		if (!otpVerified) {
			return ApiResponse.error(errorConfig.otpVerificationFailed, errorConfig.otpVerificationFailed.code);
		} else {
			const serviceRequestName = (hasImsVerification) ? otpService.IMS_REQUEST : otpService.SIGNUP_REQUEST; 
			const otpVerified = {
				otp: String(Math.floor(1000 + Math.random() * 9000)),
				createdAt: _.get(userDetails, "_system." + serviceRequestName + ".createdAt", moment().format("MMMM Do YYYY, h:mm:ss a")),
				updatedAt: _.get(userDetails, "_system." + serviceRequestName + ".updatedAt", moment().format("MMMM Do YYYY, h:mm:ss a")),
				attempts: _.get(userDetails, "_system." + serviceRequestName + ".attempts", 5),
				viaMobile: true,
				isOtpVerify: true
			};
			const phoneNumber = input.countryCode + input.mobile; // mobile
			input.email = await getDummyEmail(phoneNumber); // change for removing email address 
			input.isOtpVerify = true;
			if(hasImsVerification) 	{
				await unVerifiedImsUser.storeUnverifiedImsUserWithOTP(input, otpVerified,configuration.actionList.verifyOtp);//sync don inthis function
			} else {
				await unverifiedUser.storeUnverifiedUserWithOTP(input, otpVerified,configuration.actionList.verifyOtp);//sync don inthis function
			}
			finalMessage = { "isVerified": true };
			return ApiResponse.success(finalMessage);
		}

	} catch (error) {
		if (!error.code) {
			console.error("No Error Code in verifyOTP API", error);
			return ApiResponse.error(errorConfig.requestFailed, 400);
		}
		switch (error.code) {
		case "otp/invalid-request":
		case "document/not-found":
			return ApiResponse.error(errorConfig.otpDataNotFound.description, errorConfig.otpDataNotFound.code);
		case "otp/expired":
			return ApiResponse.error(errorConfig.otpExpired.description, errorConfig.otpExpired.code);
		case "otp/invalid": {
			const newSystemData=await otpService.otpVerificationFailed( userDetails, (hasImsVerification) ? "ims" : "signUp");
			console.debug("new System data",newSystemData);
			if(hasImsVerification) 	{
				await unVerifiedImsUser.updateUnverifiedImsUserInformation({ "mobile":  input.mobile },{ _system: newSystemData });
			} else {
				await unverifiedUser.updateUnverifiedUserInformation({ "mobile":  input.mobile },{ _system: newSystemData });
			}	
			return ApiResponse.error(errorConfig.otpVerificationFailed.description, errorConfig.otpVerificationFailed.code);
		}
		default:
			console.log("New Error Code, which is not handled in verifyOTP API: ", error.code);
			return ApiResponse.error(errorConfig.requestFailed, 400);
		}
	}


}
async function checkMobileWithoutOtpSending(userInput) {
	try {
		const phoneNumber = userInput.countryCode + userInput.mobile; // mobile
		const mobileExists = await phoneExists(phoneNumber);
		return mobileExists;
	}
	catch (error) {
		console.error(error);
		return ApiResponse.error(errorConfig.requestFailed, 400);
	}
}
// async function checkMobile(userInput) {
//     console.log("Reach in check Mobile function");
//     try {
//         const phoneNumber = userInput.countryCode + userInput.mobile; // mobile
//         const mobileExists = await phoneExists(userInput.mobile);
//         console.log("existence of user phone: ", mobileExists);
//         if (mobileExists === false) {
//             //MobilNumber not exist in DB, We have to send OTP.
//             // const sendOTPResponse = await otpService.sendOtp(userInput);
//             return false;
//         } else {

//             return true;
//         }
//     } catch (error) {
//         console.error(error);
//         return ApiResponse.error(errorConfig.requestFailed, 400);
//     }
// };
// async function phoneExists(phoneNumber) {
//     try {
//         const user = await userService.getUserByPhone(phoneNumber);
//         if (_.has(user, 'status')) {
//             console.log("User Does't Exist in Auth", user)
//             return false
//         } else {
//             return true;
//         }
//     } catch (error) {
//         //console.log(error);
//         return false; // resolve in both case, else it will go to Handler's catch block
//     }
// }
//Ned to Modify
async function getDummyEmail(emailpart) {
	return emailpart + "@voot.com";
}
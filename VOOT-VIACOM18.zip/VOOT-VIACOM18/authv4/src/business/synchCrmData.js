const { configuration } = require( "../config" );
const kafkaService = require( "../services/kafkaService" );
const notificationService = require( "../services/notificationService" );

module.exports = synchCrmData;

async function synchCrmData ( input ) {
	try {
		let synchNotificationObj, metaData = {};
		metaData.function = "synchCrmData";
		metaData.error = {};
		// if ( input && input.uid && !input.email ) input.email = "";
		synchNotificationObj = await notificationService.reconIntitialNotificationObj( input, metaData );
		if ( input.uid ) synchNotificationObj.data.uid = input.uid;
		kafkaService.pushEventToKafka( configuration.kafkaConfig.topic.recon, synchNotificationObj );
		return synchNotificationObj;
	} catch ( error ) {
		console.log( "error in synchCrmDataBusiness/Catch", error, error.stack );
		throw error;
	}

}

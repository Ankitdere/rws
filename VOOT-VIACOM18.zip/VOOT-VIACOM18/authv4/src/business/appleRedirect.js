"use strict";

module.exports = {setAppleUnverifiedUserData};
const { setAppleUnverifiedUser, getUnverifiedAppleUser } = require("../services").appleService;
const _ = require("lodash");
const jwt = require("jsonwebtoken");
const moment = require("moment");


async function setAppleUnverifiedUserData(userData) {
	try {

		let unverifiedUserData;
		const idTokenDecoded = jwt.decode(userData.id_token); 
		const uid  = idTokenDecoded.sub;
		userData.lastLoginDate  =  moment().format("MMMM Do YYYY, h:mm:ss a");
		const unverifiedUser = await getUnverifiedAppleUser(uid); 
		if(unverifiedUser){
			unverifiedUserData = unverifiedUser;
			unverifiedUserData.id_token = _.get(userData,"id_token");
			unverifiedUserData.code = _.get(userData,"code");
			unverifiedUserData.lastLoginDate  =  moment().format("MMMM Do YYYY, h:mm:ss a");
		}else{
			unverifiedUserData = userData;
		}
		const result = await setAppleUnverifiedUser({"uid": uid}, unverifiedUserData);
		return result;
	} catch (err) {
		console.log("Error in Apple redirect Business:", err);
		return false;
	}
}
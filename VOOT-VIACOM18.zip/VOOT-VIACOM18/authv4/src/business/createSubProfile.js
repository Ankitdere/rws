"use strict";

const subProfile = require("../services").subProfile;
const { mongoSubProfile } = require("../format");
const {
	errorConfig, configuration: config
} = require("../config");
const Constant = require("../utils/constant/generic");

module.exports = createProfile;

/**
 * @param {Object} input 
 * @param {Object} request 
 * @returns {Object}
 */
async function createProfile(input, request) {
	try {
		const { tokenInfo } = request;
		const query = {
			uid: tokenInfo.uid,
		};
		const subProfileCount = await subProfile.getCountUid(query);
		const canBeInserted =
			subProfileCount.status == Constant.NO_UID_FOUND ||
			subProfileCount.data < config.noOfSubProfilesAllowed;

		if (!canBeInserted) throw new Error(errorConfig.maxLimitSubProfile.description);

		const userAuthMongo = await mongoSubProfile.initFormatSubProfile(input, request);
		const userData = await subProfile.insertSubProfileInformation(userAuthMongo);
		if (userData.status == Constant.SUCCESS_STATUS) {
			let finalOutput = await mongoSubProfile.createSubProfileResponse(
				userAuthMongo,
				tokenInfo,
				request.headers
			);
			return finalOutput;
		}
		throw new Error(errorConfig.createSubProfile.description);

	} catch (error) {
		console.error("\n Error in createSubProfile Business/catch \n", error);
		if (error && error.message == errorConfig.maxLimitSubProfile.description) {
			throw new Error(errorConfig.maxLimitSubProfile.description);
		}
		throw new Error(errorConfig.createSubProfile.description);
	}

}



const anonymousTokenService = require("../services/index").anonymousTokenService;
const Config = require("../config").configuration;
const errorUtilities = require("../config").errorConfig;
const { tokenService } = require("../services");
const { apiResponse } = require("../utils");
const _ = require("lodash");
const responseFormat = require("../format").responseFormat;
const mixpanelConfig = require("../config/mixPanelConfig");
const Constanst = require( "../utils/constant/generic" );
const userProfileService = require("../services").userProfileService;
const commonUtil = require("../utils").common;

async function createAccessAndRefreshToken(params, accessToken) {
	let eventBaseName = "";
	let uid;
	try {
		let finalResponse = {
			grantType: params.grantType,
			clientId: params.clientId,
			apikey: params.apiKey,
		};
		let result;
		// if (params.partnerName) finalResponse.partnerName = params.partnerName;
		// if (params.code) finalResponse.code = params.code;
		let secretKey=params.clientId;
		let accessExpiry = Config.AnonymousToken.jwt.expiry.access[secretKey];
		let refreshExpiry = Config.AnonymousToken.jwt.expiry.refresh[secretKey];
		let accessSecret = Config.AnonymousToken.jwt.secret.access[secretKey];
		let rehreshSecret = Config.AnonymousToken.jwt.secret.refresh[secretKey];
		if (params.grantType == Config.AnonymousGrantType.anonymous) {
			eventBaseName = mixpanelConfig.token;
			let payload = { grantType: params.grantType, clientId: params.clientId, kUserId: Config.AnonymousToken.kalturaIdForAnonymous, uid: Config.AnonymousToken.AnonymousUserId, email: Config.AnonymousToken.AnonymousEmailId};
			result = await anonymousTokenService.createAccessAndRefreshToken(payload, accessSecret, rehreshSecret, accessExpiry, refreshExpiry, params.clientId,eventBaseName,Config.AnonymousToken.jwt.issuer);
		}
		else if (params.grantType == Config.AnonymousGrantType.authorization_token || params.grantType == Config.AnonymousGrantType.interactivity || params.grantType == Config.AnonymousGrantType.vendor_feature_token) {
			let issuer = (Config.AnonymousGrantType.vendor_feature_token==params.grantType) ?  Constanst.VOOT: Config.AnonymousToken.jwt.issuer;
			eventBaseName = mixpanelConfig.token;
			if (!accessToken) {
				console.error("\n Error in createAndRefreshToken/validation granttype authorization_token \n");
				throw apiResponse.error(errorUtilities.invalidProfileToken.description, errorUtilities.invalidProfileToken.code,eventBaseName+mixpanelConfig.clientValidation_Error,params,params.clientId,400);
			}
			const {decoded }= await tokenService.verifyToken(accessToken);
			decoded.grantType = params.grantType;
			decoded.clientId = params.clientId;
			decoded.platform = "VOOT";
			decoded.phoneNo = _.get(decoded, "uid");
			uid = _.get(decoded, "uid");
			// if (params.partnerName) decoded.partnerName = params.partnerName;
			// if (params.code) decoded.code = params.code;
			_.pullAt(decoded, "exp");
			_.pullAt(decoded, "iss");
			_.pullAt(decoded, "iat");
			_.pullAt(decoded, "TncAgreement");
			result = await anonymousTokenService.createAccessAndRefreshToken(decoded, accessSecret, rehreshSecret, accessExpiry, refreshExpiry, params.clientId,eventBaseName,issuer);
		}
		else {
			let issuer = (Config.AnonymousGrantType.vendor_feature_token==params.grantTypeRequest) ?  Constanst.VOOT: Config.AnonymousToken.jwt.issuer;
			eventBaseName = mixpanelConfig.tokenRefresh;
			if(!_.isEmpty(params.grantTypeRequest))
			{
				const decodedToken=await verifyToken(params.refreshToken,params.clientId, params.grantTypeRequest,true,eventBaseName);
				if (decodedToken.grantType != params.grantTypeRequest) {
					throw apiResponse.error(errorUtilities.invalidAnonymosTokenGrantTypeRefresh.description, errorUtilities.invalidAnonymosTokenGrantTypeRefresh.code, eventBaseName + mixpanelConfig.serverValidation_Error, params, params.clientId, 400);
				}
				finalResponse.grantType = params.grantTypeRequest;
			}
			result = await anonymousTokenService.refreshAccessToken(params.refreshToken, Config.AnonymousToken.jwt.secret.access[params.clientId], params.clientId,eventBaseName,issuer);
		}
		finalResponse.authToken = result;
		return finalResponse;
	}
	catch (err) {
		if (err.message && err.message == errorUtilities.invalidAccessToken.description) {
			throw apiResponse.error(errorUtilities.invalidAccessToken.description, errorUtilities.invalidAccessToken.code,eventBaseName+mixpanelConfig.clientValidation_Error,params,params.clientId,400);
		}
		if (err.message && err.message == errorUtilities.expiredProfileToken.description) {
			throw apiResponse.error(errorUtilities.expiredProfileToken.description, errorUtilities.expiredProfileToken.code,eventBaseName+mixpanelConfig.clientValidation_Error,params,params.clientId,400);
		}
		if (params.grantType && params.grantType == Config.AnonymousGrantType.refresh_token) {
			throw responseFormat.errorResponseCodeForAnonymous(params.grantTypeRequest,err,eventBaseName,params,uid);
		}
		throw err;
	}

}

async function verifyToken(accessToken, clientId, grantType,isInternalCall,baseEventName) {
	try {
		let clientIdNew=clientId;
		let secret = Config.AnonymousToken.jwt.secret.access[clientId];
		let responseStructure=Config.AnonymousAPIResponse.verifyTokenApiResponseMapToClientId[clientIdNew];
		clientIdNew= (!Config.AnonymousGrantType.vendor_feature_token==grantType) ? clientId : null;
		let issuer = (Config.AnonymousGrantType.vendor_feature_token==grantType) ?  Constanst.VOOT: Config.AnonymousToken.jwt.issuer;
		let decodedValue= await anonymousTokenService.verifyToken(accessToken, secret, clientIdNew,baseEventName,issuer);
		if(Config.AnonymousAPIResponse.verifyTokenApiResponseMapToClientId[clientId])
		{
			let userData=await userProfileService.getUserInformationById(decodedValue.uid);
			userData.grantType=grantType;
			userData.clientId=clientId;
			let userDataRequired=await getUserSpecificData(userData,responseStructure);
			decodedValue.userData=userDataRequired;
		}
		return decodedValue;
	}
	catch (err) {
		if(!isInternalCall)throw responseFormat.errorResponseCodeForVerifyAnonymous(grantType,err,baseEventName,clientId);
		throw err;
	}
}
async function getUserSpecificData(userData,responseStructure)
{
	try
	{
		let response=responseStructure;
		let count=commonUtil.countCharacterOccurenceInAString(responseStructure,"$")/2;
		for(let i=1;i<count;i+=2)
		{
			let substr=responseStructure.substring(commonUtil.getPositionOfSubstringOccurence(responseStructure, "$$", i)+2,commonUtil.getPositionOfSubstringOccurence(responseStructure, "$$", i+1));
			if(!_.isEmpty(_.get(userData,substr)))
			{
				response=response.replace(`$$${substr}$$`,`${_.get(userData,substr,"")}`);
			}
			if(_.isEmpty(_.get(userData,"profileData.ProfileName")))
			{
				response=response.replace("$$profileData.ProfileName$$",`${_.get(userData,"profileData.FirstName","")+" "+_.get(userData,"profileData.LastName","")}`);
			}
			if(_.isEmpty(_.get(userData,substr)))
			{
				response=response.replace(`$$${substr}$$`,"");
			}
		}
    
		return JSON.parse(response);
	}
	catch(err)
	{
		console.log(err);
	}
}

module.exports = { createAccessAndRefreshToken, verifyToken };

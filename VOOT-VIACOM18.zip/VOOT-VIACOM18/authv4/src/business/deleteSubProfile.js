"use strict";

const { subProfile, redisService } = require("../services");
const { errorConfig } = require("../config");
const Constant = require("../utils/constant/generic");
const moment = require("moment");

module.exports = deleteSubProfile;

/**
 * @param {Object} input 
 * @param {Object} request 
 * @returns {Object}
 */
async function deleteSubProfile(input,request) {
	const { tokenInfo } = request;
	try {
		const query = {
			childUid: input.childUid,
			uid: tokenInfo.uid
		};
		if(input.childUid === tokenInfo.uid) throw new Error(errorConfig.parentProfileCantBeDeleted.description);
		const userData = await subProfile.deleteSubProfileInformation(query);
		if (userData.status == Constant.SUCCESS_STATUS) {
			if (userData.data && userData.data.deletedCount === 0) {
				throw new Error(errorConfig.subProfileAlreadyDeleted.description);
			}
			try {
				await redisService.saveUserIntoRedis(input.childUid, moment().unix());
				return errorConfig.deleteSubProfileSuccess;
			} catch (err) {
				console.log("Redis Unable to Set Value", err);
			}
		}
		throw new Error(errorConfig.deleteSubProfile.description);

	} catch (error) {
		console.error("\n Error in deleteSubProfile Business/catch \n", error);
		if(error.message === errorConfig.parentProfileCantBeDeleted.description)
		{
			throw new Error(errorConfig.parentProfileCantBeDeleted.description);	
		}
		if(error.message === errorConfig.subProfileAlreadyDeleted.description)
		{
			throw new Error(errorConfig.subProfileAlreadyDeleted.description);	
		}
		console.log("Error in deleteSubProfile",error);
		throw new Error(errorConfig.deleteSubProfile.description);
	}

}



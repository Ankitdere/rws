const { errorConfig } = require("../config");
const { userProfileService, userService} = require("../services");
const _ = require("lodash");
const { apiResponse, generateHash } = require("../utils");
const randomId = require("randomstring");
const moment = require("moment");

module.exports = resetPassword;

async function resetPassword(input, tokenInfo) {
	console.info(`AccountService.resetPassword() with parameter(s) input=${JSON.stringify(input)}`);

	let email,salt;
	try {
		//In Case of Forgot password Verify token with different Ke
		email = _.get(tokenInfo, "email");
		if (_.isEmpty(email))
			throw new Error(errorConfig.cantChangePassword.description);
		// eslint-disable-next-line no-undef
		let temp = await Promise.all([userProfileService.getUserInformationByEmail(email), userService.getUserByEmail(email)]);
		let userProfile = temp[0];
		let userAuth = temp[1];
		_.get(userAuth, "customClaims.customUid", _.get(tokenInfo, "uid"));

		salt = randomId.generate({
			length: 8,
			charset: "alphanumeric"
		});
		let passwordHash = await generateHash(input.newPassword, salt);
		await userService.updateOrInsertUser({ "uid": _.get(userProfile, "uid") }, { "passwordHash": passwordHash, "passwordSalt": salt });
		await userProfileService.deleteField({ uid: userProfile.uid },{ $unset:{"_system":1},updatedAt:moment().utcOffset(+530).unix() } );
		return apiResponse.success(errorConfig.changePasswordSuccess);
	} catch (error) {
		console.error(error);
		if (error.message == errorConfig.invalidAccessToken.description)
			throw apiResponse.error(errorConfig.invalidAccessToken.description, errorConfig.invalidAccessToken.code);

		if (error.message == errorConfig.cantChangePassword.description)
			throw apiResponse.error(errorConfig.cantChangePassword.description, errorConfig.cantChangePassword.code);

		if (error.code === "auth/wrong-password") {
			throw apiResponse.error(errorConfig.wrongPassword.description, errorConfig.wrongPassword.code);
		}
		throw apiResponse.error(errorConfig.requestFailed, 400);
	}


}


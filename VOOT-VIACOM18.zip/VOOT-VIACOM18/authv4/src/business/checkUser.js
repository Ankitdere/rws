"use strict";
const { errorConfig, configuration } = require("../config");
const { userProfileService, userService, otpService, sqsService } = require("../services");
const _ = require("lodash");
const responseFormat = require("../format").responseFormat;
const ApiResponse = require("../utils").apiResponse;
const constant = require("../utils/constant/generic");
const mixpanelEvent = require("../config/mixPanelConfig");
const kafkaService = require("../services/kafkaService");
const notificationService = require("../services/notificationService");

module.exports = {
	checkUser,
	checkEmail,
	checkMobile,
	phoneExists
};

async function checkUser(input) {
	console.info(`AccountService checkUser with parameter(s) input=${JSON.stringify(input)}`);
	let checkUserResponse, userExists;
	let metaData = {},notificationObj;
	metaData = await notificationService.createMetaDataForRecon("checkUser");
	console.debug("metaData", metaData);
	notificationObj = await notificationService.reconIntitialNotificationObj(input, metaData);
	notificationObj = await notificationService.updateNotificationStage(notificationObj, true, "validation", null, "success");
	let data = {};
	data.initialAction = "sync";
	data.currentAction = "sync";
	notificationObj = await notificationService.updateReconInfo(notificationObj, data);
	try {
		switch (input.type) {
		case "email":
			userExists = await checkEmail(input,notificationObj);
			checkUserResponse = await responseFormat.emailResponse(userExists.IsExist);
			return checkUserResponse;
		case "mobile":
			userExists = await checkMobile(input,notificationObj);
			return userExists;
		default:
			return ApiResponse.error(errorConfig.requestFailed, 400);

		}
	} catch (error) {
		console.error("No Error Code in checkUser API", error);
		return ApiResponse.error(errorConfig.requestFailed, 400);
	}
}

async function checkEmail(input,notificationObj) {
	try {
		let userExists, finalMessage, email;
		email = _.get(input, "email", "").toLowerCase();
		userExists = await userProfileService.getUsersInformationByEmail(email);
		console.debug("existence of user: ", userExists);
		if ((_.get(userExists, "status")) == 1702) {
			finalMessage = { "IsExist": false };
			return ApiResponse.success(finalMessage);
			// }
			//end
		} else {
			finalMessage = { "IsExist": true };
			//console.log(finalMessage);
			if (userExists && userExists.length && userExists.length > 1  ) {
				//ToDO: add notification object intial change
				notificationObj = await notificationService.updateNotificationStage(notificationObj, true, "sync", null, "success");
				if(configuration.kafkaConfig.enable.recon){
					await kafkaService.pushEventToKafka(configuration.kafkaConfig.topic.recon, notificationObj);
				}
				if(configuration.SQS.isSQSEnabled){
					sqsService.sendEmailToSQS(email, true);
				}
			}
			return ApiResponse.success(finalMessage);
		}
	} catch (error) {
		console.error(error);
		return ApiResponse.error(errorConfig.requestFailed, 400, mixpanelEvent.checkUser + _.get(input, "type", "") + mixpanelEvent.serverValidation_Error, input, _.get(input.data, "email"));
	}

}
async function checkMobile(userInput,notificationObj) {
	//console.log("Reach in check Mobile function");
	try {
		const phoneNumber = userInput.countryCode + userInput.mobile; // mobile
		const mobileExists = await phoneExists(phoneNumber,notificationObj);
		console.debug("existence of user phone: ", mobileExists);
		if (mobileExists === false) {
			//MobilNumber not exist in DB, We have to send OTP.
			const sendOTPResponse = await otpService.sendOtp(userInput, null, (userInput.otpVersion) ? userInput.otpVersion : constant.VALID_OTP_VERSION.v1);
			return sendOTPResponse;
		} else {
			let checkUserResponse = await responseFormat.phoneNumberResponse(mobileExists);
			return checkUserResponse;
		}
	} catch (error) {
		console.error(error);
		return ApiResponse.error(errorConfig.requestFailed, 400);
	}
}
async function phoneExists(phoneNumber,notificationObj) {
	try {
		const user = await userService.getUserByPhone(phoneNumber);
		console.log(user);
		if (_.has(user, "status")) {
			console.debug("User Does't Exist in Auth V4 ", user);
			return false;

		} else {
			if ( user && user.length && user.length > 1 ) {
				const { email } = user[0];
				notificationObj = await notificationService.updateNotificationStage(notificationObj, true, "sync", null, "success");
				if(configuration.kafkaConfig.enable.recon){
					await kafkaService.pushEventToKafka(configuration.kafkaConfig.topic.recon, notificationObj);
				}
				if(configuration.SQS.isSQSEnabled){
					sqsService.sendEmailToSQS((email) ? email : `${phoneNumber}@voot.com`, false);
				}
                
			}
			return true;
		}
	} catch (error) {
		//console.log(error);
		return false; // resolve in both case, else it will go to Handler's catch block
	}
}


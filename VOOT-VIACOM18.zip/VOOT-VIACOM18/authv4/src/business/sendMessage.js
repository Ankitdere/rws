const _ = require("lodash");
const { errorConfig } = require("../config");
const apiResponse = require("../utils").apiResponse;
const { userProfileService,sendMessageService } = require("../services");
const constant = require("../utils/constant/generic");
module.exports = sendMessageBusiness;
/**
 * business logic
 * @param {*} input 
 * @returns 
 */
async function sendMessageBusiness(input) {

	try {
		//business logic part
		let response, emailBody = {}, smsBody = {}, uid, priority, email, mobile;
		uid = _.get(input, "uid");
		priority = _.get(input, "priority");

		//prepare data:
		if (_.has(input, "email")) {
			emailBody.subject = Buffer.from(_.get(input.email, "subject"), "base64").toString("utf8");
			emailBody.body = Buffer.from(_.get(input.email, "body"), "base64").toString("utf8");
		} 
		if (_.has(input, "sms")) {
			smsBody.body = Buffer.from(_.get(input.sms, "body"), "base64").toString("utf8");
			smsBody.templateId = Buffer.from(_.get(input.sms, "templateId"), "base64").toString("utf8");
			smsBody.type = Buffer.from(_.get(input.sms, "type"), "base64").toString("utf8");
			smsBody.header = Buffer.from(_.get(input.sms, "header"), "base64").toString("utf8");
		}
		//read data from userprofile
		let userProfile = await userProfileService.getUserInformationById(uid);
		if (_.has(userProfile, "status")) {//user not found
			return apiResponse.error(errorConfig.userDoesNotExist.description, 
				errorConfig.userDoesNotExist.code);
		}
		userProfile = (JSON.parse(JSON.stringify(userProfile)));

		//check priority and type of user:
		priority = await checkPriority(userProfile);
		switch (priority) {
		case "sms":
			mobile = _.get(userProfile, "mobile");
			response = await sendMessageService.prepareAndSendSMS(smsBody, mobile );//sms service
			break;
		case "email":
			email = userProfile.email;
			if (userProfile.profileData.AmazonDetails && !_.isEmpty(
				_.get(userProfile.profileData.AmazonDetails,"Email",
					_.get(userProfile.profileData.AmazonDetails,"email"))))
			{
				email = _.get( userProfile.profileData.AmazonDetails,"Email",
					_.get(userProfile.profileData.AmazonDetails,"email"));
			}
			response = await sendMessageService.prepareAndSendEmail(emailBody,email);//email service
			break;
		default:
			return apiResponse.error(errorConfig.failedSMSAndEMAIL.description, errorConfig.failedSMSAndEMAIL.code);
		}
		return response;
	} catch (error) {
		console.error("error in sendMessageBusiness/Catch", error, error.message);
		throw error;
	}
}
/**
 * checking user type sms/email.
 * @param {*} userProfile 
 * @returns 
 */
async function checkPriority(userProfile){
	try{
		let priority = constant.PRIORITY.DEFAULT;
		//Traditional mobile and amazon user condition(work only non partner users)
		let isDummyEmail = await checkDummyEmail(userProfile.email);
		if ( userProfile && userProfile.mobile && 
			!_.isNil(userProfile, "mobile") && isDummyEmail && !_.has(userProfile, "partnerType")){
			
			priority = constant.PRIORITY.SMS;

			if( userProfile.profileData.AmazonDetails && !_.isEmpty( 
				_.get(userProfile.profileData.AmazonDetails,"Email",
					_.get(userProfile.profileData.AmazonDetails,"email"))) ){

				priority = constant.PRIORITY.EMAIL;
			}
		}
		if ( userProfile.email && !_.isNil(userProfile, "email") && !isDummyEmail 
		&& !_.has(userProfile, "partnerType") ) {
			priority = constant.PRIORITY.EMAIL;
		} 
		console.log("priority",priority);
		return priority;
	}catch(error){
		console.error("error in checkPriority/Catch ",error);
		throw error;
	}
	
}
/**
 * dummy email check
 * @param {*} email 
 * @returns 
 */
async function checkDummyEmail(email){
	let flag = false;
	for(let i =0;i<constant.DUMMY_EMAIL_CHECK.length;i++){
		if(_.includes(email,constant.DUMMY_EMAIL_CHECK[i])){
			flag = true;
			break;
		}
	}
	return flag;
}

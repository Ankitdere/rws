const _ = require("lodash");
const kalturaService = require("../services/kalturaService");
const userProfileService = require("../services/usersProfile");
const genericConstant = require("../utils/constant/generic");
module.exports = checkKalturaAccount;

async function checkKalturaAccount(input) {
	try {
		let userDetails;
		let resposne;
		let value = _.get(input, "email");
		if (Object.keys(input)[0] === "uid") {
			userDetails = await userProfileService.getUserEmailAndUidById(input.uid);
			if (_.get(userDetails, "status") == 1701) throw { status: { code: userDetails.status, message: userDetails.message } };
			// check tempEmail for partner user
			value = (genericConstant.PARTNER_TYPES_FOR_CHECK_KALTURA_ACCOUNT.includes(userDetails.partnerType)) ? userDetails.tempEmail : userDetails.email;
		}

		const kalturaData = await kalturaService.getUserByUsername(value);
		resposne = {
			email: kalturaData.username,
			uid: _.get(userDetails, "uid") || _.get(kalturaData, "externalId"),
			platform: "",
			kalturaBuildNo: "3",
			kUserId:_.get(kalturaData, "id")

		};
		return resposne;
	} catch (error) {
		console.log("error in checkKalturaAccountBusinesss/Catch", error, error.message);
		throw error;
	}
}

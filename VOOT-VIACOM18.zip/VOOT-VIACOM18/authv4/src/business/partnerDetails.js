const { errorConfig } = require("../config");
const userProfileService = require("../services").userProfileService;
const _ = require("lodash");
const { apiResponse } = require("../utils");
const TATASkyRepo = require("../services");
const M2MITRepo = require("./m2mit");
const Config = require("../config").configuration;
const responseFormatter = require("../format").responseFormat;
const GenericConstantUtil = require("../utils/constant/generic");
module.exports = getPartnerDetails;

async function getPartnerDetails(input) {
	try {
		let response;
		switch (input.partnerType) {

		case Config.M2MITDetails.partnerName:
		{
			let { uid, userData } = await M2MITRepo.getM2MITCollectionDetails(Config.App.users, _.get(input, "uniqueId"));
			if (uid) {
				console.log("UserData", uid);
				response = await responseFormatter.v3getPartnerProfileResponse(uid, userData);
				return response;
			} else {
				return apiResponse.error(errorConfig.userDoesNotExist.description, errorConfig.userDoesNotExist.code);
			}
		}
		case Config.tSkyDetails.partnerType:
		{
			let { uid, userData } = await TATASkyRepo.getTskyCollectionDetails(_.get(input, "uniqueId"));
			if (uid) {
				console.log("UserData", uid);
				response = await responseFormatter.v3getPartnerProfileResponse(uid, userData);
				return response;
			} else {
				return apiResponse.error(errorConfig.userDoesNotExist.description, errorConfig.userDoesNotExist.code);
			}
		}
		case Config.jioSubscription.partnerType:
		{
			let { uid,userData } = await userProfileService.getPartnerDetailsByExternalId(_.get(input, "externalId"), _.get(input, "partnerType", "JIO"));
			console.log("Return Data", userData);
			if (userData) {
				console.log("UserData");
				response = await responseFormatter.v3getPartnerProfileResponse(uid, userData);
				return response;
			} else {
				return apiResponse.error(errorConfig.userDoesNotExist.description, errorConfig.userDoesNotExist.code);
			}
		}
		case GenericConstantUtil.PARTNER.YUPPTV.CODE:
		{
			let { uid, userData } = await M2MITRepo.getM2MITCollectionDetails(Config.App.users, _.get(input, "uniqueId"), GenericConstantUtil.PARTNER.YUPPTV.CODE);
			console.log("Return Data", userData);
			if (userData) {
				console.log("UserData", uid);
				response = await responseFormatter.v3getPartnerProfileResponse(uid, userData);
				return response;
			} else {
				return apiResponse.error(errorConfig.userDoesNotExist.description, errorConfig.userDoesNotExist.code);
			}
		}
		case GenericConstantUtil.PARTNER.FLIPKART.CODE:
		{
			let { uid, userData } = await M2MITRepo.getM2MITCollectionDetails(Config.App.users, _.get(input, "uniqueId"), GenericConstantUtil.PARTNER.FLIPKART.CODE);
			console.log("Return Data", userData);
			if (userData) {
				console.log("UserData", uid);
				response = await responseFormatter.v3getPartnerProfileResponse(uid, userData);
				return response;
			} else {
				return apiResponse.error(errorConfig.userDoesNotExist.description, errorConfig.userDoesNotExist.code);
			}
		}

		}
	} catch (e) {
		console.log(e);
		throw e;
	}
}


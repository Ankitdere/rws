"use strict";

module.exports = { fbLogin, googleLogin, doLoginAndSignUp, appleLogin ,createNewUserInMongo };
const config = require("../config").configuration;
const { OAuth2Client } = require("google-auth-library");
const graph = require("fbgraph");
const util = require("util");
const googleclient = new OAuth2Client(config.google.clientId, "", "");
const _ = require("lodash");
const userService = require("../services").userService;
const userProfileService = require("../services").userProfileService;
const responseFormat = require("../format").responseFormat;
const mongoUser = require("../format").mongoUser;
const mongoUserProfile = require("../format").mongoUserProfile;
const errorConfig = require("../config").errorConfig;
const kalturaBL = require("./kalturaBL");
const constant = require("../utils/constant/generic");
const { error } = require("../utils").apiResponse;
const {validateAppleIdToken, validateAppleCode } = require("../services/tokenService");
const {getUnverifiedAppleUser, deleteUnverfiedAppleuser} = require("../services").appleService;
const apiResponse = require("../utils/apiResponse");
const { otpService} =require("../services");
graph.setVersion( "10.0" );
const mixpanelService =require("../services/mixpanelService");
const mixpanelConfig =require("../config/mixPanelConfig");
const sqsService =require("../services/sqsService");
const kafkaService = require("../services/kafkaService");
const notificationService = require("../services/notificationService");
const moment = require("moment");
const FB_TOKEN_EXPIRY_CODE = 190;
const commonUtils = require("../utils").common;

async function fbLogin(input) {
	try {
		console.debug("FbLogin function started");
		const userDetails = await getFbUserDetails(input);
		const fbAuth = transformFBDetails(userDetails);
		return loginAuth(input, fbAuth, "facebook");
	} catch (error) {
		console.error("Auth Service Login Error: ", error,error.stack);
		mixpanelService(mixpanelConfig.externalCall+"Facebook"+mixpanelConfig.serverValidation_Error,{input:input, message:_.get(error,"stack",error), StatusCode: 400, distinct_id:_.get(input.data, "email", _.get(input.data, "mobile", _.get(input.data, "uid")))},_.get(input.data, "email", _.get(input.data, "mobile", _.get(input.data, "uid"))));
		if (!error || !error.code){
			return apiResponse.error(errorConfig.requestFailed, 400);
		}
		switch (error.code) {
		case "auth/wrong-password":
			return apiResponse.error(errorConfig.wrongPassword.description, errorConfig.wrongPassword.code);
		case "auth/user-not-found":
			return apiResponse.error(errorConfig.userDoesNotExist.description, errorConfig.userDoesNotExist.code);
		case "auth/invalid-email":
			return apiResponse.error(errorConfig.invalidEmail.description, errorConfig.invalidEmail.code);
		case "auth/invalid-uid":
			return apiResponse.error(errorConfig.invalidUid.description, errorConfig.invalidUid.code);
		case "auth/invalid-credential":
			return apiResponse.error(errorConfig.invalidAccessToken.description + " " + error.message, 1907);
		case "auth/too-many-requests":
			return apiResponse.error(errorConfig.tooManyAttempts.description, errorConfig.tooManyAttempts.code);
		case "apple/token-expired":
			return apiResponse.error(errorConfig.expiredIdToken.description, errorConfig.expiredIdToken.code);
		case "apple/invalid-nonce":
			return apiResponse.error(errorConfig.invalidNonce.description, errorConfig.invalidNonce.code);
		case "apple/invalid-id-token":
			return apiResponse.error(errorConfig.invalidIdToken.description, errorConfig.invalidIdToken.code);
		case errorConfig.errorCodes.USER_WRONG_USERNAME_OR_PASSWORD.code:
			return apiResponse.error(errorConfig.kalturaUserWrongUsernameOrPassword.description, errorConfig.kalturaUserWrongUsernameOrPassword.code);
		case errorConfig.errorCodes.INSIDE_LOCK_TIME.code:
			return apiResponse.error(errorConfig.kalturaInsideLockTime.description, errorConfig.kalturaInsideLockTime.code);
		default:
			throw apiResponse.error(errorConfig.requestFailed, 400);
		}
	}
}

async function googleLogin(input) {
	try {
		let userDetails;
		try {
			const options = {
				idToken: input.data.token,
				audience: config.google.clientId,
			};
			userDetails = await googleclient.verifyIdToken(options);
		} catch (error) {
			console.log("Error in token verify", error);
			throw { code: "auth/invalid-google-token" };
		}
		let gAuth = transformGoogleDetails(_.get(userDetails, "payload"));
		return loginAuth(input, gAuth, "google");
	} catch (error) {
		console.error("Auth Service Login Error: ", error,error.stack);
		mixpanelService(mixpanelConfig.externalCall+"google"+mixpanelConfig.serverValidation_Error,{input:input, message:_.get(error,"stack",error), StatusCode: 400, distinct_id:_.get(input.data, "email", _.get(input.data, "mobile",  _.get(input.data, "uid")))},_.get(input.data, "email", _.get(input.data, "mobile",  _.get(input.data, "uid"))));
		if (!error || !error.code){
			return apiResponse.error(errorConfig.requestFailed, 400);
		}            
		switch (error.code) {
		case "auth/wrong-password":
			return apiResponse.error(errorConfig.wrongPassword.description, errorConfig.wrongPassword.code);
		case "auth/user-not-found":
			return apiResponse.error(errorConfig.userDoesNotExist.description, errorConfig.userDoesNotExist.code);
		case "auth/invalid-email":
			return apiResponse.error(errorConfig.invalidEmail.description, errorConfig.invalidEmail.code);
		case "auth/invalid-uid":
			return apiResponse.error(errorConfig.invalidUid.description, errorConfig.invalidUid.code);
		case "auth/invalid-credential":
			return apiResponse.error(errorConfig.invalidAccessToken.description + " " + error.message, 1907);
		case "auth/too-many-requests":
			return apiResponse.error(errorConfig.tooManyAttempts.description, errorConfig.tooManyAttempts.code);
		case "apple/token-expired":
			return apiResponse.error(errorConfig.expiredIdToken.description, errorConfig.expiredIdToken.code);
		case "apple/invalid-nonce":
			return apiResponse.error(errorConfig.invalidNonce.description, errorConfig.invalidNonce.code);
		case "apple/invalid-id-token":
			return apiResponse.error(errorConfig.invalidIdToken.description, errorConfig.invalidIdToken.code);
		case errorConfig.errorCodes.USER_WRONG_USERNAME_OR_PASSWORD.code:
			return apiResponse.error(errorConfig.kalturaUserWrongUsernameOrPassword.description, errorConfig.kalturaUserWrongUsernameOrPassword.code);
		case errorConfig.errorCodes.INSIDE_LOCK_TIME.code:
			return apiResponse.error(errorConfig.kalturaInsideLockTime.description, errorConfig.kalturaInsideLockTime.code);
		case "auth/invalid-google-token":
			return apiResponse.error(errorConfig.invalidFborGToken.description, errorConfig.invalidFborGToken.code);
		default:
			throw apiResponse.error(errorConfig.requestFailed, 400);
		}
	}
}

function transformGoogleDetails(userDetails) {
	let { name, email, picture, sub } = userDetails;
	email = email.toLowerCase();
	return {
		name,
		email,
		picture,
		id: sub
	};
}

function transformFBDetails(userDetails) {
	let { name, email, birthday, id } = userDetails;
	email = email ?email.toLowerCase():email;
	return {
		name,
		email,
		picture: _.get(userDetails, "picture.data.url", null),
		birthdate: birthday,
		id
	};
}

/**
 * Function  used for Apple Login with following 
 *   Verify the Apple Id token
 *   Verify the Apple Code to get Apple's access and refresh token
 *   Create User if does't exist otherwise login(On Mongo and Kaltura)
 * @param input Input data(type, deviceId, deviceBrand, token, rawNonce).
 * @return  Apple Login response
 */
async function appleLogin(input) {
	try {
		// These are optional params
		const rawNonce = _.get(input,"data.rawNonce");
		const authCode = _.get(input,"data.authCode","");
		const firstName = _.get(input,"data.firstname","");
		const lastName = _.get(input,"data.lastname","");
		let emailId = _.get(input,"data.email","");
		const redirectUrlApple = _.get(input,"data.redirectUrlApple","");
		const authData = input.data;
		let decodedToken = await validateAppleIdToken(authData.token,rawNonce);
		let userId, unverifiedUser, firebaseUser;
		if(_.isEmpty(authCode)){
			unverifiedUser = await getUnverifiedAppleUser(decodedToken.sub);
			emailId = _.get(unverifiedUser,"email","");
		}else{
			unverifiedUser = {
				code: authCode,
				firstName: firstName,
				lastName : lastName
			};
		}
		if(!_.isEmpty(emailId)){
			decodedToken.email  = emailId;
		}
		let redirectUrl = config.ApppleSignIn.redirectURL;
		if(unverifiedUser.originalUrl === "/v3/appleRedirect-app" || unverifiedUser.originalUrl === "/usersV3/v3/appleRedirect-app" ){
			redirectUrl = config.ApppleSignIn.redirectURLApp;
		}
		if(!_.isEmpty(redirectUrlApple)){
			redirectUrl = redirectUrlApple;
		}
		const appleResponse = await validateAppleCode(unverifiedUser.code, decodedToken.aud,"authorization_code",redirectUrl);
		decodedToken.accessToken = _.get(appleResponse,"access_token","");
		decodedToken.refreshToken = _.get(appleResponse,"refresh_token","");
		// decodedToken.accessToken = decodedToken.refreshToken = 'asa';
		// Search user with apple's UID
		const email = _.get(decodedToken,"email");
		//create user directly as its a new user with sub @voot.com
		let userRecord = await userProfileService.getAppleUserById(decodedToken.sub);
		if(_.has(userRecord,"status") && !_.isEmpty(email)){
			userRecord = await userProfileService.getUserInformationByEmail(decodedToken.email); 
		}    
		console.debug("UserRecord",userRecord);
		let isSignup = false;    
		// If user found then update the data and sign in 
		if(!_.has(userRecord,"status")){
			// userData = prevUserDoc = prevUserDoc.data();       
			let data = mongoUserProfile.initFormatForUserProfileSocail(input,email, undefined, undefined,decodedToken);
			data.profileData.isFirstLogin = false;
			// let userInfo  = userProfileService.getUserInformationById(userId);
			// userInfo
			let tempEmail = _.get(userRecord,"data.email",_.get(userRecord,"email",""));
			// Check if user record's email is not prrivate apple Id And Shared email is private then only update email otherwise not\
			if (!/@privaterelay.appleid.com\s*$/.test(email) &&  /@privaterelay.appleid.com\s*$/.test(tempEmail)) {
				// need to update email as we get actual email of user instead of private email
				userRecord.email = email;
			}
			userRecord.profileData.AppleUser =  data.profileData.AppleUser ;
			userId = _.get(userRecord,"uid",_.get(userRecord,"profileData.uid")) ;
			console.log("User Id ", userId);
			firebaseUser = await userService.getUserById(userId);
			if(_.has(firebaseUser, "status")){  
				firebaseUser = await mongoUser.initFormatExistingSocailUser(decodedToken, userId, false, true);
				console.log("FirebaseUser", firebaseUser);
				userService.insertUser(firebaseUser);
			}
			await userProfileService.updateUserInformation({"uid":userId}, {$set: userRecord}) ;
		}else{
			// Register user if not found in FireStore
			if(commonUtils.blockByProvider(input.type) && commonUtils.blockByPlatform(input.userAgent))
				isSignup = true;
			if(!isSignup){
				let createUserData = {};
				let userName = _.get(unverifiedUser,"firstName","") + " "+ _.get(unverifiedUser,"lastName","");
				if(!_.isEmpty(email)){
					createUserData = {email:email,
						displayName: userName,
					};
				}

				createUserData.sub  = _.get(decodedToken,"sub");
				// init user, currenlty not creating user in userauth as userprofile is already holding that record
				userRecord = firebaseUser = await mongoUser.initFormatSocailUser(createUserData, false, true);
				// not inserting data in uaerauth
				userService.insertUser(userRecord);
				userId = _.get(userRecord,"uid");
			}   
		}
		if(_.isEmpty(authCode)){
			await deleteUnverfiedAppleuser({"uid":decodedToken.sub});
		}
		if(isSignup)return commonUtils.notallowedSignupMethod(input.type,input.userAgent);//block social account signup
		return doLoginAndSignUp(input, userRecord, firebaseUser, userId,false, decodedToken);
	} catch (err) {
		console.error("Error in apple login",err,err.stack);
		mixpanelService(mixpanelConfig.externalCall+"apple"+mixpanelConfig.serverValidation_Error,{input:input, message:_.get(error,"stack",error), StatusCode: 400, distinct_id:_.get(input.data, "email", _.get(input.data, "mobile",  _.get(input.data, "uid")))},_.get(input.data, "email", _.get(input.data, "mobile",  _.get(input.data, "uid"))));
		if (_.get(err, "message", "").match("Wrong")) {
			throw new Error(errorConfig.invalidFborGToken.code);
		}
		switch (err.code) {
		case "apple/token-expired":
			return error(errorConfig.expiredIdToken.description, errorConfig.expiredIdToken.code);
		case "apple/invalid-nonce":
			return error(errorConfig.invalidNonce.description, errorConfig.invalidNonce.code);
		case "apple/invalid-id-token":
			return error(errorConfig.invalidIdToken.description, errorConfig.invalidIdToken.code);
		case errorConfig.errorCodes.USER_WRONG_USERNAME_OR_PASSWORD.code:
			return error(errorConfig.kalturaUserWrongUsernameOrPassword.description, errorConfig.kalturaUserWrongUsernameOrPassword.code);
		case errorConfig.errorCodes.INSIDE_LOCK_TIME.code:
			return error(errorConfig.kalturaInsideLockTime.description, errorConfig.kalturaInsideLockTime.code);
		default:
			throw error(errorConfig.requestFailed, 400);
		}
	}
}

async function doLoginAndSignUp(input = "", userRecord = "", firebaseUser = "", userId = "", isRemoveTempPassword = true, decodedToken = "") {
	try{
		let userDetails,userData, customUid,notificationObj;
		let metaData = {};
		let data = {};
		// Step 1:Check user in Mongo Profile By UID`
		userDetails = await userProfileService.getUserInformationById(userId);
		console.debug("Userdetails fetched from Mongo",JSON.stringify(userDetails));
		// If user account not found then register and return response
		if (_.has(userDetails, "status")) {
			console.debug("Create a new user in Mongo");
			if (!_.isEmpty(firebaseUser.providerData[0].email)) {
				// Fetch user data from Mongo First
				let prevUserDoc = await userProfileService.getUserInformationByEmail(firebaseUser.providerData[0].email);
				// If user Not found then register, otherwise merge accounts and login
				if(_.has(prevUserDoc,"status")){
					// Top priority for username if email missing logic
					if (_.isEmpty(firebaseUser.email)) {
						if (_.isEmpty(firebaseUser.providerData[0].email)) {
							firebaseUser.email = firebaseUser.uid + config.userEmailDomain;
						} else {
							firebaseUser.email = firebaseUser.providerData[0].email;
						}
					}
					let kalturaUserName = firebaseUser.email;
					if (input.type === "facebook") {
						userData = mongoUserProfile.initFormatForUserProfileSocail(input, kalturaUserName, undefined, userRecord);
					}
					else if (input.type === "apple") {
						kalturaUserName = firebaseUser.email ? firebaseUser.email: firebaseUser.uid+config.userEmailDomain;
						userData = mongoUserProfile.initFormatForUserProfileSocail(input, kalturaUserName, undefined,undefined, decodedToken);
					} else if (input.type === "amazon") {
						kalturaUserName = firebaseUser.email;
						userData = mongoUserProfile.initFormatForUserProfileSocail(input, kalturaUserName, undefined, undefined, decodedToken);
					}
					else {
						userData = mongoUserProfile.initFormatForUserProfileSocail(input, kalturaUserName);
					}
					_.set(userData, "profileData.isFirstLogin", true);
					_.set(userData, "profileData.IsProfileUpdated", false); // for avoid update Account API
					let emailTemp, mobileTemp = "";
					if(input.type === "mobile"){
						emailTemp = _.get(firebaseUser,"email","");
						mobileTemp = _.get(firebaseUser,"phoneNumber","");
					}
					// Create User in Mongo and push firestore Create in Queue
					await createNewUserInMongo(firebaseUser,userData, kalturaUserName,emailTemp,mobileTemp);
					customUid = firebaseUser.uid;
					// let registerResponse = await this.registerKalturaAndCreateResponse(kalturaUserName, customUid, input, firebaseUser, userData, prevUserDoc);
					// return ApiResponse.success(registerResponse);
					const kalthuraLoginResponse = await kalturaBL.kalturaRegistration(kalturaUserName, customUid , input, userRecord, userData);
					let finalOutput = await responseFormat.v3SignUpResponse(userRecord, userData, _.get(input, "deviceId"), kalthuraLoginResponse,input);
					if(input.type === "apple") {
						console.debug("-------------",decodedToken);
						_.set(finalOutput, "data.email", decodedToken.email);
					}
					return finalOutput;
				}
				//  If previous user Doc exist 
				prevUserDoc = responseFormat.responseUpdateProfileData(prevUserDoc);
				customUid = _.get(prevUserDoc, "profileData.uid", _.get(prevUserDoc, "profileData.Uid", _.get(prevUserDoc, "uid")));
				console.debug("prevUserDoc %j", prevUserDoc);
				//  Add Custom Uid in Mongo User also
				await userService.updateOrInsertUser({ uid: customUid }, { $set: { "customClaims.customUid": customUid } });
				//check if uid and custom uid is same or not
				if ((userRecord.customClaims && userRecord.customClaims.customUid !== customUid) || (userRecord.customClaims == undefined)) { 
					userRecord = await userService.updateOrInsertUser({ uid: userId },{ $set: { "customClaims.customUid": customUid } });
				}
				if(userRecord.customClaims == undefined){
					userRecord.customClaims = {};
				}
				userRecord.customClaims.customUid = customUid;
				userDetails = await userProfileService.getUserInformationById(customUid);
				if (!userDetails)
					userDetails = prevUserDoc;
				userDetails = responseFormat.responseUpdateProfileData(userDetails);
				userRecord.uid = userId = customUid;
				console.log("userRecord %j", userRecord);
			}
		}else if(userRecord.customClaims && !_.isEmpty(userRecord.customClaims.customUid)){
			userRecord.uid  = userId =  _.get(userRecord.customClaims,"customUid",userRecord.uid);
		}
		//add notification it will fix logout issue also
		console.log("config.kafkaConfig.enable.recon",config.kafkaConfig.enable.recon);
		if (config.kafkaConfig.enable.recon) {
			metaData = await notificationService.createMetaDataForRecon("doLoginAndSignUp");
			data.initialAction = "sync";
			data.currentAction = "sync";
			notificationObj = await notificationService.reconIntitialNotificationObj(input, metaData);
			notificationObj = await notificationService.updateReconInfo(notificationObj, data);
			notificationObj = await notificationService.updateNotificationStage(notificationObj, true, "sync", null, "success");
			console.log("notificationObj",notificationObj);
			if (config.kafkaConfig.enable.recon) {
				await kafkaService.pushEventToKafka(config.kafkaConfig.topic.recon, notificationObj);
			}
		}
		//TODO: Add optional HousholdId to attach new user to existing household
		if (_.isEmpty(_.get(firebaseUser, "email"))) {
			if (_.isEmpty(_.get(firebaseUser, "providerData[0].email"))) {
				firebaseUser.email = firebaseUser.uid + config.userEmailDomain;
			} else {
				firebaseUser.email = firebaseUser.providerData[0].email;
			}
		}
		if (_.isEmpty(_.get(input, "email"))) {
			input.email = firebaseUser.email;
		}
		if ( config.SQS.isSQSEnabled ) {
			sqsService.sendEmailToSQS( firebaseUser.email, false, true, userId ).catch( ( err ) => {
				console.log( "Error in sending message to Queue from social login", err );
			} );
		}
		const kalturaLoginResponse = await kalturaBL.doKalturaLogin(input,userRecord, userDetails);
		// const kalturaLoginResponse = await kalturaBL.kalturaRegistration(input.email, userId, input, userRecord, userDetails);
		if (_.isEmpty(userRecord.uid)) {
			userRecord.uid = userId;
		}
		let finalOutput = await responseFormat.v3SignUpResponse(userRecord, userDetails, _.get(input, "deviceId"), kalturaLoginResponse,input);
		let authData = input.password? input.password :"";
		let isAuthwithTempPassword = _.get(userDetails, "_system.resetPassword") != _.get(authData, "password");
		if (_.get(finalOutput, "data.isTemporaryPassword") && isRemoveTempPassword && isAuthwithTempPassword) {
			userProfileService.updateUserInformation({"uid":userId},{$set: {"profileData._system": ""}});
			_.set(finalOutput, "data.isTemporaryPassword", false);
			// Firebase code will be shifted to SQS
		}
		//Old login attempt  code to remove loginAttempt node.
		// if (userDetails && userDetails.loginAttempt !== undefined && userDetails.loginAttempt != null) {
		//     userProfileService.updateUserInformation({ 'uid': _.get(userDetails, 'uid') }, { $unset: { "loginAttempt": 1 } });
		// }
		//check if loginAttemptSystem
		// New Code to Block the User exceeded the Login Limit Login Attempt 
		if (userDetails && userDetails._system !== undefined && userDetails._system!=null && userDetails._system.failedAttempt != null && userDetails._system.failedAttempt.loginAttemptService != null) {
			if ( userDetails.loginStatus == constant.USER_STATUS.LOCKED && constant.userLoginBlockTypes.includes( input.type ) ) {
				let blockStatus = await otpService.isUserBlocked(userDetails, "loginAttemptService", config.LoginConfigurations.maxNumberOfWrongAttempt, config.LoginConfigurations.blockDurationLogin);
				if (blockStatus) {
					let _system = { ...userDetails._system };
					if (_system.failedAttempt && _system.failedAttempt.loginAttemptService && _system.failedAttempt.loginAttemptService.lastUpdatedAt) {
						_system.failedAttempt.loginAttemptService.lastUpdatedAt = moment();
					}
					return apiResponse.error(errorConfig.yourAccountBlocked.description, errorConfig.yourAccountBlocked.code);
				} else {
					userProfileService.updateUserInformation({ "uid": _.get(userDetails, "uid") }, { $set: { loginStatus: constant.USER_STATUS.ACTIVE }, $unset: { status: 1 ,loginAttempt :1  } });
					_.pullAt(userDetails, "_system");
				}
			}
		}
		let isFirstLogin = _.get(finalOutput, "data.isFirstLogin");
		if (isFirstLogin === true || isFirstLogin == undefined) {
			userProfileService.updateUserInformation({"uid":userId}, {$set:{"profileData.isFirstLogin": false}});
			_.set(finalOutput, "data.isFirstLogin", false);
		}
		if (input.type === "amazon" ) {
			if ((_.get(userRecord, "passwordHash") == "") || (_.get(userRecord, "passwordSalt") == "")||(_.get(userRecord, "passwordHash") == undefined)) {
				_.set(finalOutput, "data.isPasswordSet", false);
			} else {
				_.set(finalOutput, "data.isPasswordSet", true);
			}
		}
		if (userDetails._system) {
			let newSystem = userDetails._system;
			delete newSystem.failedAttempt;
			userProfileService.updateUserInformation({ uid: userId }, { $set: { loginStatus: constant.USER_STATUS.ACTIVE, _system: newSystem }, $unset: { status: 1, loginAttempt: 1 } });
		}
		else {
			userProfileService.updateUserInformation({ uid: userId }, { $set: { loginStatus: constant.USER_STATUS.ACTIVE }, $unset: { status: 1, loginAttempt: 1 } });
            
		}
		//sending region notification into queue
		if (config.kafkaConfig.enable.isUpdateAuth && input.regionInfo &&
			((input.regionInfo.region !== userDetails.region) || (input.regionInfo.country !== userDetails.country))
		) { 
			const regionNotificationObj = await notificationService.createRegionNotification(
				userDetails,
				_.get(input, "regionInfo", {})
			);
			kafkaService.pushEventToKafka(config.kafkaConfig.topic.updateAuthData, regionNotificationObj);
		}
		
		return finalOutput;
	}catch(err){
		if(err.code =="yourAccountBlocked"){
			return apiResponse.error(errorConfig.yourAccountBlocked.description, errorConfig.yourAccountBlocked.code);
		}
		throw err;
	}
}

async function createNewUserInMongo(userRecord, userData, email= "", mobile = ""){
	//this is the 1st record creation
	console.log("First  Record Creation | Auth: ", userRecord, "\n Record to be Stored in Firestore DB: ", userData);
	const customUid = userRecord.uid;
	userData.email = userRecord.providerData[0].email;
	if(!userData.email && email ){
		userData.email = email;
	}
	if(mobile){
		userData.mobile = mobile;
	}
	userData.profileData.uid = customUid;
	console.debug("Successfully Added Firebase Custom UID");
	console.debug(userRecord.uid, JSON.stringify(userData), customUid, JSON.stringify(userData.profileData));
	await userProfileService.updateUserInformation({uid:userRecord.uid}, userData);
	return userData;
}

/**
 * @param {Object} input 
 * @returns {Object} data from fb
 */
async function getFbUserDetails(input) {
	try {
		const path = "/me?fields=picture,name,email,gender,birthday&scope=user_mobile_phone";
		const graphGet = util.promisify(graph.get);
		graph.setAccessToken(input.data.token);
		const userAuth = await graphGet(path);
		const hasError = Object.prototype.hasOwnProperty.call(userAuth, "error");
		if (hasError === false) return userAuth;
		return fbErrorHandling(userAuth.error);
	} catch (error) {
		return fbErrorHandling(error);
	}
}


/**
 * @param {Object} error 
 */
function fbErrorHandling(error) {
	const { code = null } = error;
	if (code === FB_TOKEN_EXPIRY_CODE) {
		throw {
			code: "auth/invalid-credential",
			message: ": Token Expired",
		};
	}
	throw error;
}

/** 
 * @param {Object} input 
 * @param {Object} providerData 
 * @param {String} provider 
 * @returns {Object}
 */
async function loginAuth(input, providerData, provider) {
	let userAuth;
	let isFbLogin = false;let isSignup = false;
	if (provider === "facebook") {
		userAuth = await userService.getUserByFbUid(providerData.id);
		isFbLogin = true;
	} else if (provider === "google") {
		userAuth = await userService.getUserByGUid(providerData.id);
	} else {
		throw new Error("Invalid provider");
	}
	console.debug("Userservice result", JSON.stringify(userAuth));
	if (_.has(userAuth, "status")) {
		if(commonUtils.blockByProvider(input.type) && commonUtils.blockByPlatform(input.userAgent))
			isSignup = true;
		if(!isSignup){
			userAuth = await mongoUser.initFormatSocailUser(providerData, isFbLogin);
			userService.insertUser(userAuth);
		}
	} else {
		userAuth = _.isEmpty(userAuth[0]) ? userAuth : userAuth[0];
	}
	if(isSignup)return commonUtils.notallowedSignupMethod(input.type);//block social account signup
	//TODO:need correction
	const userId = _.get(userAuth, "uid", _.get(userAuth, "profileData.uid"));
	return doLoginAndSignUp(input, userAuth, userAuth, userId);
}
"use strict";

const kalturaService = require("../services").kalturaService;
const kalturaBL = require("./kalturaBL");
const _ = require("lodash");

module.exports = refreshKs;

async function refreshKs(input, tokenInfo, deviceId) {
	console.debug("Inside getTokenInfo() with parameter accessToken: ", tokenInfo);
	let kTokenId = _.get(input, "kTokenId");
	let kToken = _.get(input, "kToken");
	if (kTokenId.length < 30) {
		const decoded = tokenInfo;
		let kLoginData = await kalturaBL.getKalturaExternalIdAndLogin(decoded, null);
		let kalturaAppTokenResponse = await kalturaService.getAppToken(_.get(kLoginData, "result.loginSession.ks"));
		return {
			ks: _.get(kLoginData, "result.loginSession.ks"),
			kUserId: _.get(kLoginData, "result.user.id"),
			kTokenId: _.get(kalturaAppTokenResponse, "result.id"),
			kToken: _.get(kalturaAppTokenResponse, "result.token"),
			createdAt: _.get(kalturaAppTokenResponse, "result.createDate"),
			expiresAt: _.get(kalturaAppTokenResponse, "result.expiry")
		};
	}
	const newSession = await kalturaService.regenerateSession(kTokenId, kToken, deviceId);
	return {
		ks: newSession.result.ks,
		kUserId: newSession.result.userId,
		kTokenId: kTokenId,
		kToken: kToken,
		createdAt: newSession.result.createDate,
		expiresAt: newSession.result.expiry
	};
}
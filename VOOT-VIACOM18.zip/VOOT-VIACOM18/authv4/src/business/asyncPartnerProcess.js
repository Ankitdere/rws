
const { kafkaService, notificationService, userProfileService, userService } = require("../services");
const config = require("../config/configuration");
const { checkEntitlementStatus, checkMobileSubscriptionForAsync } = require("./m2mit");
const _ = require("lodash");
const tokenService = require("../services/tokenService");
const kalturaService = require("../services/kalturaService");
const apiResponse = require("../utils").apiResponse;
const errorconfig = require("../config").errorConfig;
const storeKUserId = require("./partnerSignIn").storeKUserId;
const mixPanelConfig = require("../config/mixPanelConfig");


async function processPartnerNotificaton(requestBody) {
	let basicNotification;
	try {
		basicNotification = await notificationService.getInitialNotificationObj(requestBody);
		console.log("In processPartnerNotificaton.");
		const { data: { uniqueId }, partnerName } = requestBody;
		console.log(" uniqueId, partnerName.", uniqueId, partnerName);
		let basicInfo = { partnerType: partnerName, uniqueId: uniqueId, deviceId: _.get(requestBody, "deviceId", "") };
		basicNotification = await notificationService.updateBasicInfo(basicNotification, basicInfo);
		const { uid, userData } = await getStatusFromDocumentDb(uniqueId, partnerName);
		basicNotification = await notificationService.updateNotificationStage(basicNotification, true, "validation");
		console.debug("My notification Object", basicNotification);
		let response, notificationObj, entilementStatus;
		if (partnerName == config.tSkyDetails.partnerType) {
			switch (requestBody.action) {
			case "Register":
				if (userData && (userData.isActive == "true" || userData.isActive == true)) {
					throw { code: "partner/user-already-registered", uid: _.get(userData, "uniqueId", requestBody.data.uniqueId) };
				}
				if (uid) {
					response = { "status": { "code": 200, "message": `${requestBody.partnerName}${errorconfig.PartnerUserDataRenew}` } };
				} else {
					response = { "status": { "code": 200, "message": `${requestBody.partnerName}` + " user is Registered." } };
				}
				notificationObj = await notificationService.createNotificationObject( "create_and_register", partnerName, requestBody );
				break;
			case "Cancel":
				if ( !uid ) {
					throw { code: "partner/user-not-found", };
				}
				if ( userData && ( userData.isActive == "false" || userData.isActive == false ) ) {
					throw { code: "partner/user-already-inactive", uid: _.get( userData, "uniqueId", requestBody.data.uniqueId ) };
				}
				notificationObj = await notificationService.createNotificationObject( "create_and_update_subscription", partnerName, requestBody );
				response = { "status": { "code": 200, "message": `${requestBody.partnerName}${errorconfig.PartnerUserDataCancel}` } };
				break;
			case "Renew":
			case "Trial_Period":
			case "Grace_Period":
			{
				let type = requestBody.action == "Renew" ? "create_and_update_subscription" : "create_and_process";
				if ( userData && ( userData.isActive == "true" || userData.isActive == true ) && requestBody.action == "Renew" ) {
					throw { code: "partner/user-already-active", uid: _.get( userData, "uniqueId", requestBody.data.uniqueId ) };
				}
				if ( userData && ( userData.isActive == "true" || userData.isActive == true ) ) {
					response = { "status": { "code": 200, "message": `${requestBody.partnerName}${errorconfig.PartnerUserDataUpdated}` } };
					//throw { code: "partner/user-already-active", uid: _.get(userData, 'uniqueId', requestBody.data.uniqueId) };
				}
				if ( uid ) {
					//notificationObj = await notificationService.createNotificationObject("create_and_update_subscription", partnerName, requestBody);
					response = { "status": { "code": 200, "message": `${requestBody.partnerName}${errorconfig.PartnerUserDataRenew}` } };
				} else {
					type = requestBody.action == "Renew" ? "create_and_register" : "create_and_process";
					response = { "status": { "code": 200, "message": `${requestBody.partnerName}` + " user is Registered." } };
				}
				//response = { "status": { "code": 200, "message": `${requestBody.partnerName}${errorconfig.PartnerUserDataRenew}` } };
				notificationObj = await notificationService.createNotificationObject( type, partnerName, requestBody );
				break;
			}

			}
			kafkaService.pushEventToKafka( config.kafkaConfig.topic.partnerNotification, notificationObj );
			return response;
		}
		else {
			const accessToken = await tokenService.createAccessTokenAndRefreshToken( { uid: uid, email: _.get( userData, "email" ), kUserId: _.get( userData, "kUserId" ), deviceId: _.get( userData, "deviceId", _.get( requestBody, "deviceId", "" ) ), partnerType: _.get( requestBody, "partnerName", _.get( userData, "partnerType", "" ) ) } );
			switch ( requestBody.action ) {
			case "Register":
				if ( userData && uid ) {
					throw { code: "partner/user-already-registered", uid: _.get( requestBody.data, "uniqueId", uid ) };
				}
				if ( requestBody.data.mobile ) {
					try {
						let prevUserMongoDoc;
						prevUserMongoDoc = await userService.getUserByPhone( requestBody.data.mobile );
						if ( !_.has( prevUserMongoDoc, "status" ) ) {
							//user has profile in mongo
							let uid = _.get( prevUserMongoDoc[ 0 ], "customClaims.customUid", _.get( prevUserMongoDoc[ 0 ], "uid" ) );
							let kalturaOttListResponse = await kalturaService.getUserByUsernameOrExternalIdNew( _.get( prevUserMongoDoc[ 0 ], "email" ), uid );
							console.debug( "kalturaOttListResponse", kalturaOttListResponse );
							await storeKUserId( _.get( kalturaOttListResponse, "id" ), uid );
							let accessToken = await tokenService.createAccessTokenAndRefreshToken( { uid: uid, email: _.get( prevUserMongoDoc[ 0 ], "email", "" ), kUserId: _.get( kalturaOttListResponse, "id", "" ) } );
							let mobileCheck = await checkMobileSubscriptionForAsync( requestBody, accessToken, prevUserMongoDoc[ 0 ], );//Sync in this Function 
							if ( mobileCheck != false ) {
								//notificationObj = await notificationService.createNotificationObject("create_and_register", partnerName, requestBody, null);
								basicNotification = await notificationService.updateNotificationStage( basicNotification, true, "auth", {
									"message": errorconfig.mobileIsAlreadyExistAndIntegratedWithM2MIT.description,
									"code": errorconfig.mobileIsAlreadyExistAndIntegratedWithM2MIT.code, uid: _.get( requestBody.data, "uniqueId", uid )
								} );
								kafkaService.pushEventToKafka( config.kafkaConfig.topic.partnerNotification, basicNotification );
								return mobileCheck;
							} else {
								basicNotification = await notificationService.updateNotificationStage( basicNotification, true, "subscription", {
									"message": errorconfig.mobileAlreadyExist.description,
									"code": errorconfig.mobileAlreadyExist.code, uid: _.get( requestBody.data, "uniqueId", uid )
								} );
								console.log( "BasicNotification one", basicNotification );
								kafkaService.pushEventToKafka( config.kafkaConfig.topic.partnerNotification, basicNotification );
								return apiResponse.error( errorconfig.mobileAlreadyExist.description,
									errorconfig.mobileAlreadyExist.code,
									mixPanelConfig.partnerNotification + _.get( requestBody, "partnerName" ) + mixPanelConfig.success,
									requestBody,
									_.get( requestBody.data, "uniqueId", uid ),
									400,
									false
								);
							}
						} else {
							throw { code: "auth/user-not-found" };
						}
					} catch ( e ) {
						console.log( "Error in search  By phone Number", e );
						if ( e.code != "auth/user-not-found" ) {
							throw e;
						}
					}
				}
				response = { "status": { "code": 200, "message": `${requestBody.partnerName}` + " user is Registered." } };
				notificationObj = await notificationService.createNotificationObject("create_and_register_user", partnerName, requestBody, "ABC");
				break;
			case "Cancel":
				if (!uid) {
					throw { code: "partner/user-not-found", uid: _.get(requestBody.data, "uniqueId") };
				}
				entilementStatus = await checkEntitlementStatus(accessToken);
				if (entilementStatus == false) {
					notificationObj = await notificationService.createNotificationObject("create_and_update_subscription", partnerName, requestBody, null);
					response = { "status": { "code": 200, "message": `${requestBody.partnerName} subscription has been cancelled` } };

				} else {
					throw { code: "partner/user-already-inactive", uid: _.get(requestBody.data, "uniqueId", uid) };
				}
				break;
			case "Activate":
				if (!uid) {
					throw { code: "partner/user-not-found", uid: _.get(requestBody.data, "uniqueId") };
				}
				entilementStatus = await checkEntitlementStatus(accessToken);
				notificationObj = await notificationService.createNotificationObject("create_and_activate_subscription", partnerName, requestBody, requestBody.data.planId);
				if (entilementStatus == true) { //If user is not expired and totally new user then allow activation				
					response = { "status": { "code": 200, "message": `${requestBody.partnerName}` + " user is activated." } };
				} else {
					if (config.M2MITAsyncConfig.subscription.isStack) {
						response = { "status": { "code": 200, "message": `${requestBody.partnerName}` + " user is activated." } };
					}
					throw { code: "partner/user-already-active-m2mit", uid: _.get(requestBody.data, "uniqueId") };
				}
				break;
			}
			kafkaService.pushEventToKafka(config.kafkaConfig.topic.partnerNotification, notificationObj);
			return response;
		}
	} catch (e) {
		basicNotification = await notificationService.updateNotificationStage(basicNotification, false, "subscription", { code: e.code, uid: _.get(requestBody.data, "uniqueId") },"error");
		console.log("BasicNotification Push:", basicNotification);
		e.basicNotification = basicNotification;
		console.log("errror", e, e.stack);
		throw e;
	}
}



async function getStatusFromDocumentDb(uniqueId, partnerName) {
	let uid,userData;
	try {
		let userProfileData = await userProfileService.getPartnerDetailsByUniqueId(uniqueId, partnerName);
		console.log("user profile data............", userProfileData);
		if (_.get(userProfileData, "status") == 1702) {
			return false;
		}
		else {   //Document Present in mongoDB return this
			if (!_.has(userProfileData, "status")) {
				uid = _.get(userProfileData, "uid");
				userData = userProfileData;
			}
			return { uid: uid, userData: userData };
		}
	} catch (e) {
		console.log("Error in Fetching the document", e, e.stack);
	}




}
module.exports = { processPartnerNotificaton };
"use strict";
const _ = require("lodash");
const userService = require("../services").userService;
const { getUserAuthPasswordProvider } = require("../utils").common;

/**
 * @param {string} email 
 * @returns {{IsExist: boolean}} finalOutput
 * 
 */
async function checkEmail(email) {
	const finalOutput = {
		"IsExist": false
	};
	try {
		const users = await userService.getAllUserRecordsByEmail(email);
		if (!_.has(users, "status")) {
			const passwordUsers = await getUserAuthPasswordProvider(users);
			if (!_.has(passwordUsers, "status")) {
				finalOutput.IsExist = true;
			}
		}
		return finalOutput;
	} catch (err) {
		return finalOutput;
	}
}

module.exports = checkEmail;
/* eslint-disable no-undef */
const { errorConfig, forgotPasswordTemplate, configuration } = require("../config");
const { userProfileService, mailService, userService, otpService, kafkaService, notificationService } = require("../services");
const _ = require("lodash");
const commonUtils = require("../utils").common;
const response = require("../format").responseFormat;
const apiResponse = require("../utils/apiResponse");
const { responseFormat, mongoUser } = require("../format");
const moment = require("moment");
const commonUtil = require("../utils").common;
const constant = require("../utils/constant/generic");
module.exports = forgotPassword;

async function forgotPassword(input) {
	console.debug("forgotPassword() with parameter input", input);
	let response;
	if (_.has(input, "email")) {
		response = await emailForgotFlow(input);//This Flow contain new template version as well as old
		return response;
	} else if (_.has(input, "mobile")) {
		response = await mobileForgotFlow(input);
		return response;
	}
}
async function emailForgotFlow(input) {
	let user, email,results;
	email = _.get(input, "email", "").toLowerCase();
	let usersData = await Promise.all([userProfileService.getUserInformationByEmail(email), userService.getAllUserRecordsByEmail(email)]);
	let userProfile = usersData[0];
	user = usersData[1];
   
	if(!_.has(user,"status")){
		user = await commonUtil.getUserAuthPasswordProvider(user);
	}
	if (_.has(user, "status") && !_.has(userProfile, "status"))
		return  apiResponse.error(errorConfig.checkEmailSocialLogin.description, errorConfig.checkEmailSocialLogin.code);
	else if (_.has(user, "status") && _.has(userProfile, "status"))
		return apiResponse.error(errorConfig.emailNotRegistered.description, errorConfig.emailNotRegistered.code);
	let customClaims = _.get(user, "customClaims");
	let traditionalCheck = _.get(user, "passwordHash", _.get(customClaims, "password"));

	//If user is not registered with traditional id then show error message
	if (_.isEmpty(traditionalCheck)) {
		// check for traditional user in provider data
		let providerData = _.get(user, "providerData");
		if (_.isEmpty(providerData)) {
			return apiResponse.error(errorConfig.checkEmailSocialLogin.description, errorConfig.checkEmailSocialLogin.code);
		}
		// Commenting as we are already using password user only 
		// let checkUser = false;
		// for (var i = 0; i < providerData.length; i++) {
		//     let password = _.get(providerData[i], 'providerId');
		//     if (password === 'password') {
		//         checkUser = true;
		//     }
		// }
		// if (!checkUser) {
		//     return  apiResponse.error(errorConfig.checkEmailSocialLogin.description, errorConfig.checkEmailSocialLogin.code);
		// }
	}
	// Based on the Template Version API will sent new Email Format as well send response accordingly.  
	if ((_.has(input, "templateVersion") || _.has(input, "action"))) {
		if (configuration.Otp.isUserBlockEnableForVerifyOtp && userProfile && userProfile._system && userProfile._system.failedAttempt && userProfile._system.failedAttempt.forgotPassword) {
			const isUserBlocked = await otpService.isUserBlocked(userProfile, "forgotPassword", configuration.Otp.maxNumberOfWrongOtpAttempts, configuration.Otp.blockDurationForVerifyOtp);
			if (isUserBlocked) {
				throw new Error(errorConfig.userlocked.description, errorConfig.userlocked.code);
			}
		}
		let resetPassword = await otpService._getRandomOTP();
		let otpData = await otpService.generate(resetPassword, false);

		if (userProfile._system !== undefined && userProfile._system != null && userProfile._system.forgotPasswordEmail !== undefined) {
			console.info("UserPending Request", userProfile);
			otpData = await otpService.checkOtpAttempts(userProfile, otpService.FORGOT_PASSWORD_EMAIL_REQUEST, false);
			resetPassword = otpData.otp;
			if (otpData.code !== undefined && otpData.code === "otp/exceededMaxGenerationLimit") {
				throw new Error(errorConfig.otpLimitExceeded.description, errorConfig.otpLimitExceeded.code);
			}
		}
		let _systemData = {...userProfile._system, [otpService.FORGOT_PASSWORD_EMAIL_REQUEST]: otpData, resetPassword: resetPassword };
		if (userProfile._system && userProfile._system.failedAttempt) {
			_systemData.failedAttempt = userProfile._system.failedAttempt;
		}

		if (!_.isEmpty(traditionalCheck)) {
			results = await userProfileService.updateUserInformation({ "uid": _.get(user.customClaims, "customUid", _.get(user, "uid")) }, { _system: _systemData,updatedAt:moment().utcOffset(+530).unix() });
		} else {
			results = await userProfileService.updateUserInformation({ "uid": user.uid }, { _system: _systemData, updatedAt:moment().utcOffset(+530).unix() });
		}
		if (configuration.kafkaConfig.enable.isUpdateAuth && input.regionInfo &&
			((input.regionInfo.region !== userProfile.region) || (input.regionInfo.country !== userProfile.country))
		) { 
			const regionNotificationObj = await notificationService.createRegionNotification(
				userProfile,
				_.get(input, "regionInfo", {})
			);
			kafkaService.pushEventToKafka(configuration.kafkaConfig.topic.updateAuthData, regionNotificationObj);
		}
		console.log(results);
		const emailresetPasswordSubject = forgotPasswordTemplate.passwordReset;
		const emailHeader = forgotPasswordTemplate.bodyHeader.replace("{displayName}", _.get(results.profileData, "FirstName", _.get(userProfile.profileData, "ProfileName")));
		forgotPasswordTemplate.bodySubject.replace("{Password}", resetPassword);
		const newEmailBodyFooter = forgotPasswordTemplate.newForgotPasswordTemplate.replace("{Password}", resetPassword).replace("{DEEPLINK}", `${forgotPasswordTemplate.deepLink2}` + `${email}`);
		let emailBody = emailHeader + newEmailBodyFooter + forgotPasswordTemplate.footer;
		await mailService.sendMail(email, emailresetPasswordSubject, emailBody);
		return response.emailForgotPassResponse(errorConfig.forgotPasswordEmailSuccess, otpData);
	}
	else {
		const resetPassword = (commonUtils.randomString(6));
		const _systemData = { resetPassword: resetPassword };
		console.info("_systemData:", _systemData);
		const results = await userProfileService.updateUserInformation({ "uid": user.uid }, { _system: _systemData,updatedAt:moment().utcOffset(+530).unix() });
		console.info(results);
		const emailSubject = forgotPasswordTemplate.forgotPasswordSubject;
		const emailHeader = forgotPasswordTemplate.bodyHeader.replace("{displayName}", _.get(results.profileData, "FirstName", _.get(userProfile.profileData, "ProfileName")));
		const emailBodyFooter = forgotPasswordTemplate.bodySubject.replace("{Password}", resetPassword);
		const emailBody = emailHeader + emailBodyFooter + forgotPasswordTemplate.footer;
		await mailService.sendMail(email, emailSubject, emailBody);
		return errorConfig.forgotPasswordEmailSuccess;
	}

}
async function mobileForgotFlow(input) {
	try {
		let user;
		let mobile;
		let uid;
		mobile = input.countryCode + input.mobile;
		user = await userService.getUserByPhone(mobile);
		if (!_.has(user, "status") && !_.isEmpty(user[0]) && user[0].email && user[0].email.search("@m2mit.com")>0) {
			//await userProfileService.updateUserInformation({ uid: user[0].uid }, { email: `${ mobile }@voot.com` });
			let providerData=await mongoUser.providedMobileCollection( user[0].uid,mobile, `${ mobile }@voot.com`);
			await userService.updateOrInsertUser({ uid: user[0].uid }, { email: `${ mobile }@voot.com`,providerData:providerData });
			user[0].email = `${mobile}@voot.com`;
		}
		else if (!_.has(user, "status")) {
			input.email = user[0].email.toLowerCase();
			uid = user[0].uid;
		}
		else if(_.has(user,"status")) {
			return apiResponse.error(errorConfig.mobileNotRegistered.description, errorConfig.mobileNotRegistered.code);
		}

		let otpData = await otpService.generate();
		let userDetails;
		/* to check user attempt for day */   
		userDetails = await userProfileService.getUserInformationByEmail(input.email);
		if (userDetails._system !== undefined && userDetails._system != null && userDetails._system.forgotPasswordMobile !== undefined) {
			otpData = await otpService.checkOtpAttempts(userDetails, otpService.FORGOT_PASSWORD_REQUEST, true);
			if (otpData.code !== undefined && otpData.code === "otp/exceededMaxGenerationLimit") {
				return apiResponse.error(errorConfig.otpLimitExceeded.description, errorConfig.otpLimitExceeded.code);
			}
		}
		const _systemData = {...userDetails._system, [otpService.FORGOT_PASSWORD_REQUEST]: otpData };
		await userProfileService.updateUserInformation({ "uid": uid }, { _system: _systemData,updatedAt:moment().utcOffset(+530).unix()  });
		const { sms: smsConfig } = configuration;
		const { properties: smsProps } = smsConfig;
		const peID = smsConfig.peID.VOOT;
		const hasOtpVersion = Object.prototype.hasOwnProperty.call(input, "otpVersion");
		if (hasOtpVersion) {
			if (input.otpVersion === constant.VALID_OTP_VERSION.v2){
				const messageTemplate = forgotPasswordTemplate.forgotPasswordMobileHashCode.replace("{HASHCODE}", configuration.Otp.otpHashCode);
				const { templateId, header } = smsProps.forgotPasswordMobileHashCode;
				const smsParams = {
					destination: mobile,
					otp: otpData.otp,
					messageTemplate,
					phone: input.mobile,
					peID,
					templateId,
					header,
					type: "OTP"
				};
				await otpService.sendSMS(smsParams); 
			}
		}else{
			const { templateId, header } = smsProps.forgotPasswordMobile;
			const smsParams = {
				destination: mobile,
				otp: otpData.otp,
				messageTemplate: forgotPasswordTemplate.forgotPasswordMobile,
				phone: input.mobile,
				peID,
				templateId,
				header
			};
			await otpService.sendSMS(smsParams); 
		}
		const successMessage = await responseFormat.phoneNumberForgotPassResponse(userDetails, otpData);
		
		if (configuration.kafkaConfig.enable.isUpdateAuth && input.regionInfo &&
			((input.regionInfo.region !== userDetails.region) || (input.regionInfo.country !== userDetails.country))
		) { 
			const regionNotificationObj = await notificationService.createRegionNotification(
				userDetails,
				_.get(input, "regionInfo", {})
			);
			kafkaService.pushEventToKafka(configuration.kafkaConfig.topic.updateAuthData, regionNotificationObj);
		}
		return apiResponse.success(successMessage);
		// return apiResponse.success(results);
	} catch (error) {
		if (!error.code) {
			console.error("No Error Code ", error);
			return apiResponse.error(errorConfig.requestFailed, 400);
		}
		switch (error.code) {
		case "auth/user-not-found":
		case 5: // NOT_FOUND, document related to uId but user might exist in firebase auth | TODO: fix it
			return apiResponse.error(errorConfig.mobileNotRegistered.description, errorConfig.mobileNotRegistered.code);
		default:
			console.log("New Error Code, which is not handled: ", error.code);
			return apiResponse.error(errorConfig.requestFailed);
		}
	}
}

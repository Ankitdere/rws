"use strict";
const jioSubscriptionService = require("../services").jioSubscriptionService;
module.exports = jioEntitlement;

async function jioEntitlement(ks, ssoToken, decoded, userRecord) {
	return await jioSubscriptionService.getEntitleMentStatus(ks, ssoToken, decoded, userRecord);
}

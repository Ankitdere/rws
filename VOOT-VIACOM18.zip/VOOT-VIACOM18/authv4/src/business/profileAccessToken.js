"use strict";
const responseFormat = require("../format").responseFormat;
const _ = require("lodash");
const {  userProfileService} = require("../services");

module.exports = profileAccessToken;

async function profileAccessToken(userToken) {
	try {
		let userDetails = await userProfileService.getUserInformationById(_.get(userToken, "uid"));
    
		if(_.isEmpty(userDetails.uid)){
			userDetails.uid = _.get(userToken, "uid");
		}
		console.log("UserDetails",userDetails);
		return await responseFormat.v3ProfileResponse(userDetails,userDetails);
	} catch (err) {
		throw err;
	}
}
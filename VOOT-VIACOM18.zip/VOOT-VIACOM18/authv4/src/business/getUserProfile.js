"use strict";
const responseFormat = require("../format").responseFormat;
const socialLogin = require("./socialLogin");
const _ = require("lodash");
const apiResponse = require("../utils").apiResponse;
const errorConfig = require("../config").errorConfig;
const config = require("../config").configuration;
const ksmDetails = require("../services").ksmUserDeviceService;
const userService = require("../services").userService;
const userKsmEncrptedService = require("../services").userKsmEncrptedService;
const userProfileService = require("../services").userProfileService;
const commonUtil = require("./updateProfile");
const commonUtilResponse = require("../utils").common;
const moment = require("moment");
module.exports = getProfile;

async function getProfile(userToken, headers, endpoint) {
	try {
		console.log("My User token ", userToken);
		console.log("Condition Criteria for response", _.get(headers, "profiletype", _.get(headers, "profile-type")));
		console.log("Headers", headers);
		let localCredentials;
		let ksmDeviceDetails;
		let finalResponse;
		let finalKSMDetails;
		let finalResponseObj;
		if (_.get(headers, "profiletype") == "ALL" || _.get(headers, "profile-type") == "ALL" || _.get(headers, "profiletype") == "COMMON" || _.get(headers, "profile-type") == "COMMON") {
			console.log("Condition for Whole Response");
			let userAuth = await userService.getUserById(_.get(userToken, "uid"));
			console.log("User Auth Profile", userAuth);
			let input = {
				"type": "traditional",
				"deviceId": "HTC",
				"deviceBrand": "HTC",
				"data": {
					"email": _.get(userAuth, "email", _.get(userToken, "email")),
				}
			};
			finalResponse = await socialLogin.doLoginAndSignUp(input, userAuth, userAuth, _.get(userToken, "uid"), true, "", endpoint);
			if(finalResponse.data && finalResponse.data.birthDate){
				const birthDate = finalResponse.data.birthDate;
				const country = _.get(headers, "country", "NA");
				console.log("birth and country in v3UserProfileResponse ",birthDate,country, commonUtilResponse.isKidProfile(birthDate,country));
				_.set(finalResponse, "data.isKidProfile",commonUtilResponse.isKidProfile(birthDate,country));
			}
			const isParentPinSet = (userToken && userToken.parentPinMode)? true : false;
			_.set(finalResponse, "data.parentPinMode.isParentPinSet", isParentPinSet);
			const isParentPinEnabled = (userToken && userToken.parentPinMode && userToken.parentPinMode.isParentPinEnabled)? true : false;
			_.set(finalResponse, "data.parentPinMode.isParentPinEnabled", isParentPinEnabled);
		}
		
		if (_.get(headers, "apiVersion") == "v2") {
			ksmDeviceDetails = await ksmDetails.getKSMDevicesByUidAnddeviceId(_.get(userToken, "uid"), _.get(headers, "deviceId"));
			console.debug("KsmDetails", ksmDeviceDetails);
            
			//Syncing Code for Device and Platform
			if ( config.ksmConfig && config.ksmConfig.syncedDeviceAndPlatform && !_.isEmpty( _.get( config.ksmConfig.syncedDeviceAndPlatform, `${_.get( headers, "device" )}:${_.get( headers, "platform" )}`, "" ) ) ) {
				const [ syncedDevice, syncedPlatform ] = _.get( config.ksmConfig.syncedDeviceAndPlatform, `${_.get( headers, "device" )}:${_.get( headers, "platform" )}`, ":" ).split( ":" );
				ksmDeviceDetails = await ksmDetails.getKSMDevicesByUidAnddeviceId( _.get( userToken, "uid" ), syncedDevice );
				console.debug("ksm Details 2 ...",ksmDeviceDetails);
				if (_.get(ksmDeviceDetails, "status") != 1752) {
					try {
						await userKsmEncrptedService.syncListBetweenThePlatform( syncedPlatform, syncedDevice, userToken.uid, ksmDeviceDetails, true );
						ksmDeviceDetails = await ksmDetails.getKSMDevicesByUidAnddeviceIdPrimary( _.get( userToken, "uid" ), _.get( headers, "platform" ) );
						
					}
					catch (e) {
						console.log("Error in platform Syncing",e,e.stack);
					}
				}
				
			}
			
			if (_.get(ksmDeviceDetails, "status") == 1752) {
				ksmDeviceDetails = {};
			}
			if ( config.ksmConfig && config.ksmConfig.syncedDeviceAndPlatform && !_.isEmpty( _.get( config.ksmConfig.syncedDeviceAndPlatform, `${_.get( headers, "device" )}:${_.get( headers, "platform" )}`, "" ) ) ) {
				try {
					//Update HTMLvtv Pin for Already Existing Credential
					const [ syncedDevice, syncedPlatform ] = _.get( config.ksmConfig.syncedDeviceAndPlatform, `${_.get( headers, "device" )}:${_.get( headers, "platform" )}`, ":" ).split( ":" );
					if (userToken.kidSafeMode && userToken.kidSafeMode.pin && userToken.kidSafeMode.pin && userToken.kidSafeMode.pin.tv && !userToken.kidSafeMode.pin.tv.html5tv) {
						localCredentials = await getencryptedPinBydeviceAndPlatform( syncedDevice, syncedPlatform, userToken );
						if (_.has(localCredentials, "pin")) {
							//decrypt on the basis of symmetric algorithm                      
							let ksmDetails = _.get(userToken, "kidSafeMode", {});
							let pin = await userKsmEncrptedService.decryptStringWithSymmetricKey( _.get( localCredentials, "pin" ), syncedDevice, syncedPlatform );
							console.log("pin2", pin);
							if (pin) {
								let allPins = await commonUtil.generatePinForWholeCollection(pin);
								ksmDetails = { ...ksmDetails, "pin": allPins };
								console.debug("KSM USERPROFILE.....", userToken);
								await userProfileService.updateUserInformation({ uid: userToken.uid }, { kidSafeMode: ksmDetails, updatedAt: moment().utcOffset(+530).unix() });
								userToken = { ...userToken, kidSafeMode: ksmDetails };
								console.debug("KSM USERPROFILE.....", userToken);
							} else {
								throw { message: "Invalid Recovery Pin" };
							}
						}
					}
                    
				} catch (e) {
					console.log("Get user Details..", e, e.stack);
				}
			}

			localCredentials = await getencryptedPinBydeviceAndPlatform(_.get(headers, "device"), _.get(headers, "platform"), userToken);
			if (_.get(headers, "profiletype") == "kidSafeMode" || _.get(headers, "profile-type") == "kidSafeMode" || _.get(headers, "profiletype") == "COMMON" || _.get(headers, "profile-type") == "COMMON") {

				finalKSMDetails =  await responseFormat.v3UserProfileResponse(userToken, ksmDeviceDetails, localCredentials, headers, false, false);
			} else {

				finalKSMDetails = await responseFormat.v3UserProfileResponse(userToken, ksmDeviceDetails, localCredentials, headers, true, false);
			}
		} else {

			finalKSMDetails =  await responseFormat.v3UserProfileResponse(userToken, ksmDeviceDetails, localCredentials, headers, true, true);
		}
		if(_.get(headers, "profiletype") == "kidSafeMode" || _.get(headers, "profile-type") == "kidSafeMode"){
			finalResponseObj = finalKSMDetails;
		}
		else if(_.get(headers, "profiletype") == "ALL" || _.get(headers, "profile-type") == "ALL"){
			finalResponseObj = finalResponse;
		}
		else if(_.get(headers, "profiletype") == "COMMON" || _.get(headers, "profile-type") == "COMMON"){
			finalResponseObj = await responseFormat.v3UserProfileCommonResponse(finalResponse,finalKSMDetails, headers);
		} else{
			finalResponseObj = finalKSMDetails;
		}
		return finalResponseObj;
	} catch (err) {
		console.error("Auth Service Login Error: ", err,err.stack);
		if (!err || !err.code)
			return apiResponse.error(errorConfig.requestFailed, 400);
		switch (err.code) {
		case "auth/wrong-password":
			return apiResponse.error(errorConfig.wrongPassword.description, errorConfig.wrongPassword.code);
		case "auth/user-not-found":
			return apiResponse.error(errorConfig.userDoesNotExist.description, errorConfig.userDoesNotExist.code);
		case "auth/invalid-email":
			return apiResponse.error(errorConfig.invalidEmail.description, errorConfig.invalidEmail.code);
		case "auth/invalid-uid":
			return apiResponse.error(errorConfig.invalidUid.description, errorConfig.invalidUid.code);
		case "auth/too-many-requests":
			return apiResponse.error(errorConfig.tooManyAttempts.description, errorConfig.tooManyAttempts.code);
		case errorConfig.errorCodes.USER_WRONG_USERNAME_OR_PASSWORD.code:
			return apiResponse.error(errorConfig.kalturaUserWrongUsernameOrPassword.description, errorConfig.kalturaUserWrongUsernameOrPassword.code);
		case errorConfig.errorCodes.INSIDE_LOCK_TIME.code:
			return apiResponse.error(errorConfig.kalturaInsideLockTime.description, errorConfig.kalturaInsideLockTime.code);
		default:
			throw apiResponse.error(errorConfig.requestFailed, 400);

		}
	}
}

async function getencryptedPinBydeviceAndPlatform(device, platform, userProfileData) {
	try {
		let ksmObject = _.get(userProfileData, "kidSafeMode");
		let mobile;
		let countryCode;
		let pin;
		if (_.has(ksmObject, "recovery")) {
			mobile = ksmObject.recovery.mobile;
			countryCode = ksmObject.recovery.countryCode;
		}
		if (_.has(ksmObject, "pin")) {
			pin = ksmObject.pin[device][platform];

			//return mypin
		}
		let localObject = {
			mobile: mobile ,
			countryCode: countryCode ? countryCode : "+91",
			pin: pin 
		};
		// let localObject = {
		//     mobile: mobile ? mobile : '',
		//     countryCode: countryCode ? countryCode : '+91',
		//     pin: pin ? pin : ''
		// }
		return localObject;
	} catch (e) {
		console.log("Error in finding the Error", e);
	}
}

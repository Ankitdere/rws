const { errorConfig, configuration } = require("../config");
const userProfileService = require("../services").userProfileService;
const userService = require("../services").userService;
const _ = require("lodash");
const { apiResponse, generateHash } = require("../utils");
const randomId = require("randomstring");
const moment = require("moment");
const auditLogNotificationservice = require("../services/auditLogNotificationService");
const kafkaService = require("../services/kafkaService");
const constant  = require("../utils/constant/generic");
module.exports = passwordChange;

async function passwordChange(input, user, auditObj) {
	console.info(`AccountService.changePassword() with parameter(s) input=${JSON.stringify(input)}`);
	let email, salt, passwordHash, notificationObj;
	let auditValue={};
	//not keeping password details in audit
	auditValue.from = constant.PASSWORD_CHANGE_AUDIT.FROM;
	auditValue.to = constant.PASSWORD_CHANGE_AUDIT.TO;
	auditValue.uid =  _.get(user, "uid");
	try {
		email = _.get(user, "email");
		if(_.has(input,"mobile")||_.has(input,"countryCode")){
			const mobile = input.countryCode + input.mobile;
			input.email=`${mobile}@voot.com`;
		}
		if (_.lowerCase(_.get(input, "email")) != _.lowerCase(email))
			throw apiResponse.error(errorConfig.cantChangePassword.description);
		salt = randomId.generate({
			length: 8,
			charset: "alphanumeric"
		});
		passwordHash = await generateHash(input.newPassword, salt);
		let result = await userService.updateOrInsertUser({ "uid": user.uid }, { "passwordHash": passwordHash, "passwordSalt": salt });
		//add notification for password change
		notificationObj = await auditLogNotificationservice.getAuditNotificationObj(auditObj,"update_password",auditValue,result);
		console.log("before push",notificationObj);
		if(configuration.kafkaConfig.enable.audit){
			kafkaService.pushEventToKafka(configuration.kafkaConfig.topic.audit_log,notificationObj);
		}
		await userProfileService.updateUserInformation({ uid: user.uid }, { $unset:{"_system": 1,"loginAttemptSystem":1}, updatedAt:moment().utcOffset(+530).unix() });
		return apiResponse.success(errorConfig.changePasswordSuccess);
	} catch (error) {
		console.error("error",error,error.stack);
		if (errorConfig.message == errorConfig.cantChangePassword.code)
			throw apiResponse.error(errorConfig.cantChangePassword.description, errorConfig.cantChangePassword.code);
		throw error;
	}
}

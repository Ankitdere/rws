"use strict";
const randomId = require("randomstring");
module.exports = loginCode;
const deviceActivationCode = require("../services").deviceActivationCode;
async function loginCode(deviceId, deviceBrand) {
	try {
		let randomCode = randomId.generate({
			length: 4,
			charset: "alphanumeric",
			capitalization:"uppercase"
		});
		let { expiresAt } = await deviceActivationCode.insertDeviceCode(deviceId, deviceBrand, randomCode);
		return {
			code : randomCode,
			expiresIn : expiresAt
		};
	} catch (err) {
		throw err;
	}
}

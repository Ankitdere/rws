const { errorConfig } = require("../config");
const { userProfileService, userService, redisService, kalturaService } = require("../services");
const _ = require("lodash");
const { apiResponse, generateHash } = require("../utils");
const randomId = require("randomstring");
const moment = require("moment");
const kalturaBL = require("./kalturaBL");
const commonUtil = require("../utils").common;
const socialLogin = require("./socialLogin");

module.exports = resetPasswordWithLogin;

async function resetPasswordWithLogin(input, tokenInfo) {
	console.debug(`AccountService.resetPasswordWithLogin() with parameter(s) input=${JSON.stringify(input)}`);
	let email, salt, passwordHash, uId;
	try {
		email = _.get(tokenInfo, "email");
		if (_.isEmpty(email))
			return apiResponse.error(errorConfig.cantChangePassword.description, errorConfig.cantChangePassword.code);
		// eslint-disable-next-line no-undef
		let temp = await Promise.all([userProfileService.getUserInformationByEmail(email), userService.getAllUserRecordsByEmail(email)]);
		let userProfile = temp[0];
		let userAuth = temp[1];
		if(userAuth.length > 0){
			userAuth = await commonUtil.getUserAuthPasswordProvider(userAuth);
		}
		uId = _.get(userAuth, "customClaims.customUid", _.get(tokenInfo, "uid"));
		console.log("UserId......", uId);
		salt = randomId.generate({
			length: 8,
			charset: "alphanumeric"
		});
		passwordHash = await generateHash(input.newPassword, salt);
		userService.updateOrInsertUser({ "uid": _.get(userAuth, "uid") }, { "passwordHash": passwordHash, "passwordSalt": salt });
		try{
			userProfileService.updateUserInformation({ "uid":uId }, { updatedAt:moment().utcOffset(+530).unix() });
		}catch(err){
			console.error("Error in updating user profile updatedAt node",err);
		}
           
            
		try {
			await redisService.saveUserIntoRedis(uId, moment().unix());
		}
		catch (err) {
			console.log("Redis Unable to Set Value", err);

		}
		//login and revoke API 
		const kalturaUserLoginResult = await kalturaBL.doKalturaLogin(input, userAuth, userProfile);
		const ks = kalturaUserLoginResult.ks;
		const kalturaRevokefunction = await kalturaService.revokeKs(ks);
		console.debug("Kaltur revok res", kalturaRevokefunction);
		let loginInput = await checkUserType(email, input);
		let logInput = JSON.stringify(loginInput);
		let lInput = JSON.parse(logInput);
		return socialLogin.doLoginAndSignUp(lInput, userAuth, userAuth, uId);
            
	} catch (error) {
		console.error(error);
		if (error.message == errorConfig.invalidAccessToken.description)
			throw new Error(apiResponse.error(errorConfig.invalidAccessToken.description, errorConfig.invalidAccessToken.code));

		if (error.message == errorConfig.cantChangePassword.description)
			throw new Error(apiResponse.error(errorConfig.cantChangePassword.description, errorConfig.cantChangePassword.code));

		if (error.code === "auth/wrong-password") {
			throw new Error(apiResponse.error(errorConfig.wrongPassword.description, errorConfig.wrongPassword.code));
		}
		throw new Error(apiResponse.error(errorConfig.requestFailed, 400));
	}
}
async function checkUserType(email, input) {
	let loginInput;
	loginInput = {
		type: "traditional",
		deviceId: input.deviceId,
		deviceBrand: input.deviceBrand,
		data: {
			email: email,
			password: input.newPassword
		}
	};
	return loginInput;
}

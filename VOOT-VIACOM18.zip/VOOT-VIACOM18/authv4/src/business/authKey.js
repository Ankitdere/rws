"use strict";

const tokenService = require("../services").tokenService;
module.exports = authKey;

async function authKey(lastLoginProvider, profileId, decoded, userToken) {
	return await tokenService.createAccessTokenForScreenz(lastLoginProvider, profileId, decoded, userToken);
}
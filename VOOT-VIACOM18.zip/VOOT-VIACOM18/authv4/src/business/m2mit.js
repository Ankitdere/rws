"use strict";

const _ = require("lodash");
// const envconfig = require("../config").envconfig;
const apiResponse = require("../utils").apiResponse;
const config = require("../config").configuration;
const errorconfig = require("../config").errorConfig;
const { userService, pxApiService,tokenService, userProfileService } = require("../services");
const mongoUser = require("../format").mongoUser;
const utils = require("../utils").common;
const moment = require("moment");
const { responseFormat } = require("../format");
const kalturaBL = require("./kalturaBL");
const kalturaService = require("../services/kalturaService");
const storeKUserId = require("./partnerSignIn").storeKUserId;
const commonHelperFunctions = require("../helper").commonHelperFunctions;
const mixpanelService =require("../services/mixpanelService");
const notificationService = require("../services/notificationService");
const kafkaService = require("../services/kafkaService");
const mixPanelConfig =require("../config/mixPanelConfig");
const Constanst = require( "../utils/constant/generic" );
async function m2mitNotification(input) {
	let notificationObj = await notificationService.getInitialNotificationObj(input);
	try {
		let partnerData;
		let userAuthData;
		let userProfile;
		let response = {};
		let PXAction;
		let PXResponse;
		let accessToken;
		let entilementStatus;
		let basicInfo = { partnerType: input.partnerName, uniqueId: input.data.uniqueId,deviceId: input.deviceId };
		notificationObj = await notificationService.updateBasicInfo(notificationObj, basicInfo);
		const { uid, userData } = await getM2MITCollectionDetails(config.App.users, input.data.uniqueId);
		notificationObj = await notificationService.updateNotificationStage(notificationObj,true,"validation");

		if (uid) {
			if ( _.isEmpty( _.get( userData, "kUserId" ) ) ) {
				try {
					let response = await kalturaService.getUserByUsername( _.get( userData, "tempEmail" ) );
					userData.kUserId = _.get( response, "id" );
					await storeKUserId( userData.kUserId, uid, _.get( userData, "deviceId", "" ) );
				} catch ( err ) {
					console.error( "Error in getting kuser id from kaltura", err );
				}
			}
			accessToken = await tokenService.createAccessTokenAndRefreshToken({ uid: uid, email: _.get(userData, "tempEmail"), kUserId: _.get(userData, "kUserId"), deviceId: _.get(input.data, "deviceId", _.get(userData, "deviceId")), partnerType: _.get(input, "partnerName", _.get(userData, "partnerType", "")) });
			console.log("User Access Token", accessToken);
		}
		const pxpartnerDetails = {};
		pxpartnerDetails.platform = config.pXApiDetails.partnerPlatform;
		pxpartnerDetails.partnerName = config.pXApiDetails.m2MITParnerName;
		switch (input.action) {
		case "Register":
			if (userData && uid) {
				notificationObj=await notificationService.updateNotificationStage(notificationObj,false,"auth",{ code: "partner/user-already-registered" ,uid:_.get(input.data,"uniqueId",uid) });
				const userAuthData = await userService.getUserByPhone( input.data.mobile );
				if ( _.has( userAuthData, "status" ) && (_.get(userData,"mobile") == input.data.mobile ) && ( userData && _.get( userData, "partnerType", "" ) != Constanst.PARTNER_TYPES.JIO ) ) {
					const updatedInput = JSON.parse( JSON.stringify( input ) );
					updatedInput.data.email = _.isEmpty( userData.email ) ? utils.tempEmail( input.data.mobile ) : userData.email;
					const userAuthDataCreate = await mongoUser.initFormatMobileUserByUid( updatedInput.data, userData.uid );
					await userService.insertUser( userAuthDataCreate );
				}
				throw { code: "partner/user-already-registered" ,uid:_.get(input.data,"uniqueId",uid) };
			}
			userAuthData = await m2mitRegisterUser(input);
			notificationObj = await notificationService.updateNotificationStage(notificationObj, true, "auth",userAuthData);
			if (config.kafkaConfig.enable.processNotification) {
				kafkaService.pushEventToKafka(config.kafkaConfig.topic.partnerNotification, notificationObj);
			}
			return userAuthData;
		case "Cancel":
			if (!uid) {
				notificationObj = await notificationService.updateNotificationStage(notificationObj, false, "auth", { code: "partner/user-not-found", uid: _.get(input.data, "uniqueId") });
				throw { code: "partner/user-not-found",uid:_.get(input.data,"uniqueId") };
			}
			/*if (userData && (userData.isActive == false || userData.isActive == 'false'))
                    throw { code: "partner/user-already-inactive" };*/
			entilementStatus = await checkEntitlementStatus(accessToken);
			if (entilementStatus == false) {
				PXAction = config.pXApiDetails.cancelSubcriptionAction;
				userProfile = await userProfileService.getUserInformationById(uid);
				input.deviceId = _.get(userProfile, "deviceId");
				input.deviceBrand = _.get(userProfile, "deviceBrand");
				partnerData = await m2mitCancellation(input, uid);
				_.set(userProfile, "isActive", false);
				// userProfile = await userProfileService.getUserInformationById(uid)
        
				PXResponse = await pxApiService.callPX(input, userProfile, pxpartnerDetails, _.get(accessToken, "accessToken"), PXAction);
				if (!PXResponse) {
					notificationObj = await notificationService.updateNotificationStage(notificationObj, false, "subscription",{ code: "partner/subscription-fail",uid:uid });
					throw { code: "partner/subscription-fail",uid:uid };
				}
				_.unset(input,"partnerToken");
				response = { "status": { "code": 200, "message": `${input.partnerName} subscription has been cancelled` } };
				notificationObj = await notificationService.updateNotificationStage(notificationObj, true, "auth",response);
				notificationObj = await notificationService.updateNotificationStage(notificationObj, true, "subscription");
				mixpanelService(mixPanelConfig.partnerNotification+_.get(input,"partnerName")+mixPanelConfig.success,
					response
					,_.get(input.data,"uniqueId")
					,null,
					null,
					false
				);
				if (config.kafkaConfig.enable.processNotification) {
					kafkaService.pushEventToKafka(config.kafkaConfig.topic.partnerNotification, notificationObj);
				}
				return response;
			} else {
				notificationObj = await notificationService.updateNotificationStage(notificationObj, false, "subscription",{ code: "partner/user-already-inactive",uid:_.get(input.data,"uniqueId",uid) });
				throw { code: "partner/user-already-inactive",uid:_.get(input.data,"uniqueId",uid) };
			}
		case "Activate":
			if (!uid) {
				notificationObj = await notificationService.updateNotificationStage(notificationObj, false, "auth",{ code: "partner/user-not-found" ,uid:_.get(input.data,"uniqueId")});
				throw { code: "partner/user-not-found" ,uid:_.get(input.data,"uniqueId")};
			}
                
			/*if (userData && (userData.isActive == true || userData.isActive == 'true'))
                throw { code: "partner/user-already-active-m2mit" }; */
			entilementStatus = await checkEntitlementStatus(accessToken);
			if (entilementStatus == true) { //If user is not expired and totally new user then allow activation
				partnerData = await m2mitActivateUser(input, uid);
				// userProfile = await userProfileService.getUserInformationById(uid);
				userProfile = await userProfileService.getUserInformationByIdFromPrimaryPre(uid);
				userProfile.subscription = partnerData;
				if (userProfile && (!userProfile.subscription || _.isEmpty(userProfile.subscription.activationDate) || _.isEmpty(userProfile.subscription.endDate) )) userProfile.subscription = partnerData;
				input.deviceId = _.get(userProfile, "deviceId");
				input.deviceBrand = _.get(userProfile, "deviceBrand");
				PXAction = config.pXApiDetails.newSubcriptionAction;
                    
				PXResponse = await pxApiService.callPX(input, userProfile, pxpartnerDetails, _.get(accessToken, "accessToken"), PXAction);
                    
				if (!PXResponse) {
					notificationObj = await notificationService.updateNotificationStage(notificationObj, false, "subscription",{ code: "partner/subscription-fail",uid:uid });
					throw { code: "partner/subscription-fail",uid:uid };
				}
				_.unset(input,"partnerToken");
				response = { "status": { "code": 200, "message": `${input.partnerName}` + " user is activated." } };
				notificationObj = await notificationService.updateNotificationStage(notificationObj, true, "auth",response);
				notificationObj = await notificationService.updateNotificationStage(notificationObj, true, "subscription");
				const noticationObj = notificationService.getfinalNotificationObj(userProfile, response);
				if (config.kafkaConfig.enable.processNotification) {
					kafkaService.pushEventToKafka(config.kafkaConfig.topic.partnerNotification, noticationObj);
				}
				mixpanelService(mixPanelConfig.partnerNotification+_.get(input,"partnerName")+mixPanelConfig.success,
					input
					,_.get(input.data,"uniqueId"),null,null,false);
				notificationObj = await notificationService.updateNotificationStage(notificationObj, true, "subscription");
				if (config.kafkaConfig.enable.processNotification) {
					kafkaService.pushEventToKafka(config.kafkaConfig.topic.partnerNotification, notificationObj);
				}
				return response;
			} else {
				notificationObj = await notificationService.updateNotificationStage(notificationObj, false, "auth",{ code: "partner/user-already-active-m2mit" ,uid:_.get(input.data,"uniqueId") });
				throw { code: "partner/user-already-active-m2mit" ,uid:_.get(input.data,"uniqueId") };
			}
		}
	} catch (e) {
		console.error("error in m2mitNotification catch/", e, e.stack);
		if (config.kafkaConfig.enable.processNotification && config.kafkaConfig.enable.processNotificationError) {
			kafkaService.pushEventToKafka(config.kafkaConfig.topic.partnerNotification, notificationObj);
		}
		throw e;
	}
}
async function getM2MITCollectionDetails(collection, uniqueId, partnerName = config.M2MITDetails.partnerName) {
	let userData;
	let uid;
	let dbName;
	let result = await userProfileService.getPartnerDetailsByUniqueId(uniqueId, partnerName);
	// call user auth to get password hash and password salt, if found then dont update the M2MIT password in user auth
	if (_.has(result, "status")) {
		return false;
	}
	else {
		if (!_.has(result, "status")) {
			uid = _.get(result, "uid");
			userData = result,
			dbName = "mongoDb";
		}
		return { uid: uid, userData: userData, dbName: dbName };
	}
}
async function m2mitRegisterUser(input) {
	let prevUserMongoDoc;
	let userProfileData;
	try {
		// eslint-disable-next-line no-undef
		[ prevUserMongoDoc, userProfileData ] = await Promise.all( [ userService.getUserByPhone( input.data.mobile ), userProfileService.getUserInformationByMobileWithCountryCode( input.data.mobile ) ] );
		if ( !_.has( prevUserMongoDoc, "status" ) || !_.has( userProfileData, "status" ) ) {//user has profile in mongo

			if ( _.has( prevUserMongoDoc, "status" ) && !_.has( userProfileData, "status" ) && ( userProfileData && _.get( userProfileData, "partnerType", "" ) != Constanst.PARTNER_TYPES.JIO ) ) {
				input.data.email = _.isEmpty( userProfileData.email ) ? utils.tempEmail( input.data.mobile ) : userProfileData.email;
				const userAuthData = await mongoUser.initFormatMobileUserByUid( input.data, userProfileData.uid );
				prevUserMongoDoc = [];
				prevUserMongoDoc.push( userAuthData );
				await userService.insertUser( userAuthData );
			}
			else if ( ( userProfileData && _.get( userProfileData, "partnerType", "" ) == Constanst.PARTNER_TYPES.JIO ) && _.has( prevUserMongoDoc, "status" ) ) {
				throw { code: "auth/user-not-found" };
			}
			let uid = _.get(prevUserMongoDoc[0], "customClaims.customUid", _.get(prevUserMongoDoc[0], "uid"));
			let kalturaOttListResponse = await kalturaService.getUserByUsernameOrExternalIdNew(_.get(prevUserMongoDoc[0], "email"), uid);
			console.debug("kalturaOttListResponse", kalturaOttListResponse);
			await storeKUserId(_.get(kalturaOttListResponse, "id"), uid);
			let accessToken = await tokenService.createAccessTokenAndRefreshToken({ uid: uid, email: _.get(prevUserMongoDoc[0], "email", ""), kUserId: _.get(kalturaOttListResponse, "id", "") });
			let mobileCheck = await checkMobileSubscription(input, accessToken, prevUserMongoDoc[0]);//Sync in this Function 
			if (mobileCheck != false) {
				return mobileCheck;
			} else {
				_.unset(input,"partnerToken");
				return apiResponse.error(errorconfig.mobileAlreadyExist.description, 
					errorconfig.mobileAlreadyExist.code,
					mixPanelConfig.partnerNotification+_.get(input,"partnerName")+mixPanelConfig.success,
					input,
					_.get(input.data,"uniqueId",uid),
					400,
					false
				);  
			}
		}  else {
			throw { code: "auth/user-not-found" };
		}

	}
	catch (err) {
		// console.error(err)
		try {
			console.error("Error,", err);
			if ( err.code === "auth/user-not-found" ) {
				let userSignUpData = {};
				userSignUpData.password = input.data.password;
				userSignUpData.mobile = input.data.mobile;
				let tempEmail = await utils.getDummyEmail(input.data.mobile);
				userSignUpData.email = tempEmail; // use passed parameter email
				const userCreated = await mongoUser.initFormatMobileUser(userSignUpData, input, input);
				await userService.insertUser(userCreated);
				let partnerData = await storePartnerData(input, userSignUpData);
				partnerData = JSON.parse(JSON.stringify(partnerData));
				let profiledata = await createUserInMongoDB(_.get(userCreated, "uid"), partnerData, true, input.partnerName, 1, tempEmail, input.action);
				const customUid = userSignUpData.uid = _.get(userCreated, "uid");
				input.deviceBrand = input.data.deviceBrand;
				input.deviceId = input.data.deviceId;
				let kalthuraLoginResponse = await kalturaBL.kalturaRegistration(_.get(userCreated, "email", tempEmail), _.get(userCreated, "uid"), input, userCreated, profiledata,false);
				console.debug("Kaltura Login response ", kalthuraLoginResponse);
				let finalOutput = await responseFormat.v3SignUpResponse(userCreated, profiledata, _.get(input, "deviceId"), kalthuraLoginResponse, input);
				console.debug("Final Output", finalOutput);
				let kUserId = _.get(kalthuraLoginResponse, "kUserId");
				await userProfileService.updateUserInformation({ "uid": _.get(userCreated, "uid", customUid) }, { "kUserId": kUserId });
				let response = { "status": { "code": 200, "message": `${input.partnerName}` + " user is Registered." } };
				_.unset(input,"partnerToken");
				mixpanelService(mixPanelConfig.partnerNotification+_.get(input,"partnerName")+mixPanelConfig.success,
					input,
					_.get(input.data,"uniqueId"),null,null,false);
				return response;
			} else throw err;
		} catch (err) {
			throw err;
		}
		// }
	}
}
async function storePartnerData(input, userSignUpData) {
	try {
		return {
			uniqueId: _.get(input, "uniqueId", input.data.uniqueId),
			isActive: false,
			partnerName: _.get(input, "partnerName", input.data.partnerName),
			mobile: _.get( input, "mobile", _.get( input.data, "mobile", userSignUpData.mobile ) ),
			email: _.get(input, "email", userSignUpData.email),
			deviceId: _.get(input, "deviceId", input.data.deviceId),
			deviceBrand: _.get(input, "deviceBrand", input.data.deviceBrand),
		};
	}
	catch (e) {
		console.error("Storage error", e);
		throw e;
	}
}
async function createUserInMongoDB(uId, partnerData, newUser, partnerType, lastLoginCount = 1, tempEmail = null, actionToStoreTime = "") {

	let profileData,splitData;

	if (_.has(partnerData, "mobile")) splitData = await utils.splitMobileWithCountryCode(_.get(partnerData, "mobile"));
	let lastLoginDate = moment().format("MMMM Do YYYY, h:mm:ss a");
	if (!newUser) {
		await commonHelperFunctions.setDocumentTimeStamp(uId, (actionToStoreTime == "Register" ? "Renew" : actionToStoreTime));
		profileData = {
			tempEmail: tempEmail,
			partnerType: partnerType,
			...partnerData,
			lastLoginDate: lastLoginDate,
			lastLoginCount: lastLoginCount + 1,

		};
	} else {
		await commonHelperFunctions.setDocumentTimeStamp(uId, actionToStoreTime);
		profileData = {
			tempEmail: tempEmail,
			partnerType: partnerType,
			...partnerData,
			lastLoginDate: lastLoginDate,
			lastLoginCount: 1,
			profileData: {
				Mobile: _.get(splitData, "Mobile"),
				CountryCode: _.get(splitData, "CountryCode", "+91"),
				Preferences: { Languages: ["Hindi", "English"] },
				Gender: "U"
			},
			uid: uId

		};
	}
	console.debug("Profile data", profileData);
	await userProfileService.updateUserInformation({ uid: uId }, profileData);
	// const userDocumentUpdated = await Admin.database.collection(config.App.users).doc(uId).set(profileData, { merge: true });
	//console.info({ userProfileService });
	return profileData;
}
async function m2mitActivateUser(input, uId) {
	try {
		const today = moment().format("DD-MM-YYYY");
		let planName = input.data.planId;
		let days = _.get(config.M2MITDetails.planId, planName);
		let endDate = moment(today, "DD-MM-YYYY").add(days, "days").format("DD-MM-YYYY");
		let startDate = today.split("-");
		let subscriptionEndDate = endDate.split("-");
		let sDate = new Date(Date.UTC(+startDate[2], startDate[1] - 1, +startDate[0]));
		let eDate = new Date(Date.UTC(+subscriptionEndDate[2], subscriptionEndDate[1] - 1, +subscriptionEndDate[0]));
		input.data.startDate = sDate.toISOString().replace("Z", "");
		input.data.endDate = eDate.toISOString().replace("Z", "");
		let subscription;
		let isActive = true;
		await commonHelperFunctions.setDocumentTimeStamp(uId, input.action),
		subscription ={
			startDate: input.data.startDate,
			activationDate: input.data.startDate,
			endDate: input.data.endDate,
			planName: planName,
			planId: input.data.planId,
			days: days
		};
		const userDocumentUpdated = await userProfileService.updateUserInformation({ "uid": uId },{"subscription":subscription,"isActive":isActive});
		// const userDocumentUpdated = await Admin.database.collection(config.App.users).doc(uId).set(subscription,{ 'isActive': true }, { merge: true });
		console.log("userDocumentUpdated-----",{ userDocumentUpdated });
		return subscription;

	}
	catch (err) {
		throw err;

	}
}
async function m2mitCancellation(input, uId) {
	try {
		await commonHelperFunctions.setDocumentTimeStamp(uId, input.action);
		const userDocumentUpdated = await userProfileService.updateUserInformation({ "uid": uId }, { "isActive": false });
		return userDocumentUpdated;

	}
	catch (err) {
		console.error("subscription err", err);

	}
}
async function checkEntitlementStatus(accessToken) {
	let pxResponse = await pxApiService.checkEntitlementStatus(_.get(accessToken, "accessToken"));
	if ((_.get(pxResponse, "status")) == config.pXApiDetails.newSubcriptionAction || (_.get(pxResponse, "status")) == config.pXApiDetails.expiredUser) {
		return true;
	} else {
		return false;
	}


}
async function checkMobileSubscription(input, accessToken, prevUserMongoDoc) {

	try {
		let pxResponse = await checkEntitlementStatus(accessToken);
		if (pxResponse == true) {
			let userSignUpData = {};

			if (!_.has(prevUserMongoDoc, "status")) {
				let tempEmail = await utils.getDummyEmail(input.data.mobile);
				userSignUpData.email = tempEmail;
				let partnerData = await storePartnerData(input, userSignUpData);
				partnerData = JSON.parse(JSON.stringify(partnerData));
				await createUserInMongoDB(_.get(prevUserMongoDoc, "uid"), partnerData, false, input.partnerName, 1, tempEmail);
				_.unset(input,"partnerToken");
				return apiResponse.error(errorconfig.mobileIsAlreadyExistAndIntegratedWithM2MIT.description,
					errorconfig.mobileIsAlreadyExistAndIntegratedWithM2MIT.code,
					mixPanelConfig.partnerNotification+_.get(input,"partnerName")+mixPanelConfig.success,
					input
					,_.get(input.data,"uniqueId",_.get(prevUserMongoDoc, "uid"))
					,400,false
				);
			}
		} else {
			console.log("user is Already activated");
			return false;
		}

	} catch (e) {
		console.log(e);
	}
}

async function checkMobileSubscriptionForAsync(input, accessToken, prevUserMongoDoc) {

	try {
		let userSignUpData = {};
		let pxResponse = await checkEntitlementStatus(accessToken);
		if (pxResponse == true) {
			if (!_.has(prevUserMongoDoc, "status")) {
				let tempEmail = await utils.getDummyEmail(input.data.mobile);
				userSignUpData.email = tempEmail;
				let partnerData = await storePartnerData(input, userSignUpData);
				partnerData = JSON.parse(JSON.stringify(partnerData));
				await createUserInMongoDB(_.get(prevUserMongoDoc, "uid"), partnerData, false, input.partnerName, 1, tempEmail);
				_.unset(input,"partnerToken");
				return apiResponse.error(errorconfig.mobileIsAlreadyExistAndIntegratedWithM2MIT.description,
					errorconfig.mobileIsAlreadyExistAndIntegratedWithM2MIT.code,
					mixPanelConfig.partnerNotification+_.get(input,"partnerName")+mixPanelConfig.success,
					input
					,_.get(input.data,"uniqueId",_.get(prevUserMongoDoc, "uid"))
					,400,false
				);
			}
		} else {
			console.log("user is Already activated");
			return false;
		}

	} catch (error) {
		console.log("Error in Subsciption Check",error,error.stack);
	}
}

module.exports = {
	m2mitNotification,
	getM2MITCollectionDetails,
	checkEntitlementStatus,
	checkMobileSubscriptionForAsync

};
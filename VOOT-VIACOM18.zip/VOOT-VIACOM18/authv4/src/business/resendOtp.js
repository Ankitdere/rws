"use strict";
const { errorConfig, configuration,forgotPasswordTemplate } = require("../config");
const { otpService } = require("../services");
const responseFormat = require("../format").responseFormat;
const ApiResponse = require("../utils").apiResponse;
const unverifiedUser = require("../services/unverifiedUser");
const unVerifiedImsUser = require("../services/unVerifiedImsUser");
const { checkMobileWithoutOtpSending } = require("./verifyOtp");
const constant = require("../utils/constant/generic");
const _ = require("lodash");

module.exports = resendOtp;

async function resendOtp(userInput,service) {
	try {
		let userExists, userDetails, hasImsService, imsRequest, signUpRequest;
		const phoneNumber = userInput.countryCode + userInput.mobile; // mobile
		userExists = await checkMobileWithoutOtpSending(userInput);
		userInput.email = await getDummyEmail(phoneNumber); // change for removing email address
		userInput.isOtpVerify = false;
		if(_.get(userInput, "action") === "imsOtp") {
			hasImsService = 1;
			userDetails = await unVerifiedImsUser._getUnverifiedImsUserData(userInput.mobile, userInput.countryCode);
			if (configuration.Otp.isUserBlockEnableForIms && userDetails._system && userDetails._system.failedAttempt) {
				const isUserBlockedResult = await otpService.isUserBlocked(userDetails, "ims", configuration.Otp.maxNumberOfWrongOtpIms, configuration.Otp.blockDurationIms);
				if (isUserBlockedResult) {
					return ApiResponse.error(errorConfig.userlocked.description, errorConfig.userlocked.code);
				}
			}
			imsRequest = await otpService.generate();
			if (userDetails.mobile) {
				imsRequest = await otpService.checkOtpAttempts(userDetails,"imsRequest",true);
				if (imsRequest.code !== undefined && imsRequest.code === "otp/exceededMaxGenerationLimit") {
					return ApiResponse.error(errorConfig.otpLimitExceeded.description, errorConfig.otpLimitExceeded.code);
				}
			}
			await unVerifiedImsUser.storeUnverifiedImsUserWithOTP(userInput, imsRequest,configuration.actionList.resendOtp,(userDetails._system && userDetails._system.failedAttempt)?userDetails._system.failedAttempt:null);
		}
		else if(userExists === true){
			//MobilNumber exist in DB
			return ApiResponse.error(errorConfig.mobileAlreadyExist.description,errorConfig.mobileAlreadyExist.code);
		} else {
			hasImsService = 0;
			userDetails = await unverifiedUser._getUnverifiedUserData(userInput.mobile, userInput.countryCode, phoneNumber);
			if (configuration.Otp.isUserBlockEnableForSignUp && userDetails._system && userDetails._system.failedAttempt) {
				const isUserBlockedResult = await otpService.isUserBlocked(userDetails, "signUp", configuration.Otp.maxNumberOfWrongOtpSignUp, configuration.Otp.blockDurationSignUp);
				if (isUserBlockedResult) {
					return ApiResponse.error(errorConfig.userlocked.description, errorConfig.userlocked.code);
				}
			}
			signUpRequest = await otpService.generate();
			if (userDetails.mobile) {
				signUpRequest = await otpService.checkOtpAttempts(userDetails,"signUpRequest",true);
				if (signUpRequest.code !== undefined && signUpRequest.code === "otp/exceededMaxGenerationLimit") {
					return ApiResponse.error(errorConfig.otpLimitExceeded.description, errorConfig.otpLimitExceeded.code);
				}
			}
			await unverifiedUser.storeUnverifiedUserWithOTP(userInput, signUpRequest,configuration.actionList.resendOtp,(userDetails._system && userDetails._system.failedAttempt)?userDetails._system.failedAttempt:null);
		}
		const { sms: smsConfig } = configuration;
		const { properties: smsProps } = smsConfig;
		const peID = smsConfig.peID.VOOT;
		if (userInput.otpVersion && userInput.otpVersion == constant.VALID_OTP_VERSION.v2) {
			const messageTemplate = forgotPasswordTemplate.signUpHashCode.replace("{HASHCODE}", configuration.Otp.otpHashCode);
			const { templateId, header } = smsProps.signUpHashCode;
			const smsParams = {
				destination: phoneNumber,
				otp: hasImsService ? imsRequest.otp : signUpRequest.otp,
				messageTemplate: hasImsService ? forgotPasswordTemplate.ims : messageTemplate,
				peID,
				templateId,
				header,
			};
			otpService.sendSMS(smsParams); // async, not awaiting
		} else {
			const { templateId, header } = smsProps.signUp;
			const smsParams = {
				destination: phoneNumber,
				otp: hasImsService ? imsRequest.otp : signUpRequest.otp,
				messageTemplate: hasImsService ? forgotPasswordTemplate.ims : forgotPasswordTemplate.signUp,
				peID,
				templateId,
				header,
			};
			otpService.sendSMS(smsParams); // not waiting for it's result
		}
		const response = {
			attempts: hasImsService ? imsRequest.attempts : signUpRequest.attempts,
			maxAttempts: configuration.Otp.maxAttempts
		};
		const sendOTPResponse = await responseFormat.phoneNumberResponse(false,response,service);
		return ApiResponse.success(sendOTPResponse);

	} catch (error) {
		if (!error.code) {
			console.error("No Error Code ",error);
			throw ApiResponse.error(errorConfig.requestFailed, 400);
		}
		switch (error.code) {
		//case 'auth/insufficient-permission: // when firebase auth credentials are not provided correctly
		case "otp/exceededMaxGenerationLimit":
			throw  ApiResponse.error(errorConfig.otpLimitExceeded.description, errorConfig.otpLimitExceeded.code);
		default:
			console.log("New Error Code, which is not handled: ", error.code);
			throw  ApiResponse.error(errorConfig.requestFailed, 400);
		}
	}

}

// async function checkEmail(input) {
//     try {
//         let userExists, finalMessage, email;
//         email = _.get(input, 'email', '').toLowerCase();
//         userExists = await userService.getUserByEmail(email);
//         console.log("existence of user: ", userExists);
//         if (userExists != undefined) {
//             finalMessage = { "IsExist": true };
//             console.log(finalMessage);
//             return ApiResponse.success(finalMessage);
//         }
//         finalMessage = { "IsExist": false };
//         return ApiResponse.success(finalMessage);
//     } catch (error) {
//         console.error(error);
//         return ApiResponse.error(errorConfig.requestFailed, 400);
//     }

// }
// async function checkMobile(userInput) {
//     console.log("Reach in check Mobile function");
//     try {
//         const phoneNumber = userInput.countryCode + userInput.mobile; // mobile
//         const mobileExists = await phoneExists(phoneNumber);
//         return mobileExists
//     } catch (error) {
//         console.error(error);
//         return ApiResponse.error(errorConfig.requestFailed, 400);
//     }
// };
// async function phoneExists(phoneNumber) {
//     try {
//         const user = await userService.getUserByPhone(phoneNumber);
//         if (_.has(user, 'status')) {
//             console.log("User Does't Exist in Auth", user)
//             return false
//         } else {
//             return true;
//         }
//     } catch (error) {
//         //console.log(error);
//         return false; // resolve in both case, else it will go to Handler's catch block
//     }
// }
//Ned to Modify
async function getDummyEmail(emailpart) {
	return emailpart + "@voot.com";
}
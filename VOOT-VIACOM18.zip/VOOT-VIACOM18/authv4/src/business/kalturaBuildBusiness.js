const _ = require("lodash");
const kalturaOldBuildService = require("../services").kalturaOldBuildService;
const { errorConfig } = require("../config");
module.exports = kalturaBuildBusiness;

async function kalturaBuildBusiness(input) {
	try {
		let fetchUserQuery = { "uid": 1, "email": 1 };
		let kalturaBuildData;
		let value = _.get(input, "uid");
		kalturaBuildData = await kalturaOldBuildService.getKalturaOldBuildUser({ uid: value }, fetchUserQuery);
		if (!_.has(kalturaBuildData, "status")) {
			throw new Error(errorConfig.kalturaBuildAlreadyExist.code);
		}
		value = _.get(input, "email");
		kalturaBuildData = await kalturaOldBuildService.getKalturaOldBuildUser({ email: value }, fetchUserQuery);
		if (!_.has(kalturaBuildData, "status")) {
			throw new Error(errorConfig.kalturaBuildAlreadyExist.code);
		}
		return await kalturaOldBuildService.insertKalturaBuildData(input);
	} catch (error) {
		console.log("error in kalturaBuildBusiness/Catch", error, error.message);
		throw error;
	}
}

"use strict";
const jioSubscriptionService = require("../services").jioSubscriptionService;
module.exports = jioSubscription;

async function jioSubscription(input) {
	return await jioSubscriptionService.doSubscribeVootUser(input);
}

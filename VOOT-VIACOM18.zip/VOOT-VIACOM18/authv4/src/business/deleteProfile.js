const moment = require("moment");
const { mailService } = require("../services");
const {
	deleteProfileTemplate, configuration, errorConfig
} = require("../config");

async function deleteProfile(user) {
	const { email } = configuration.accountDeletion;
	const {
		uid,
		email: userEmail = "",
		mobile: userMobile = ""
	} = user;
	const timeStamp = moment().utcOffset("+05:30").format("DD/MM/YY HH:mm:ss").toString() + " IST";
	const emailSubject = deleteProfileTemplate.subject;
	const emailBodySubject = deleteProfileTemplate.bodySubject
		.replace("{mobile}", userMobile)
		.replace("{email}", userEmail)
		.replace("{uid}", uid)
		.replace("{timestamp}", timeStamp);
	const emailBody = deleteProfileTemplate.header + emailBodySubject + deleteProfileTemplate.footer;
	await mailService.sendMail(email, emailSubject, emailBody);
	return errorConfig.deleteProfileEmailSuccess;
}

module.exports = deleteProfile;


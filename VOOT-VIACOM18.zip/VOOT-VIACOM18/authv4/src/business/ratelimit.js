/* eslint-disable no-undef */
module.exports = {
	createOne: createOne
};

// Imports
const To = require("../utils/to");
const RatelimitService = require("../services/ratelimit");

/**
 * Create one ratelimit
 * @param ratelimit 
 * @param params 
 * @param flags 
 */
async function createOne(ratelimit, params, flags) {
	try {
		// Initialize
		let error;

		// Create
		[error] = await To(RatelimitService.createOne(ratelimit, params, flags));
		if (error) {
			console.error(error);
		}

		// Response
		return Promise.resolve({ code: 200, message: "Success" });
	} catch (error) {
		return Promise.resolve({ code: 200, message: "Success" });
	}
}
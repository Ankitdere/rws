"use strict";

module.exports = {updateProfile,generatePinForWholeCollection};
const userProfileService = require("../services").userProfileService;
const errorConfig = require("../config").errorConfig;
const config = require("../config").configuration;
const _ = require("lodash");
const moment = require("moment");
const ksmUserDeviceService = require("../services").ksmUserDeviceService;
const userKsmEncrptedService = require("../services").userKsmEncrptedService;
const auditLogNotificationservice = require("../services/auditLogNotificationService");
const kafkaService = require("../services/kafkaService");
const { apiResponse } = require("../utils");
const constant = require("../utils/constant/generic");
const configuration =require("../config").configuration;

async function updateProfile(input, userToken, headers,auditObj) {
	try {
		console.log("updateProfile is called with input data", input);
		let accountData = _.get(userToken, "profileData", {});
		let auditData = {};//audit data object
		let notificationObj;
		let finalPinDetails,pinDetails; //these variables hold the details of either kidSafeMode or parentPinMode
		let mode;
		let ksmPinDetails = _.get(userToken, "kidSafeMode", {});
		let parentPinDetails = _.get(userToken, "parentPinMode", {});
		
		if (_.get(userToken, "status", 0) == 1701) {
			throw new Error(errorConfig.userDoesNotExist.description);
		}
		if (input.subTitle) accountData = { ...accountData, SubTitle: input.subTitle };
		accountData = { ...accountData, isProfileUpdated: true };
	
		// New KSM and parent Pin changes
		if ( headers && headers.apiVersion && headers.apiVersion == "v2" ) {
			const platform = _.get(headers, "platform");
			const device = _.get(headers, "device");

			//prepare finalDeatils and mode basis on either ksm or parentPin
			pinDetails = _.has(input, constant.PINDETAILS.TYPE.kID_SAFE_MODE )
				? _.get(input, constant.PINDETAILS.TYPE.kID_SAFE_MODE) : (_.has(input, constant.PINDETAILS.TYPE.PARENT_PIN_MODE)
					? _.get(input, constant.PINDETAILS.TYPE.PARENT_PIN_MODE) : {});

			finalPinDetails = JSON.parse(JSON.stringify(pinDetails));
			if(_.has(input, constant.PINDETAILS.TYPE.PARENT_PIN_MODE) && (!parentPinDetails.pin  && (input.parentPinMode && !input.parentPinMode.pin))){
				throw new Error(errorConfig.pinIsRequired.description);
			}
			mode = (_.has(input, constant.PINDETAILS.TYPE.kID_SAFE_MODE) && 
			!_.has(input, constant.PINDETAILS.TYPE.PARENT_PIN_MODE)) ?
				constant.PINDETAILS.TYPE.kID_SAFE_MODE : constant.PINDETAILS.TYPE.PARENT_PIN_MODE;

			//decrypt on the basis of symmetric algorithm       
			if (_.has(pinDetails, "pin")) {

				let pin = await userKsmEncrptedService.decryptStringWithSymmetricKey(
					_.get(pinDetails, "pin"), 
					device,
					platform
				);
				console.log("pin2",pin);
				if(pin){
					let allPins = await generatePinForWholeCollection(pin);
					finalPinDetails = { 
						...finalPinDetails, 
						"pin": allPins 
					};
				}else{
					throw new Error(errorConfig.invalidKsmPin.description);
				}
			}
			//input contains status which is false then:
			if (mode === constant.PINDETAILS.TYPE.PARENT_PIN_MODE
				&& _.has(pinDetails,"isParentPinEnabled") 
				&& pinDetails.isParentPinEnabled === false) {
				
				//input or db details doesn't contains Pin then throw err
				if ( _.isEmpty(pinDetails) || (!pinDetails.pin)  ) { 
					throw new Error(errorConfig.pinIsRequired.description);
				}
				if (_.isEmpty(parentPinDetails) || (!parentPinDetails.pin)) { 
					throw new Error(errorConfig.invalidKsmPin.description);
				}
				let pinList = [_.get(pinDetails, "pin"), parentPinDetails.pin[device][platform]];
				let result = [];
				for (let pin in pinList) { 
					const decryptPin = await userKsmEncrptedService.decryptStringWithSymmetricKey(
						pinList[pin],
						device,
						platform
					);
					result.push(decryptPin);
				}	
				const [decryptInputPin, decryptDBPin] = result;
				if (!decryptInputPin || !decryptDBPin || (decryptInputPin !== decryptDBPin)) {
					throw new Error(errorConfig.invalidKsmPin.description);
				}
			}

			if (_.has(pinDetails,"recovery") ){
                    
				if(userToken && userToken.mobile && userToken.mobile != ""){
					// Put an option in config to !config.ksmConfig.updateRecoveryMobile &&
					console.log("Update config Mobile Number",config.ksmConfig.updateRecoveryMobile);
					if( !config.ksmConfig.updateRecoveryMobile && userToken.mobile 
						!= `${pinDetails.recovery.countryCode}${pinDetails.recovery.mobile}`)
					{
						return apiResponse.error(errorConfig.mobileNotMatched.description, 
							errorConfig.mobileNotMatched.code);
					}
				}
				let recovery = {};
				finalPinDetails = { ...finalPinDetails, recovery };
				recovery = {
					...recovery,
					mobile: pinDetails.recovery.mobile,
					countryCode: pinDetails.recovery.countryCode
				};
				finalPinDetails = { ...finalPinDetails, recovery };
			}
			finalPinDetails = { 
				...finalPinDetails, 
				createdAt: moment().utcOffset(+530).unix(),
				updatedAt: moment().utcOffset(+530).unix() 
			};
			
			//prepare device collection details only for ksm 
			if(_.has(input, constant.PINDETAILS.TYPE.kID_SAFE_MODE )){
				await updateDeviceBasedDetailsKSM(input, device, platform, userToken);
			}

			//update pin details in userprofile based on mode:
			await prepareAndUpdateDataBasedOnMode(mode, userToken, accountData, finalPinDetails, ksmPinDetails, parentPinDetails);
			
		}else {
			let updateResult = await userProfileService.updateUserInformation(
				{ uid: userToken.uid }, 
				{ 
					profileData: accountData, 
					updatedAt: moment().utcOffset(+530).unix() 
				}
			);
			//add notification from subTitle update:
			if (_.has(userToken.profileData, "SubTitle")
				&& (_.get(userToken.profileData, "SubTitle") != input.subTitle)
				&& configuration.kafkaConfig.enable.audit) {
				auditData.from = _.get(userToken.profileData, "SubTitle");
				auditData.to = input.subTitle;
				auditData.uid = _.get(userToken, "uid");
				notificationObj = await auditLogNotificationservice.getAuditNotificationObj(
					auditObj,
					"update_subTitle",
					auditData,
					updateResult
				);
				console.log("before push", notificationObj);
				kafkaService.pushEventToKafka(
					configuration.kafkaConfig.topic.audit_log,
					notificationObj
				);
			}
		}
		return errorConfig.updateAccountSuccess;
	}
	catch (error) {
		console.log("Error in Update Account", error,error.code);
		if (error.message == errorConfig.invalidKsmPin.description)
			return apiResponse.error( errorConfig.invalidKsmPin.description, 
				errorConfig.invalidKsmPin.code);
		if(error.message == errorConfig.userDoesNotExist.description)        
			return apiResponse.error( errorConfig.userDoesNotExist.description, 
				errorConfig.userDoesNotExist.code);
		if(error.message == errorConfig.pinIsRequired.description){
			return apiResponse.error(errorConfig.pinIsRequired.description,
				errorConfig.pinIsRequired.code);
		}
		return apiResponse.error(errorConfig.invalidSubTitle.description,
			errorConfig.invalidSubTitle.code);
	}
}

async function generatePinForWholeCollection(pin) {
	try {
		let results = [];
		for (let device in configuration.ksmPlatformAndDeviceConfig.ksm) {
			if (configuration.ksmPlatformAndDeviceConfig.ksm.hasOwnProperty(device)) {
				console.log(device + " -> " + configuration.ksmPlatformAndDeviceConfig.ksm[device]);
				let jsonObject = {};
				jsonObject[device] = device;
				jsonObject[device] = {};
				for (let platform in configuration.ksmPlatformAndDeviceConfig.ksm[device]) {
					let encryptedData = await userKsmEncrptedService.encryptStringWithSymmetricKey(
						pin, 
						device, 
						platform
					);
					jsonObject[device][platform] = platform;
					jsonObject[device][platform] = {};
					jsonObject[device][platform] = encryptedData;
					console.log("jsonObject", jsonObject);
					//  jsonObject[device][platform]=encryptedData;
				}
				results.push(jsonObject);
			}
		}
		let finalJson={};
		results.push({pinUpdatedAt: moment().utcOffset(+530).unix() });
		Object.assign(finalJson, ...results);
		return finalJson;

	} catch (e) {
		console.log("Error in pin generator", e);
	}
}
/**
 * function for add ksm details based on device & sync details between platforms.
 * @param {Object} input 
 * @param {String} device 
 * @param {String} platform 
 * @param {Object} userToken 
 */
async function updateDeviceBasedDetailsKSM(input, device, platform, userToken) {
	try {
		let ksmDeviceDetails = {};//this variable create the collection based on different UID
		if (input.kidSafeMode.deviceId) ksmDeviceDetails = {
			...ksmDeviceDetails,
			deviceId: input.kidSafeMode.deviceId
		};
		if (input.kidSafeMode.status) ksmDeviceDetails = {
			...ksmDeviceDetails,
			status: input.kidSafeMode.status
		};
		if (input.kidSafeMode.contentRestriction) ksmDeviceDetails = {
			...ksmDeviceDetails,
			contentRestriction: input.kidSafeMode.contentRestriction
		};
		ksmDeviceDetails = {
			...ksmDeviceDetails,
			createdAt: moment().utcOffset(+530).unix(),
			updatedAt: moment().utcOffset(+530).unix(),
			activationTime: moment().utcOffset(+530).unix(),
			device: device,
			platform: platform
		};
		try {
			await userKsmEncrptedService.syncListBetweenThePlatform(
				platform,
				device,
				userToken.uid,
				ksmDeviceDetails, false
			);
		}
		catch (e) {
			console.log("Error in platform Syncing", e);
		}
		await ksmUserDeviceService.updateDeviceCode(
			userToken.uid,
			_.get(ksmDeviceDetails, "deviceId"),
			ksmDeviceDetails
		);
	} catch (error) {
		console.log("Error in updateDeviceBasedDetailsKSM/catch block", error, error.stack);
		throw error;
	}
}

/**
 * update pin details based on mode
 * @param {String} mode 
 * @param {Object} userToken 
 * @param {Object} accountData 
 * @param {Object} finalPinDetails 
 */
async function prepareAndUpdateDataBasedOnMode(mode, userToken, accountData, finalPinDetails, ksmPinDetails, parentPinDetails) {
	try {
		let query, updateQuery;
		query = { uid: userToken.uid };
		if (mode === constant.PINDETAILS.TYPE.PARENT_PIN_MODE) {
			if (finalPinDetails.pin) parentPinDetails.pin = finalPinDetails.pin;
			if (finalPinDetails.deviceId) parentPinDetails.deviceId = finalPinDetails.deviceId;
			if (_.has(finalPinDetails,"isParentPinEnabled")) parentPinDetails.isParentPinEnabled = finalPinDetails.isParentPinEnabled;
			if (finalPinDetails.recovery) parentPinDetails.recovery = finalPinDetails.recovery;
			
			updateQuery = {
				profileData: accountData, 
				parentPinMode: parentPinDetails,
				updatedAt: moment().utcOffset(+530).unix()
			};
		} else {
			if (finalPinDetails.pin) ksmPinDetails.pin = finalPinDetails.pin;
			if (finalPinDetails.deviceId) ksmPinDetails.deviceId = finalPinDetails.deviceId;
			if (finalPinDetails.status) ksmPinDetails.status = finalPinDetails.status;
			if (finalPinDetails.recovery) ksmPinDetails.recovery = finalPinDetails.recovery;
			if (finalPinDetails.contentRestriction) ksmPinDetails.contentRestriction = finalPinDetails.contentRestriction;
			
			updateQuery = {
				profileData: accountData, 
				kidSafeMode: ksmPinDetails,
				updatedAt: moment().utcOffset(+530).unix()
			};
		}
		await userProfileService.updateUserInformation(query, updateQuery);
	} catch (error) {
		console.log("error from prepareAndUpdateDataBasedOnMode/Catch block", error);
		throw error;
	}
}
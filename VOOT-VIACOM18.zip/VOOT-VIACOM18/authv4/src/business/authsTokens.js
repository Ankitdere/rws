"use strict";

module.exports = authsTokens;

const RandomId = require("randomstring");

const userProfileService = require("../services").userProfileService;
const errorConfig = require("../config").errorConfig;
const apiResponse = require("../utils/apiResponse");
const config = require("../config").configuration;
const _ = require("lodash");
const moment = require("moment");
const template =  require("../config/forgotPasswordTemplate");
const smsService = require("../services/otpService");
const encryptionService = require("../services/userDeviceEncriptionService");
const commonUtil = require("./updateProfile");
const auditLogNotificationservice = require("../services/auditLogNotificationService");
const kafkaService = require("../services/kafkaService");
const constant = require("../utils/constant/generic");
async function authsTokens(input, userToken, headers, auditObj) {
	try {
		let auditData = {};
		if (_.get(userToken, "status", 0) == 1701) {
			throw new Error(errorConfig.userDoesNotExist.code);
		}
		console.log("input data", input);
		//recovery
		if ( input.type === config.ksmConfig.kidSafeModeRecovery || 
			input.type === config.ksmConfig.parentPinModeRecovery ) {
			const platform = _.get(headers, "platform");
			const device = _.get(headers, "device");
			//store recovery details from request
			let inputRecoveryDetails = (input.kidSafeMode) ? _.get(input, constant.PINDETAILS.TYPE.kID_SAFE_MODE): 
				((input.parentPinMode) ? _.get(input, constant.PINDETAILS.TYPE.PARENT_PIN_MODE) : {});
			//store pin details and mode
			let {userProfilePinDetails, mode } = await prepareModeBasedProfileData(userToken,input.type);
			
			if(_.isEmpty(userProfilePinDetails)){
				let description = (mode === constant.PINDETAILS.TYPE.kID_SAFE_MODE) 
					? errorConfig.ksmDetailsNotFound.description
					:errorConfig.parentPinDetailsNotFound.description;
				return apiResponse.error(
					description, 
					errorConfig.ksmDetailsNotFound.code
				);
			}
			if( inputRecoveryDetails && inputRecoveryDetails.recovery && inputRecoveryDetails.recovery.mobile && 
				inputRecoveryDetails.recovery.countryCode ) {
				let  mobile = inputRecoveryDetails.recovery.mobile;
				let  countryCode = inputRecoveryDetails.recovery.countryCode;
				let phoneNumber  = `${countryCode}${mobile}`;
				//audit data preparation
				if(userProfilePinDetails && userProfilePinDetails.pin && userProfilePinDetails.recovery){
					//for audit purpose:
					auditData.from = userProfilePinDetails.recovery.mobile;
					auditData.to = mobile ;
					auditData.uid = _.get(userToken, "uid");
				}
				console.debug("auditData",auditData);
				if( userToken && userToken.mobile && userToken.mobile != "" ) {
					if(!config.ksmConfig.updateRecoveryMobile && userToken.mobile != phoneNumber){
						return apiResponse.error(
							errorConfig.mobileNotMatched.description, 
							errorConfig.mobileNotMatched.code
						);
					}
				}
				if( userProfilePinDetails && userProfilePinDetails.pin ){
					let encryptedPin  = userProfilePinDetails.pin[device][platform];
					let decryptedPin  = await encryptionService.decryptStringWithSymmetricKey(
						encryptedPin,
						device,
						platform
					);
					// Need to decrypt the Pin
					// let decryptedPin  = "1234";
					// send pin to mobile
					await _processPinAttempts(
						userToken, 
						input.type, 
						mobile, 
						countryCode,
						auditData,
						auditObj,
						userProfilePinDetails,
						mode
					);
					smsService.sendPin(phoneNumber,decryptedPin, template.recoveryPin);
					return {"isRecovered":true};
				}else{
					//need to change this message or make configurable
					return apiResponse.error(
						errorConfig.ksmDetailsNotFound.description, 
						errorConfig.ksmDetailsNotFound.code
					);
				}
			}     
		}
		//reset
		if(input.type == config.ksmConfig.kidSafeModeReset ||  
			input.type === config.ksmConfig.parentPinModeReset ) {
			// Generate 4 digit pin
         
			let randomPin = RandomId.generate({
				length: 4,
				charset: "numeric",
				capitalization:"uppercase"
			});
			let allEncryptedPins = await commonUtil.generatePinForWholeCollection(randomPin);
			let {userProfilePinDetails, mode } = await prepareModeBasedProfileData(userToken,input.type);
			if(_.isEmpty(userProfilePinDetails)){
				//need to update errormessage
				let description = (mode === constant.PINDETAILS.TYPE.kID_SAFE_MODE) 
					? errorConfig.ksmDetailsNotFound.description
					:errorConfig.parentPinDetailsNotFound.description;
				return apiResponse.error(
					description, 
					errorConfig.ksmDetailsNotFound.code
				);
			}
			userProfilePinDetails.pin = allEncryptedPins;
			let action = (mode === constant.PINDETAILS.TYPE.PARENT_PIN_MODE)
				? config.ksmConfig.parentPinModeReset
				: config.ksmConfig.kidSafeModeReset;
			let pinValidationData =  await _processPinAttempts(
				userToken ,
				action ,
				"",
				"",
				"",
				"",
				userProfilePinDetails,
				mode
			);
			return {
				attempts: _.get(pinValidationData, "attempts", 1),
				pin:  randomPin,
				maxAttempts: config.ksmConfig.maxAttempts
			};
		}
		// throw new Error(errorConfig.type);
	}
	catch (error) {
		console.error("Auth Service Login Error: ", error);
		if (!error || !error.code)
			return apiResponse.error(errorConfig.requestFailed, 400);
		switch (error.code) {
		case "pin/exceededMaxGenerationLimit":
			return {status:{
				code: errorConfig.pinLimitExceeded.code,
				message: errorConfig.pinLimitExceeded.description,
				unlockInSec : error.unlockInSec
			}};
		default:
			throw apiResponse.error(errorConfig.requestFailed, 400);

		}

	}
}

async function _processPinAttempts(userDetails, action, mobile = "", countryCode ="",auditData="",auditObj="", userProfilePinDetails="", mode="") {
	console.log("Inside the function _processOtpAttempts=", action);
	try {
		let userProfilePinInfo = JSON.parse(JSON.stringify(userProfilePinDetails));
		let otpRequest = undefined;
		if(!_.isEmpty(userProfilePinDetails)){
			otpRequest =  eval("userProfilePinDetails." + action); // userDetails is being used inside eval
		}
		let otpValidationData = otpRequest !== undefined ? otpRequest : {};
		if(mobile && countryCode){
			userProfilePinDetails = {...userProfilePinDetails, recovery : {mobile:mobile, countryCode:countryCode} };
		}
		if (_.isEmpty(otpValidationData)) {
			otpValidationData.attempts = 1;
			otpValidationData.updatedAt = moment().format("MMMM Do YYYY, h:mm:ss a");
			userProfilePinDetails = {...userProfilePinDetails, [action]: otpValidationData };
			console.log("userProfile pin details", userProfilePinDetails);
			//update function based on mode
			await updateProfileDataBasedOnMode(mode, userDetails, userProfilePinDetails);
			return  otpValidationData ;
		}
		const otpTimestamp = moment(otpValidationData.updatedAt, "MMMM Do YYYY, h:mm:ss a");
		const currentTimestamp = moment();
		const elapsedMinutes = currentTimestamp.diff(otpTimestamp, "minutes");
		console.log("OTP was generated", elapsedMinutes, "minutes ago");
		const minutesInADay = config.ksmConfig.mobileBlockLimit;
		if (elapsedMinutes > minutesInADay) otpValidationData.attempts = 0;
		if (parseInt(otpValidationData.attempts) >= config.ksmConfig.maxAttempts){
			let unlockInSec = (minutesInADay - elapsedMinutes ) * 60;
			throw { code: "pin/exceededMaxGenerationLimit", "unlockInSec":unlockInSec };

		}
		otpValidationData.attempts++;
		// otpValidationData.isOtpVerify = false;
		otpValidationData.updatedAt = moment().format("MMMM Do YYYY, h:mm:ss a");
		/* 15 min otp same send check */
		// const minutesFifteen = Config.ksmConfig.sameOTPLimit;
		// if (elapsedMinutes > minutesFifteen) { // if difference is greater then 15 then only otp change
		//   //otpValidationData.otp = action === this.FORGOT_PASSWORD_REQUEST ? utility.randomString(6) : this._getRandomOTP(); // since password is minimum 6 characters in length
		//   otpValidationData.otp = _getRandomOTP(); // since password is minimum 6 characters in length
		// }
		userProfilePinDetails = {...userProfilePinDetails, [action]: otpValidationData };
		console.log("userProfile pin details", userProfilePinDetails);
		let updateResult = await updateProfileDataBasedOnMode(mode, userDetails, userProfilePinDetails);
		//add notification for ksm recovery mobile update:
		if((userProfilePinInfo.recovery) && (userProfilePinInfo.recovery.mobile!= mobile)
			&& (config.kafkaConfig.enable.audit) ){
			let notificationObj = await auditLogNotificationservice.getAuditNotificationObj(
				auditObj, 
				"update_recovery_mobile", 
				auditData, 
				updateResult
			);
			console.log("before push",notificationObj);
			kafkaService.pushEventToKafka(config.kafkaConfig.topic.audit_log, notificationObj);
		}
		return otpValidationData;
	}catch(error){
		console.log("errorin processing the Request",error);
		throw error;
	}
}

/**
 * function will update data irrespect mode
 * @param {String} mode 
 * @param {Object} userDetails 
 * @param {Object} userProfilePinDetails 
 */
async function updateProfileDataBasedOnMode(mode, userDetails, userProfilePinDetails) {
	try {
		let query, updateQuery;
		query = { uid: userDetails.uid };
		if (mode === constant.PINDETAILS.TYPE.PARENT_PIN_MODE) {
			updateQuery = {
				parentPinMode: userProfilePinDetails,
				updatedAt: moment().utcOffset(+530).unix()
			};
		} else {
			updateQuery = {
				kidSafeMode: userProfilePinDetails,
				updatedAt: moment().utcOffset(+530).unix()
			};
		}
		await userProfileService.updateUserInformation(query, updateQuery);
	} catch (error) {
		console.log("error from prepareAndUpdateDataBasedOnMode/Catch block", error);
		throw error;
	}
}

/**
 * 
 * @param {Object} userToken 
 * @param {String} type 
 * @returns 
 */
async function prepareModeBasedProfileData(userToken,type){
	let userProfilePinDetails = {}, mode = "";
	//Give priority to parentPin details
	mode = (type === config.ksmConfig.parentPinModeRecovery || type === config.ksmConfig.parentPinModeReset)
		?constant.PINDETAILS.TYPE.PARENT_PIN_MODE:constant.PINDETAILS.TYPE.kID_SAFE_MODE;
	if( userToken.parentPinMode && !_.isEmpty(userToken.parentPinMode) && 
	(type === config.ksmConfig.parentPinModeRecovery || type === config.ksmConfig.parentPinModeReset) ){
		userProfilePinDetails = userToken.parentPinMode;
		mode = constant.PINDETAILS.TYPE.PARENT_PIN_MODE;
		return {userProfilePinDetails,mode};
	}
	if( userToken.kidSafeMode && !_.isEmpty(userToken.kidSafeMode) && 
	(type === config.ksmConfig.kidSafeModeRecovery || type === config.ksmConfig.kidSafeModeReset) ){
		mode = constant.PINDETAILS.TYPE.kID_SAFE_MODE;
		userProfilePinDetails = userToken.kidSafeMode;
	}
	return {userProfilePinDetails,mode};
}
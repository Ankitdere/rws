"use strict";

const subProfile = require("../services").subProfile;
const { mongoSubProfile } = require("../format");
const {	errorConfig } = require("../config");
const Constant = require("../utils/constant/generic");

module.exports = updateProfile;

/**
 * @param {Object} input 
 * @param {Object} request 
 * @returns {Object}
 */
async function updateProfile(input, request) {
	try {
		const { tokenInfo } = request;
		const query = {
			uid: tokenInfo.uid,
			childUid: input.childUid,
		};
		const params = { upsert: false, useFindAndModify: false, new: true };
		const updateSubProfileData = await mongoSubProfile.initFormatSubProfileUpdate(input, request);
		const userData = await subProfile.updateSubProfileInformation(query,updateSubProfileData,params);

		if (userData.status !== Constant.SUCCESS_STATUS) throw new Error(errorConfig.subProfileDoesNotExist.description);			
		let finalOutput = await mongoSubProfile.updateSubProfileResponse(
			userData.data,
			tokenInfo,
			request.headers
		);
		return finalOutput;

	} catch (error) {
		console.error("\n Error in updateSubProfile Business/catch \n", error);
		if (error && error.message == errorConfig.subProfileDoesNotExist.description) {
			throw new Error(errorConfig.subProfileDoesNotExist.description);
		}
		throw new Error(errorConfig.updateSubProfile.description);
	}

}



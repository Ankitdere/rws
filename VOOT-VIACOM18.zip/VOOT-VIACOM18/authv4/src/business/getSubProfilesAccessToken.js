"use strict";

const _ = require("lodash");
const { subProfile } = require("../services");
const {
	errorConfig
} = require("../config");
const tokenService = require("../services").tokenService;
const constant = require("../utils/constant/generic");
const commonUtils = require("../utils").common;
/**
 * @param {Object} input 
 * @param {Object} request 
 * @returns {Object}
 */
async function getSubProfilesAccessToken(input, request) {
	try {
		const { tokenInfo, userToken, subProfileData = null} = request;
		const { parentPinMode } = userToken;
		const { childUid: childUidFromAccessToken = null, uid: uidFromAccessToken = null } = tokenInfo;
		const isSameProfile = (childUidFromAccessToken !== null) && (childUidFromAccessToken === input.childUid);
		const isPrimaryProfile = (uidFromAccessToken === input.childUid);//....is targetProfile primary or not
		let targetProfileData;
		const sourceProfileData = (subProfileData === null) ? userToken : subProfileData[0];
		if(!isSameProfile && !isPrimaryProfile) {
			const filter = { uid:uidFromAccessToken, childUid: input.childUid };
			targetProfileData = await subProfile.getAllSubProfilesInformation(filter);
			if (targetProfileData && targetProfileData.data && targetProfileData.data.length === 0) {
				throw new Error(errorConfig.subProfileDoesNotExist.description);
			}
			targetProfileData = targetProfileData.data[0];
		}else{
			targetProfileData = (isPrimaryProfile)? userToken : subProfileData[0];
		}
		// To check parentPin option
		const apiVersion = request.header("apiVersion");
		if (apiVersion === constant.API_VERSION["4@0"] && parentPinMode && parentPinMode.isParentPinEnabled) {
			const { sourceIsKid, targetIsKid } = await checkSubProfileUserType(
				sourceProfileData,
				targetProfileData,
				request.headers,
			);
			if (sourceIsKid && !targetIsKid) { 
				const device = request.header("device");
				const platform = request.header("platform");
				await commonUtils.customKsmDevicePlatformValidator(request.headers);  
				if (!input.parentPinMode) {
					throw new Error(errorConfig.parentPinModeError.description);
				} 
				const { pin } = input.parentPinMode;
				const userPinData = parentPinMode.pin[device] ? parentPinMode.pin[device][platform] : "";
				if (!userPinData) throw new Error(errorConfig.parentPinError.description);
				if (userPinData !== pin) {
					throw new Error(errorConfig.parentPinError.description);
				}
			}
			
		}
		tokenInfo.childUid = input.childUid;
		_.pullAt(tokenInfo, "exp");
		_.pullAt(tokenInfo, "iss");
		_.pullAt(tokenInfo, "iat");
		_.pullAt(tokenInfo, "TncAgreement");
		return await tokenService.createAccessTokenAndRefreshToken(tokenInfo);
	} catch (error) {
		console.error("\n Error in getSubProfilesAccessToken Business/catch \n", error);
		if (error.message === errorConfig.subProfileDoesNotExist.description) throw new Error(errorConfig.subProfileDoesNotExist.description);
		if (error.message === errorConfig.parentPinError.description) throw new Error(errorConfig.parentPinError.description);
		if (error.message === errorConfig.parentPinModeError.description) throw new Error(errorConfig.parentPinModeError.description);
		if (error.status.message === errorConfig.invalidDeviceAndPlatformMissMatch.description) throw new Error(errorConfig.invalidDeviceAndPlatformMissMatch.description);
		throw new Error(errorConfig.getSubProfilesAccessToken.description);
	}

}
/**
 * @param {object} profile  Primary/Sub Profile
 * @returns {string} BirthDate
 */
function getBirthDate(profile = {}) {
	const { uid, childUid = null } = profile;
	if (childUid === null) return profile.profileData.BirthDate;
	const isPrimary = uid === childUid;
	if (isPrimary) return profile.profileData.BirthDate;
	return profile.BirthDate;
}

/**
 * @param {object} sourceProfileData 
 * @param {object} targetProfileData 
 * @param {object} headers
 * @param {string} headers.country 
 * @returns {{sourceIsKid: boolean, targetIsKid: boolean}} 
 */
async function checkSubProfileUserType(sourceProfileData, targetProfileData, headers = {}) {
	try {
		const { country= "NA" } = headers;
		const list = [sourceProfileData, targetProfileData];
		const [sourceIsKid, targetIsKid] = list
			.map(profile => getBirthDate(profile))
			.map(date => commonUtils.isKidProfile(date, country));
		return { sourceIsKid, targetIsKid };
	} catch (error) {
		console.error("Error in checkSubProfileUserType Catch", error);
		throw error;
	}
}
module.exports = getSubProfilesAccessToken;


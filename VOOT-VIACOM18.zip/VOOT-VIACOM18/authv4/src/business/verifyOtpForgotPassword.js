const { errorConfig,configuration } = require("../config");
const {userProfileService,userService,otpService} = require("../services");
const _ = require("lodash");
const { apiResponse} = require("../utils");
const jwt = require("jsonwebtoken");
const common = require("../utils/common");
const moment = require("moment");
const constant = require("../utils/constant/generic");
const { notificationService, kafkaService } = require("../services");
                                                                                                                                                      
module.exports = verifyOtpForgotPassword;

async function verifyOtpForgotPassword(input) {
	console.info(`AccountService verifyOtpForgotPassword() with parameter(s) input=${JSON.stringify(input)}`);
    
	let response;
	if (_.has(input, "email")) {
		response = await verifyOtpForEmailForgotFlow(input);//This Flow contain new template version as well as old
		return response;
	} else if (_.has(input, "mobile")) {
		response = await verifyOtpForMobileForgotFlow(input);
		return response;
	}
}
async function verifyOtpForEmailForgotFlow(input) {
	let userProfile,email,userRecord;
	try {
		if (_.has(input, "email")) {
			email = input.email;
			userRecord = await userService.getUserByEmail(email);
			if (!userRecord) return new Error(errorConfig.emailNotRegistered.description, errorConfig.emailNotRegistered.code);
		}
		// Get verifed user data from firestore
		userProfile= await userProfileService.getUserInformationByEmail(input.email);
		if (configuration.kafkaConfig.enable.isUpdateAuth && input.regionInfo &&
			((input.regionInfo.region !== userProfile.region) || (input.regionInfo.country !== userProfile.country))
		) { 
			//sending region notification into queue
			const regionNotificationObj = await notificationService.createRegionNotification(
				userProfile,
				_.get(input, "regionInfo", {})
			);
			kafkaService.pushEventToKafka(configuration.kafkaConfig.topic.updateAuthData, regionNotificationObj);
		}
		console.log("===============verifieUser==============", userProfile);
		console.log(configuration.Otp);
		if (configuration.Otp.isUserBlockEnableForVerifyOtp && userProfile && userProfile._system && userProfile._system.failedAttempt && userProfile._system.failedAttempt.forgotPassword) {
			const isUserBlocked = await otpService.isUserBlocked(userProfile, "forgotPassword", configuration.Otp.maxNumberOfWrongOtpAttempts, configuration.Otp.blockDurationForVerifyOtp);
			if (isUserBlocked) {
				let _system = { ...userProfile._system };
				if (_system.failedAttempt && _system.failedAttempt.forgotPassword && _system.failedAttempt.forgotPassword.lastUpdatedAt) {
					_system.failedAttempt.forgotPassword.lastUpdatedAt = moment();
				}
				console.log(`update status for user ${ userProfile.uid } and system will be`, _system);
				await userProfileService.updateUserInformation({ uid: userProfile.uid }, { loginStatus: constant.USER_STATUS.LOCKED, _system });
				throw { code: "user/locked" };
				// return new Error(errorConfig.userlocked.description, errorConfig.userlocked.code);
			}
		}
		// Verify OTP 
		const otpVerified = await otpService.verifyOtp(_.get(input, "otp"), userProfile, otpService.FORGOT_PASSWORD_EMAIL_REQUEST);

		if (!otpVerified) {
			return new Error(errorConfig.otpVerificationFailed, errorConfig.otpVerificationFailed.code);
		} else {
			// _.set(UnverifiedUser, '_system.'+OtpService.SIGNUP_REQUEST+'.isOtpVerify', true);
			//_.set(userData, 'profileData.IsFirstLogin', true);
			userProfile.uid = _.get(userRecord,"customClaims.customUid",_.get(userProfile,"uid"));
			const otpVerified = await common.DbTemplateforVerifyOtpForgetPassword(userProfile, otpService.FORGOT_PASSWORD_EMAIL_REQUEST, true, true);
			const _systemData= { forgotPasswordEmail: otpVerified };
			console.log("_systemData:", _systemData);
			const payload = {
				email: userRecord.email,
				uid: userProfile.uid
			};
			const token = await jwt.sign(payload, configuration.jwtForgotPassword.secret, { expiresIn: configuration.jwtForgotPassword.tokenexpiresin, issuer: configuration.jwtForgotPassword.issuer });
			let finalMessage = {
				isVerified: true,
				token: token
			};
    
			const results = await userProfileService.deleteField({ uid: userProfile.uid },{ $unset:{"_system":1,status:1}} );
        
			console.debug("===============results", results);
			return finalMessage;
            
		}

	} catch (error) {
		if (!error.code) {
			console.error("No Error Code in verifyOtpForgotPassword API", error);
			return error;
			// return reject(ApiResponse.error(errorUtility.requestFailed, 400));
		}
		switch (error.code) {
		case "otp/invalid-request":
		case "document/not-found":
			throw new Error(errorConfig.otpDataNotFound.description, errorConfig.otpDataNotFound.code);
		case "otp/expired":
			throw new Error(errorConfig.otpExpired.description, errorConfig.otpExpired.code);
		case "otp/invalid":{
			const newSystemData=await otpService.otpVerificationFailed( userProfile, "forgotPassword");
			await userProfileService.updateUserInformation({ uid: userProfile.uid },{ _system: newSystemData });
			throw new Error(errorConfig.otpVerificationFailed.description, errorConfig.otpVerificationFailed.code);
		}
		case "auth/user-not-found":
			throw new Error(errorConfig.emailNotRegistered.description, errorConfig.emailNotRegistered.code);
		case "user/locked":
			throw new Error(errorConfig.userlocked.description, errorConfig.userlocked.code);
		default:
			console.log("New Error Code, which is not handled in verifyOtpForgotPassword API: ", error.code);
			throw new Error(errorConfig.requestFailed, 400);
		}
	}
}
async function verifyOtpForMobileForgotFlow(input) {
	let userProfile;
	try {
		let mobile, finalMessage;
		mobile = input.countryCode + input.mobile;
		let userRecord = await userService.getUserByPhone(mobile);
		userRecord=userRecord[0];
		if (!userRecord) return apiResponse.error(errorConfig.mobileNotRegistered.description, errorConfig.mobileNotRegistered.code);
		// Get verifed user data from firestore
		userProfile = await userProfileService.getUserInformationByEmail(userRecord.email);
		if (configuration.kafkaConfig.enable.isUpdateAuth && input.regionInfo &&
			((input.regionInfo.region !== userProfile.region) || (input.regionInfo.country !== userProfile.country))) { 
			//sending region notification into queue
			const regionNotificationObj = await notificationService.createRegionNotification(
				userProfile,
				_.get(input, "regionInfo", {})
			);
			kafkaService.pushEventToKafka(configuration.kafkaConfig.topic.updateAuthData, regionNotificationObj);
		}
		console.log("===============verifieUser==============", userProfile);
		if (configuration.Otp.isUserBlockEnableForVerifyOtp && userProfile && userProfile._system && userProfile._system.failedAttempt && userProfile._system.failedAttempt.forgotPassword) {
			const isUserBlocked = await otpService.isUserBlocked(userProfile, "forgotPassword", configuration.Otp.maxNumberOfWrongOtpAttempts, configuration.Otp.blockDurationForVerifyOtp);
			if (isUserBlocked) {
				let _system = { ...userProfile._system };
				if (_system.failedAttempt && _system.failedAttempt.forgotPassword && _system.failedAttempt.forgotPassword.lastUpdatedAt) {
					_system.failedAttempt.forgotPassword.lastUpdatedAt = moment();
				}
				await userProfileService.updateUserInformation({ uid: userProfile.uid }, { loginStatus: constant.USER_STATUS.LOCKED, _system });
				throw { code: "user/locked" };
				// return new Error(errorConfig.userlocked.description, errorConfig.userlocked.code);
			}
		}
		// Verify OTP 
		const otpVerified = await otpService.verifyOtp(input.otp, userProfile, otpService.FORGOT_PASSWORD_REQUEST);
		if (!otpVerified) {
			return apiResponse.error(errorConfig.otpVerificationFailed.description, errorConfig.otpVerificationFailed.code);
		} else {
			const otpVerified = await common.DbTemplateforVerifyOtpForgetPassword(userProfile, otpService.FORGOT_PASSWORD_REQUEST, true, true);
			const _systemData = { forgotPasswordMobile: otpVerified };
			console.log("_systemData:", _systemData);
			const update = await userProfileService.updateUserInformation({ "uid": userRecord.uid }, { _system: _systemData });
			console.log("update or not",update);
			const payload = {
				email: userRecord.email,
				uid: userProfile.uid
			};
			const token = await jwt.sign(payload, configuration.jwtForgotPassword.secret, { expiresIn: configuration.jwtForgotPassword.tokenexpiresin, issuer: configuration.jwtForgotPassword.issuer });
			finalMessage = {
				isVerified: true,
				token: token
			};
			const results = await userProfileService.deleteField({ uid: userProfile.uid },{  $set: { loginStatus: constant.USER_STATUS.ACTIVE },$unset:{"_system":1,"status":1}} );
			console.log("===============results", results);
			return apiResponse.success(finalMessage);
		}

	} catch (error) {
		if (!error.code) {
			console.error("No Error Code in verifyOtpForgotPassword API", error);
			return apiResponse.error(errorConfig.requestFailed, 400);
		}
		switch (error.code) {
		case "otp/invalid-request":
		case "document/not-found":
			return apiResponse.error(errorConfig.otpDataNotFound.description, errorConfig.otpDataNotFound.code);
		case "otp/expired":
			return apiResponse.error(errorConfig.otpExpired.description, errorConfig.otpExpired.code);
		case "otp/invalid": {
			const newSystemData=await otpService.otpVerificationFailed(userProfile, "forgotPassword");
			await userProfileService.updateUserInformation({ uid: userProfile.uid },{ _system: newSystemData });
			return apiResponse.error(errorConfig.otpVerificationFailed.description, errorConfig.otpVerificationFailed.code);
		}
		case "auth/user-not-found":
			return apiResponse.error(errorConfig.mobileNotRegistered.description, errorConfig.mobileNotRegistered.code);
		case "user/locked":
			return apiResponse.error(errorConfig.userlocked.description, errorConfig.userlocked.code);
		default:
			console.log("New Error Code, which is not handled in verifyOtpForgotPassword API: ", error.code);
			return apiResponse.error(errorConfig.requestFailed, 400);
		}
	}



}

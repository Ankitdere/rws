const { errorConfig } = require("../config");
const {userProfileService,userService,redisService,kalturaService,kafkaService,auditLogNotificationservice } = require("../services");
const _ = require("lodash");
const { apiResponse, generateHash } = require("../utils");
const randomId = require("randomstring");
const  firebaseHash= require("../utils").firebaseHash;
const moment =require("moment");
const configuration = require("../config/configuration");
const commonUtil = require("../utils").common;
const socialLogin = require("./socialLogin");
const kalturaBL = require("./kalturaBL");
const generic = require("../utils/constant/generic");
module.exports = changePasswordWithLogin;

async function changePasswordWithLogin(input,tokenInfo, auditObj) {
	console.debug(`AccountService.changePasswordWithLoginModel() with parameter(s) input=${JSON.stringify(input)}`);
	let email, uId, isLoggedIn=true;
	let auditValue={},notificationObj;
	try {
		email = _.get(tokenInfo, "email");
		if (_.isEmpty(email))
			return apiResponse.error(errorConfig.cantChangePassword.description,errorConfig.cantChangePassword.code);
		// eslint-disable-next-line no-undef
		let temp = await Promise.all([userProfileService.getUserInformationByEmail(email), userService.getAllUserRecordsByEmail(email)]);
		let userProfile = temp[0];
		let userAuth = temp[1];           
		if (!_.has(userAuth, "status")) {
			if(userAuth.length > 0){
				userAuth = await commonUtil.getUserAuthPasswordProvider(userAuth);
			}
			let { passwordHash, passwordSalt } = userAuth;
			if (!_.isEmpty(passwordHash) && !_.isEmpty(passwordSalt)) {
				isLoggedIn = await firebaseHash(input.oldPassword, passwordSalt, passwordHash);
			} // } else {
			//     isLoggedIn = await authenticateUserWithLegacy(userAuth, authData.password);
			// }
			if (!isLoggedIn && isLoggedIn == false)
				throw { code: "auth/wrong-password" };
		}
		uId =  _.get(userAuth,"customClaims.customUid",_.get(tokenInfo,"uid"));
		let salt = randomId.generate({
			length: 8,
			charset: "alphanumeric"
		});
		let passwordHash = await generateHash(input.newPassword, salt);
		//not keeping password details in audit
		auditValue.from = generic.PASSWORD_CHANGE_AUDIT.FROM;
		auditValue.to = generic.PASSWORD_CHANGE_AUDIT.TO;
		auditValue.uid = uId;
		let updateResult = userService.updateOrInsertUser({ "uid": _.get(userAuth,"uid",_.get(userProfile,"uid")) }, { "passwordHash": passwordHash, "passwordSalt": salt });
		//add audit log notification
		notificationObj = await auditLogNotificationservice.getAuditNotificationObj(auditObj,"update_password",auditValue,updateResult);
		console.log("before push",notificationObj);
		if(configuration.kafkaConfig.enable.audit){
			kafkaService.pushEventToKafka(configuration.kafkaConfig.topic.audit_log, notificationObj);
		}
		try{
			await redisService.saveUserIntoRedis(uId, moment().unix());
		}catch(err){
			console.log("Redis Unable to Set Value",err);
		}
		userProfileService.deleteField({ uid: uId },{ $unset:{"_system":1},updatedAt:moment().utcOffset(+530).unix()} );
		const kalturaUserLoginResult = await kalturaBL.doKalturaLogin(input, userAuth, userProfile);
		const ks = kalturaUserLoginResult.ks;
		console.debug("Kaltur login res", ks);
		const kalturaRevokefunction = await kalturaService.revokeKs(ks);
		console.debug("Kaltur revok res", kalturaRevokefunction);

		let loginInput = await checkUserType(email,input);
		let logInput = JSON.stringify(loginInput);
		let lInput = JSON.parse(logInput);
		// const loginresult = await login(lInput);
            
		return socialLogin.doLoginAndSignUp(lInput, userAuth, userAuth, uId);

           
	} catch (error) {
		console.error(error);
		if (error.message == errorConfig.invalidAccessToken.description)
			throw new Error(apiResponse.error(errorConfig.invalidAccessToken.description, errorConfig.invalidAccessToken.code));

		if (error.message == errorConfig.cantChangePassword.description)
			throw new Error(apiResponse.error(errorConfig.cantChangePassword.description, errorConfig.cantChangePassword.code));

		if (error.code == "auth/wrong-password") {
			throw apiResponse.error(errorConfig.wrongPassword.description, errorConfig.wrongPassword.code);
		}
		throw new Error(apiResponse.error(errorConfig.requestFailed, 400));
	}
}
async function checkUserType(email,input) {
	let loginInput;        
	loginInput = {
		type: "traditional",
		deviceId: input.deviceId,
		deviceBrand: input.deviceBrand,
		data: {
			email: email,
			password: input.newPassword
		}
	};
	return loginInput;
}

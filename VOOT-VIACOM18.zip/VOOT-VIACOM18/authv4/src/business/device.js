module.exports = {
	createOne: createOne
};

// Imports
const To = require("../utils/to");
const DeviceService = require("../services/device");

/**
 * Create one device
 * @param device 
 * @param params 
 * @param flags 
 */
async function createOne(device, params, flags) {
	try {
		// Initialize
		let error;

		// Create
		[error] = await To(DeviceService.createOne(device, params, flags));
		if (error) {
			console.error(error);
		}

		// Response
		// eslint-disable-next-line no-undef
		return Promise.resolve({ code: 200, message: "Success" });
	} catch (error) {
		// eslint-disable-next-line no-undef
		return Promise.resolve({ code: 200, message: "Success" });
	}
}
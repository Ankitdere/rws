"use strict";

module.exports = login;
const userService = require("../services").userService;
const userProfileService = require("../services").userProfileService;
const { otpService } = require("../services");
const { googleLogin, fbLogin, appleLogin } = require("./socialLogin");
const firebaseHash = require("../utils").firebaseHash;
const { getSha1Hash, getSha256Hash } = require("../utils").legacyHash;
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");
const moment = require("moment");
const apiResponse = require("../utils/apiResponse");
const config = require("../config").configuration;
const socialLogin = require("./socialLogin");
const commonUtil = require("../utils").common;
const notificationService = require("../services/notificationService");
const constant = require("../utils/constant/generic");
const {doAmazonLogin} = require("./amazonLogin");
async function login(input,auditObj) {
	let response, notificationObj;
	let metaData = {};
	metaData = await notificationService.createMetaDataForRecon("login");
	console.log("metaData", metaData);
	notificationObj = await notificationService.reconIntitialNotificationObj(input, metaData);
	notificationObj = await notificationService.updateNotificationStage(notificationObj, true, "validation", null, "success");
	switch (input.type) {
	case "traditional":
		response = await doTraditionalLogin(input,notificationObj);
		break;
	case "facebook":
		response = await fbLogin(input);
		break;
	case "google":
		response = await googleLogin(input);
		break;
	case "apple":
		response = await appleLogin(input);
		break;
	case "mobile":
		response = await doMobileLogin(input,notificationObj);
		break;
	case "amazon":
		response = await doAmazonLogin(input,auditObj);
		break;
	}
	return response;
}

async function doTraditionalLogin(input,notificationObj) {
	let userProfile;
	try {
		// TODO Error : 'auth/wrong-password', 'auth/too-many-requests'
		let authData  = input.data;
		let userAuth = await  userService.getAllUserRecordsByEmail(authData.email);
		console.debug("User auth record: ", JSON.stringify(userAuth));
		if(_.has(userAuth,"status"))
		{
			//notification for userauth sync:
			let data = {};
			data.initialAction = "sync";
			data.currentAction = "sync";
			notificationObj = await notificationService.updateReconInfo(notificationObj, data);
			await notificationService.updateNotificationStage(notificationObj, true, "sync", data, "success");
			//For Future reference: 28-09-2021
			// if (config.kafkaConfig.enable.recon) {
			//await kafkaService.pushEventToKafka(config.kafkaConfig.topic.recon, notificationObj)
			//}
			return apiResponse.error(errorConfig.userDoesNotExist.description, errorConfig.userDoesNotExist.code);

		}
		if (userAuth.length > 0) {
			//TODO :Need to Discuss With Team 
			userAuth = await commonUtil.getUserAuthPasswordProvider(userAuth, true);
			// userAuth = await commonUtil.getUserAuthPasswordProvider(userAuth,true)
		}
		// userAuth = _.isEmpty(userAuth[0])?userAuth:userAuth[0];
		console.debug("userAuth------ ", JSON.stringify(userAuth));
		let isLoggedIn = false;
		authData.password = _.trim(authData.password);
		// TODO: userRecord.passwordHash === undefined // Not handlling in V4
		let { passwordHash, passwordSalt } = userAuth;
		if (!_.isEmpty(passwordHash) && !_.isEmpty(passwordSalt)) {
			isLoggedIn = await firebaseHash(authData.password, passwordSalt, passwordHash);
		} else {
			isLoggedIn = await authenticateUserWithLegacy(userAuth, authData.password);
		}
        
		if (!isLoggedIn) {
			userProfile = await userProfileService.getUserInformationByEmail(authData.email);
			if (_.has(userProfile, "status")) {
				return apiResponse.error(errorConfig.wrongPassword.description, errorConfig.wrongPassword.code);
			}
			isLoggedIn = authenticateWithResetPassword(userProfile, authData.password);
			_.get(userAuth, "customClaims.customUid", "uid");
			//This Code block the user if user hit incorrect Password more than 5 time and unset if it is login Again via login 
			if (config.LoginConfigurations.isLoginMaxAttemptsEnable) {
               
				if (userProfile._system && userProfile._system!=null &&userProfile._system.failedAttempt !== undefined && userProfile._system.failedAttempt.loginAttemptService != null) {
					let blockStatus= await otpService.isUserBlocked(userProfile,"loginAttemptService", config.LoginConfigurations.maxNumberOfWrongAttempt , config.LoginConfigurations.blockDurationLogin );
					console.log("status",blockStatus);
					if (blockStatus) {
						let _system = { ...userProfile._system };
						if (_system.failedAttempt && _system.failedAttempt.loginAttemptService && _system.failedAttempt.loginAttemptService.lastUpdatedAt) {
							_system.failedAttempt.loginAttemptService.lastUpdatedAt = moment();
						}
						console.log(`update status for user ${ userProfile.uid } and system will be`, _system);
						await userProfileService.updateUserInformation({ uid: userProfile.uid }, { loginStatus: constant.USER_STATUS.LOCKED, _system });
						throw ({ code: "yourAccountBlocked" });
						// const results = await userProfileService.updateUserInformation({ 'uid': _.get(userProfile, 'uid') }, loginAttemptSystem);
					}
				}
          
				//return apiResponse.error(errorConfig.wrongPassword.description, errorConfig.wrongPassword.code);
			}
			throw({code:"auth/wrong-password"});
		}
		userAuth = _.isEmpty(userAuth[0]) ? userAuth : userAuth[0];
		let userId = _.get(userAuth, "uid");
		return socialLogin.doLoginAndSignUp(input, userAuth, userAuth, userId);
	} catch (error) {
		console.error("Auth Service Login Error: ", error);
		if (!error || !error.code)
			return apiResponse.error(errorConfig.requestFailed, 400);
		switch (error.code) {
		case "auth/wrong-password":
			if(config.LoginConfigurations.isLoginMaxAttemptsEnable){
				const newSystemData=await otpService.otpVerificationFailed( userProfile, "loginAttemptService");
				await userProfileService.updateUserInformation({ uid: userProfile.uid },{ _system: newSystemData });
			}
			return apiResponse.error(errorConfig.wrongPassword.description, errorConfig.wrongPassword.code);
		case "auth/user-not-found":
			return apiResponse.error(errorConfig.userDoesNotExist.description, errorConfig.userDoesNotExist.code);
		case "auth/invalid-email":
			return apiResponse.error(errorConfig.invalidEmail.description, errorConfig.invalidEmail.code);
		case "auth/invalid-uid":
			return apiResponse.error(errorConfig.invalidUid.description, errorConfig.invalidUid.code);
		case "auth/too-many-requests":
			return apiResponse.error(errorConfig.tooManyAttempts.description, errorConfig.tooManyAttempts.code);
		case "maxPasswordAttempt":
			return apiResponse.error(errorConfig.maxPasswordAttempt.description, errorConfig.maxPasswordAttempt.code);
		case "yourAccountBlocked":
			return apiResponse.error(errorConfig.yourAccountBlocked.description, errorConfig.yourAccountBlocked.code);
		case errorConfig.errorCodes.USER_WRONG_USERNAME_OR_PASSWORD.code:
			return apiResponse.error(errorConfig.kalturaUserWrongUsernameOrPassword.description, errorConfig.kalturaUserWrongUsernameOrPassword.code);
		case errorConfig.errorCodes.INSIDE_LOCK_TIME.code:
			return apiResponse.error(errorConfig.kalturaInsideLockTime.description, errorConfig.kalturaInsideLockTime.code);
		default:
			throw apiResponse.error(errorConfig.requestFailed, 400);

		}

	}
}

async function authenticateUserWithLegacy(userAuth, password) {
	const customClaim = _.get(userAuth, "customClaims", {});
	const passwordClaim = _.get(customClaim, "password", undefined);
	if (!passwordClaim)
		return false;
	let hashedPassword = "";
	switch (customClaim.source) {
	case "lr":
		hashedPassword = await getSha1Hash(password);
		break;
	case "sql":
		hashedPassword = await getSha256Hash(password);
		break;
	default:
		break;
	}
	// TODO : Update the password if length is greater than 6  // await Firebase.updateUserPassword(userRecord, password);
	return passwordClaim === hashedPassword;
}

function authenticateWithResetPassword(userProfile, password) {
	let resetPassword = _.get(userProfile, "_system.resetPassword");
	return _.isEqual(password, resetPassword);
}
async function doMobileLogin(input,notificationObj) {
	let userDetails;
	try {
		let authData = input.data;
		console.log("Inside the login with the mobile number===", authData.mobile);
		const mobile = authData.countryCode + authData.mobile;
		let userAuth = await userService.getUserByPhone(mobile);

		if (_.has(userAuth, "status")){
			let data = {};
			data.initialAction = "sync";
			data.currentAction = "sync";
			notificationObj = await notificationService.updateReconInfo(notificationObj,data);
			await notificationService.updateNotificationStage(notificationObj, true, "sync",data, "success");
			//await kafkaService.pushEventToKafka(config.kafkaConfig.topic.recon, notificationObj)
			return apiResponse.error(errorConfig.mobileNotRegistered.description, errorConfig.mobileNotRegistered.code);
		}
		let isLoggedIn = false;
		userAuth = _.isEmpty(userAuth[0]) ? userAuth : userAuth[0];
		authData.password = _.trim(authData.password);
		// // TODO: userAuth.passwordHash === undefined // Not handlling in V4
		let { passwordHash, passwordSalt } = userAuth;
		if (!_.isEmpty(passwordHash) && !_.isEmpty(passwordSalt)) {
			isLoggedIn = await firebaseHash(authData.password, passwordSalt, passwordHash);
		} else {
			isLoggedIn = await authenticateUserWithLegacy(userAuth, authData.password);
		}
		//check if login attempts failed more than 5 times
		if (!isLoggedIn) {
           
			let uId = _.get(userAuth, "uid");
			userDetails = await userProfileService.getUserInformationById(uId);
			console.log("userDetails", userDetails);
			if (config.LoginConfigurations.isLoginMaxAttemptsEnable) {
				if (userDetails._system && userDetails._system!=null && userDetails._system.failedAttempt !== undefined && userDetails._system.failedAttempt.loginAttemptService != null) {
					let blockStatus= await otpService.isUserBlocked(userDetails,"loginAttemptService",  config.LoginConfigurations.maxNumberOfWrongAttempt , config.LoginConfigurations.blockDurationLogin);
					console.log("status",blockStatus);
					if (blockStatus) {
						let _system = { ...userDetails._system };
						if (_system.failedAttempt && _system.failedAttempt.loginAttemptService && _system.failedAttempt.loginAttemptService.lastUpdatedAt) {
							_system.failedAttempt.loginAttemptService.lastUpdatedAt = moment();
						}
						console.log(`update status for user ${ userDetails.uid } and system will be`, _system);
						await userProfileService.updateUserInformation({ uid: userDetails.uid }, { loginStatus: constant.USER_STATUS.LOCKED, _system });
						throw ({ code: "yourAccountBlocked" });
						// const results = await userProfileService.updateUserInformation({ 'uid': _.get(userProfile, 'uid') }, loginAttemptSystem);
					}
				}
			}
			throw({code:"auth/wrong-password"});
			// return apiResponse.error(errorConfig.wrongPassword.description, errorConfig.wrongPassword.code);
		}
		let userId = _.get(userAuth, "uid");
      
        
		return socialLogin.doLoginAndSignUp(input, userAuth, userAuth, userId);
	} catch (error) {
		console.error("Auth Service Login Error: ", error, error.stack);
		if (!error || !error.code)
			return apiResponse.error(errorConfig.requestFailed, 400);
		switch (error.code) {
		case "auth/wrong-password":
			if(config.LoginConfigurations.isLoginMaxAttemptsEnable){
				const newSystemData=await otpService.otpVerificationFailed( userDetails, "loginAttemptService");
				await userProfileService.updateUserInformation({ uid: userDetails.uid },{ _system: newSystemData });
			}
			return apiResponse.error(errorConfig.wrongPassword.description, errorConfig.wrongPassword.code);
		case "auth/user-not-found":
			return apiResponse.error(errorConfig.userDoesNotExist.description, errorConfig.userDoesNotExist.code);
		case "auth/invalid-email":
			return apiResponse.error(errorConfig.invalidEmail.description, errorConfig.invalidEmail.code);
		case "auth/invalid-uid":
			return apiResponse.error(errorConfig.invalidUid.description, errorConfig.invalidUid.code);
		case "auth/too-many-requests":
			return apiResponse.error(errorConfig.tooManyAttempts.description, errorConfig.tooManyAttempts.code);
		case "maxPasswordAttempt":
			return apiResponse.error(errorConfig.maxPasswordAttempt.description, errorConfig.maxPasswordAttempt.code);
		case "yourAccountBlocked":
			return apiResponse.error(errorConfig.yourAccountBlocked.description, errorConfig.yourAccountBlocked.code);
		case errorConfig.errorCodes.USER_WRONG_USERNAME_OR_PASSWORD.code:
			return apiResponse.error(errorConfig.kalturaUserWrongUsernameOrPassword.description, errorConfig.kalturaUserWrongUsernameOrPassword.code);
		case errorConfig.errorCodes.INSIDE_LOCK_TIME.code:
			return apiResponse.error(errorConfig.kalturaInsideLockTime.description, errorConfig.kalturaInsideLockTime.code);
		default:
			throw apiResponse.error(errorConfig.requestFailed, 400);

		}

	}
}








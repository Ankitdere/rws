"use strict";

module.exports = signUp;
const { userService, userProfileService, unverifiedUser } = require("../services");
const responseFormat = require("../format").responseFormat;
const mongoUser = require("../format").mongoUser;
const mongoUserProfile = require("../format").mongoUserProfile;
const _ = require("lodash");
const { isPasswordUser } = require("../utils").common;
const { errorConfig, configuration } = require("../config");
const kalturaBL = require("./kalturaBL");
const ApiResponse = require("../utils").apiResponse;
const { kafkaService, notificationService } = require("../services");

async function signUp(input) {
	try {
		let signUpResponse;

		switch (input.type) {
		case "traditional":
			signUpResponse = await doTraditionalSignUp(input);
			break;
		case "mobile":
			signUpResponse = await doMobileSignUp(input);
			break;
		}

		return signUpResponse;
	} catch (err) {
		throw err;
	}
}


async function doTraditionalSignUp(input) {
	try{
		let customUid, userAuth, userRecord, userData, prevUserDoc;
		userData =  prevUserDoc = await userProfileService.getUserInformationByEmail(_.get(input, "data.email"));
		if (!_.has(prevUserDoc, "status")) {
			prevUserDoc = responseFormat.responseUpdateProfileData(prevUserDoc);
			customUid = _.get(prevUserDoc, "profileData.uid", _.get(prevUserDoc, "profileData.Uid", _.get(prevUserDoc, "uid")));
			console.log("prevUserDoc %j", JSON.stringify(prevUserDoc));
			userRecord = await userProfileService.getUserInformationById(customUid);
			userRecord = responseFormat.responseUpdateProfileData(userRecord);
			userRecord.uid = customUid;
			//console.log("userRecord %j", JSON.stringify(userRecord));
		}
		userAuth = await userService.getUserByEmail(_.get(input, "data.email"));
		console.debug("UserAuth Data", JSON.stringify(userAuth));
		if (_.has(userAuth, "status")) {
			let userAuthMongo = await mongoUser.initFormatTraditionalUser(input);
			let userProfileMongo;
			// let userProfileMongo = mongoUserProfile.initFormatUserProfileTraditional(userAuthMongo, _.get(input, 'data', {}), input.countryCode);
			if(_.has(userData,"status")){
				userProfileMongo = mongoUserProfile.initFormatUserProfileTraditional(userAuthMongo, _.get(input, "data", {}), input.countryCode);
			}else{
				userAuthMongo.customClaims.customUid = userData.uid || userAuthMongo.uid;
				userProfileMongo = userData;
			}
			console.debug("User Profile To update",userProfileMongo);
			// eslint-disable-next-line no-undef
			await Promise.all([userService.insertUser(userAuthMongo), userProfileService.updateUserInformation({uid: userAuthMongo.uid},userProfileMongo)]);
			if (configuration.kafkaConfig.enable.isUpdateAuth && input.regionInfo
				&& ((input.regionInfo.region !== userProfileMongo.region)
					|| (input.regionInfo.country !== userProfileMongo.country))
			) { 
				//sending region notification into queue
				const regionNotificationObj = await notificationService.createRegionNotification(
					userAuthMongo,
					_.get(input, "regionInfo", {})
				);
				kafkaService.pushEventToKafka(configuration.kafkaConfig.topic.updateAuthData, regionNotificationObj);
			}
			let kalthuraLoginResponse = await kalturaBL.kalturaRegistration(_.get(userAuthMongo, "email"), _.get(userAuthMongo, "uid"), input, userAuthMongo, userProfileMongo);
			let finalOutput = await responseFormat.v3SignUpResponse(userAuthMongo, userProfileMongo, _.get(input, "deviceId"), kalthuraLoginResponse, input);
			return finalOutput;
    
		}
		let providerData = _.get(userAuth, "providerData", []);
		if (!isPasswordUser(providerData) && _.get(userRecord, "uid")) {
			let userAuthMongo = await mongoUser.updateFormatTraditionalUser(userAuth, input);
            
			if(!_.has(prevUserDoc,"status")){
				if (_.isEmpty(userData.email)) {
					userData.email = input.data.email;
					userProfileService.updateOrInsertUser({uid:customUid},userData);    
				}
			}
			userAuthMongo.customClaims = { customUid: customUid } ;
			await userService.updateOrInsertUser({ uid: _.get(userAuth, "uid") }, userAuthMongo);
			userAuthMongo.uid = customUid;
			if (configuration.kafkaConfig.enable.isUpdateAuth && input.regionInfo &&
				((input.regionInfo.region !== userData.region) || (input.regionInfo.country !== userData.country))
			) { 
				const regionNotificationObj = await notificationService.createRegionNotification(
					userData,
					_.get(input, "regionInfo", {})
				);
				kafkaService.pushEventToKafka(configuration.kafkaConfig.topic.updateAuthData, regionNotificationObj);
			}
			let kalthuraLoginResponse = await kalturaBL.doKalturaLogin(input, userAuth, userRecord);
			let finalOutput = await responseFormat.v3SignUpResponse(userAuthMongo, userRecord, _.get(input, "deviceId"), kalthuraLoginResponse, input);
			return finalOutput;
		} else {
			throw new Error(errorConfig.emailAlreadyRegistered.code);
		}
	}catch(err){
		console.error("Error in doTraditionalSignUp", err,err.stack);
		throw err;
	}
    
}

async function doMobileSignUp(input) {
	const mobile = input.data.countryCode + input.data.mobile;
	let prevUserDoc = await userService.getUserByPhone(mobile);
	try {
		if (!_.has(prevUserDoc, "status")) {//user Exist in Mongo Auth
			return ApiResponse.error(errorConfig.mobileAlreadyExist.description, errorConfig.mobileAlreadyExist.code);
		} else if (_.has(prevUserDoc, "status")) {// User not Exist in Mongo Auth
			const userSignUpData = await unverifiedUser.getUserInformationByMobileCountryCode(input.data.mobile, input.data.countryCode);
			if (userSignUpData.mobile == undefined) return ApiResponse.error(errorConfig.otpDataNotFound.description, errorConfig.otpDataNotFound.code);
			if (userSignUpData.isOtpVerify == false) return ApiResponse.error(errorConfig.mobileNotVerify.description, errorConfig.mobileNotVerify.code);
			userSignUpData.password = input.data.password;
			userSignUpData.mobile = mobile;
			if (input.data.email) userSignUpData.email = input.data.email; // use passed parameter email
			let userAuthMongo = await mongoUser.initFormatMobileUser(userSignUpData, input);
			let userProfileMongo = mongoUserProfile.initFormatUserProfileTraditional(userAuthMongo, _.get(input, "data", {}), input.data.countryCode);
			let userCreated = await userService.insertUser(userAuthMongo);
			let userAuthCreated = await userProfileService.updateUserInformation({ uid: _.get(userAuthMongo, "uid") }, userProfileMongo);
			if ((_.has(userAuthCreated, "status")) || (_.has(userCreated, "status"))) {
				return ApiResponse.error(userAuthCreated.message, userAuthCreated.status);
			}
			if (configuration.kafkaConfig.enable.isUpdateAuth && input.regionInfo &&
				((input.regionInfo.region !== userAuthCreated.region) || (input.regionInfo.country !== userAuthCreated.country))
			) { 
				const regionNotificationObj = await notificationService.createRegionNotification(
					userAuthCreated,
					_.get(input, "regionInfo", {})
				);
				kafkaService.pushEventToKafka(configuration.kafkaConfig.topic.updateAuthData, regionNotificationObj);
			}
			let kalthuraLoginResponse = await kalturaBL.kalturaRegistration(_.get(userAuthMongo, "email"), _.get(userAuthMongo, "uid"), input, userAuthMongo, userProfileMongo);
			let finalOutput = await responseFormat.v3SignUpResponse(userAuthMongo, userProfileMongo, _.get(input, "deviceId"), kalthuraLoginResponse, input);
			return finalOutput;

		}
	} catch (err) {
		throw err;
	}
}

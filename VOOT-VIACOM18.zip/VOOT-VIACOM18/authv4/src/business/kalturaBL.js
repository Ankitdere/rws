"use strict";
const _ = require("lodash");
const kalturaService = require("../services").kalturaService;
const kalturaErrorConfig = require("../config").errorConfig;
const { configuration } = require("../config");
const mixpanelService = require("../services/mixpanelService");
const mixPanelConfig = require("../config/mixPanelConfig");
const kafkaService = require("../services/kafkaService");
const notificationService = require("../services/notificationService");
let notificationObj;
module.exports = {
	getKalturaExternalIdAndLogin,
	updatePasswordAndLogin,
	doKalturaLogin,
	kalturaRegistration
};


async function getKalturaExternalIdAndLogin(user, udid) {
	console.debug("Inside the _getKalturaExternalIdAndLogin function");
	let email = _.get(user, "email", _.get(user, "Email"));
	let uid = _.get(user, "uid", _.get(user, "Uid"));
	console.debug("email:-", email, "uId:-", uid, "deviceId:-", udid);
	try {
		const kalturaUserData = await kalturaService.getUserByUsernameOrExternalIdNew(email, uid);
		if (_.has(kalturaUserData, "externalId")) {

			return await kalturaService.login(_.get(kalturaUserData, "username"), _.get(kalturaUserData, "externalId"), udid);
		}
	} catch (err) {
		throw err;
	}
	return false;
}


// Attempt MultiRequest
async function updatePasswordAndLogin(user, udid) {
	console.debug("Inside the _getKalturaExternalIdAndLogin function");
	let email = _.get(user, "email", _.get(user, "Email"));
	let uid = _.get(user, "uid", _.get(user, "Uid"));
	console.debug("email:-", email, "uId:-", uid, "deviceId:-", udid);
	try {
		await kalturaService.getUserByUsernameOrExternalIdNew(email, uid);
		const kalturaUserResponse = await kalturaService.updatePasswordAndLogin(user, udid);
		mixpanelService(mixPanelConfig.externalCallKaltura + "UpdatePasswordAndLogin" + mixPanelConfig.success, { email: email, uid: uid, distinct_id: email, input: user }, email);
		console.debug("Kaltur external id :kal", kalturaUserResponse);
		return kalturaUserResponse;
		// if (_.has(kalturaUserData, 'externalId')) {

		// return await kalturaService.login(_.get(kalturaUserData, 'username'), _.get(kalturaUserData, 'externalId'), udid);
	} catch (err) {
		mixpanelService(mixPanelConfig.externalCallKaltura + "UpdatePasswordAndLogin" + mixPanelConfig.error, { email: email, uid: uid, distinct_id: email, input: user, error: err }, email);
		throw err;
	}
}


async function doKalturaLogin(input, user, userDetails, uniqueId = "", mixpanelPartnerFlag = true) {
	console.debug("loginKalturaAndCreateResponse with parameters userDetails", userDetails);
	try {
		console.debug("Reached Without Kaltura login in Auth Service");
		const kalturaLoginResponse = await kalturalogin(input, user, uniqueId, mixpanelPartnerFlag);
		if (_.has(kalturaLoginResponse, "result.error.code"))
			throw kalturaLoginResponse;
		return kalturaLoginResponse;
	} catch (error) {
		switch (_.get(error, "result.error.code", _.get(error, "code"))) {
		case kalturaErrorConfig.errorCodes.USER_DOES_NOT_EXIST.code: // Kaltura user does not exists, register as new user
			console.debug("Kaltura user does not exist, registering as new");
			return kalturaRegistration(user.email, user.uid, input, user, userDetails);
		case kalturaErrorConfig.errorCodes.INSIDE_LOCK_TIME.code: // Kaltura user does not exists, register as new user
			throw { code: kalturaErrorConfig.errorCodes.INSIDE_LOCK_TIME.code, message: kalturaErrorConfig.errorCodes.INSIDE_LOCK_TIME.message };
		default:
			console.error("unknown error in kaltura login: %j", error);
			throw error;
		}
	}
}

async function kalturalogin(input, user, uniqueId = "", mixpanelPartnerFlag = true) {
	let distict_id;
	try {
		console.debug("kalturalogin Input: ", input);
		console.debug("kalturalogin User: ", user);
		let kalturaUserLoginResult;
		let deviceId=_.get(input,"deviceId");
		//check for Windows NT 6.3 to uid             
		if (input.deviceBrand.toLowerCase().trim() == "pc/mac") {
			deviceId = _.get(user, "uid", _.get(user, "Uid"));
			console.log("update deviceId Windows NT 6.3 to uid", deviceId);
		}
		const device = await kalturaService.setupHouseholdDevice(deviceId, input.deviceBrand); // Not an API but a promise, do we need to await here?
		console.debug("====== Device ==========: ", device);
		if (input.deviceBrand.toLowerCase().trim() == "pc/mac") {
			device.udid = _.get(user, "uid", _.get(user, "Uid"));
			console.debug("update deviceId Windows NT 6.3 to uid", device.udid);
		}
		let uid = _.get(user, "uid", _.get(user, "Uid"));
		let email = _.get(user, "email", _.get(user, "Email", `${uid}@voot.com`));
		try {
			console.debug("email:-", email, "uId:-", uid, "deviceId:-", device.udid);
			kalturaUserLoginResult = await kalturaService.login(email, uid, device.udid);
			console.debug("kaltura login response-:", kalturaUserLoginResult);
			if (mixpanelPartnerFlag == true) {
				distict_id = email;
			} else {
				distict_id = uniqueId ? uniqueId : uid;
			}
			mixpanelService(mixPanelConfig.externalCallKaltura + "Login" + mixPanelConfig.success, { email: email, uid: uid, distinct_id: distict_id }, distict_id, null, null, mixpanelPartnerFlag);
		} catch (error) {
			console.error("kaltura login error 1:", error);
			if (mixpanelPartnerFlag == true) {
				distict_id = email;
			} else {
				distict_id = uniqueId ? uniqueId : uid;
			}
			mixpanelService(mixPanelConfig.externalCallKaltura + "Login" + mixPanelConfig.error, { email: email, uid: uid, distinct_id: distict_id, input: input, error: error }, distict_id, null, null, mixpanelPartnerFlag);
			if (!_.has(error.result.error, "code")) {
				return error;
			}
			switch (_.get(error.result.error, "code")) {
			case "2000": throw error;
			case "2015": throw error;
			case "1011":
				//  kalturaUserLoginResult = await getKalturaExternalIdAndLogin(user, device.udid);
				await updatePasswordAndLogin(user, device.udid);
				kalturaUserLoginResult = await kalturaService.login(email, uid, device.udid);  //VOOTDESK-1578
				break;
			}
		}
		if (kalturaUserLoginResult.result.user.householdId !== 0) {
			console.debug("add device in houseHold:", kalturaUserLoginResult.result.user.householdId);
			await kalturaService.addDeviceToUserHousehold(device, kalturaUserLoginResult.result, kalturaUserLoginResult.result.user.householdId, uid, email); // not waiting for response
		}
		const kalturaAppTokenResponse = await kalturaService.getAppToken(kalturaUserLoginResult.result.loginSession.ks);
		const v3kathuraResponse = {
			ks: kalturaUserLoginResult.result.loginSession.ks,
			kUserId: kalturaUserLoginResult.result.user.id,
			kTokenId: kalturaAppTokenResponse.result.id,
			kToken: kalturaAppTokenResponse.result.token,
			householdId: kalturaUserLoginResult.result.user.householdId,
		};
		return v3kathuraResponse;
	}
	catch (error) {
		console.error("Error in kaltura login:", error);
		//add notification for username and password is not correct error
		if(_.get(error.result.error, "code")=="1011"){
			let metaData = {};
			let data = {};
			data.initialAction = "kaltura";
			data.currentAction = "kaltura";
			metaData = await notificationService.createMetaDataForRecon("kalturalogin",error);
			console.log("metaData", metaData);
			notificationObj = await notificationService.reconIntitialNotificationObj(input, metaData);
			notificationObj = await notificationService.updateReconInfo(notificationObj,data);
			notificationObj = await notificationService.updateNotificationStage(notificationObj, false, "kaltura", error, "error");
			await kafkaService.pushEventToKafka(configuration.kafkaConfig.topic.recon, notificationObj);
		}
		throw error;
	}
}
/**
    * Create the user from unverified user data
    * @returns Promise
    * @param email Username for Kaltura
    * @param userId Password for Kaltura
    */

async function kalturaRegistration(email, userId, input, userRecord, userData, mixpanelPartnerFlag = true) {
	try {
		let skipRegistation = false;
		let distinctId = email;
		let deviceId = _.get(input, "deviceId");
		try {
			await kalturaService.register(email, userId);
			if (mixpanelPartnerFlag == false) {
				distinctId = _.get(input.data, "uniqueId", _.get(input.data, "externalId"));
			}
			mixpanelService(mixPanelConfig.externalCallKaltura + "Registration" + mixPanelConfig.success, { email: email, uid: userId, distinct_id: distinctId }, distinctId, null, null, mixpanelPartnerFlag);
		} catch (error) {
			console.error("errrrrorssssss in kaltura", error);
			mixpanelService(mixPanelConfig.externalCallKaltura + "Registration" + mixPanelConfig.error, { email: email, uid: userId, distinct_id: distinctId, error: error }, distinctId, null, null, mixpanelPartnerFlag);
			// skip registration incase same user exists
			if (_.get(error, "result.error.code") == kalturaErrorConfig.errorCodes.USER_ALREADY_EXISTS.code) {
				skipRegistation = true;
			} else if (_.get(error, "result.error.code") == kalturaErrorConfig.errorCodes.EXTERNAL_ID_ALREADY_EXISTS.code) { // @TODO : Temp fix done, Will remove once V3 stabled
				userRecord = JSON.parse(JSON.stringify(userRecord));
				_.set(userRecord, "email", `${userId}@voot.com`);
				skipRegistation = true;
			} else {
				console.debug("Kaltura Registraion Failed ::: ", " Email ::: ", email, "User Id ::: ", userId);
				throw error;
			}
		}
		if (skipRegistation) {
			console.debug("Kaltura Registraion Failed, skip registration :::", " Email ::: ", _.get(userRecord, "email"), "User Id ::: ", userId);
			let loginResponse = await doKalturaLogin(input, userRecord, userData, distinctId, mixpanelPartnerFlag); // @TODO : Temp fix done, Will remove once V3 stabled
			if (_.get(loginResponse, "data.email") == `${userId}@voot.com`) {
				_.set(loginResponse, "data.email", email);
			}
			return loginResponse;
		}
		//check for Windows NT 6.3 to uid             
		if (input.deviceBrand.toLowerCase().trim() == "pc/mac") {
			deviceId = _.get(userRecord, "uid");
			console.debug("update deviceId Windows NT 6.3 to uid", deviceId);
		}
		const kalturaUserLoginResult = await kalturaService.login(email, userId, deviceId);
		// eslint-disable-next-line no-undef
		const [kalturaHousehold, device, kalturaAppTokenResponse] = await Promise.all([
			kalturaService.createHousehold(email, kalturaUserLoginResult.result.loginSession.ks,userId,distinctId,mixpanelPartnerFlag),
			kalturaService.setupHouseholdDevice(deviceId, input.deviceBrand),
			kalturaService.getAppToken(kalturaUserLoginResult.result.loginSession.ks)
		]);
		if (_.get(kalturaHousehold, "result.id")) {
			console.log("kalturaHousehold.result.id::", _.get(kalturaHousehold, "result.id"));
			await kalturaService.addDeviceToUserHousehold(device, kalturaUserLoginResult.result, _.get(kalturaHousehold, "result.id"), userId, distinctId, mixpanelPartnerFlag); // not waiting for response
		}
		const v3kathuraResponse = {
			ks: kalturaUserLoginResult.result.loginSession.ks,
			kUserId: kalturaUserLoginResult.result.user.id,
			kTokenId: kalturaAppTokenResponse.result.id,
			kToken: kalturaAppTokenResponse.result.token,
			householdId: _.get(kalturaHousehold, "result.id", 0),
		};
		return v3kathuraResponse;
	}
	catch (error) {
		console.error("Exception occured in kaltura registration", error);
		return {};
	}
}

const{ isMobileNumberValid, notallowedSignupMethod, blockByProvider, blockByPlatform } = require("../utils").common;
const { validateAmazoneToken } = require("../services/tokenService");
const { getDummyEmail, splitMobileWithCountryCode } = require("../utils/common");
const auditLogNotificationservice = require("../services/auditLogNotificationService");
const config = require("../config").configuration;
const _ = require("lodash");
const { userProfileService, userService } = require("../services");
const { createNewUserInMongo, doLoginAndSignUp } = require("./socialLogin");
const { mongoUser, mongoUserProfile } = require("../format");
const moment = require("moment");
const errorConfig = require("../config").errorConfig;
const { error } = require("../utils").apiResponse;
const mixpanelConfig = require("../config/mixPanelConfig");
const mixpanelService = require("../services/mixpanelService");
const kafkaService = require("../services/kafkaService");
async function doAmazonLogin(input, auditObj) {
	try {

		let email;
		let auditValue = {};
		let userId;
		let firebaseUser;
		let userRecord;
		let notificationObj = {};
		let notificationObj2 = {};
		//Needed this value for update logs
		// eslint-disable-next-line no-unused-vars
		let updateResult;

		// These are optional params
		let partnerData = await validateAmazoneToken(input.data.token);
		// For Testing Purpose
		// let partnerData = {
		// 	"user_id": "amzn1.account.AFULSZQQVMQYIVGN6MORAFRTBQWQ",
		// 	"name": "Manali Sethi",
		// 	"mobile_number": "+919292929291",
		// 	"email": "vootplsexecute5@gmail.com"

		// };
		let AmazonProvidedDetails = await arrangeAmazoneProvidedData(partnerData);
		let userAmazoneProfileRecord = await getAmazonDetailsByExternalId(_.get(partnerData, "user_id"));
		if (!_.has(userAmazoneProfileRecord, "status")) {// if user found in userProfile by externalId
			console.log("User exist by externalId",_.get(partnerData, "user_id"),userAmazoneProfileRecord);
			let AmazoneRecord=_.get(userAmazoneProfileRecord,"profileData.AmazonDetails");
			console.log("old region",input.data);
			input.data.region= _.get(AmazoneRecord, "region", "IN");
		}
		let isSignup = false; 
		if (config.amazonValidCountriesList.includes(_.get(input.data, "region"))) {
			console.log("Integration With Email Profile for UK Region");
			AmazonProvidedDetails = { ...AmazonProvidedDetails, profileType: "email" };
			AmazonProvidedDetails = { ...AmazonProvidedDetails, region: _.get(input.data, "region") };
			console.log("AmazonProvidedDetails",AmazonProvidedDetails);
			if (!partnerData.email) throw { code: "amazon/invalid-credential" };
			// let userAmazoneProfileRecord = await getAmazonDetailsByExternalId(_.get(partnerData, "user_id"));
			email = partnerData.email;
			console.log("userAmazoneProfileRecord", userAmazoneProfileRecord);
			if (_.has(userAmazoneProfileRecord, "status")) {// if user not found in userProfile by externalId
				if(blockByProvider(input.type) && blockByPlatform(input.userAgent))
					isSignup = true;
				if(!isSignup){
					let amazonData = await emailHandlerWithAmazon(input, AmazonProvidedDetails, email);
					userId = _.get(amazonData, "userId");
					firebaseUser = _.get(amazonData, "firebaseUser");
					userRecord = _.get(amazonData, "userRecord");
					console.log(`User ID :${userId},firebaseUser:${firebaseUser},userRecord:${userRecord}`);
				}


			} else {

				if (_.get(partnerData, "email") == _.get(userAmazoneProfileRecord, "email")) {

					firebaseUser = await getUserById(_.get(userAmazoneProfileRecord, "uid", _.get(userAmazoneProfileRecord, "profileData.uid")));
					//firebaseUser = await userService.getUserById(_.get(userAmazoneProfileRecord, 'uid'))
					userId = _.get(userAmazoneProfileRecord, "uid", _.get(userAmazoneProfileRecord, "profileData.uid"));
					if (_.has(userAmazoneProfileRecord, "data")) {
						userRecord = userAmazoneProfileRecord.data;
						userRecord.uid = userAmazoneProfileRecord.uid;
					}
					else {
						userRecord = userAmazoneProfileRecord;
					}
					console.log(`User ID :${userId},firebaseUser:${firebaseUser},userRecord:${userRecord}`);

				} else {

					console.log("Remove the old email  and update the new emailId");
					email = _.get(partnerData, "email");
					await userProfileService.deleteField({ uid: _.get(userAmazoneProfileRecord, "uid") }, { $unset: { "profileData.AmazonDetails": 1 } });
					let amazonData = await emailHandlerWithAmazon(input, AmazonProvidedDetails, email);
					userId = _.get(amazonData, "userId");
					firebaseUser = _.get(amazonData, "firebaseUser");
					userRecord = _.get(amazonData, "userRecord");
					updateResult = _.get(amazonData, "updateResult");
					console.log(`User ID :${userId},firebaseUser:${firebaseUser},userRecord:${userRecord}`);
					auditValue.from = _.get(userAmazoneProfileRecord, "email", (_.get(userAmazoneProfileRecord, "data.email")));
					auditValue.to = _.get(partnerData, "email");
					auditValue.uid = _.get(userAmazoneProfileRecord, "uid");
					let auditValueForChangedUid = { ...auditValue, "from": _.get(userAmazoneProfileRecord, "uid"), "to": userId };
					notificationObj = await auditLogNotificationservice.getAuditNotificationObj(auditObj, "update_mobile", auditValue, updateResult);
					notificationObj2 = await auditLogNotificationservice.getAuditNotificationObj(auditObj, "update_uid", auditValueForChangedUid, updateResult);
					console.log("notification Object------", notificationObj, notificationObj2);
					if (config.kafkaConfig.enable.audit) {
						kafkaService.pushEventToKafka(config.kafkaConfig.topic.audit_log, notificationObj);
						kafkaService.pushEventToKafka(config.kafkaConfig.topic.audit_log, notificationObj2);
					}
				}

			}


		} else {//Mobile Flow for INDIA
			console.log("Integration With Mobile Profile for India Region");
			AmazonProvidedDetails = { ...AmazonProvidedDetails, profileType: "mobile" };
			AmazonProvidedDetails = { ...AmazonProvidedDetails, region: _.get(input.data, "region", "IN") };
			if (!partnerData.mobile_number) throw { code: "amazon/invalid-credential" };

			const isMobileValid = isMobileNumberValid(partnerData.mobile_number);
			if (!isMobileValid) {
				throw { code: "amazon/invalid-credential" };
			}
			console.log("AmazoneProvidedDetails", AmazonProvidedDetails);
			//Fetch Record from userProfile Collection by Amazone External Id then in firestore 
			//let userAmazoneProfileRecord = await getAmazonDetailsByExternalId(_.get(partnerData, "user_id"));
			console.log("userAmazoneProfileRecord", userAmazoneProfileRecord);

			let tempEmail = await getDummyEmail(partnerData.mobile_number);
			if (_.has(userAmazoneProfileRecord, "status")) {// if user not found in userProfile by externalId
				if(blockByProvider(input.type) && blockByPlatform(input.userAgent))
					isSignup = true;
				if(!isSignup){
					let amazonData = await mobileHandlerWithAmazon(input, AmazonProvidedDetails, partnerData, tempEmail);
					userId = _.get(amazonData, "userId");
					firebaseUser = _.get(amazonData, "firebaseUser");
					userRecord = _.get(amazonData, "userRecord");
					console.log(`User ID :${userId},firebaseUser:${firebaseUser},userRecord:${userRecord}`);
				}

			} else {
				if (_.get(partnerData, "mobile_number") == _.get(userAmazoneProfileRecord, "mobile")) {

					firebaseUser = await getUserById(_.get(userAmazoneProfileRecord, "uid", _.get(userAmazoneProfileRecord, "profileData.uid")));
					//firebaseUser = await userService.getUserById(_.get(userAmazoneProfileRecord, 'uid'))
					let data = await arrangeIntegrationData(AmazonProvidedDetails);
					console.log(data,"amazon data befor update.");
					await userProfileService.updateUserInformation({ uid: _.get(userAmazoneProfileRecord, "uid", _.get(firebaseUser[0], "uid")) }, { "profileData.AmazonDetails": data, "profileData.ProfileType": _.get(AmazonProvidedDetails, "profileType", "") });
					userId = _.get(userAmazoneProfileRecord, "uid", _.get(userAmazoneProfileRecord, "profileData.uid"));
					if (_.has(userAmazoneProfileRecord, "data")) {
						userRecord = userAmazoneProfileRecord.data;
						userRecord.uid = userAmazoneProfileRecord.uid;
					}
					else {
						userRecord = userAmazoneProfileRecord;
					}

					console.debug("userId", userId);
					console.debug("userRecord", userRecord);
				} else {
					console.log("Remove From the Previous Mobile Number and update the new Mobile Number");

					await userProfileService.deleteField({ uid: _.get(userAmazoneProfileRecord, "uid") }, { $unset: { "profileData.AmazonDetails": 1 } });
					let amazonData = await mobileHandlerWithAmazon(input, AmazonProvidedDetails, partnerData, tempEmail, auditObj);
					userId = _.get(amazonData, "userId");
					firebaseUser = _.get(amazonData, "firebaseUser");
					userRecord = _.get(amazonData, "userRecord");
					updateResult = _.get(amazonData, "updateResult");
					auditValue.from = _.get(userAmazoneProfileRecord, "mobile", (_.get(userAmazoneProfileRecord, "data.mobile")));
					auditValue.to = _.get(partnerData, "mobile_number");
					auditValue.uid = _.get(userAmazoneProfileRecord, "uid");
					let auditValueForChangedUid = { ...auditValue, "from": _.get(userAmazoneProfileRecord, "uid"), "to": userId };
					notificationObj = await auditLogNotificationservice.getAuditNotificationObj(auditObj, "update_mobile", auditValue, updateResult);
					notificationObj2 = await auditLogNotificationservice.getAuditNotificationObj(auditObj, "update_uid", auditValueForChangedUid, updateResult);
					console.log("notification Object------", notificationObj, notificationObj2);
					if (config.kafkaConfig.enable.audit) {
						kafkaService.pushEventToKafka(config.kafkaConfig.topic.audit_log, notificationObj);
						kafkaService.pushEventToKafka(config.kafkaConfig.topic.audit_log, notificationObj2);
					}
					console.log(`User ID :${userId},firebaseUser:${firebaseUser},userRecord:${userRecord}`);
				}
			}
		}
		if(isSignup)return notallowedSignupMethod(input.type);//block social account signup
		return doLoginAndSignUp(input, firebaseUser, firebaseUser, userId, false, AmazonProvidedDetails);
	} catch (err) {
		console.log("errrrr", err, err.stack);

		mixpanelService(mixpanelConfig.externalCall + "amazon" + mixpanelConfig.serverValidation_Error, { input: input, message: _.get(err, "stack", err), StatusCode: 400, distinct_id: _.get(input.data, "uid") }, _.get(input.data, "uid"));

		if (_.get(err, "message", "").match("Wrong")) {
			throw new Error(errorConfig.invalidFborGToken.code);
		}
		switch (err.code) {
		case "amazon/invalid-credential":
			return error(errorConfig.invalidAmazonCredential.description, errorConfig.invalidAmazonCredential.code);
		case "amazon/invalid-id-token":
			return error(errorConfig.invalidAccessToken.description + ":Amazon Token is Expired", 1907);
		case errorConfig.errorCodes.USER_WRONG_USERNAME_OR_PASSWORD.code:
			return error(errorConfig.kalturaUserWrongUsernameOrPassword.description, errorConfig.kalturaUserWrongUsernameOrPassword.code);
		case errorConfig.errorCodes.INSIDE_LOCK_TIME.code:
			return error(errorConfig.kalturaInsideLockTime.description, errorConfig.kalturaInsideLockTime.code);
		default:
			throw error(errorConfig.requestFailed, 400);
		}

	}
}
async function arrangeIntegrationData(amazonData) {
	let data = {
		// FullName: _.get(amazonData, "name", ""),
		// Mobile: _.get(amazonData, "mobile", ""),
		// ProfileName: _.get(amazonData, "name", ""),
		// CountryCode: _.get(amazonData, "countryCode", ""),
		// AmazonDetails: {
		externalId: _.get(amazonData, "externalId"), //UID(facebook)  or ID (facebook)
		IsEmailSubscribed: "false",
		PhotoUrl: "",
		RegistrationProvider: "amazon",
		Provider: "amazon",
		LastLoginDate: moment().format("MMMM Do YYYY, h:mm:ss a"),
		Name: _.get(amazonData, "name", ""),
		PostalAddress: _.get(amazonData, "postal_address", ""),
		PostalCode: _.get(amazonData, "postal_code", ""),
		Mobile_Number: _.get(amazonData, "mobile_number", ""),
		Email: _.get(amazonData, "email", ""),
		region: _.get(amazonData, "region","") 
		// }

	};
	return data;
}

async function arrangeAmazoneProvidedData(partnerData) {
	let AmazonProvidedDetails = {}, SplitedData;
	if (partnerData.user_id) AmazonProvidedDetails = { ...AmazonProvidedDetails, externalId: partnerData.user_id };
	if (partnerData.mobile_number) AmazonProvidedDetails = { ...AmazonProvidedDetails, mobile_number: partnerData.mobile_number };
	if (partnerData.email) AmazonProvidedDetails = { ...AmazonProvidedDetails, email: partnerData.email };
	if (partnerData.postal_address) AmazonProvidedDetails = { ...AmazonProvidedDetails, postal_address: partnerData.postal_address };
	if (partnerData.postal_code) AmazonProvidedDetails = { ...AmazonProvidedDetails, postal_code: partnerData.postal_code };
	if (partnerData.name) AmazonProvidedDetails = { ...AmazonProvidedDetails, name: partnerData.name };
	AmazonProvidedDetails = { ...AmazonProvidedDetails, registration_provider: "amazon" };
	AmazonProvidedDetails = { ...AmazonProvidedDetails, provider: "amazon" };
	AmazonProvidedDetails = { ...AmazonProvidedDetails, photo_url: "" };

	if (partnerData.mobile_number) SplitedData = await splitMobileWithCountryCode(partnerData.mobile_number);
	AmazonProvidedDetails = { ...AmazonProvidedDetails, mobile: _.get(SplitedData, "Mobile") };
	AmazonProvidedDetails = { ...AmazonProvidedDetails, countryCode: _.get(SplitedData, "CountryCode", "+91") };
	return AmazonProvidedDetails;
}

async function getAmazonDetailsByExternalId(externalId) {
	let userAmazoneProfileRecord = await userProfileService.getAmazonDetailsByExternalId(externalId);
	if (_.has(userAmazoneProfileRecord, "status")) {
		return userAmazoneProfileRecord;
	} else {
		return userAmazoneProfileRecord;
	}
}
async function getUserById(uid) {
	let userAuthProfile = await userService.getUserByIdFromPrimaryPre(uid);
	return userAuthProfile;



}
async function getUserByPhone(mobile) {
	let userAuthProfile = await userService.getUserByPhone(mobile);
	return userAuthProfile;
}
async function emailHandlerWithAmazon(input, AmazonProvidedDetails, email) {
	let userId, firebaseUser, updateResult, userRecord;
	try {
		userRecord = await userProfileService.getUserInformationByEmail(email);//Search by email first
		if (!_.has(userRecord, "status")) {// User Already Exist with Email 
			let data = await arrangeIntegrationData(AmazonProvidedDetails);
			updateResult = await userProfileService.updateUserInformation({ uid: _.get(userRecord, "uid", _.get(userRecord[0], "uid")) }, { "profileData.AmazonDetails": data, "profileData.ProfileType": _.get(AmazonProvidedDetails, "profileType", "") });
			// await userProfileService.updateUserInformation({ uid: _.get(userRecord, "uid", _.get(userRecord[0], "uid")) }, { , "email": email ? email : _.get(AmazonProvidedDetails, "email") });//for unsync data in user profile remove later                    
			firebaseUser = await userService.getUserByIdFromPrimaryPre(_.get(userRecord, "uid", _.get(userRecord[0], "uid")));
			userId = userRecord.uid;
			//Already Exist 
		} else {
			throw { code: "auth/user-not-found" };
			//No Email found
		}
	} catch (error) {
		if (error.code === "auth/user-not-found") {
			let userData = await mongoUser.initFormatAmazoneUser(AmazonProvidedDetails, email, _.get(AmazonProvidedDetails, "profileType"));
			userService.insertUser(userData);
			userId = userData.uid;
			let data = mongoUserProfile.initFormatForUserProfileSocail(input, email, undefined, undefined, undefined, AmazonProvidedDetails);
			await createNewUserInMongo(userData, data, email);
			firebaseUser = userData;
		}
	}
	let amazonData = {
		"userId": userId,
		"firebaseUser": firebaseUser,
		"userRecord": userRecord,
		"updateResult": updateResult
	};
	return amazonData;
}
async function mobileHandlerWithAmazon(input, AmazonProvidedDetails, partnerData, tempEmail) {
	let userId, firebaseUser, updateResult, userRecord;
	try {
		let userAuthRecord = await getUserByPhone(_.get(partnerData, "mobile_number"));// find that user Registered with Mobile Number
		//let userAuthRecord = await userService.getUserByPhone(_.get(partnerData, 'mobile_number'));// find that user Registered with Mobile Number
		console.log("userAuthrecord.........", userAuthRecord);
		if (!_.has(userAuthRecord, "status")) {//if user record found then update in firestore with credentials 
			let data = await arrangeIntegrationData(AmazonProvidedDetails);
			console.log(data,"amazpn data1 before update");
			await userProfileService.updateUserInformation({ uid: _.get(userAuthRecord, "uid", _.get(userAuthRecord[0], "uid")) }, { "profileData.AmazonDetails": data, "mobile": _.get(AmazonProvidedDetails, "mobile_number"), "email": tempEmail, "profileData.ProfileType": _.get(AmazonProvidedDetails, "profileType") });
			userRecord = await userProfileService.getUserInformationByIdFromPrimaryPre(_.get(userAuthRecord, "uid", _.get(userAuthRecord[0], "uid")));
			firebaseUser = _.isEmpty(userAuthRecord[0]) ? userAuthRecord : userAuthRecord[0];
			userId = _.get(userAuthRecord, "uid", _.get(userAuthRecord[0], "uid"));
		} else {
			throw { code: "auth/user-not-found" };
		}
	} catch (errror) {
		console.log("ERROR......", errror, errror.stack);
		// create new Amazone User With mobile Without Password 
		if (errror.code === "auth/user-not-found") {
			let userData = await mongoUser.initFormatAmazoneUser(AmazonProvidedDetails, tempEmail);

			userService.insertUser(userData);
			userId = userData.uid;
			let data = mongoUserProfile.initFormatForUserProfileSocail(input, tempEmail, undefined, undefined, undefined, AmazonProvidedDetails);
			await createNewUserInMongo(userData, data, tempEmail, partnerData.mobile_number);
			firebaseUser = userData;
			userRecord = await userProfileService.getUserInformationByIdFromPrimaryPre(_.get(userData, "uid"));
		}
	}
	let amazonData = {
		"userId": userId,
		"firebaseUser": firebaseUser,
		"userRecord": userRecord,
		"updateResult": updateResult
	};
	return amazonData;
}


module.exports = { doAmazonLogin };

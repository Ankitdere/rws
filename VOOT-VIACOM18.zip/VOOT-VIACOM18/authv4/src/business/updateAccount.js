"use strict";
const userProfileService = require("../services").userProfileService;
const  {auditLogNotificationservice, kafkaService }= require("../services");
const mongoUserProfileFormat = require("../format").mongoUserProfile;
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");
const config = require("../config").configuration;
const moment = require("moment");
const constant = require("../utils/constant/generic");
const commonUtils = require("../utils").common;

async function updateAccount(input, options, auditObj) {
	const { userToken, headers } = options;
	let accountData = _.get(userToken, "profileData", {});
	let auditValue={},notificationObj;
	if (_.get(userToken, "status", 0) == 1701) {
		throw new Error(errorConfig.userDoesNotExist.code);
	}
	if (!_.has(input, "tncVersion") || _.isEmpty(input, "tncVersion")) {
		console.log("tncVersion and tncAcceptTime is blank", input.tncVersion);
		// if tncVersion is empty then both value will null
		input.tncAcceptTime = null; input.tncVersion = null;
	} else {
		input.tncAcceptTime = Date.now();
	}
	if (input.languages) accountData = {...accountData, Preferences: { Languages: mongoUserProfileFormat.fillLanguages(input) } };
	if (input.profilename) accountData = { ...accountData, ProfileName: input.profilename };
	if (input.firstname) accountData = { ...accountData, FirstName: input.firstname };
	if (input.lastname) accountData = { ...accountData, LastName: input.lastname };
	if (input.birthdate) accountData = { ...accountData, BirthDate: input.birthdate };
	if (input.gender) accountData = { ...accountData, Gender: input.gender };
	if (input.tncVersion) accountData = { ...accountData, TncVersion: input.tncVersion };
	if (input.tncAcceptTime) accountData = { ...accountData, TncAcceptTime: parseInt(input.tncAcceptTime) };
	accountData = { ...accountData, isProfileUpdated: true };
	if (_.isEmpty(_.get(userToken.profileData,"TncAgreement")) && input.tncVersion!=null) {
		let tncVersion, tncAcceptTime = "";
		if (input.tncVersion) {
			{ tncVersion = input.tncVersion; }
			tncVersion = tncVersion.replace(".", "[dot]");
		}
		if (input.tncAcceptTime) { tncAcceptTime = input.tncAcceptTime; }
		let TncAgreement = {};
		TncAgreement[tncVersion] = tncAcceptTime;
		if (input.tncVersion && input.tncAcceptTime) {
			accountData = { ...accountData, TncAgreement };
		}
	} else if( input.tncVersion!=null) {
		let tncVersion, tncAcceptTime = "";
		if (input.tncVersion) {
			{ tncVersion = input.tncVersion; }
			tncVersion = tncVersion.replace(".", "[dot]");
		}
		if (input.tncAcceptTime) { tncAcceptTime = input.tncAcceptTime; }
		let TncAgreement = userToken.profileData.TncAgreement;
		TncAgreement[tncVersion] = tncAcceptTime;
		accountData = { ...accountData, TncAgreement };
		accountData = { ...accountData, isProfileUpdated: true };
	}
	const query = { profileData: accountData, updatedAt: moment().utcOffset(+530).unix() };
	let updateResult = await userProfileService.updateUserInformation({ uid: userToken.uid }, query);

	// tnc change audit:
	if(userToken.profileData && userToken.profileData.TncVersion && (userToken.profileData.TncVersion)!=input.tncVersion ){
		
		if (config.kafkaConfig.enable.audit) {
			auditValue.from = userToken.profileData.TncVersion;
			auditValue.to = input.tncVersion;
			auditValue.uid = userToken.uid;
			notificationObj = await auditLogNotificationservice.getAuditNotificationObj(auditObj,"update_tnc",auditValue,updateResult);
			console.log("before push",notificationObj);
			kafkaService.pushEventToKafka(config.kafkaConfig.topic.audit_log, notificationObj);
		}
	}
	// To check is kid profile 
	return updateAPIResponse(headers, accountData);
}

function updateAPIResponse(headers, accountData) {
	const userBirthDate = accountData.BirthDate;
	const { country, apiversion } = headers;
	if (apiversion === constant.API_VERSION["4@0"]) {
		const isKidProfile = commonUtils.isKidProfile(userBirthDate, country);
		const responseArray = {
			isPosted: true,
			isKidProfile: isKidProfile
		};
		return responseArray;
	}
	return errorConfig.updateAccountSuccess;
}
module.exports = updateAccount;


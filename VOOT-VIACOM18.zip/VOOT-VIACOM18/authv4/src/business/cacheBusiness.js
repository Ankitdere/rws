const parameterStoreService = require( "../services/parameterStoreService" );
const config = require( "../config/configuration" );
const cache = require( "../config/cacheConnection" );
const _ = require( "lodash" );

module.exports = { settingAllInCache, settingCache };
/**
 * Function to set all the cache values from ssm
 */
async function settingAllInCache () {
	try {
		let valueArray = [];
		const result = await parameterStoreService.getAllParameterStoreValues();
		for ( let record of result ) {
			let key = record.Name;
			let parameterStoreValue = JSON.parse( record.Value );
			cache.set( key, parameterStoreValue.value, parameterStoreValue.defaultTTL );
			try {
				parameterStoreValue = JSON.parse( parameterStoreValue.value );
			} catch ( err ) {
				parameterStoreValue = parameterStoreValue.value;
			}
			valueArray.push( parameterStoreValue );
		}

		await updateConfiguration( valueArray );
	}
	catch ( err ) {
		console.log( err );
		throw err;
	}
}
/**
 * Function to set single key value to cache from ssm
 * @param {String} key 
 */
async function settingCache ( key ) {
	let parameterStoreValue;
	try {
		let result = await parameterStoreService.getParameterStoreValue( key );
		result = JSON.parse( result.Value );
		try {
			parameterStoreValue = JSON.parse( result.value );
		} catch ( err ) {
			parameterStoreValue = result.value;
		}
		let valueArray = [ parameterStoreValue ];
		await updateConfiguration( valueArray );
	}
	catch ( err ) {
		console.log( err );
		throw err;
	}
}
/**
 * Function to Update the value of configuration 
 * @param {Array<JSON>} params 
 */
function updateConfiguration ( params ) {
	for ( let record of params ) {
		if ( record && record.mongo ) config.mongo = record.mongo;
		if ( record.kaltura ) config.kaltura = record.kaltura;
		if ( record.Mailer ) config.Mailer = record.Mailer;
		if ( record.App ) config.App = record.App;
		if ( record.Encryption ) config.Encryption = record.Encryption;
		if ( record.DefaultLanguages ) config.DefaultLanguages = record.DefaultLanguages;
		if ( record.DefaultProfileLanguages ) config.DefaultProfileLanguages = record.DefaultProfileLanguages;
		if ( record.DefaultErrorMail ) config.DefaultErrorMail = record.DefaultErrorMail;
		if ( record.deviceActivation ) config.deviceActivation = record.deviceActivation;
		if ( record.Avatar ) config.Avatar = record.Avatar;
		if ( record.profileUpdatesEmailFrequency ) config.profileUpdatesEmailFrequency = record.profileUpdatesEmailFrequency;
		if ( record.loginRadius ) config.loginRadius = record.loginRadius;
		if ( record.userEmailDomain ) config.userEmailDomain = record.userEmailDomain;
		if ( record.google ) config.google = record.google;
		if ( record.firebase ) config.firebase = record.firebase;
		if ( record.allowedOrigins ) config.allowedOrigins = record.allowedOrigins;
		if ( record.jwt ) config.jwt = record.jwt;
		if ( record.jwt2 ) config.jwt2 = record.jwt2;
		if ( record.wd ) config.wd = record.wd;
		if ( record.syncEndpoint ) config.syncEndpoint = record.syncEndpoint;
		if ( record.loginRadiusConfig ) config.loginRadiusConfig = record.loginRadiusConfig;
		if ( record.jwtDeleteUser ) config.jwtDeleteUser = record.jwtDeleteUser;
		if ( record.jwtadminKsToken ) config.jwtadminKsToken = record.jwtadminKsToken;
		if ( record.jwtScreenzUser ) config.jwtScreenzUser = record.jwtScreenzUser;
		if ( record.jwtForgotPassword ) config.jwtForgotPassword = record.jwtForgotPassword;
		if ( record.serviceAccount ) config.serviceAccount = record.serviceAccount;
		if ( record.Otp ) config.Otp = record.Otp;
		if ( record.AWS ) config.AWS = record.AWS;
		if ( record.deviceBrands ) config.deviceBrands = record.deviceBrands;
		if ( record.redis ) config.redis = record.redis;
		if ( record.ApppleSignIn ) config.ApppleSignIn = record.ApppleSignIn;
		if ( record.AWS2 ) config.AWS1 = record.AWS2;
		if ( record.v4Tov3Syn ) config.v4Tov3Syn = record.v4Tov3Syn;
		if ( record.SQS ) config.SQS = record.SQS;
		if ( record.tSkyDetails ) {
			config.jwtPartnerNotification = {};
			config.jwtPartnerNotification.secret = record.tSkyDetails.jwtPartnerNotification;
		}
		if ( record.pxApi ) config.pxApi = record.pxApi;
		if ( record.jioSubscription ) config.jioSubscription = record.jioSubscription;
		if ( record.jioSubscriptionDetailsCertificate ) {
			config.jioSubscription.certificate = record.jioSubscriptionDetailsCertificate.certificate;
			config.jioSubscription.certificationEnable = record.jioSubscriptionDetailsCertificate.certificationEnable;
		}
		if ( record.tSkyDetails ) config.tSkyDetails = record.tSkyDetails;
		if ( record.pXApiDetails ) config.pXApiDetails = record.pXApiDetails;
		if ( record.M2MITDetails ) config.M2MITDetails = record.M2MITDetails;
		if ( record.m2mitCertificate ) {
			config.M2MITDetails.certificate = record.m2mitCertificate.certificate;
			config.M2MITDetails.certificationEnable = record.m2mitCertificate.certificationEnable;
		}
		if (record.isKarixEnabled) config.isKarixEnabled = record.isKarixEnabled;
		if (record.Karix) config.Karix = record.Karix;
		if (record.accountDeletion) config.accountDeletion = record.accountDeletion;
		if (record.flipkart) config.partners[0] = record.flipkart;
		if (record.airtel) config.partners[1] = record.airtel;
		if (record.yupptv) config.partners[2] = record.yupptv;
		if (record.actionList) config.actionList = record.actionList;
		if (record.hashConfig) config.hashConfig = record.hashConfig;
		if (record.AmazonDetails) config.AmazonDetails = record.AmazonDetails;
		if (record.AnonymousToken) config.AnonymousToken = record.AnonymousToken;
		if (record.AnonymousGrantType) config.AnonymousGrantType = record.AnonymousGrantType;
		if (record.AnonymousTokenSource) config.AnonymousTokenSource = record.AnonymousTokenSource;
		if (record.AnonymousTokenClientIdApiKey) config.AnonymousTokenClientIdApiKey = record.AnonymousTokenClientIdApiKey;
		if (record.AnonymousTokenClientId) config.AnonymousTokenClientId = record.AnonymousTokenClientId;
		if (record.AnonymousTokenClientAndPartnerMap) config.AnonymousTokenClientAndPartnerMap = record.AnonymousTokenClientAndPartnerMap;
		if (record.productId) config.productId = record.productId;
		if (record.swaggerHost) config.swaggerHost = record.swaggerHost;
		if (record.getOtpDetails) config.getOtpDetails = record.getOtpDetails;
		if (record.mpAuthApiToken) config.mpAuthApiToken = record.mpAuthApiToken;
		if (record.mpPartnerApiToken) config.mpPartnerApiToken = record.mpPartnerApiToken;
		if (record.mpApiEndPoint) config.mpApiEndPoint = record.mpApiEndPoint;
		if (record.ksmBasicInfo) config.ksmConfig= record.ksmBasicInfo;
		if (record.ksmPlatformAndDeviceConfig) config.ksmPlatformAndDeviceConfig =  record.ksmPlatformAndDeviceConfig;
		if (record.amazonValidMobile) config.amazonValidMobile = record.amazonValidMobile;
		if (record.kafkaConfig) config.kafkaConfig = record.kafkaConfig;
		if (record.logEnable) config.logEnable = record.logEnable;
		if (record.blockUserList) config.blockUserList = record.blockUserList;
		if ( record.sms ) config.sms = record.sms;
		if ( record.internalServiceAPI ) config.internalServiceAPI = record.internalServiceAPI;
		if ( record.AnonymousGrantTypeCheckDisable ) config.AnonymousGrantTypeCheckDisable = record.AnonymousGrantTypeCheckDisable;
		if ( record.AnonymousAPIResponse ) config.AnonymousAPIResponse = record.AnonymousAPIResponse;
		if ( record.corsOrigin ) config.corsOrigin = record.corsOrigin;
		if ( record.LoginConfigurations ) config.LoginConfigurations = record.LoginConfigurations;
		if ( record.M2MITAsyncConfig ) config.M2MITAsyncConfig = record.M2MITAsyncConfig;
		if ( record.TataSkyAsyncConfig ) config.TataSkyAsyncConfig = record.TataSkyAsyncConfig;
		if ( record.YuppTvAsyncConfig ) config.YuppTvAsyncConfig = record.YuppTvAsyncConfig;
		if (record.kafkaConfig) config.kafkaConfig = record.kafkaConfig;
		if (  _.has( record, "mpAuthApiSwitch") )config.mpAuthApiSwitch = record.mpAuthApiSwitch;
		if ( _.has( record, "mpPartnerApiSwitch") ) config.mpPartnerApiSwitch = record.mpPartnerApiSwitch;
		if (record.noOfSubProfilesAllowed) config.noOfSubProfilesAllowed = record.noOfSubProfilesAllowed;
		if (record.SendMessageAPIKey) config.SendMessageAPIKey = record.SendMessageAPIKey;
		if (record.SmsDataAPIKeyList) config.SmsDataAPIKeyList = record.SmsDataAPIKeyList;
		if (record.kidProfileAgeLimit) config.kidProfileAgeLimit = record.kidProfileAgeLimit;
		if (record.defaultDateOfBirth) config.defaultDateOfBirth = record.defaultDateOfBirth;
		if (record.limitConfig) config.limitConfig = record.limitConfig;
		if (record.blockPartnerConfig) config.blockPartnerConfig = record.blockPartnerConfig;
	}
}
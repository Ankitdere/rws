"use strict";

const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const errorConfig = require("../config").errorConfig;
const config = require("../config").configuration;
const _ = require("lodash");
const mongoUser = require("../format").mongoUser;
const mongoUserProfile = require("../format").mongoUserProfile;
const { responseFormat } = require("../format");
const { jioUserDetails, tSkyUserDetails, userProfileService, userService,pxApiService, tokenService, kalturaService } = require("../services");
const mixpanelService =require("../services/mixpanelService");
const mixPanelConfig = require("../config/mixPanelConfig");
const notificationService = require("../services").notificationService;
const kafkaService = require("../services/kafkaService");

module.exports = {
	partnerSignInUp,
	storeKUserId
};
async function partnerSignInUp(input) {

	let response, partnerData, uid, userData, PXAction,tokenExpiryDay;
	let notificationObj = await notificationService.getInitialNotificationObj(input);
	try {
		const partnerDetails = {};

		switch (input.partnerType) {
		case config.jioSubscription.partnerType:
			({ uid, userData, partnerData } = await jioUserDetails(input));
			partnerDetails.platform = config.jioSubscription.platform;
			partnerDetails.partnerName = config.jioSubscription.partnerName;
			break;
		case config.tSkyDetails.partnerType:
			({ uid, userData, partnerData } = await tSkyUserDetails(input));
			// Need to verify calling of userprofiles 2 times
			console.log("Partner Data fetched from tSkyUserDetails",partnerData);
			try{
				if(partnerData.email != "")
				{
					await getEmailLinkedUser((_.get(partnerData,"email")).toLowerCase(), uid);
				}
			}catch(err){
				console.error("Error in case config.tSkyDetails.partnerType",err);
			}
			partnerDetails.platform = config.tSkyDetails.platform;
			partnerDetails.partnerName = config.tSkyDetails.partnerName;
			break;
		}
		if (uid) {
			const tempEmail = await createTempEmail(uid, input);
			if(_.isEmpty(_.get(userData, "kUserId"))){
				try{
					let response = await  kalturaService.getUserByUsername(tempEmail);
					userData.kUserId = _.get(response,"id");
					await storeKUserId(userData.kUserId, uid, _.get(input, "deviceId", ""));
				}catch(err){
					console.error("Error in getting kuser id from kaltura",err);
				}
			}
			const accessToken = await tokenService.createAccessTokenAndRefreshToken({ uid: uid, email: tempEmail, kUserId: _.get(userData, "kUserId"), deviceId: _.get(input, "deviceId", ""), partnerType: _.get(input, "partnerType", _.get(userData, "partnerType", "")) });
			let userProfile;
			let profileData = userProfile=mongoUserProfile.initorUpdateProfilePartner(uid, partnerData, false, input.partnerType, parseInt(_.get(userData, "lastLoginCount"), 10), tempEmail);
			await userProfileService.updateUserInformation({ uid: uid }, profileData);
			profileData.subscription = partnerData.subscription;
			userProfile.uid=uid;
			userProfile.externalId = _.get(userData, "externalId");
			notificationObj = await notificationService.updateBasicInfo(notificationObj, userProfile);
			if (_.get(input, "partnerType") == config.jioSubscription.partnerType && profileData && profileData.subscription && profileData.subscription.endDate) {
				let entitlementstatus = await pxApiService.checkEntitlementStatus(_.get(accessToken,"accessToken"));
				console.log("entitlementstatus",entitlementstatus);
				if ((new Date(profileData.subscription.endDate).getTime()/1000) < new Date().getTime()/1000) {
					PXAction = config.pXApiDetails.cancelSubcriptionAction;
				}
				// if ((new Date(userData.subscription.endDate).getTime()) < (new Date(profileData.subscription.endDate).getTime())) {
				//     PXAction = config.pXApiDetails.renewSubcriptionAction;
				// }
				if (entitlementstatus && entitlementstatus.activeTillDate && entitlementstatus.activeTillDate.timeStamp && _.get(entitlementstatus,"activeTillDate.timeStamp") < (new Date(profileData.subscription.endDate).getTime()/1000)) {
					PXAction = config.pXApiDetails.renewSubcriptionAction;
				}
				if (entitlementstatus && entitlementstatus.lastActiveSubDate && entitlementstatus.lastActiveSubDate.timeStamp && _.get(entitlementstatus,"lastActiveSubDate.timeStamp") < (new Date(profileData.subscription.endDate).getTime()/1000)) {
					PXAction = config.pXApiDetails.renewSubcriptionAction;
				}
				if (_.get(entitlementstatus,"status") == config.pXApiDetails.newSubcriptionAction) {
					PXAction = config.pXApiDetails.newSubcriptionAction;
				}
			}
			// let userProfile = await userProfileService.getUserInformationById(uid);
			// let userProfile = await userProfileService.getUserInformationByIdFromPrimaryPre(uid);
			// if (_.get(input, 'partnerType') == config.jioSubscription.partnerType && profileData && profileData.subscription && profileData.subscription.endDate) {
			//     console.log("Userprofile before updating JIO details",userProfile);
			//     userProfile.subscription.endDate = profileData.subscription.endDate ? profileData.subscription.endDate : userProfile.subscription.endDate;
			//     userProfile.subscription.startDate = profileData.subscription.startDate ?profileData.subscription.startDate :userProfile.subscription.startDate ;
			//     userProfile.subscription.activationDate = profileData.subscription.activationDate ? profileData.subscription.activationDate :  userProfile.subscription.activationDate; 
			//     console.log("Userprofile after updating JIO details",userProfile);
			// } 
			console.log("PXACtion",PXAction);
			if (PXAction) {
				let pxresponse = pxApiService.callPX(input, userProfile, partnerDetails, accessToken.accessToken, PXAction);
				console.log("Px response", pxresponse);
			}
			if (_.get(input, "partnerType") == config.jioSubscription.partnerType && profileData && profileData.subscription && profileData.subscription.endDate) {
				tokenExpiryDay= await commonUtils.tokenDateCalculator(partnerData.subscription.endDate);
				console.debug("tokenExpiryDay",tokenExpiryDay);
			}
			let mongoAuth = await mongoUser.initFormatForFirebaseOtherPartner(uid, profileData, input.partnerType.toLowerCase(), partnerData);
			await userService.updateOrInsertUser({ uid: uid }, mongoAuth);
			response = await kalturaLogin(input, tempEmail, userProfile, userData, partnerData, partnerDetails,tokenExpiryDay);
			notificationObj = await notificationService.updateNotificationStage(notificationObj, true, "auth",response);
			// if (PXAction) {
			//     let pxresponse = pxApiService.callPX(input, userProfile, partnerDetails, response.data.authToken.accessToken, PXAction);
			//     console.log("Px response", pxresponse);
			// }
        
            
		} else {
			// const linkedUserId = await this.getLinkedUser(partnerData.mobileNumber);
			PXAction = config.pXApiDetails.newSubcriptionAction;
			//create a user in Auth
			let userAuthMongo = await mongoUser.initFormatForOtherPartner(input, (input.partnerType).toLowerCase());
			await userService.insertUser(userAuthMongo);
			getLinkedUser(partnerData.mobile, _.get(userAuthMongo, "uid"));
			// create a profile in userProfile
			const tempEmail = await createTempEmail(_.get(userAuthMongo, "uid"), input);
			if(input.partnerType==config.jioSubscription.partnerType) tokenExpiryDay= await commonUtils.tokenDateCalculator(partnerData.subscription.endDate);
			console.debug("tokenExpiryDay",tokenExpiryDay);
			let profileData = await mongoUserProfile.initorUpdateProfilePartner(_.get(userAuthMongo, "uid"), partnerData, true, input.partnerType, null, tempEmail);
			await userProfileService.updateUserInformation({ uid: _.get(userAuthMongo, "uid") }, profileData);
			profileData.subscription = partnerData.subscription;
			// let userProfile = await userProfileService.getUserInformationById(_.get(userAuthMongo, 'uid'));
			let userProfile = await userProfileService.getUserInformationByIdFromPrimaryPre(_.get(userAuthMongo, "uid"));
			userProfile.subscription = partnerData.subscription;
			notificationObj = await notificationService.updateBasicInfo(notificationObj, userProfile);
			notificationObj = await notificationService.updateNotificationStage(notificationObj, true, "auth");
			// Added code as cluster data was not getting synced after insertion
			console.debug("User profile fetched from DB",userProfile);
			console.debug("Profile data prepared",profileData);
			if(_.isEmpty(userProfile) || _.has(userProfile,"status")){
				userProfile = profileData;
			}
			console.log("User Profile After ", userProfile);
			//userProfileData = userProfile;
			response = await kalturaRegistration(tempEmail, input, userProfile, userAuthMongo,null,tokenExpiryDay);
			await pxApiService.callPX(input, userProfile, partnerDetails, response.data.authToken.accessToken, PXAction);
		}
		notificationObj = await notificationService.updateNotificationStage(notificationObj, true, "subscription");
		notificationObj = await notificationService.updateNotificationStage(notificationObj, true, "entitlement");
		console.log("notification object", notificationObj);
		if (config.kafkaConfig.enable.processNotification) {
			kafkaService.pushEventToKafka(config.kafkaConfig.topic.partnerNotification, notificationObj);
		}
		
		if (config.kafkaConfig.enable.isUpdateAuth && !_.isEmpty(input.regionInfo) &&
			((input.regionInfo.region !== userData.region) || (input.regionInfo.country !== userData.country))
		) { 
			//sending region notification into queue
			const regionNotificationObj = await notificationService.createRegionNotification(
				userData,
				_.get(input, "regionInfo", {})
			);
			kafkaService.pushEventToKafka(config.kafkaConfig.topic.updateAuthData, regionNotificationObj);
		}
		return apiResponse.success(response, 0, 200,
			mixPanelConfig.partnerSignIn + _.get(input, "partnerType") + mixPanelConfig.success,
			input.data,
			_.get(userData, "uniqueId", _.get(input.data, "externalId", _.get(input.data, "dsn"))),
			false
		);

	} catch (error) {
		console.error("Error........", error);
		if (config.kafkaConfig.enable.processNotification && config.kafkaConfig.enable.processNotificationError) {
			kafkaService.pushEventToKafka(config.kafkaConfig.topic.partnerNotification, notificationObj);
		}
		if (error.code) {
			switch (error.code) {
			case "partner/invalid-token":
				throw { https: 400, error: apiResponse.error(errorConfig.partnerInvalidToken.description, errorConfig.partnerInvalidToken.code) };
			case "partner/user-not-subscribed":
				throw { https: 400, error: apiResponse.error(errorConfig.partnerUserNotSubscribed.description, errorConfig.partnerUserNotSubscribed.code,mixPanelConfig.partnerSignIn+_.get(input,"partnerType")+mixPanelConfig.error,input,error.uid?error.uid:_.get(input.data,"externalId",_.get(input.data,"dsn")),400,false) }; //R15 TODO: Update the message.                 
			case "partner/user-not-found":
				throw { https: 400, error: apiResponse.error(errorConfig.partnerUserDoesNotExist.description, errorConfig.partnerUserDoesNotExist.code,mixPanelConfig.partnerSignIn+_.get(input,"partnerType")+mixPanelConfig.error,input,error.uid?error.uid:_.get(input.data,"externalId",_.get(input.data,"dsn")),400,false) };
			case "partner/Invalid-expired-Token":
				throw { https: 400, error: apiResponse.error(errorConfig.partnerInvalidToken.description, errorConfig.partnerUserNotSubscribed.code) }; //R15 TODO: Update the message.    
			case "partner/user-plan-expired":
				throw { https: 400, error: apiResponse.error(errorConfig.partnerInvalidToken.description, errorConfig.partnerInvalidToken.code) };
			}
		}
		if (error.status) {
			if (error.status.code == errorConfig.partnerInvalidToken.code) {
				throw { https: 400, error: apiResponse.error(errorConfig.partnerInvalidToken.description, errorConfig.partnerInvalidToken.code) };
			}
			if (error.status.code == errorConfig.invalidPartnerToken.code) {
				throw { https: 400, error: apiResponse.error(errorConfig.invalidPartnerToken.description, errorConfig.partnerInvalidToken.code) };
			}
			if (error.status.code == errorConfig.invalidSsoToken.code) {
				throw { https: 400, error: apiResponse.error(errorConfig.invalidSsoToken.description, errorConfig.invalidSsoToken.code) };
			}
		}
		if (!error.code) throw { https: 500, error: apiResponse.error(errorConfig.requestFailed, 500) };

	}
}




async function getLinkedUser(mobileNumber, userUid) {
	try {
		console.log("Linked partner Mobile Number", mobileNumber, userUid);
		const result = await userProfileService.getUsersInformationByEmail(`${mobileNumber}@voot.com`);
		let linkedUserId;
		const authUser = await userService.getUserByPhone(`${mobileNumber}`);
		const authUserresult = await userProfileService.getUserInformationById(authUser.uid);
		if (!authUserresult.linkedUserId) {
			linkedUserId = authUser.uid;
		}
		let userData,uid;
		// await result.forEach((doc) => {
		//     const uid = doc.uid
		//     userData = doc;
		//     if (!userData.linkedUserId)
		//         linkedUserId = uid;
		// });
		if (!_.has(result, "status")) {
			uid = _.get(result, "uid");
			userData = result;
			if (!userData.linkedUserId)
				linkedUserId = uid;

		}

		if (linkedUserId) {
			console.log("User already found with", linkedUserId);
			// await userService.setCustomUserClaims(userUid, customClaims);
			// await Admin.database.collection(Config.App.users).doc(userUid).set(profileUpdate, { merge: true });
			// await Admin.database.collection(Config.App.users).doc(linkedUserId).set(traditionalProfileUpdate, { merge: true });
			await userProfileService.updateUserInformation({ "uid": userUid }, { linkedUserId: linkedUserId });
			await userProfileService.updateUserInformation({ "uid": linkedUserId }, { linkedUserId: userUid });
		}
		return linkedUserId;
	} catch (e) {
		console.error("Error to find a linked Node ",e);
	}
}

async function getEmailLinkedUser(email, userUid) {
	try {
		console.log("Linked partner Email", email);
		const result = await userProfileService.getUsersInformationByEmail(email);
		let linkedUserId;
		const authUser = await userService.getUserByEmail(email);
		const authUserresult = await userProfileService.getUserInformationById(authUser.uid);
		if (!authUserresult.linkedUserId) {
			linkedUserId = authUser.uid;
		}
		let userData;
		await result.forEach((doc) => {
			const uid = doc.uid;
			userData = doc;
			if (!userData.linkedUserId)
				linkedUserId = uid;
		});
		if (linkedUserId) {
			console.log("User already found with", linkedUserId);
			// await userService.setCustomUserClaims(userUid, customClaims);
			await userProfileService.updateUserInformation({ "uid": userUid }, { linkedUserId: linkedUserId });
			await userProfileService.updateUserInformation({ "uid": linkedUserId }, { linkedUserId: userUid });
			//await Admin.database.collection(Config.App.users).doc(userUid).set(profileUpdate, { merge: true });
			//await Admin.database.collection(Config.App.users).doc(linkedUserId).set(traditionalProfileUpdate, { merge: true });
		}
		return linkedUserId;
	} catch (e) {
		console.error("Error to find a linked Node ",e);
		return false;
	}
}

async function storeKUserId(kUserId, uid, deviceId) {

	let storedata = { "kUserId": kUserId, "deviceId": deviceId };
	const userDocumentUpdated = await userProfileService.updateUserInformation({ "uid": uid }, storedata);
	console.info({ userDocumentUpdated });
}
async function createTempEmail(uId, input) {
	let domainName = _.get(input, "partnerType") ? _.get(input, "partnerType") : config.tSkyDetails.partnerType;
	if (domainName == (config.tSkyDetails.partnerType)) { domainName = config.tSkyDetails.staticEmail; }
	const tempEmail = `${uId}@${domainName.toLowerCase()}.com`;
	return tempEmail;
}

async function kalturaRegistration(email, input, userRecord, userData, deviceDetails = null,tokenExpiryDay=null) {
	let uid;
	try {
		uid = _.get(userRecord, "profileData.uid", _.get(userRecord, "uid", ""));
		//JIO Case 
		if (_.get(input, "partnerType") == config.jioSubscription.partnerType) {
			//input.deviceId = input.deviceId;
			input.deviceBrand = input.partnerType;
		}
		//TataSky Case 
		if (_.has(deviceDetails, "deviceId")) {
			input.deviceId = deviceDetails.deviceId;
		}
		if (_.has(deviceDetails, "deviceBrand")) {
			input.deviceBrand = deviceDetails.deviceBrand;
		}

		try {
			await kalturaService.register(email, uid);
			mixpanelService(mixPanelConfig.externalCallKaltura+"Registration"+mixPanelConfig.success,
				{email:email,uid:uid,distinct_id:_.get(input.data,"uniqueId",_.get(input.data,"externalId",_.get(input.data,"dsn")),uid)},
				_.get(input.data,"uniqueId",_.get(input.data,"externalId",_.get(input.data,"dsn",uid))),null,null,false);
			// return kalturaUserLoginResult

		} catch (error) {
			return apiResponse.error(error);
		}

		const kalturaUserLoginResult = await kalturaService.login(email, uid, input.deviceId);
		mixpanelService(mixPanelConfig.externalCallKaltura+"Login"+mixPanelConfig.success, {email:email,uid:uid,distinct_id:_.get(input.data,"uniqueId",_.get(input.data,"externalId",_.get(input.data,"dsn",uid)))},_.get(input.data,"uniqueId",_.get(input.data,"externalId",_.get(input.data,"dsn",uid))),null,null,false);
		// eslint-disable-next-line no-undef
		const [kalturaHousehold, device, kalturaAppTokenResponse] = await Promise.all([
			kalturaService.createHousehold(email, kalturaUserLoginResult.result.loginSession.ks,uid,_.get(input.data,"uniqueId",_.get(input.data,"externalId",_.get(input.data,"dsn")),email),false),
			kalturaService.setupHouseholdDevice(input.deviceId, input.deviceBrand),
			kalturaService.getAppToken(kalturaUserLoginResult.result.loginSession.ks)
		]);
		if (kalturaUserLoginResult.result.user.householdId !== 0)
			kalturaService.addDeviceToUserHousehold(device, kalturaUserLoginResult.result,null,uid,_.get(input.data,"uniqueId",_.get(input.data,"externalId",_.get(input.data,"dsn",email))),false); // not waiting for response
		let kUserId = _.get(kalturaUserLoginResult, "result.user.id");

		await storeKUserId(kUserId, uid, input.deviceId);
		return await responseFormat.partnerApiResponse(_.get(kalturaHousehold, "result.id"), kalturaUserLoginResult, kalturaAppTokenResponse, userData, userRecord, email, input,tokenExpiryDay);

	}
	catch (error) {
		mixpanelService(mixPanelConfig.externalCallKaltura+"Registration/Login"+mixPanelConfig.error, {email:email,uid:uid,distinct_id:email},uid,null,null,false);
		console.error("Error in Kaltura", error);
		if (!error.code) throw apiResponse.error(errorConfig.requestFailed, 500);
	}
}
async function kalturaLogin(input, tempEmail, userRecord, userData, jioData, partnerDetails,tokenExpiryDay=null) {
	let distinct_id;
	try {
		let uid = _.get(userRecord, "profileData.uid", _.get(userRecord, "uid", ""));

		if (_.get(input, "partnerType") == config.tSkyDetails.partnerType) {
			input.deviceBrand = config.tSkyDetails.deviceBrand;
			//input.deviceId = input.deviceId;//V3API-1096
		}
		if (_.get(input, "partnerType") == config.jioSubscription.partnerType) {
			input.deviceBrand = input.partnerType;
			//input.deviceId = input.deviceId;
		}
		console.debug("Device id", input.deviceId);
		console.debug("DeviceBrand", input.deviceBrand);
		let device = await kalturaService.setupHouseholdDevice(input.deviceId, input.deviceBrand); // Not an API but a promise, do we need to await here?
		console.log("====== Device ==========: ", device);
		let kalturaUserLoginResult;
		distinct_id=_.get(input.data,"uniqueId",_.get(input.data,"externalId",_.get(userRecord,"uniqueId",tempEmail)));
		try {
			kalturaUserLoginResult = await kalturaService.login(tempEmail, uid, device.udid);
			mixpanelService(mixPanelConfig.externalCallKaltura+"Login"+mixPanelConfig.success, {email:tempEmail,uid:uid,distinct_id:distinct_id},distinct_id,null,null,false);
		} catch (error) {
			console.log("Error in kalturalogin function of Partner service",error);
			mixpanelService(mixPanelConfig.externalCallKaltura+"Registration/Login"+mixPanelConfig.error, {email:tempEmail,uid:uid,distinct_id:distinct_id},distinct_id,null,null,false);
			switch (_.get(error, "result.error.code", _.get(error, "code"))) {
			case errorConfig.errorCodes.USER_DOES_NOT_EXIST.code: // Kaltura user does not exists, register as new user

				kalturaRegistration(tempEmail, input, userRecord, userData);
				break;
			case errorConfig.errorCodes.USER_WRONG_USERNAME_OR_PASSWORD.code: // Kaltura user does not exists, register as new user
				kalturaUserLoginResult = await kalturaUserCheckAndRegister(tempEmail, input, uid,device);
				try{
					await storeKUserId(_.get(kalturaUserLoginResult, "result.user.id"), uid);
				}catch(err){
					console.error("Error in storing kuserId from kalturalogin",err);
				}

				break;
			case errorConfig.errorCodes.INSIDE_LOCK_TIME.code: // Kaltura user does not exists, register as new user
				apiResponse.error(errorConfig.errorCodes.INSIDE_LOCK_TIME.message, errorConfig.errorCodes.INSIDE_LOCK_TIME.code);
				break;
			default:
				apiResponse.error("unknown error in kaltura login:", error);
			}
		}

		let kalturaHousehold;

		if (kalturaUserLoginResult.result.user.householdId !== 0) {
			console.log("add device in houseHold:", kalturaUserLoginResult.result.user.householdId);
			await kalturaService.addDeviceToUserHousehold(device, kalturaUserLoginResult.result, kalturaUserLoginResult.result.user.householdId,uid,distinct_id,false); // not waiting for response
			kalturaUserLoginResult.result.user.householdId;
		} else {
			console.log("=================Kaltura HouseHold is 0 for===", tempEmail);
			kalturaHousehold = await kalturaService.createHousehold(tempEmail, kalturaUserLoginResult.result.loginSession.ks,uid,distinct_id,false);
			device = await kalturaService.setupHouseholdDevice(input.deviceId, input.deviceBrand);
			await kalturaService.addDeviceToUserHousehold(device, kalturaUserLoginResult.result, _.get(kalturaHousehold, "result.id"),uid,distinct_id,false); // not waiting for response
			_.get(kalturaHousehold, "result.id");

		}
		const kalturaAppTokenResponse = await kalturaService.getAppToken(kalturaUserLoginResult.result.loginSession.ks);
		return await responseFormat.partnerApiResponse(_.get(kalturaUserLoginResult, "result.user.householdId"), kalturaUserLoginResult, kalturaAppTokenResponse, userData, userRecord, tempEmail, input,tokenExpiryDay);
	}
	catch (error) {
		console.error("Error in kaltura login:", error);
		if (!error.code) throw apiResponse.error(errorConfig.requestFailed, 500);
	}
}
async function kalturaUserCheckAndRegister(tempEmail, input,uid,device){
	// const kaltura = new Kaltura();
	try{
		const kalturaOttListResponse = await kalturaService.getUserByUsernameOrExternalIdNew(tempEmail,uid);
		await kalturaService.updatePasswordAndLogin(tempEmail,uid,kalturaOttListResponse.id);
		return await kalturaService.login(tempEmail, uid, device.udid); //VOOTDESK-1094  //VOOTDESK- 
	}catch(error){
		console.log("Error in kalturaUserCheckAndRegister", error);
		switch (_.get(error, "result.error.code", _.get(error, "code"))) {
		case errorConfig.errorCodes.USER_DOES_NOT_EXIST.code: // Kaltura user does not exists, register as new user
			console.info("Kaltura user does not exist, registering as new");
			await kalturaService.register(tempEmail, uid);
			return await kalturaService.login(tempEmail, uid, device.udid);
		case errorConfig.errorCodes.INSIDE_LOCK_TIME.code: // Kaltura user does not exists, register as new user
			throw({code: errorConfig.errorCodes.INSIDE_LOCK_TIME.code, message: errorConfig.errorCodes.INSIDE_LOCK_TIME.message});

		default:
			console.debug("unknown error in kaltura login: %j", error);
			throw(error);
		}
	}
    
}

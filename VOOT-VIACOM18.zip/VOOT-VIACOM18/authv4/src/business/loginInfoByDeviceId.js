"use strict";
const loginInfoByDeviceIdService = require( "../services" ).loginInfoByDeviceIdService;
const  userProfileService  = require("../services").userProfileService;
const _ = require( "underscore" );
const apiResponse = require( "../utils" ).apiResponse;
const errorConfig = require( "../config" ).errorConfig;
module.exports = { getLoginInfoByDeviceId };
async function getLoginInfoByDeviceId ( deviceId ) {
	try {
		let deviceData = await loginInfoByDeviceIdService.getDataFromDeviceIdLoginDetails( { deviceId: deviceId },{},{ updatedAt: -1},1 );
		console.log( "device Data for uid: ", deviceData[ 0 ].uid );
		if(deviceData[ 0 ].uid){
			const userRecord=await userProfileService.getUserInformationByUid({uid:deviceData[ 0 ].uid},{"profileData.ProfileName":1,"profileData.LastName":1,"profileData.FirstName":1});
			if(userRecord.profileData ){
				deviceData[0].ProfileName = userRecord.profileData.ProfileName;
				if(_.isEmpty(deviceData[0].ProfileName)) deviceData[0].ProfileName = userRecord.profileData.FirstName+""+userRecord.profileData.LastName;
			}
			console.log("deviceData[0]",deviceData[0]);
		}
		return deviceData[ 0 ];
	} catch ( err ) {
		if ( _.has( err, "status" ) ) {
			throw apiResponse.error( errorConfig.deviceDoesNotExist.description, errorConfig.deviceDoesNotExist.code );//response.status( output.httpCode ).send( apiResponse.success( output.responseData ) );
		}
		throw err;
	}
}

"use strict";

module.exports = activateCode;
const { getDeviceCode, updateDeviceCode } = require("../services").deviceActivationCode;
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");

async function activateCode(input) {
	let deviceActivationCode = _.get(input, "code");
	let token = _.get(input, "accessToken");
	const deviceCodeInfo = await getDeviceCode(deviceActivationCode);
	if(_.get(deviceCodeInfo, "status", 0) == 1752){
		throw new Error(errorConfig.invalidDeviceActivationCode.code);
	}
	let codeExpireDate = _.get(deviceCodeInfo, "expiresAt");
	if (Date.now() > codeExpireDate) {
		throw new Error(errorConfig.expiredDeviceActivationCode.code);
	}
	let activateCodeResponse = await updateDeviceCode(deviceActivationCode, token);
	if (_.has(activateCodeResponse, "status")) {
		return {
			data: {
				message: _.get(activateCodeResponse, "message")
			}
		};
	}
	return {
		data: {
			message: errorConfig.loginCodeDeviceActivationSuccess
		}
	};
}
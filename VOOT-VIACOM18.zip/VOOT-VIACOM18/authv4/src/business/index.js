const login = require("./login");
const signUp = require("./signUp");
const updateAccount = require("./updateAccount");
const { googleLogin, fbLogin } = require("./socialLogin");
const checkEmail = require("./checkEmail");
const loginCode = require("./loginCode");
const activateCode = require("./activateCode");
const verifyCode = require("./verifyCode");
const forgotPassword = require("./forgotPassword");
const passwordChange = require("./passwordChange");
const profileAccessToken = require("./profileAccessToken");
const refreshAccessToken = require("./refreshAccessToken");
const refreshKs = require("./refreshKs");
const kalturaBL = require("./kalturaBL");
const authKey = require("./authKey");
const jioEntitlement = require("./jioEntitlement");
const jioSubscription = require("./jioSubscription");
const deltaMigration = require("./deltaMigration");
const updateProfile =require("./updateProfile");
const deleteProfile = require("./deleteProfile");
const getUserProfile =require("./getUserProfile");
const verifyOtpForgotPassword =require("./verifyOtpForgotPassword");
const resetPasswordWithLogin=require("./resetPasswordWithLogin");
const changePasswordWithLogin=require("./changePasswordWithLogin"); 
const appleRedirect = require("./appleRedirect"); 
const checkUser=require("./checkUser").checkUser;
const resendOtp =require("./resendOtp");
const verifyOtp= require("./verifyOtp").verifyOtp;
const resetPassword=require("./resetPassword");
const partnerNotification = require("./partnerNotification");
const partnerSignIn = require("./partnerSignIn").partnerSignInUp;
const m2mitNotification = require("./m2mit").m2mitNotification;
const remoteConfig = require("./remoteConfig").getRemoteConfig;
const partnerDetails=require("./partnerDetails");
const anonymousTokenBusiness = require("./AnonymousTokenBusiness");
const authsTokens = require("./authsTokens");
const getOtpDetails = require("./getOtpDetails");
const asynPartnerProcess = require("./asyncPartnerProcess");
const searchDetailsBuisness = require("./searchDetails");
const loginInfoByDeviceIdBusiness = require( "./loginInfoByDeviceId" );
const kalturaBuildBusiness = require("./kalturaBuildBusiness");
const checkKalturaBusiness = require("./checkKalturaAccountBusiness");
const synchCrmData = require( "./synchCrmData" );
const createSubProfile = require( "./createSubProfile" );
const getSubProfiles = require( "./getSubProfiles" );
const getSubProfilesAccessToken = require( "./getSubProfilesAccessToken" );
const deleteSubProfile = require( "./deleteSubProfile" );
const updateSubProfile = require( "./updateSubProfile" );


const sendMessage = require( "./sendMessage" );
const smsData = require("./smsData");

module.exports = {
	login,
	signUp,
	googleLogin,
	fbLogin,
	updateAccount,
	updateProfile,
	checkEmail,
	loginCode,
	activateCode,
	verifyCode,
	forgotPassword,
	passwordChange,
	profileAccessToken,
	refreshAccessToken,
	refreshKs,
	kalturaBL,
	authKey,
	jioEntitlement,
	jioSubscription,
	deltaMigration,
	deleteProfile,
	getUserProfile,
	verifyOtpForgotPassword,
	resetPasswordWithLogin,
	changePasswordWithLogin,
	appleRedirect,
	checkUser,
	resendOtp,
	verifyOtp,
	resetPassword,
	partnerNotification,
	partnerSignIn,
	m2mitNotification,
	remoteConfig,
	partnerDetails,
	anonymousTokenBusiness,
	authsTokens,
	getOtpDetails,
	asynPartnerProcess,
	searchDetailsBuisness,
	loginInfoByDeviceIdBusiness,
	kalturaBuildBusiness,
	checkKalturaBusiness,
	synchCrmData,
	getSubProfiles,
	createSubProfile,
	getSubProfilesAccessToken,
	deleteSubProfile,
	updateSubProfile,
	sendMessage,
	smsData
};
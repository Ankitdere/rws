"use strict";

module.exports = verifyCode;
const { getDeviceCode,deleteDeviceCode } = require("../services").deviceActivationCode;
const {errorConfig,configuration} = require("../config");
const tokenService = require("../services").tokenService;
const responseFormat = require("../format").responseFormat;
const _ = require("lodash");
const kalturaBL = require("./kalturaBL");
const { kafkaService, notificationService } = require("../services");

async function verifyCode(input) {
	// TODO: Error => invalidDeviceActivationCode, requestFailed
	console.log("Inside Verify Code with input params",input);
	console.debug("Inside Verify Code with input deviceBrand",_.get(input, "deviceBrand"));
	const activatedDevice = await getDeviceCode(_.get(input, "code"));
	// currently unknown error
	if (_.has(activatedDevice, "status")) {
		throw new Error(errorConfig.invalidDeviceActivationCode.code);
	}
	let codeExpireDate = _.get(activatedDevice, "expiresAt");
	if (Date.now() > codeExpireDate) {
		throw new Error(errorConfig.expiredDeviceActivationCode.code);
	}
	// deviceId does not match in doc
	if (!_.isEqual(_.get(activatedDevice, "deviceId"), _.get(input, "deviceId")))
		throw new Error(errorConfig.invalidDeviceId.code);

	// deviceBrand does not match in doc
	if (!_.isEqual(_.get(activatedDevice, "deviceBrand"), _.get(input, "deviceBrand")))
		throw new Error(errorConfig.invalidDeviceBrand.code);

	let accessToken = _.get(activatedDevice, "accessToken");
	if (!accessToken)
		throw new Error(errorConfig.loginCodeDeviceActivationFailure.code);

	let { decoded, user } = await tokenService.verifyToken(accessToken);

	if (!decoded) {
		throw new Error(errorConfig.invalidAccessToken.code);
	}
	console.debug("token data", decoded);
	user = responseFormat.responseUpdateProfileData(user);
	// TODO: Kaltura Implementation 
	/* const v3loginResponse = await this.loginKalturaAndCreateResponse(loginCodeReq, {
		uid: _.get(decoded, 'uid'),
		email: _.get(decoded, 'email', _.get(userDetails, 'email'))
	}, userDetails); */
	
	const { uid, email } = user;
	if (configuration.kafkaConfig.enable.isUpdateAuth && input.regionInfo &&
		((input.regionInfo.region !== user.region) || (input.regionInfo.country !== user.country))
	) { 
		const regionNotificationObj = await notificationService.createRegionNotification(
			user,
			_.get(input, "regionInfo", {})
		);
		kafkaService.pushEventToKafka(configuration.kafkaConfig.topic.updateAuthData, regionNotificationObj);
	}
	let kalthuraLoginResponse = await kalturaBL.doKalturaLogin(input, { uid, email }, user);
	console.log("Userdetails fetched from Mongo",JSON.stringify(user));
	const v3loginResponse = await responseFormat.v3LoginResponse(user, user, input, kalthuraLoginResponse);
	console.log("Authtoken", v3loginResponse.data.authToken);
	
	// isFirstLogin
	let isFirstLogin = _.get(v3loginResponse, "data.isFirstLogin");
	await deleteDeviceCode(_.get(input, "code"));
	
	if (isFirstLogin === true || isFirstLogin == undefined) {
		_.set(v3loginResponse, "data.isFirstLogin", false);
	}
	// TODO: Delete the login code
	return v3loginResponse;
}
/* eslint-disable no-undef */
const JWT = require("jsonwebtoken");
const Moment = require("moment");
const Config = require("../config/configuration");
const To = require("../utils/to");
const ModuleError = require("../errors/module");
const HttpRestUtil = require("../utils/http/rest");
const RandomUtil = require("../utils/random");
const JwtUtil = require("../utils/jwt");
const GenericValidationUtil = require("../utils/validate/generic");
const GenericConstantUtil = require("../utils/constant/generic");
const ConverterUtil = require("../utils/converter");
const PxApiService = require("../services/pxApiService");
const KalturaService = require("../services/kalturaService");
const PartnerUserService = require("../services/partnerUser");
const notificationService = require("../services/notificationService");
const kafkaService = require("../services/kafkaService");
const config = require("../config/configuration");
const mixpanelService = require("../services/mixpanelService");
const _ = require("lodash");
const commonUtil = require("../utils").common;
const mixpanelConfig = require("../config/mixPanelConfig");
const randomId = require("randomstring");

module.exports = {
	getOne: getOne,
	createOne: createOne,
	getOneSubscriptionForOne: getOneSubscriptionForOne,
	createOneSubscriptionForOne: createOneSubscriptionForOne,
	updateOneSubscriptionForOne: updateOneSubscriptionForOne,
	registerOneInKaltura: registerOneInKaltura,
	updateStatusForOne: updateStatusForOne,
	getStatusForOne: getStatusForOne,
	loginOne: loginOne,
	refreshOneToken: refreshOneToken,
	getOnePlan: getOnePlan,
	getBillingHistoryForOneUser: getBillingHistoryForOneUser,
	createAsyncOne:createAsyncOne,
	updateAsyncStatusForOne:updateAsyncStatusForOne
};

/**
 * Get one partner user
 * @param authUser 
 * @param user 
 * @param params 
 * @param flags 
 */
async function getOne(authUser, user, params, flags) {
	try {
		// Initialize
		let error, result;

		// Get
		[error, result] = await To(PartnerUserService.getOne(authUser, user, params, flags));
		if (error) {
			throw new ModuleError(error.code, error.message, error.data);
		}

		// Response
		if (GenericValidationUtil.isSuccessResponseAndNonEmptyData(result)) {
			return Promise.resolve({ code: result.code, message: result.message, data: result.data });
		} else {
			throw new ModuleError(500, "An error occured while retrieving one partner user.", null);
		}
	} catch (error) {
		if (error && error.code && error.message) {
			return Promise.reject({ code: error.code, message: error.message, data: error.data });
		} else {
			return Promise.reject({ code: 500, message: "An error occured while retrieving one partner user: " + error });
		}
	}
}

/**
 * Create one partner user
 * @param authUser 
 * @param partnerUser 
 * @param params 
 * @param flags 
 */
async function createOne(authUser, partnerUser, params, flags, distinctId = "") {
	try {
		console.log("Start - Partner User Service -> createOne.");
		// Initialize
		let error, existingResult, createResult, existingSubscriptionResult, kalturaResult, pxResult, planResult, kalturaUserLoginResult, billingHistoryResult;
		let existingPartnerUser = null;
		let query, plan, subscription, existingSubscription, accessToken, refreshToken, kalturaSession;
		let response = null;
		let isSubscriptionUpdated = false;
		let billingHistory = [];
		let lastBilling = null;
		let isGrantSubscription = false;
		let updateObj = {};

		console.log("Check if partner user already exists.");
		// Get
		[error, existingResult] = await To(getOne(authUser, { uniqueId: partnerUser.user.uniqueId }, params, flags));
		if (error) {
			if (error.code != 404) {
				throw new ModuleError(error.code, error.message, error.data);
			} else {
				console.log("Partner user doesn't exist with this uniqueId.");

				// Check if partner exists with this mobile number or email
				query = {};
				if (GenericValidationUtil.isValidPhoneNumber(partnerUser.user.mobile)) {
					if (partnerUser.user.mobile.includes("+")) {
						query.mobile = partnerUser.user.mobile;
					} else {
						query.mobile = authUser.partner.default.phone.countryCode + partnerUser.user.mobile;
					}
				} else if (GenericValidationUtil.isValidEmail(partnerUser.user.email)) {
					query.email = partnerUser.user.email;
				}

				if (GenericValidationUtil.isNonEmptyObject(query)) {
					[error, existingResult] = await To(getOne(authUser, query, params, flags));
					if (error) {
						if (error.code != 404) {
							throw new ModuleError(error.code, error.message, error.data);
						} else {
							console.log("Partner user doesn't exist with this mobile/email.");

							// For traditional user
							if (query.mobile) {
								// Populate
								query = {
									email: query.mobile + "@voot.com"
								};

								[error, existingResult] = await To(getOne(authUser, query, params, flags));
								if (error) {
									if (error.code != 404) {
										throw new ModuleError(error.code, error.message, error.data);
									} else {
										console.log("Partner user doesn't exist with this email as traditional user.");

										existingPartnerUser = null;
									}
								}
							}
						}
					}
					if (GenericValidationUtil.isSuccessResponseAndNonEmptyData(existingResult)) {
						// Nothing to do
					} else {
						existingPartnerUser = null;
					}
				}
			}
		}

		if (GenericValidationUtil.isSuccessResponseAndNonEmptyData(existingResult)) {
			if (existingResult.data.db && GenericValidationUtil.isEqualStringsIgnoreCase(existingResult.data.db, "mongo")) {
				existingPartnerUser = ConverterUtil.mongoToPartnerUser(existingResult.data.user);
			} else {
				existingPartnerUser = existingResult.data.user;
			}
			console.log("existingPartnerUser: ", existingPartnerUser);

			// Validate if this user is already having another uniqueId
			if (existingPartnerUser.uniqueId && existingPartnerUser.partnerType // Since uniqueId is specific to partner for now, checing if partnerType is also present
                && existingPartnerUser.uniqueId != partnerUser.user.uniqueId) {
				throw new ModuleError(409, "Another user already exists with a different uniqueId for this mobile/email.", null);
			}
		}

		console.log("Get subscription plan details.");
		// Get plan details
		[error, planResult] = await To(getOnePlan(authUser, { code: partnerUser.subscription.planCode }, null, null));
		if (error) {
			throw new ModuleError(error.code, error.message, error.data);
		} else if (!GenericValidationUtil.isSuccessResponseAndNonEmptyData(planResult)) {
			throw new ModuleError(503, "An error occured while retrieving details for one plan.", null);
		} else {
			plan = planResult.data;
			subscription = {
				startDate: Math.ceil(Date.now() / 1000),
				endDate: Math.ceil(Date.now() / 1000) + plan.duration
			};

			// Populate for partner user
			partnerUser.user.subscription = {
				transactionId: RandomUtil.string(32),
				source: partnerUser.subscription.source || "",
				deviceType: (partnerUser.device.type) ? partnerUser.device.type.toUpperCase() : ""
			};
			if (subscription.startDate) {
				partnerUser.user.subscription.startDate = Moment(subscription.startDate * 1000).format("YYYY-MM-DDTHH:mm:ss.SSS") + "Z";
				partnerUser.user.subscription.activationDate = partnerUser.user.subscription.startDate;
			}
			if (subscription.endDate) {
				partnerUser.user.subscription.endDate = Moment(subscription.endDate * 1000).format("YYYY-MM-DDTHH:mm:ss.SSS") + "Z";
			}
		}

		if (existingPartnerUser) {
			console.log("Partner user already exists.");
			// Partner user already exists

			// Check if kUserId is stored in DB. If not, store it here
			if (!existingPartnerUser.kUserId) {
				console.log("kUserId not present as part of existing details. Performing Kaltura login to retrieve.");
				// Kaltura Login
				kalturaUserLoginResult = await KalturaService.login(existingPartnerUser.email, existingPartnerUser.id, existingPartnerUser.deviceId);
				if (!GenericValidationUtil.isNonEmptyObject(kalturaUserLoginResult)
                    || (GenericValidationUtil.isNonEmptyObject(kalturaUserLoginResult) && !GenericValidationUtil.isNonEmptyObject(kalturaUserLoginResult.result))) {
					mixpanelService(mixpanelConfig.externalCallKaltura + "Login" + mixpanelConfig.error + mixpanelConfig.yuppTv, { email: existingPartnerUser.email, uid: existingPartnerUser.id, distinct_id: distinctId }, distinctId, null, null,  false);
					console.error("Unable to perform Kaltura login");
				} else {
					mixpanelService(mixpanelConfig.externalCallKaltura + "Login" + mixpanelConfig.success + mixpanelConfig.yuppTv, { email: existingPartnerUser.email, uid: existingPartnerUser.id, distinct_id: distinctId }, distinctId, null, null,false);
					kalturaSession = {
						token: kalturaUserLoginResult.result.loginSession.ks,
						expiry: kalturaUserLoginResult.result.loginSession.expiry,
						kUserId: kalturaUserLoginResult.result.user.id
					};
				}
			}

			// Check if this user already has a valid subscription.
			[error, existingSubscriptionResult] = await To(getOneSubscriptionForOne(authUser, { id: existingPartnerUser.id, email: existingPartnerUser.email }, null, null,distinctId));
			console.log("Subscription Status: =====", existingSubscriptionResult);
			if (error) {
				throw new ModuleError(error.code, error.message, error.data);
			} else if (!GenericValidationUtil.isSuccessResponseAndNonEmptyData(existingSubscriptionResult)) {
				throw new ModuleError(500, "An error occured while retrieving existing subscription details for one partner user.", null);
			} else {
				existingSubscription = existingSubscriptionResult.data;
				console.log("existingSubscription: ", existingSubscription);
				if (GenericValidationUtil.isEqualStringsIgnoreCase(existingSubscription.status, Config.pXApiDetails.activeSubcriptionAction)) {
					console.log("Partner user already has an active subscription.");
					throw new ModuleError(409, "Partner user already has an active subscription.", null);
				} else if (GenericValidationUtil.isEqualStringsIgnoreCase(existingSubscription.status, Config.pXApiDetails.expiredSubcriptionAction)) {
					// Renew subscription
					console.log("Partner's existing subscription is expired. Hence renewing it");

					// Get Billing History to identify last transaction type
					[error, billingHistoryResult] = await To(getBillingHistoryForOneUser(
						authUser,
						{
							id: existingPartnerUser.id,
							email: existingPartnerUser.email,
							kUserId: existingPartnerUser.kUserId || kalturaSession.kUserId,
							device: {
								id: existingPartnerUser.deviceId,
							}
						},
						null,
						null,
						distinctId
					));
					if (error) {
						console.error("An error occured while retrieving billing history for one partner user:");
						console.error(error);
						throw new ModuleError(500, "An error occured while retrieving billing history for one partner user.", null);
					} else if (!GenericValidationUtil.isSuccessResponse(billingHistoryResult)) {
						throw new ModuleError(500, "An error occured while retrieving billing history for one partner user.", null);
					} else {
						billingHistory = billingHistoryResult.data;
						if (GenericValidationUtil.isNonEmptyArray(billingHistory)) {
							lastBilling = billingHistory[0];
							console.log("lastBilling: ", lastBilling);
						} else {
							console.log("No billing history found for this partner user.");
						}
					}

					// Check if we've to grant a new subscription or renew
					// Verify if "renew"ing subscription of existing partner user
					if (lastBilling && lastBilling.paymentDetails && lastBilling.paymentDetails.extras && lastBilling.paymentDetails.extras.mode
                        && GenericValidationUtil.isEqualStringsIgnoreCase(lastBilling.paymentDetails.extras.mode, GenericConstantUtil.BILLING.PAYMENT_DETAILS.MODE.PARTNER)) {
						if (lastBilling.itemDetails && lastBilling.itemDetails.name
                            && !GenericValidationUtil.isEqualStringsIgnoreCase(lastBilling.itemDetails.name, authUser.partner.default.subscription.code)) {
							isGrantSubscription = true;
						} else {
							isGrantSubscription = false;
						}
					} else {
						isGrantSubscription = true;
					}

					if (isGrantSubscription) {
						[error, pxResult] = await To(createOneSubscriptionForOne(
							authUser,
							{
								id: existingPartnerUser.id,
								email: existingPartnerUser.email,
								device: {
									id: partnerUser.device.id,
									brand: authUser.partner.default.device.brand
								},
								subscription: {
									startDate: subscription.startDate,
									endDate: subscription.endDate
								},
								kUserId: existingPartnerUser.kUserId || kalturaSession.kUserId
							},
							null,
							null,
							distinctId
						));
					} else {
						[error, pxResult] = await To(updateOneSubscriptionForOne(
							authUser,
							{
								id: existingPartnerUser.id,
								email: existingPartnerUser.email,
								device: {
									id: partnerUser.device.id,
									branch: partnerUser.device.brand
								},
								subscription: {
									startDate: subscription.startDate,
									endDate: subscription.endDate,
									action: Config.pXApiDetails.renewSubcriptionAction
								},
								kUserId: existingPartnerUser.kUserId || kalturaSession.kUserId
							},
							null,
							null,
							distinctId
						));
					}
					if (error) {
						console.dir(error);
						throw new ModuleError(error.code, error.message, error.data);
					} else if (!GenericValidationUtil.isSuccessResponse(pxResult)) {
						throw new ModuleError(503, "An error occured while renewing subscription.", null);
					} else {
						console.log("Subscription renewed successfully.");
						isSubscriptionUpdated = true;
					}
				} else if (GenericValidationUtil.isEqualStringsIgnoreCase(existingSubscription.status, Config.pXApiDetails.newSubcriptionAction)) {
					console.log("No subscription exists for this partner user. Hence, creating one.");
					// Create new subscription
					[error, pxResult] = await To(createOneSubscriptionForOne(
						authUser,
						{
							id: existingPartnerUser.id,
							email: existingPartnerUser.email,
							device: {
								id: partnerUser.device.id,
								brand: authUser.partner.default.device.brand
							},
							subscription: {
								startDate: subscription.startDate,
								endDate: subscription.endDate
							},
							kUserId: existingPartnerUser.kUserId || kalturaSession.kUserId
						},
						null,
						null,
						distinctId
					));
					if (error) {
						console.dir(error);
						throw new ModuleError(error.code, error.message, error.data);
					} else if (!GenericValidationUtil.isSuccessResponse(pxResult)) {
						throw new ModuleError(503, "An error occured while creating subscription.", null);
					} else {
						console.log("Subscription created successfully.");
						isSubscriptionUpdated = true;
					}
				} else {
					console.log("Unable to identify current subscription status for this partner user.");
					throw new ModuleError(500, "Unable to identify current subscription status for this partner user.", null);
				}

				if (isSubscriptionUpdated) {
					console.log("Updating subscription details in Firestore.");
					// Update subscription details
					// Populate
					updateObj = {
						id: existingPartnerUser.id,
						uid: existingPartnerUser.uid,
						uniqueId: partnerUser.user.uniqueId,
						deviceId: partnerUser.device.id,
						// kUserId: kalturaSession.kUserId,
						isActive: true,
						subscription: {
							startDate: Moment(subscription.startDate * 1000).format("YYYY-MM-DDTHH:mm:ss.SSS") + "Z",
							endDate: Moment(subscription.endDate * 1000).format("YYYY-MM-DDTHH:mm:ss.SSS") + "Z",
							transactionId: RandomUtil.string(32),
							activationDate: (existingPartnerUser.subscription && existingPartnerUser.subscription.activationDate) ? existingPartnerUser.subscription.activationDate : partnerUser.user.subscription.startDate
						},
						partnerType: existingPartnerUser.partnerType || authUser.partner.code
					};
					//for other partner user change partnerType
					if(existingPartnerUser.partnerType!=authUser.partner.code){
						updateObj.partnerType = authUser.partner.code;
					}

					if (!GenericValidationUtil.isNonEmptyObject(kalturaSession)) {
						console.log("Retrieving Kaltura login session details:");

						// Kaltura Login
						kalturaUserLoginResult = await KalturaService.login(existingPartnerUser.email, existingPartnerUser.id, partnerUser.device.id);
						if (!GenericValidationUtil.isNonEmptyObject(kalturaUserLoginResult)
                            || (GenericValidationUtil.isNonEmptyObject(kalturaUserLoginResult) && !GenericValidationUtil.isNonEmptyObject(kalturaUserLoginResult.result))) {
							mixpanelService(mixpanelConfig.externalCallKaltura + "Login" + mixpanelConfig.error + mixpanelConfig.yuppTv, { email: existingPartnerUser.email, uid: existingPartnerUser.id, distinct_id: distinctId }, distinctId, null, null,  false);
							console.error("Unable to perform Kaltura login");
						} else {
							kalturaSession = {
								token: kalturaUserLoginResult.result.loginSession.ks,
								expiry: kalturaUserLoginResult.result.loginSession.expiry,
								kUserId: kalturaUserLoginResult.result.user.id
							};
							mixpanelService(mixpanelConfig.externalCallKaltura + "Login" + mixpanelConfig.success + mixpanelConfig.yuppTv, { email: existingPartnerUser.email, uid: existingPartnerUser.id, distinct_id: distinctId }, distinctId, null, null,  false);
							updateObj.kUserId = kalturaSession.kUserId;
						}
					} else if (kalturaSession.kUserId) {
						updateObj.kUserId = kalturaSession.kUserId;
					}
					[error, updateResult] = await To(PartnerUserService.updateOne(authUser, updateObj, null, null));
					if (error) {
						throw new ModuleError(error.code, error.message, error.data);
					} else {
						console.log("Subscription details updated successfully in firestore for: " + partnerUser.user.uniqueId);

					}
				}
			}
		} else {
			// Partner user doesn't exist
			// Populate defaults
			partnerUser.user.partnerType = authUser.partner.code;
			partnerUser.user.deviceId = partnerUser.device.id;
			partnerUser.user.isActive = true;
			partnerUser.user.profileData = {
				Gender: "U",
				Preferences: {
					Languages: ["Hindi", "English"]
				},
				FirstName: authUser.partner.code,
				LastName: authUser.partner.code,
				FullName: authUser.partner.code + " " + authUser.partner.code,
			};

			if (GenericValidationUtil.isValidPhoneNumber(partnerUser.user.mobile) && partnerUser.user.mobile.length == 10) {
				partnerUser.user.mobile = authUser.partner.default.phone.countryCode + partnerUser.user.mobile;
				partnerUser.user.phoneCountryCode = authUser.partner.default.phone.countryCode;
			}
			if (!partnerUser.user.email) {
				if (partnerUser.user.mobile) {
					partnerUser.user.email = partnerUser.user.mobile + "@" + authUser.partner.domain.email;
				} else {
					partnerUser.user.email = partnerUser.user.uniqueId + "@" + authUser.partner.domain.email;
				}
			}
			partnerUser.user.tempEmail = partnerUser.user.email;
			console.log("Create one partner user.");

			// Create
			[error, createResult] = await To(PartnerUserService.createOne(authUser, partnerUser.user, params, flags));
			if (error) {
				throw new ModuleError(error.code, error.message, error.data);
			}
			if (GenericValidationUtil.isSuccessResponseAndNonEmptyData(createResult)) {
				console.log("One partner user created successfully.");

				existingPartnerUser = createResult.data.mongo || createResult.data.firestore;

				console.log("Existing Partner User: ", existingPartnerUser);

				// Kaltura Registration
				[error, kalturaResult] = await To(registerOneInKaltura(
					authUser,
					existingPartnerUser,
					{
						id: partnerUser.device.id,
						brand: authUser.partner.default.device.brand,
						partnerType: authUser.partner.code
					},
					null,
					null,
					distinctId
				));
				if (error) {
					throw new ModuleError(error.code, error.message, error.data);
				} else if (!GenericValidationUtil.isSuccessResponse(kalturaResult)) {
					throw new ModuleError(503, "An error occured while registering user with Kaltura.", null);
				} else {
					console.log("One partner user registered successfully with Kaltura.");
					kalturaSession = {
						token: kalturaResult.data.token,
						expiry: kalturaResult.data.expiry,
						kUserId: kalturaResult.data.kUserId
					};
					mixpanelService(mixpanelConfig.externalCallKaltura + "Register" + mixpanelConfig.success + mixpanelConfig.yuppTv, { email: existingPartnerUser.email, uid: existingPartnerUser.id, distinct_id: distinctId }, distinctId, null, null,  false);
				}

				// PX Subscription
				[error, pxResult] = await To(createOneSubscriptionForOne(
					authUser,
					{
						id: existingPartnerUser.id,
						email: existingPartnerUser.email,
						device: {
							id: partnerUser.device.id,
							brand: authUser.partner.default.device.brand
						},
						subscription: {
							startDate: subscription.startDate,
							endDate: subscription.endDate
						},
						kUserId: kalturaSession.kUserId
					},
					null,
					null,
					distinctId
				));
				if (error) {
					console.dir(error);
					throw new ModuleError(error.code, error.message, error.data);
				} else if (!GenericValidationUtil.isSuccessResponse(pxResult)) {
					console.log(pxResult);
					throw new ModuleError(503, "An error occured while providing PX subscription.", null);
				} else {
					// Nothing to do
					console.log("Subscription created successfully.");
				}
			} else {
				throw new ModuleError(500, "An error occured while creating one partner user.", null);
			}
		}

		// Prepare
		accessToken = JWT.sign(
			{
				uId: existingPartnerUser.id,
				uniqueId: partnerUser.user.uniqueId,
			},
			authUser.partner.jwt.secret.refresh,
			{
				expiresIn: authUser.partner.jwt.expiry.access
			}
		);
		refreshToken = JWT.sign(
			{
				uId: existingPartnerUser.id,
				uniqueId: partnerUser.user.uniqueId,
			},
			authUser.partner.jwt.secret.refresh,
			{
				expiresIn: authUser.partner.jwt.expiry.refresh
			}
		);
		response = {
			uId: existingPartnerUser.id,
			mobile: partnerUser.user.mobile,
			email: partnerUser.user.email,
			auth: {
				access: {
					token: accessToken,
					expiry: JWT.decode(accessToken)["exp"]
				},
				refresh: {
					token: refreshToken,
					expiry: JWT.decode(refreshToken)["exp"]
				},
				playback: {
					token: (kalturaSession) ? kalturaSession.token : null,
					expiry: (kalturaSession) ? kalturaSession.expiry : null
				}
			},
			subscription: {
				activationDate: (partnerUser.user.subscription) ? partnerUser.user.subscription.activationDate : null,
				startDate: (partnerUser.user.subscription) ? partnerUser.user.subscription.startDate : null,
				endDate: (partnerUser.user.subscription) ? partnerUser.user.subscription.endDate : null,
				transactionId: (partnerUser.user.subscription) ? partnerUser.user.subscription.transactionId : null,
			}
		};
		console.log("End - Partner User Service -> createOne.",{ code: 200, message: "Successfully created one partner user.", data: response });

		// Response
		return Promise.resolve({ code: 200, message: "Successfully created one partner user.", data: response });
	} catch (error) {
		console.error("Error - Partner User Service -> createOne.");
		console.error(error);
		if (error && error.code && error.message) {
			return Promise.reject({ code: error.code, message: error.message, data: error.data });
		} else {
			return Promise.reject({ code: 500, message: "An error occured while creating one partner user: " + error });
		}
	}
}

/**
 * Get one subscription for one partner user
 * @param authUser 
 * @param user 
 * @param params 
 * @param flags 
 */
async function getOneSubscriptionForOne(authUser, user, params, flags,distinctId) {
	try {
		// Initialize
		let error, pxResult, tempAccessTokenResult;
		let pxAccessToken = null;
		let response = {};

		// Generate temporary access token
		[error, tempAccessTokenResult] = await To(JwtUtil.createOneTemporary(
			{
				userId: user.id,
				email: user.email,
				issuer: authUser.partner.product.voot,
				expiryDurationInSecs: 6000, // 10 mins
				jwt: {
					secret: Config.jwt.secret
				},
				kUserId: user.kUserId
			},
			null,
			null
		));
		if (error) {
			throw new ModuleError(error.code, error.message, error.data);
		} else if (!GenericValidationUtil.isSuccessResponseAndNonEmptyData(tempAccessTokenResult)) {
			throw new ModuleError(500, "An error occured while generating token to retrieve subscription details for one partner user.", null);
		} else {
			pxAccessToken = tempAccessTokenResult.data.token;
		}

		console.log("pxAccessToken: ", pxAccessToken);

		// Get status
		pxResult = await PxApiService.checkEntitlementStatus(pxAccessToken);
		if (GenericValidationUtil.isNonEmptyObject(pxResult)) {
			response = {
				status: pxResult.status
			};
		} else {
			mixpanelService(mixpanelConfig.pxCall+mixpanelConfig.checkEntitlement+mixpanelConfig.error+mixpanelConfig.yuppTv,
				pxAccessToken
				,distinctId,error,null,false);
			throw new ModuleError(500, "An error occured while retrieving subscription for one partner user.", null);
		}

		// Response
		return Promise.resolve({ code: 200, message: "Successfully retrieved subscription details for one partner user.", data: response });
	} catch (error) {
		console.error("Error - Partner User Service - getOneSubscriptionForOne");
		if (error && error.code && error.message) {
			return Promise.reject({ code: error.code, message: error.message, data: error.data });
		} else {
			return Promise.reject({ code: 500, message: "An error occured while retrieving subscription details for one partner user: " + error });
		}
	}
}

/**
 * Create one subscription for one partner user
 * @param authUser 
 * @param user 
 * @param params 
 * @param flags 
 */
async function createOneSubscriptionForOne(authUser, user, params, flags, distinctId = "") {
	let error, pxResult, tempAccessTokenResult;
	let pxRequestHeaders = {};
	let pxRequestBody = {};
	let pxAccessToken = null;
	let eventName;
	try {
		// Initialize


		// Generate temporary access token
		[error, tempAccessTokenResult] = await To(JwtUtil.createOneTemporary(
			{
				userId: user.id,
				email: user.email,
				issuer: authUser.partner.product.voot,
				expiryDurationInSecs: 6000, // 10 mins
				jwt: {
					secret: Config.jwt.secret
				},
				kUserId: user.kUserId
			},
			null,
			null
		));
		if (error) {
			throw new ModuleError(error.code, error.message, error.data);
		} else if (!GenericValidationUtil.isSuccessResponseAndNonEmptyData(tempAccessTokenResult)) {
			throw new ModuleError(500, "An error occured while generating token to create a subscription for one partner user.", null);
		} else {
			pxAccessToken = tempAccessTokenResult.data.token;
		}

		pxRequestHeaders = {
			"Content-Type": "application/json",
			product: authUser.partner.product.voot,
			accesstoken: pxAccessToken
		};
		pxRequestBody = {
			details: {
				device: {
					id: user.device.id,
					brand: user.device.brand,
				},
				platform: authUser.partner.platform.stb,
				subStartDate: user.subscription.startDate,
				subEndDate: user.subscription.endDate,
				partnerName: authUser.partner.default.subscription.code
			}
		};

		console.log("URL: ", `https://${Config.pXApiDetails.host}/${Config.pXApiDetails.partnerOrderSrvice}`);
		console.log("Request Headers: ", pxRequestHeaders);
		console.log("Request Body: ", pxRequestBody);

		// Call PX API
		[error, pxResult] = await To(HttpRestUtil.post(
			`https://${Config.pXApiDetails.host}/${Config.pXApiDetails.partnerOrderSrvice}`,
			pxRequestHeaders,
			pxRequestBody,
			null
		));
		if (error) {
			console.dir(error);
			throw new ModuleError(error.code, error.message, error.data);
		} else if (!GenericValidationUtil.isSuccessResponse(pxResult)) {
			throw new ModuleError(503, "An error occured while creating subscription for one partner user.", null);
		} else {
			// Nothing to do
		}

		// Response
		eventName = await commonUtil.preparePartnerEventName("POST", Config.pXApiDetails.partnerOrderSrvice, false, false, mixpanelConfig.success + mixpanelConfig.partnerOrderPost + mixpanelConfig.yuppTv);
		let eventProps = { userInput: pxRequestHeaders, input: pxRequestHeaders, Message: "Successfully created a subscription for one partner user.", ErrorCode: "", distinct_id: distinctId, StatusCode: 200 };
		mixpanelService(eventName, eventProps, distinctId, null, null, false);
		return Promise.resolve({ code: 200, message: "Successfully created a subscription for one partner user.", data: null });
	} catch (error) {
		eventName = await commonUtil.preparePartnerEventName("POST", Config.pXApiDetails.partnerOrderSrvice, false, false, mixpanelConfig.error + mixpanelConfig.partnerOrderPost + mixpanelConfig.yuppTv);
		let eventProps = { userInput: pxRequestHeaders, input: pxRequestHeaders, Message: error.message, ErrorCode: _.get(error, "code"), distinct_id: distinctId, StatusCode: error.code };
		mixpanelService(eventName, eventProps, distinctId, null, null, false);
		console.error("Error - Partner User Service - createOneSubscriptionForOne");
		if (error && error.code && error.message) {
			return Promise.reject({ code: error.code, message: error.message, data: error.data });
		} else {
			return Promise.reject({ code: 500, message: "An error occured while creating subscription one partner user: " + error });
		}
	}
}

/**
 * Update one subscription for one partner user
 * @param authUser 
 * @param user 
 * @param params 
 * @param flags 
 */
async function updateOneSubscriptionForOne(authUser, user) {
	let error, pxResult, tempAccessTokenResult;
	let pxAccessToken = null;
	try {
		// Initialize


		// Generate temporary access token
		[error, tempAccessTokenResult] = await To(JwtUtil.createOneTemporary(
			{
				userId: user.id,
				email: user.email,
				issuer: authUser.partner.product.voot,
				expiryDurationInSecs: 6000, // 10 mins
				jwt: {
					secret: Config.jwt.secret
				},
				kUserId: user.kUserId
			},
			null,
			null
		));
		if (error) {
			throw new ModuleError(error.code, error.message, error.data);
		} else if (!GenericValidationUtil.isSuccessResponseAndNonEmptyData(tempAccessTokenResult)) {
			throw new ModuleError(500, "An error occured while generating token to update subscription status for one partner user.", null);
		} else {
			pxAccessToken = tempAccessTokenResult.data.token;
		}

		// Update status
		console.log("Calling PX renew/cancel API.");
		//for mixpanel call
		pxResult = await PxApiService.callRenewCancelPxApi(user.id, pxAccessToken, user.subscription.endDate, user.subscription.action);
		console.log("pxResult for renew/cancel API: ", pxResult);
		if (GenericValidationUtil.isNonEmptyObject(pxResult) && GenericValidationUtil.isNonEmptyObject(pxResult.result)
            && pxResult.result.message == "success") {
			// Response
			return Promise.resolve({ code: 200, message: "Successfully updated subscription status for one partner user.", data: null });
		} else {
			throw new ModuleError(500, "An error occured while updating subscription status for one partner user.", null);
		}
	} catch (error) {
		console.error("Error - Partner User Service - updateOneSubscriptionForOne");
		console.error(error);
		if (error && error.code && error.message) {
			return Promise.reject({ code: error.code, message: error.message, data: error.data });
		} else {
			return Promise.reject({ code: 500, message: "An error occured while updating subscription status one partner user: " + error });
		}
	}
}

/**
 * Register one partner user in Kaltura
 * @param authUser 
 * @param user 
 * @param device 
 * @param params 
 * @param flags 
 */
async function registerOneInKaltura(authUser, user, device, params, flags,distinctId="") {
	try {
		// Initialize
		let error, kalturaUserLoginResult, kalturaHouseholdResult, kalturaDeviceResult, kalturaAppTokenResult;

		// Assign
		device.brand = "Android";

		// Register user in Kaltura
		await KalturaService.register(user.email, user.id);

		// Kaltura Login
		kalturaUserLoginResult = await KalturaService.login(user.email, user.id, device.id);
		if (!GenericValidationUtil.isNonEmptyObject(kalturaUserLoginResult) && !GenericValidationUtil.isNonEmptyObject(kalturaUserLoginResult.result)) {
			throw new ModuleError(503, "Unable to perform Kaltura login. Please try again.", null);
		}

		// Retrieve details from Kaltura
		[kalturaHouseholdResult, kalturaDeviceResult, kalturaAppTokenResult] = await Promise.all([
			KalturaService.createHousehold(user.email, kalturaUserLoginResult.result.loginSession.ks),
			KalturaService.setupHouseholdDevice(device.id, device.brand),
			KalturaService.getAppToken(kalturaUserLoginResult.result.loginSession.ks)
		]);
		if (!GenericValidationUtil.isNonEmptyObject(kalturaAppTokenResult) && !GenericValidationUtil.isNonEmptyObject(kalturaAppTokenResult.result)) {
			throw new ModuleError(503, "Unable to retrieve access tokens from Kaltura. Please try again.", null);
		}

		kTokenId = kalturaAppTokenResult.result.id;
		kToken = kalturaAppTokenResult.result.token;

		// Add device to user household
		await KalturaService.addDeviceToUserHousehold(kalturaDeviceResult, kalturaUserLoginResult.result, kalturaHouseholdResult.result.id);

		// Grant Entitlement - This is happening in PX API. So no need
		// await KalturaService.garntSubscription(kalturaUserLoginResult.result.user.id);

		// Update Kaltura UserID
		console.log("Updating kUserId: ", kalturaUserLoginResult.result.user.id, " for user with id: ", user.id);
		[error, updateResult] = await To(PartnerUserService.updateOne(authUser, { id: user.id, uid: user.id, kUserId: kalturaUserLoginResult.result.user.id }, null, { isUpdateOnlyUserProfile: true }));
		if (error) {
			console.error("An error occured while updating Kaltura User ID in Firestore:");
			console.error(error);
			// Not throwing any exception for backward compatibility
		}

		// Response
		return Promise.resolve({ code: 200, message: "Successfully registered one partner user in Kaltura.", data: { token: kalturaUserLoginResult.result.loginSession.ks, expiry: kalturaUserLoginResult.result.loginSession.expiry, kUserId: kalturaUserLoginResult.result.user.id } });
	} catch (error) {
		mixpanelService(mixpanelConfig.externalCallKaltura + "register" + mixpanelConfig.error + mixpanelConfig.yuppTv, { email: user.email, uid: user.id, distinct_id: distinctId }, distinctId, error, null, false);
		console.error(error);
		if (error && error.code && error.message) {
			return Promise.reject({ code: error.code, message: error.message, data: error.data });
		} else {
			return Promise.reject({ code: 500, message: "An error occured while registering one partner user in Kaltura: " + error });
		}
	}
}

/**
 * Update status for one partner user
 * @param authUser 
 * @param user 
 * @param params 
 * @param flags 
 */
async function updateStatusForOne(authUser, user, params, flags, distinct_id = "") {
	try {
		// Initialize
		let error, existingResult, existingSubscriptionResult, planResult, pxResult, updateResult, billingHistoryResult;
		let existingPartnerUser = null;
		let plan = null;
		let subscription = null;
		let updateObj = {};
		let billingHistory = [];
		let lastBilling = null;
		let isGrantSubscription = false;
		let query = {};
		let deviceId = "";
		let existingSubscription, pxRequestBody;

		// Get plan details
		if (user.subscription.status) {
			// Get plan details
			[error, planResult] = await To(getOnePlan(authUser, { code: user.subscription.planCode }, null, null));
			if (error) {
				throw new ModuleError(error.code, error.message, error.data);
			} else if (!GenericValidationUtil.isSuccessResponseAndNonEmptyData(planResult)) {
				throw new ModuleError(503, "An error occured while retrieving details for one plan.", null);
			} else {
				plan = planResult.data;
				subscription = {
					startDate: Math.ceil(Date.now() / 1000),
					endDate: Math.ceil(Date.now() / 1000) + plan.duration
				};
			}
		}

		// Get
		[error, existingResult] = await To(getOne(authUser, user, params, flags));
		if (error) {
			if (error.code != 404) {
				throw new ModuleError(error.code, error.message, error.data);
			} else {
				console.log("Partner user doesn't exist with this uniqueId.");

				// Check if partner exists with this mobile number or email
				query = {};
				if (GenericValidationUtil.isValidPhoneNumber(user.uniqueId) || GenericValidationUtil.isValidPhoneNumber(user.phone)) {
					if ((user.uniqueId && user.uniqueId.includes("+")) || (user.phone && user.phone.includes("+"))) {
						query.mobile = user.uniqueId || user.phone;
					} else {
						query.mobile = authUser.partner.default.phone.countryCode + (user.uniqueId || user.phone);
					}
				} else if (GenericValidationUtil.isValidEmail(user.uniqueId) || GenericValidationUtil.isValidEmail(user.email)) {
					query.email = user.uniqueId || user.email;
				}

				if (GenericValidationUtil.isNonEmptyObject(query)) {
					console.log("query: ", query);
					[error, existingResult] = await To(getOne(authUser, query, params, flags));
					if (error) {
						if (error.code != 404) {
							throw new ModuleError(error.code, error.message, error.data);
						} else {
							console.log("Partner user doesn't exist with this mobile/email.");

							// For traditional user
							if (query.mobile) {
								// Populate
								query = {
									email: query.mobile + "@voot.com"
								};

								[error, existingResult] = await To(getOne(authUser, query, params, flags));
								if (error) {
									if (error.code != 404) {
										throw new ModuleError(error.code, error.message, error.data);
									} else {
										console.log("Partner user doesn't exist with this email as traditional user.");

										existingPartnerUser = null;
									}
								}
							}
						}
					}
					if (GenericValidationUtil.isSuccessResponseAndNonEmptyData(existingResult)) {
						// Nothing to do
					} else {
						existingPartnerUser = null;
					}
				}
			}
		}

		if (!GenericValidationUtil.isSuccessResponseAndNonEmptyData(existingResult)) {
			throw new ModuleError(503, "An error occured while retrieving existing partner user details. Please try again.", null);
		} else {
			if (existingResult.data.db && GenericValidationUtil.isEqualStringsIgnoreCase(existingResult.data.db, "mongo")) {
				existingPartnerUser = ConverterUtil.mongoToPartnerUser(existingResult.data.user);
			} else {
				existingPartnerUser = existingResult.data.user;
			}
			console.log("existingPartnerUser: ", existingPartnerUser);

			// Validate if this user is already having another uniqueId
			if (existingPartnerUser.uniqueId && existingPartnerUser.partnerType // Since uniqueId is specific to partner for now, checing if partnerType is also present
                && existingPartnerUser.uniqueId != user.uniqueId) {
				throw new ModuleError(409, "Another user already exists with a different uniqueId for this mobile/email.", null);
			}

			// Assign
			deviceId = existingPartnerUser.deviceId || user.uniqueId || existingPartnerUser.uniqueId || existingPartnerUser.mobile || RandomUtil.string(10);
		}

		// Prepare
		updateObj = {
			uid: existingPartnerUser.uid,
			subscription: {}
		};
		pxRequestBody = {
			id: existingPartnerUser.id,
			email: existingPartnerUser.email,
			kUserId: existingPartnerUser.kUserId,
			subscription: {}
		};

		// Check if this user already has a valid subscription.
		[error, existingSubscriptionResult] = await To(getOneSubscriptionForOne(authUser, { id: existingPartnerUser.id, email: existingPartnerUser.email }, null, null));
		console.log("Subscription Status: =====", existingSubscriptionResult);
		if (error) {
			throw new ModuleError(error.code, error.message, error.data);
		} else if (!GenericValidationUtil.isSuccessResponseAndNonEmptyData(existingSubscriptionResult)) {
			throw new ModuleError(500, "An error occured while retrieving existing subscription details for one partner user.", null);
		} else {
			existingSubscription = existingSubscriptionResult.data;
			console.log("existingSubscription: ", existingSubscription);

			if (GenericValidationUtil.isEqualStringsIgnoreCase(user.subscription.status, Config.pXApiDetails.renewSubcriptionAction)
                && GenericValidationUtil.isEqualStringsIgnoreCase(existingSubscription.status, Config.pXApiDetails.activeSubcriptionAction)) {
				// If expected is "renew" and existing is "active"
				console.log("Partner user already has an active subscription.");
				throw new ModuleError(409, "Partner user already has an active subscription.", null);
			} else if (GenericValidationUtil.isEqualStringsIgnoreCase(user.subscription.status, Config.pXApiDetails.cancelSubcriptionAction)
                && GenericValidationUtil.isEqualStringsIgnoreCase(existingSubscription.status, Config.pXApiDetails.expiredSubcriptionAction)) {
				// If expected is "cancel" and existing is also "cancel"
				console.log("Partner user's subscription is already cancelled.");
				throw new ModuleError(409, "Partner user subscription is already cancelled.", null);
			}
		}

		// Get Billing History to identify last transaction type
		[error, billingHistoryResult] = await To(getBillingHistoryForOneUser(
			authUser,
			{
				id: existingPartnerUser.id,
				email: existingPartnerUser.email,
				kUserId: existingPartnerUser.kUserId,
				device: {
					id: existingPartnerUser.deviceId,
				}
			},
			null,
			null,
			distinct_id
		));
		if (error) {
			console.error("An error occured while retrieving billing history for one partner user:");
			console.error(error);
			throw new ModuleError(500, "An error occured while retrieving billing history for one partner user.", null);
		} else if (!GenericValidationUtil.isSuccessResponse(billingHistoryResult)) {
			throw new ModuleError(500, "An error occured while retrieving billing history for one partner user.", null);
		} else {
			billingHistory = billingHistoryResult.data;
			if (GenericValidationUtil.isNonEmptyArray(billingHistory)) {
				lastBilling = billingHistory[0];
				console.log("lastBilling: ", lastBilling);
			} else {
				console.log("No billing history found for this partner user.");
			}
		}

		// Prepare
		if (GenericValidationUtil.isEqualStringsIgnoreCase(user.subscription.status, Config.pXApiDetails.renewSubcriptionAction)) {
			// Verify if "renew"ing subscription of existing partner user
			if (lastBilling && lastBilling.paymentDetails && lastBilling.paymentDetails.extras && lastBilling.paymentDetails.extras.mode
                && GenericValidationUtil.isEqualStringsIgnoreCase(lastBilling.paymentDetails.extras.mode, GenericConstantUtil.BILLING.PAYMENT_DETAILS.MODE.PARTNER)) {
				if (lastBilling.itemDetails && lastBilling.itemDetails.name
                    && !GenericValidationUtil.isEqualStringsIgnoreCase(lastBilling.itemDetails.name, authUser.partner.default.subscription.code)) {
					isGrantSubscription = true;
				} else {
					isGrantSubscription = false;
				}
			} else {
				isGrantSubscription = true;
			}

			pxRequestBody.subscription.action = Config.pXApiDetails.renewSubcriptionAction;
			pxRequestBody.subscription.endDate = subscription.endDate;

			updateObj.isActive = true;
			updateObj.subscription = {
				startDate: Moment(subscription.startDate * 1000).format("YYYY-MM-DDTHH:mm:ss.SSS") + "Z",
				endDate: Moment(subscription.endDate * 1000).format("YYYY-MM-DDTHH:mm:ss.SSS") + "Z"
			};
		} else if (GenericValidationUtil.isEqualStringsIgnoreCase(user.subscription.status, Config.pXApiDetails.cancelSubcriptionAction)) {
			// Validate
			if (lastBilling && lastBilling.paymentDetails && lastBilling.paymentDetails.extras && lastBilling.paymentDetails.extras.mode) {
				if (!GenericValidationUtil.isEqualStringsIgnoreCase(lastBilling.paymentDetails.extras.mode, GenericConstantUtil.BILLING.PAYMENT_DETAILS.MODE.PARTNER)) {
					// Check if SVOD traditional is being cancelled by a partner via this API
					throw new ModuleError(403, "Cancelling subscription of traditional SVOD user by a partner is not allowed.", null);
				} else if (GenericValidationUtil.isEqualStringsIgnoreCase(lastBilling.paymentDetails.extras.mode, GenericConstantUtil.BILLING.PAYMENT_DETAILS.MODE.PARTNER)
                    && lastBilling.itemDetails && lastBilling.itemDetails.name
                    && !GenericValidationUtil.isEqualStringsIgnoreCase(lastBilling.itemDetails.name, authUser.partner.default.subscription.code)) {
					// Check if SVOD partner is being cancelled by a different partner via this API
					throw new ModuleError(403, "Cancelling subscription of SVOD user of another partner is not allowed.", null);
				}
			}

			// Populate
			pxRequestBody.subscription.action = Config.pXApiDetails.cancelSubcriptionAction;
			updateObj.isActive = false;
			updateObj.subscription = {
				endDate: Moment(Date.now()).format("YYYY-MM-DDTHH:mm:ss.SSS") + "Z"
			};
			isGrantSubscription = false;
		} else {
			throw new ModuleError(400, "Invalid subscription status. Only renew or cancel are allowed.", null);
		}

		// Validate
		if (!existingPartnerUser.kUserId) {
			throw new ModuleError(409, "Please purchase a partner subscription before trying to update.", null);
		}

		// PX Subscription
		console.log("isGrantSubscription: ", isGrantSubscription);
		if (!isGrantSubscription) {
			// Update existing subscription
			[error, pxResult] = await To(updateOneSubscriptionForOne(
				authUser,
				pxRequestBody,
				null,
				null,
				distinct_id
			));
		} else {
			// Create new subscription
			[error, pxResult] = await To(createOneSubscriptionForOne(
				authUser,
				{
					id: existingPartnerUser.id,
					email: existingPartnerUser.email,
					device: {
						id: deviceId,
						brand: authUser.partner.default.device.brand
					},
					subscription: {
						startDate: subscription.startDate,
						endDate: subscription.endDate
					},
					kUserId: existingPartnerUser.kUserId
				},
				null,
				null,
				distinct_id
			));
		}
		if (error) {
			console.dir(error);
			throw new ModuleError(error.code, error.message, error.data);
		} else if (!GenericValidationUtil.isSuccessResponse(pxResult)) {
			throw new ModuleError(503, "An error occured while renewing subscription.", null);
		} else {
			console.log("Subscription updated successfully.");
			// Update user details in firestore
			updateObj.deviceId = deviceId;
			[error, updateResult] = await To(PartnerUserService.updateOne(
				authUser,
				updateObj,
				null,
				null
			));
			if (error) {
				throw new ModuleError(error.code, error.message, error.data);
			} else if (!GenericValidationUtil.isSuccessResponse(updateResult)) {
				throw new ModuleError(503, "An error occured while updating subscription status for one partner user.", null);
			} else {
				// Nothing to do
			}
		}

		// Response
		return Promise.resolve({ code: 200, message: "Successfully updated subscription status for one partner user." });
	} catch (error) {
		console.error(error);
		if (error && error.code && error.message) {
			return Promise.reject({ code: error.code, message: error.message, data: error.data });
		} else {
			return Promise.reject({ code: 500, message: "An error occured while updating subscription status for one partner user: " + error });
		}
	}
}

/**
 * Get status for one partner user
 * @param authUser 
 * @param user 
 * @param params 
 * @param flags 
 */
async function getStatusForOne(authUser, user, params, flags) {
	try {
		// Initialize
		let error, existingResult, subscriptionResult;
		let existingPartnerUser = null;
		let response = {};
		let query = null;
		let registrationStatus = "not_registered";
		let subscriptionStatus = "not_subscribed";
		let entitlementStatus = "not_entitled";
		let subscriptionDetails = {};

		console.log("User: ", user);

		// Get
		[error, existingResult] = await To(getOne(authUser, user, params, flags));
		if (error) {
			if (error.code != 404) {
				throw new ModuleError(error.code, error.message, error.data);
			} else {
				registrationStatus = "not_registered";
				subscriptionStatus = "not_subscribed";
				entitlementStatus = "not_entitled";

				console.log("Partner user doesn't exist with this uniqueId.");

				// Check if partner exists with this mobile number or email
				query = {};
				if (GenericValidationUtil.isValidPhoneNumber(user.uniqueId) || GenericValidationUtil.isValidPhoneNumber(user.phone)) {
					if ((user.uniqueId && user.uniqueId.includes("+")) || (user.phone && user.phone.includes("+"))) {
						query.mobile = user.uniqueId || user.phone;
					} else {
						query.mobile = authUser.partner.default.phone.countryCode + (user.uniqueId || user.phone);
					}
				} else if (GenericValidationUtil.isValidEmail(user.uniqueId) || GenericValidationUtil.isValidEmail(user.email)) {
					query.email = user.uniqueId || user.email;
				}

				if (GenericValidationUtil.isNonEmptyObject(query)) {
					console.log("query: ", query);
					[error, existingResult] = await To(getOne(authUser, query, params, flags));
					if (error) {
						if (error.code != 404) {
							throw new ModuleError(error.code, error.message, error.data);
						} else {
							console.log("Partner user doesn't exist with this mobile/email.");

							// For traditional user
							if (query.mobile) {
								// Populate
								query = {
									email: query.mobile + "@voot.com"
								};

								[error, existingResult] = await To(getOne(authUser, query, params, flags));
								if (error) {
									if (error.code != 404) {
										throw new ModuleError(error.code, error.message, error.data);
									} else {
										console.log("Partner user doesn't exist with this email as traditional user.");

										existingPartnerUser = null;
									}
								}
							}
						}
					}
					if (GenericValidationUtil.isSuccessResponseAndNonEmptyData(existingResult)) {
						// Nothing to do
					} else {
						existingPartnerUser = null;
					}
				}
			}
		}

		if (!GenericValidationUtil.isSuccessResponseAndNonEmptyData(existingResult)) {
			throw new ModuleError(503, "An error occured while retrieving existing partner user details. Please try again.", null);
		} else {
			if (GenericValidationUtil.isSuccessResponseAndNonEmptyData(existingResult)) {
				if (existingResult.data.db && GenericValidationUtil.isEqualStringsIgnoreCase(existingResult.data.db, "mongo")) {
					existingPartnerUser = ConverterUtil.mongoToPartnerUser(existingResult.data.user);
				} else {
					existingPartnerUser = existingResult.data.user;
				}
				console.log("existingPartnerUser: ", existingPartnerUser);

				// Validate if this user is already having another uniqueId
				if (existingPartnerUser.uniqueId && existingPartnerUser.partnerType // Since uniqueId is specific to partner for now, checing if partnerType is also present
                    && existingPartnerUser.uniqueId != user.uniqueId) {
					throw new ModuleError(409, "Another user already exists with a different uniqueId for this mobile/email.", null);
				}
			}
		}

		if (existingPartnerUser) {
			registrationStatus = "registered";
			subscriptionStatus = "not_subscribed";
			entitlementStatus = "not_entitled";

			// Get entitlement status
			[error, subscriptionResult] = await To(getOneSubscriptionForOne(authUser, existingPartnerUser, null, null));
			if (error) {
				console.error("An error occured while retrieving subscription status for this user.");
				console.error(error);
			} else if (!GenericValidationUtil.isSuccessResponseAndNonEmptyData(subscriptionResult)) {
				subscriptionStatus = "unable_to_retrieve";
				entitlementStatus = "unable_to_retrieve";
			} else {
				subscriptionStatus = subscriptionResult.data.status;
				entitlementStatus = subscriptionResult.data.status;
			}
		} else {
			throw new ModuleError(404, "No partner user found with these details.", null);
		}

		// Populate subscription details
		if (existingPartnerUser.subscription) {
			subscriptionDetails = {
				activationDate: existingPartnerUser.subscription.activationDate,
				startDate: existingPartnerUser.subscription.startDate,
				endDate: existingPartnerUser.subscription.endDate,
				transactionId: existingPartnerUser.subscription.transactionId,
			};
		} else if (existingPartnerUser.profile && existingPartnerUser.profile.subscription) {
			subscriptionDetails = {
				activationDate: existingPartnerUser.profile.subscription.activationDate,
				startDate: existingPartnerUser.profile.subscription.startDate,
				endDate: existingPartnerUser.profile.subscription.endDate,
				transactionId: existingPartnerUser.profile.subscription.transactionId,
			};
		} else {
			subscriptionDetails = {
				activationDate: "",
				startDate: "",
				endDate: "",
				transactionId: ""
			};
		}

		// Construct
		response = {
			status: {
				registration: registrationStatus,
				subscription: subscriptionStatus,
				playbackEntitlement: entitlementStatus
			},
			uId: existingPartnerUser.id,
			email: existingPartnerUser.email,
			mobile: existingPartnerUser.mobile,
			subscription: subscriptionDetails
		};

		// Response
		return Promise.resolve({ code: 200, message: "Successfully retrieved subscription status for one partner user.", data: response });
	} catch (error) {
		console.error(error);
		if (error && error.code && error.message) {
			return Promise.reject({ code: error.code, message: error.message, data: error.data });
		} else {
			return Promise.reject({ code: 500, message: "An error occured while retrieving subscription status for one partner user: " + error });
		}
	}
}

/**
 * Login one partner user
 * @param authUser 
 * @param partnerUser 
 * @param params 
 * @param flags 
 */
async function loginOne(authUser, partnerUser, params, flags, distinctId = "", regionInfo = {}) {
	try {
		// Initialize
		let error, existingResult, kalturaUserLoginResult, accessToken, refreshToken;
		let existingPartnerUser = null;
		let response = null;

		// Get
		[error, existingResult] = await To(getOne(authUser, partnerUser.user, params, flags));
		if (error) {
			throw new ModuleError(error.code, error.message, error.data);
		}
		if (GenericValidationUtil.isSuccessResponseAndNonEmptyData(existingResult)) {
			console.log(JSON.stringify(existingResult.data));

			if (GenericValidationUtil.isSuccessResponseAndNonEmptyData(existingResult)) {
				if (existingResult.data.db && GenericValidationUtil.isEqualStringsIgnoreCase(existingResult.data.db, "mongo")) {
					existingPartnerUser = ConverterUtil.mongoToPartnerUser(existingResult.data.user);
				} else {
					existingPartnerUser = existingResult.data.user;
				}
				console.log("existingPartnerUser: ", existingPartnerUser);
			}

			console.log("Uid: ", existingPartnerUser.id);
			console.log("DeviceId: ", existingPartnerUser.deviceId);
			
			if (config.kafkaConfig.enable.isUpdateAuth && !_.isEmpty(regionInfo) &&
			((regionInfo.region !== existingPartnerUser.region) || (regionInfo.country !== existingPartnerUser.country))
			) { 
				//sending region notification into queue
				const regionNotificationObj = await notificationService.createRegionNotification(
					existingPartnerUser,
					regionInfo ? regionInfo : {}
				);
				kafkaService.pushEventToKafka(config.kafkaConfig.topic.updateAuthData, regionNotificationObj);
			}
			// Kaltura Login
			kalturaUserLoginResult = await KalturaService.login(existingPartnerUser.email, existingPartnerUser.id, existingPartnerUser.deviceId);
			if (!GenericValidationUtil.isNonEmptyObject(kalturaUserLoginResult) && !GenericValidationUtil.isNonEmptyObject(kalturaUserLoginResult.result)) {
				mixpanelService(mixpanelConfig.externalCallKaltura + "Login" + mixpanelConfig.error + mixpanelConfig.yuppTv, { email: existingPartnerUser.email, uid: existingPartnerUser.id, distinct_id: distinctId }, distinctId, null, null, false);
				throw new ModuleError(503, "Unable to perform Kaltura login. Please try again.", null);
			}
			mixpanelService(mixpanelConfig.externalCallKaltura + "Login" + mixpanelConfig.success + mixpanelConfig.yuppTv, { email: existingPartnerUser.email, uid: existingPartnerUser.id, distinct_id: distinctId }, distinctId, null, null, false);
		}

		// Prepare
		accessToken = JWT.sign(
			{
				uId: existingPartnerUser.id,
				uniqueId: existingPartnerUser.uniqueId,
			},
			authUser.partner.jwt.secret.access,
			{
				expiresIn: authUser.partner.jwt.expiry.access
			}
		);
		refreshToken = JWT.sign(
			{
				uId: existingPartnerUser.id,
				uniqueId: existingPartnerUser.uniqueId,
			},
			authUser.partner.jwt.secret.refresh,
			{
				expiresIn: authUser.partner.jwt.expiry.refresh
			}
		);
		response = {
			uId: existingPartnerUser.id,
			mobile: existingPartnerUser.mobile,
			email: existingPartnerUser.email,
			auth: {
				access: {
					token: accessToken,
					expiry: JWT.decode(accessToken)["exp"]
				},
				refresh: {
					token: refreshToken,
					expiry: JWT.decode(refreshToken)["exp"]
				},
				playback: {
					token: kalturaUserLoginResult.result.loginSession.ks,
					expiry: kalturaUserLoginResult.result.loginSession.expiry
				}
			},
			subscription: {
				activationDate: (existingPartnerUser.subscription) ? existingPartnerUser.subscription.activationDate : null,
				startDate: (existingPartnerUser.subscription) ? existingPartnerUser.subscription.startDate : null,
				endDate: (existingPartnerUser.subscription) ? existingPartnerUser.subscription.endDate : null,
				transactionId: (existingPartnerUser.subscription) ? existingPartnerUser.subscription.transactionId : null,
			}
		};
		// Response
		return Promise.resolve({ code: 200, message: "Login successful.", data: response });
	} catch (error) {
		console.log("error-------",error,error.stack);
		if (error && error.code && error.message) {
			return Promise.reject({ code: error.code, message: error.message, data: error.data });
		} else {
			return Promise.reject({ code: 500, message: "An error occured during partner user login: " + error });
		}
	}
}

/**
 * Refresh token for one partner user
 * @param authUser 
 * @param user 
 * @param params 
 * @param flags 
 */
async function refreshOneToken(authUser) {
	try {
		// Initialize
		let decoded = null;
		let result, accessToken, refreshToken;

		console.log("AuthUser: ", authUser);

		// Validate
		if (GenericValidationUtil.isValidJwt(authUser.refreshToken, authUser.partner.jwt.secret.refresh)) {
			decoded = JWT.decode(authUser.refreshToken);

			// Delete expiry and issuedAt
			delete decoded.exp;
			delete decoded.iat;
			if (config.kafkaConfig.enable.isUpdateAuth && authUser.regionInfo) { 
				//sending region notification into queue
				const regionNotificationObj = await notificationService.createRegionNotification(
					decoded,
					_.get(authUser,"regionInfo",{})
				);
				kafkaService.pushEventToKafka(config.kafkaConfig.topic.updateAuthData, regionNotificationObj);
			}
			// Create new access/refresh tokens
			accessToken = JWT.sign(decoded, authUser.partner.jwt.secret.access, { expiresIn: authUser.partner.jwt.expiry.access });
			refreshToken = JWT.sign(decoded, authUser.partner.jwt.secret.refresh, { expiresIn: authUser.partner.jwt.expiry.refresh });
			result = {
				access: {
					token: accessToken,
					expiry: JWT.decode(accessToken)["exp"]
				},
				refresh: {
					token: refreshToken,
					expiry: JWT.decode(refreshToken)["exp"]
				}
			};
		} else {
			throw new ModuleError(401, "Invalid refresh token.", null);
		}

		// Response
		return Promise.resolve({ code: 200, message: "Successfully generated new access and refresh tokens.", data: result });
	} catch (error) {
		if (error && error.code && error.message) {
			return Promise.reject({ code: error.code, message: error.message, data: error.data });
		} else {
			return Promise.reject({ code: 500, message: "An error occured while retrieving subscription status for one partner user: " + error });
		}
	}
}

/**
 * Get one plan
 * @param authUser 
 * @param plan 
 * @param params 
 * @param flags 
 */
async function getOnePlan(authUser, plan) {
	try {
		// Initialize
		let result;

		// Get
		result = authUser.partner.plans.find(p => GenericValidationUtil.isEqualStrings(p.code, plan.code));

		// Response
		if (result) {
			return Promise.resolve({ code: 200, message: "Successfully retrieved plan details.", data: result });
		} else {
			throw new ModuleError(404, "No plan found that matches the criteria.", null);
		}
	} catch (error) {
		if (error && error.code && error.message) {
			return Promise.reject({ code: error.code, message: error.message, data: error.data });
		} else {
			return Promise.reject({ code: 500, message: "An error occured while retrieving plan details: " + error });
		}
	}
}

/**
 * Get billing history for a given user
 * @param authUser 
 * @param user 
 * @param params 
 * @param flags 
 */
async function getBillingHistoryForOneUser(authUser, user, params, flags, distinctId = "") {
	let eventName;
	let error, pxResult, tempAccessTokenResult;
	let pxRequestHeaders = {};
	let pxAccessToken = null;
	let billingHistory = [];
	try {
		// Initialize


		// Generate temporary access token
		[error, tempAccessTokenResult] = await To(JwtUtil.createOneTemporary(
			{
				userId: user.id || user.uid,
				email: user.email,
				issuer: authUser.partner.product.voot,
				expiryDurationInSecs: 600, // 10 mins
				jwt: {
					secret: Config.jwt.secret
				},
				kUserId: user.kUserId,
				deviceId: user.device.id,
				partnerType: authUser.partner.code
			},
			null,
			null
		));
		if (error) {
			throw new ModuleError(error.code, error.message, error.data);
		} else if (!GenericValidationUtil.isSuccessResponseAndNonEmptyData(tempAccessTokenResult)) {
			throw new ModuleError(500, "An error occured while generating token to create a subscription for one partner user.", null);
		} else {
			pxAccessToken = tempAccessTokenResult.data.token;
		}

		pxRequestHeaders = {
			"Content-Type": "application/json",
			product: authUser.partner.product.voot,
			accesstoken: pxAccessToken
		};

		console.log("URL: ", `https://${Config.pXApiDetails.host}/${Config.pXApiDetails.billingHistory}`);
		console.log("Request Headers: ", pxRequestHeaders);

		// Call PX API
		[error, pxResult] = await To(HttpRestUtil.get(
			`https://${Config.pXApiDetails.host}/${Config.pXApiDetails.billingHistory}`,
			pxRequestHeaders,
			null,
			null
		));
		if (error) {
			console.error("An error occured while retrieving billing history for one partner user.");
			console.error(error);
			throw new ModuleError(error.code, error.message, error.data);
		} else if (!GenericValidationUtil.isSuccessResponse(pxResult)) {
			throw new ModuleError(503, "An error occured while retrieving billing history for one partner user.", null);
		} else {
			if (GenericValidationUtil.isNonEmptyObject(pxResult) && GenericValidationUtil.isNonEmptyObject(pxResult.data)
                && GenericValidationUtil.isNonEmptyObject(pxResult.data.results) && GenericValidationUtil.isNonEmptyArray(pxResult.data.results.list)) {
				billingHistory = pxResult.data.results.list;
			} else {
				console.log("No billing history found for this partner user.");
			}
		}

		//Response
		let eventProps = { userInput: pxAccessToken, input: pxAccessToken, Message: "Successfully created a subscription for one partner user.", ErrorCode: "", distinct_id: distinctId, StatusCode: 200 };
		eventName = await commonUtil.preparePartnerEventName("GET", Config.pXApiDetails.billingHistory, false, false, mixpanelConfig.billingHistory + mixpanelConfig.yuppTv + mixpanelConfig.success);
		mixpanelService(eventName, eventProps, distinctId, null, null, false);

		return Promise.resolve({ code: 200, message: "Successfully created a subscription for one partner user.", data: billingHistory });
	} catch (error) {
		eventName = await commonUtil.preparePartnerEventName("GET", Config.pXApiDetails.billingHistory, false, false, mixpanelConfig.billingHistory + mixpanelConfig.yuppTv + mixpanelConfig.error);
		let eventProps = { userInput: pxAccessToken, input: pxAccessToken, Message: error.message, ErrorCode: error.code, distinct_id: distinctId, StatusCode: error.code };
		mixpanelService(eventName, eventProps, distinctId, error.data, null, false);

		if (error && error.code && error.message) {
			return Promise.reject({ code: error.code, message: error.message, data: error.data });
		} else {
			return Promise.reject({ code: 500, message: "An error occured while retrieving billing history: " + error });
		}
	}
}

/**
 * Create one partner user
 * @param authUser 
 * @param partnerUser 
 * @param params 
 * @param flags 
 */
async function createAsyncOne(authUser, partnerUser, params, flags, distinctId = "") {
	try {
		console.log("Start - Partner User Async Service -> createAsyncOne.");
		// Initialize
		let error, existingResult,  existingSubscriptionResult,planResult, kalturaUserLoginResult;
		let existingPartnerUser = null;
		let query, plan, subscription, existingSubscription, accessToken, refreshToken, kalturaSession;
		let response = null;

		console.log("Check if partner user already exists.");
		// Get
		[error, existingResult] = await To(getOne(authUser, { uniqueId: partnerUser.user.uniqueId }, params, flags));
		if (error) {
			if (error.code != 404) {
				throw new ModuleError(error.code, error.message, error.data);
			} else {
				console.log("Partner user doesn't exist with this uniqueId.");

				// Check if partner exists with this mobile number or email
				query = {};
				if (GenericValidationUtil.isValidPhoneNumber(partnerUser.user.mobile)) {
					if (partnerUser.user.mobile.includes("+")) {
						query.mobile = partnerUser.user.mobile;
					} else {
						query.mobile = authUser.partner.default.phone.countryCode + partnerUser.user.mobile;
					}
				} else if (GenericValidationUtil.isValidEmail(partnerUser.user.email)) {
					query.email = partnerUser.user.email;
				}

				if (GenericValidationUtil.isNonEmptyObject(query)) {
					[error, existingResult] = await To(getOne(authUser, query, params, flags));
					if (error) {
						if (error.code != 404) {
							throw new ModuleError(error.code, error.message, error.data);
						} else {
							console.log("Partner user doesn't exist with this mobile/email.");

							// For traditional user
							if (query.mobile) {
								// Populate
								query = {
									email: query.mobile + "@voot.com"
								};

								[error, existingResult] = await To(getOne(authUser, query, params, flags));
								if (error) {
									if (error.code != 404) {
										throw new ModuleError(error.code, error.message, error.data);
									} else {
										console.log("Partner user doesn't exist with this email as traditional user.");

										existingPartnerUser = null;
									}
								}
							}
						}
					}
					if (GenericValidationUtil.isSuccessResponseAndNonEmptyData(existingResult)) {
						// Nothing to do
					} else {
						existingPartnerUser = null;
					}
				}
			}
		}

		if (GenericValidationUtil.isSuccessResponseAndNonEmptyData(existingResult)) {
			if (existingResult.data.db && GenericValidationUtil.isEqualStringsIgnoreCase(existingResult.data.db, "mongo")) {
				existingPartnerUser = ConverterUtil.mongoToPartnerUser(existingResult.data.user);
			} else {
				existingPartnerUser = existingResult.data.user;
			}
			console.log("existingPartnerUser: ", existingPartnerUser);

			// Validate if this user is already having another uniqueId
			if (existingPartnerUser.uniqueId && existingPartnerUser.partnerType // Since uniqueId is specific to partner for now, checing if partnerType is also present
                && existingPartnerUser.uniqueId != partnerUser.user.uniqueId) {
				throw new ModuleError(409, "Another user already exists with a different uniqueId for this mobile/email.", null);
			}
			//validate request for other partner with same uniqueId
			// if (existingPartnerUser.uniqueId && existingPartnerUser.partnerType && existingPartnerUser.partnerType!=partnerType// Since uniqueId is specific to partner for now, checing if partnerType is also present
			//     && existingPartnerUser.uniqueId == partnerUser.user.uniqueId) {
			//         console.log("inside new condition")
			//     throw new ModuleError(409, "Another user already exists with a same uniqueId for this mobile/email.", null);
			// }
		}

		console.log("Get subscription plan details.");
		// Get plan details
		[error, planResult] = await To(getOnePlan(authUser, { code: partnerUser.subscription.planCode }, null, null));
		if (error) {
			throw new ModuleError(error.code, error.message, error.data);
		} else if (!GenericValidationUtil.isSuccessResponseAndNonEmptyData(planResult)) {
			throw new ModuleError(503, "An error occured while retrieving details for one plan.", null);
		} else {
			plan = planResult.data;
			subscription = {
				startDate: Math.ceil(Date.now() / 1000),
				endDate: Math.ceil(Date.now() / 1000) + plan.duration
			};

			// Populate for partner user
			partnerUser.user.subscription = {
				transactionId: RandomUtil.string(32),
				source: partnerUser.subscription.source || "",
				deviceType: (partnerUser.device.type) ? partnerUser.device.type.toUpperCase() : ""
			};
			if (subscription.startDate) {
				partnerUser.user.subscription.startDate = Moment(subscription.startDate * 1000).format("YYYY-MM-DDTHH:mm:ss.SSS") + "Z";
				partnerUser.user.subscription.activationDate = partnerUser.user.subscription.startDate;
			}
			if (subscription.endDate) {
				partnerUser.user.subscription.endDate = Moment(subscription.endDate * 1000).format("YYYY-MM-DDTHH:mm:ss.SSS") + "Z";
			}
		}

		if (existingPartnerUser) {
			console.log("Partner user already exists.");
			if (!existingPartnerUser.kUserId) {
				console.log("kUserId not present as part of existing details. Performing Kaltura login to retrieve.");
				// Kaltura Login
				kalturaUserLoginResult = await KalturaService.login(existingPartnerUser.email, existingPartnerUser.id, existingPartnerUser.deviceId);
				if (!GenericValidationUtil.isNonEmptyObject(kalturaUserLoginResult)
                    || (GenericValidationUtil.isNonEmptyObject(kalturaUserLoginResult) && !GenericValidationUtil.isNonEmptyObject(kalturaUserLoginResult.result))) {
					mixpanelService(mixpanelConfig.externalCallKaltura + "Login" + mixpanelConfig.error + mixpanelConfig.yuppTv, { email: existingPartnerUser.email, uid: existingPartnerUser.id, distinct_id: distinctId }, distinctId, null, null, false);
					console.error("Unable to perform Kaltura login");
				} else {
					mixpanelService(mixpanelConfig.externalCallKaltura + "Login" + mixpanelConfig.success + mixpanelConfig.yuppTv, { email: existingPartnerUser.email, uid: existingPartnerUser.id, distinct_id: distinctId }, distinctId, null, null, false);
					kalturaSession = {
						token: kalturaUserLoginResult.result.loginSession.ks,
						expiry: kalturaUserLoginResult.result.loginSession.expiry,
						kUserId: kalturaUserLoginResult.result.user.id
					};
				}
			}else{
				kalturaUserLoginResult = await KalturaService.login(existingPartnerUser.email, existingPartnerUser.id, existingPartnerUser.deviceId);
				if (!GenericValidationUtil.isNonEmptyObject(kalturaUserLoginResult)
                    || (GenericValidationUtil.isNonEmptyObject(kalturaUserLoginResult) && !GenericValidationUtil.isNonEmptyObject(kalturaUserLoginResult.result))) {
					mixpanelService(mixpanelConfig.externalCallKaltura + "Login" + mixpanelConfig.error + mixpanelConfig.yuppTv, { email: existingPartnerUser.email, uid: existingPartnerUser.id, distinct_id: distinctId }, distinctId, null, null, false);
					console.error("Unable to perform Kaltura login");
				} else {
					mixpanelService(mixpanelConfig.externalCallKaltura + "Login" + mixpanelConfig.success + mixpanelConfig.yuppTv, { email: existingPartnerUser.email, uid: existingPartnerUser.id, distinct_id: distinctId }, distinctId, null, null, false);
					kalturaSession = {
						token: kalturaUserLoginResult.result.loginSession.ks,
						expiry: kalturaUserLoginResult.result.loginSession.expiry,
						kUserId: kalturaUserLoginResult.result.user.id
					};
				}

			}

			[error, existingSubscriptionResult] = await To(getOneSubscriptionForOne(authUser, { id: existingPartnerUser.id, email: existingPartnerUser.email }, null, null, distinctId));
			console.log("Subscription Status: =====", existingSubscriptionResult);
			if (error) {
				throw new ModuleError(error.code, error.message, error.data);
			} else if (!GenericValidationUtil.isSuccessResponseAndNonEmptyData(existingSubscriptionResult)) {
				throw new ModuleError(500, "An error occured while retrieving existing subscription details for one partner user.", null);
			} else {
				existingSubscription = existingSubscriptionResult.data;
				console.log("existingSubscription: ", existingSubscription);
				if (GenericValidationUtil.isEqualStringsIgnoreCase(existingSubscription.status, Config.pXApiDetails.activeSubcriptionAction)) {
					console.log("Partner user already has an active subscription.");
					throw new ModuleError(409, "Partner user already has an active subscription.", null);
				} 
			}
		}else{//login with dummy id
			kalturaUserLoginResult = await KalturaService.login("+912020322223@voot.com", "s6snDzOBuwHbh4KV9QfPrDrfnlEF", "2020322223");
			if (!GenericValidationUtil.isNonEmptyObject(kalturaUserLoginResult)
                || (GenericValidationUtil.isNonEmptyObject(kalturaUserLoginResult) && !GenericValidationUtil.isNonEmptyObject(kalturaUserLoginResult.result))) {
				//mixpanelService(mixpanelConfig.externalCallKaltura + "Login" + mixpanelConfig.error + mixpanelConfig.yuppTv, { email: existingPartnerUser.email, uid: existingPartnerUser.id, distinct_id: distinctId }, distinctId, null, null, false);
				console.error("Unable to perform Kaltura login");
			} else {
				//mixpanelService(mixpanelConfig.externalCallKaltura + "Login" + mixpanelConfig.success + mixpanelConfig.yuppTv, { email: existingPartnerUser.email, uid: existingPartnerUser.id, distinct_id: distinctId }, distinctId, null, null, false);
				kalturaSession = {
					token: kalturaUserLoginResult.result.loginSession.ks,
					expiry: kalturaUserLoginResult.result.loginSession.expiry,
					kUserId: kalturaUserLoginResult.result.user.id
				};
			}
		}
        
		// Partner user doesn't exist
		// Populate defaults
		partnerUser.user.partnerType = authUser.partner.code;
		partnerUser.user.deviceId = partnerUser.device.id;
		partnerUser.user.isActive = true;
		partnerUser.user.profileData = {
			Gender: "U",
			Preferences: {
				Languages: ["Hindi", "English"]
			},
			FirstName: authUser.partner.code,
			LastName: authUser.partner.code,
			FullName: authUser.partner.code + " " + authUser.partner.code,
		};

		if (GenericValidationUtil.isValidPhoneNumber(partnerUser.user.mobile) && partnerUser.user.mobile.length == 10) {
			partnerUser.user.mobile = authUser.partner.default.phone.countryCode + partnerUser.user.mobile;
			partnerUser.user.phoneCountryCode = authUser.partner.default.phone.countryCode;
		}
		if (!partnerUser.user.email) {
			if (partnerUser.user.mobile) {
				partnerUser.user.email = partnerUser.user.mobile + "@" + authUser.partner.domain.email;
			} else {
				partnerUser.user.email = partnerUser.user.uniqueId + "@" + authUser.partner.domain.email;
			}
		}
		partnerUser.user.tempEmail = partnerUser.user.email;
		console.debug("Create one partner user.",partnerUser.user);
		let uid = randomId.generate({
			length: 28,
			charset: "alphanumeric"
		});
		// Prepare
		accessToken = JWT.sign(
			{
				uId: uid,
				uniqueId: partnerUser.user.uniqueId,
			},
			authUser.partner.jwt.secret.refresh,
			{
				expiresIn: authUser.partner.jwt.expiry.access
			}
		);
		refreshToken = JWT.sign(
			{
				uId: uid,
				uniqueId: partnerUser.user.uniqueId,
			},
			authUser.partner.jwt.secret.refresh,
			{
				expiresIn: authUser.partner.jwt.expiry.refresh
			}
		);
		//condition
		response = {
			uId:uid,
			mobile: partnerUser.user.mobile,
			email: partnerUser.user.email,
			auth: {
				access: {
					token: accessToken,
					expiry: JWT.decode(accessToken)["exp"]
				},
				refresh: {
					token: refreshToken,
					expiry: JWT.decode(refreshToken)["exp"]
				},
				playback: {
					token: (kalturaSession) ? kalturaSession.token : null,
					expiry: (kalturaSession) ? kalturaSession.expiry : null
				}
			},
			subscription: {
				activationDate: (partnerUser.user.subscription) ? partnerUser.user.subscription.activationDate : null,
				startDate: (partnerUser.user.subscription) ? partnerUser.user.subscription.startDate : null,
				endDate: (partnerUser.user.subscription) ? partnerUser.user.subscription.endDate : null,
				transactionId: (partnerUser.user.subscription) ? partnerUser.user.subscription.transactionId : null,
			}
		};
		console.log("End - Partner User async Service -> createOne.", { code: 200, message: "Successfully created one partner user.", data: response });
		console.log("my response----", response);
		// Response
		return Promise.resolve({ code: 200, message: "Successfully created one partner user.", data: response });
        
	} catch (error) {
		//console.error("Error - Partner User async Service -> createOne.");
		console.error("Error - Partner User async Service -> createAsyncOne",error,error.stack);
		if (error && error.code && error.message) {
			return Promise.reject({ code: error.code, message: error.message, data: error.data });
		} else {
			return Promise.reject({ code: 500, message: "An error occured while creating one partner user: " + error });
		}
	}
}

/**
 * Update Async status for one partner user
 * @param authUser 
 * @param user 
 * @param params 
 * @param flags 
 */
async function updateAsyncStatusForOne(authUser, user, params, flags, distinct_id = "",request) {
	try {
		// Initialize
		let error, existingResult, existingSubscriptionResult, planResult, billingHistoryResult;
		let existingPartnerUser = null;
		let plan = null;
		let subscription = null;
		let updateObj = {};
		let billingHistory = [];
		let lastBilling = null;
		let query = {};
		let existingSubscription,pxRequestBody;
        
		// Get plan details
		if (user.subscription.status) {
			// Get plan details
			[error, planResult] = await To(getOnePlan(authUser, { code: user.subscription.planCode }, null, null));
			if (error) {
				throw new ModuleError(error.code, error.message, error.data);
			} else if (!GenericValidationUtil.isSuccessResponseAndNonEmptyData(planResult)) {
				throw new ModuleError(503, "An error occured while retrieving details for one plan.", null);
			} else {
				plan = planResult.data;
				subscription = {
					startDate: Math.ceil(Date.now() / 1000),
					endDate: Math.ceil(Date.now() / 1000) + plan.duration
				};
			}
		}

		// Get
		[error, existingResult] = await To(getOne(authUser, user, params, flags));
		if (error) {
			if (error.code != 404) {
				throw new ModuleError(error.code, error.message, error.data);
			} else {
				console.log("Partner user doesn't exist with this uniqueId.");

				// Check if partner exists with this mobile number or email
				query = {};
				if (GenericValidationUtil.isValidPhoneNumber(user.uniqueId) || GenericValidationUtil.isValidPhoneNumber(user.phone)) {
					if ((user.uniqueId && user.uniqueId.includes("+")) || (user.phone && user.phone.includes("+"))) {
						query.mobile = user.uniqueId || user.phone;
					} else {
						query.mobile = authUser.partner.default.phone.countryCode + (user.uniqueId || user.phone);
					}
				} else if (GenericValidationUtil.isValidEmail(user.uniqueId) || GenericValidationUtil.isValidEmail(user.email)) {
					query.email = user.uniqueId || user.email;
				}

				if (GenericValidationUtil.isNonEmptyObject(query)) {
					console.log("query: ", query);
					[error, existingResult] = await To(getOne(authUser, query, params, flags));
					if (error) {
						if (error.code != 404) {
							throw new ModuleError(error.code, error.message, error.data);
						} else {
							console.log("Partner user doesn't exist with this mobile/email.");

							// For traditional user
							if (query.mobile) {
								// Populate
								query = {
									email: query.mobile + "@voot.com"
								};

								[error, existingResult] = await To(getOne(authUser, query, params, flags));
								if (error) {
									if (error.code != 404) {
										throw new ModuleError(error.code, error.message, error.data);
									} else {
										console.log("Partner user doesn't exist with this email as traditional user.");

										existingPartnerUser = null;
									}
								}
							}
						}
					}
					if (GenericValidationUtil.isSuccessResponseAndNonEmptyData(existingResult)) {
						// Nothing to do
					} else {
						existingPartnerUser = null;
					}
				}
			}
		}

		if (!GenericValidationUtil.isSuccessResponseAndNonEmptyData(existingResult)) {
			throw new ModuleError(503, "An error occured while retrieving existing partner user details. Please try again.", null);
		} else {
			if (existingResult.data.db && GenericValidationUtil.isEqualStringsIgnoreCase(existingResult.data.db, "mongo")) {
				existingPartnerUser = ConverterUtil.mongoToPartnerUser(existingResult.data.user);
			} else {
				existingPartnerUser = existingResult.data.user;
			}
			console.log("existingPartnerUser: ", existingPartnerUser);

			// Validate if this user is already having another uniqueId
			if (existingPartnerUser.uniqueId && existingPartnerUser.partnerType // Since uniqueId is specific to partner for now, checing if partnerType is also present
                && existingPartnerUser.uniqueId != user.uniqueId) {
				throw new ModuleError(409, "Another user already exists with a different uniqueId for this mobile/email.", null);
			}

		}

		// Prepare
		updateObj = {
			uid: existingPartnerUser.uid,
			subscription: {}
		};
		pxRequestBody = {
			id: existingPartnerUser.id,
			email: existingPartnerUser.email,
			kUserId: existingPartnerUser.kUserId,
			subscription: {}
		};

		// Check if this user already has a valid subscription.
		[error, existingSubscriptionResult] = await To(getOneSubscriptionForOne(authUser, { id: existingPartnerUser.id, email: existingPartnerUser.email }, null, null));
		console.log("Subscription Status: =====", existingSubscriptionResult);
		if (error) {
			throw new ModuleError(error.code, error.message, error.data);
		} else if (!GenericValidationUtil.isSuccessResponseAndNonEmptyData(existingSubscriptionResult)) {
			throw new ModuleError(500, "An error occured while retrieving existing subscription details for one partner user.", null);
		} else {
			existingSubscription = existingSubscriptionResult.data;
			console.log("existingSubscription: ", existingSubscription);
			//check if multistack sub is active
			if (GenericValidationUtil.isEqualStringsIgnoreCase(user.subscription.status, Config.pXApiDetails.renewSubcriptionAction)
                && GenericValidationUtil.isEqualStringsIgnoreCase(existingSubscription.status, Config.pXApiDetails.activeSubcriptionAction)) {
				// If expected is "renew" and existing is "active"
				if (config.YuppTvAsyncConfig.subscription.isStack) {
					let notificationObj = await notificationService.createNotificationObjectForYuppTV("create_and_update_subscription", "yupptv", request.body);
					kafkaService.pushEventToKafka(config.kafkaConfig.topic.partnerNotification, notificationObj);
					return Promise.resolve({ code: 200, message: "Successfully updated subscription status for one partner user." });
				}
				console.log("Partner user already has an active subscription.");
				throw new ModuleError(409, "Partner user already has an active subscription.", null);
			} else if (GenericValidationUtil.isEqualStringsIgnoreCase(user.subscription.status, Config.pXApiDetails.cancelSubcriptionAction)
                && GenericValidationUtil.isEqualStringsIgnoreCase(existingSubscription.status, Config.pXApiDetails.expiredSubcriptionAction)) {
				// If expected is "cancel" and existing is also "cancel"
				console.log("Partner user's subscription is already cancelled.");
				throw new ModuleError(409, "Partner user subscription is already cancelled.", null);
			}
		}
		// Get Billing History to identify last transaction type
		[error, billingHistoryResult] = await To(getBillingHistoryForOneUser(
			authUser,
			{
				id: existingPartnerUser.id,
				email: existingPartnerUser.email,
				kUserId: existingPartnerUser.kUserId,
				device: {
					id: existingPartnerUser.deviceId,
				}
			},
			null,
			null,
			distinct_id
		));
		if (error) {
			console.error("An error occured while retrieving billing history for one partner user:");
			console.error(error);
			throw new ModuleError(500, "An error occured while retrieving billing history for one partner user.", null);
		} else if (!GenericValidationUtil.isSuccessResponse(billingHistoryResult)) {
			throw new ModuleError(500, "An error occured while retrieving billing history for one partner user.", null);
		} else {
			billingHistory = billingHistoryResult.data;
			if (GenericValidationUtil.isNonEmptyArray(billingHistory)) {
				lastBilling = billingHistory[0];
				console.log("lastBilling: ", lastBilling);
			} else {
				console.log("No billing history found for this partner user.");
			}
		}

		// Prepare
		if (GenericValidationUtil.isEqualStringsIgnoreCase(user.subscription.status, Config.pXApiDetails.renewSubcriptionAction)) {
			// Verify if "renew"ing subscription of existing partner user
			if (lastBilling && lastBilling.paymentDetails && lastBilling.paymentDetails.extras && lastBilling.paymentDetails.extras.mode
                && GenericValidationUtil.isEqualStringsIgnoreCase(lastBilling.paymentDetails.extras.mode, GenericConstantUtil.BILLING.PAYMENT_DETAILS.MODE.PARTNER)) {
				if (lastBilling.itemDetails && lastBilling.itemDetails.name
                    && !GenericValidationUtil.isEqualStringsIgnoreCase(lastBilling.itemDetails.name, authUser.partner.default.subscription.code)) {
					isGrantSubscription = true;
				} else {
					isGrantSubscription = false;
				}
			} else {
				isGrantSubscription = true;
			}

			pxRequestBody.subscription.action = Config.pXApiDetails.renewSubcriptionAction;
			pxRequestBody.subscription.endDate = subscription.endDate;

			updateObj.isActive = true;
			updateObj.subscription = {
				startDate: Moment(subscription.startDate * 1000).format("YYYY-MM-DDTHH:mm:ss.SSS") + "Z",
				endDate: Moment(subscription.endDate * 1000).format("YYYY-MM-DDTHH:mm:ss.SSS") + "Z"
			};
		} else if (GenericValidationUtil.isEqualStringsIgnoreCase(user.subscription.status, Config.pXApiDetails.cancelSubcriptionAction)) {
			// Validate
			if (lastBilling && lastBilling.paymentDetails && lastBilling.paymentDetails.extras && lastBilling.paymentDetails.extras.mode) {
				if (!GenericValidationUtil.isEqualStringsIgnoreCase(lastBilling.paymentDetails.extras.mode, GenericConstantUtil.BILLING.PAYMENT_DETAILS.MODE.PARTNER)) {
					// Check if SVOD traditional is being cancelled by a partner via this API
					throw new ModuleError(403, "Cancelling subscription of traditional SVOD user by a partner is not allowed.", null);
				} else if (GenericValidationUtil.isEqualStringsIgnoreCase(lastBilling.paymentDetails.extras.mode, GenericConstantUtil.BILLING.PAYMENT_DETAILS.MODE.PARTNER)
                    && lastBilling.itemDetails && lastBilling.itemDetails.name
                    && !GenericValidationUtil.isEqualStringsIgnoreCase(lastBilling.itemDetails.name, authUser.partner.default.subscription.code)) {
					// Check if SVOD partner is being cancelled by a different partner via this API
					throw new ModuleError(403, "Cancelling subscription of SVOD user of another partner is not allowed.", null);
				}
			}

			// Populate
			pxRequestBody.subscription.action = Config.pXApiDetails.cancelSubcriptionAction;
			updateObj.isActive = false;
			updateObj.subscription = {
				endDate: Moment(Date.now()).format("YYYY-MM-DDTHH:mm:ss.SSS") + "Z"
			};
			isGrantSubscription = false;
		} else {
			throw new ModuleError(400, "Invalid subscription status. Only renew or cancel are allowed.", null);
		}

		//Validate
		if (!existingPartnerUser.kUserId) {
			throw new ModuleError(409, "Please purchase a partner subscription before trying to update.", null);
		}
		// Response
		return Promise.resolve({ code: 200, message: "Successfully updated subscription status for one partner user." });
	} catch (error) {
		console.error("Check Error In Partner User", error, error.stack);
		if (error && error.code && error.message) {
			return Promise.reject({ code: error.code, message: error.message, data: error.data });
		} else {
			return Promise.reject({ code: 500, message: "An error occured while updating subscription status for one partner user: " + error });
		}
	}
}

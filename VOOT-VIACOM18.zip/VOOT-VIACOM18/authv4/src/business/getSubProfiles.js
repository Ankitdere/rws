"use strict";

module.exports = getSubProfiles;
const { subProfile } = require("../services");
const { mongoSubProfile: mongoSubProfile } = require("../format");
const { apiResponse } = require("../utils");
const {
	errorConfig
} = require("../config");
const Constant = require( "../utils/constant/generic" );

/**
 * 
 * @param {Object} request 
 * @returns {Object}
 */
async function getSubProfiles(request) {
	try {
		const { tokenInfo, userToken } = request;
		let params = {
			uid: tokenInfo.uid
		};
		const subProfileData = await subProfile.getAllSubProfilesInformation(params);
		let isDataExist = subProfileData.status == Constant.NO_UID_FOUND;
		if (isDataExist) throw apiResponse.error(errorConfig.getAllSubProfile.description, errorConfig.getAllSubProfile.code);
		isDataExist=userToken.status==Constant.NO_UID_FOUND;
		if (isDataExist) throw apiResponse.error(errorConfig.userDoesNotExist.description, errorConfig.userDoesNotExist.code);
		const userAuthMongo = await mongoSubProfile.getAllSubProfileFormat(subProfileData, request,userToken);
		if (userAuthMongo) return userAuthMongo;
		throw apiResponse.error(errorConfig.getAllSubProfile.description,errorConfig.getAllSubProfile.code);

	} catch (err) {
		console.error("\n Error in getSubProfiles Business/catch \n", err);
		throw err;
	}

}



module.exports = class ModuleError extends Error {
	constructor(code, message, data,eventName) {
		// Calling parent constructor of base Error class.
		super(message);

		// Saving class name in the property of our custom error as a shortcut.
		this.name = this.constructor.name;

		// Capturing stack trace, excluding constructor call from it.
		Error.captureStackTrace(this, this.constructor);

		// You can use any additional properties you want.
		// I'm going to use preferred HTTP status for this error types.
		// `500` is the default value if not specified.
		this.code = code || 500;

		this.data = data || null;
		this.eventName = eventName || null;
		//mixpanelService(eventName, eventProps, distinctId, null, null, isAuthProject=false);
	}
    
};
"use strict";

const partnerSignInBusiness = require("../business").partnerSignIn;
const partnerSignInModel = require("../models").partnerSignIn;
const { common, apiResponse } = require("../utils");
const constantValue = require( "../utils/constant/generic" );
const _ = require("lodash");
const mixpanelEvent =require("../config/mixPanelConfig");
const loginInfoByDeviceIdService = require( "../services" ).loginInfoByDeviceIdService;
const { ipService } = require("../services");

module.exports = partnerSignIn;

async function partnerSignIn(request, response) {
	try {
		const input = request.body;
		console.debug("API URL:", request.url);
		console.info({ input });

		const { error } = partnerSignInModel(input);
		if (error) {
			console.error("\n Error in partner \n", error);
			return response.status(400).send(apiResponse.error(common.formatValidationErrors(error),400,mixpanelEvent.partnerSignIn + _.get(input, "partnerType", "") + mixpanelEvent.clientValidation_Error, input, _.get(input.data, "externalId",input.data,"dsn"),400,false));
		}
		if (_.get(input, "data.source") == "ATV") {
			_.set(input, "data.source", "TSATV");
		}
		const { region, country } = await ipService.getCountryAndRegionDetails(request);
		_.set(input, "regionInfo", { region, country });

		const result = await partnerSignInBusiness(input);
		if ( result && result.data && result.data.uId ) {
			input.type = constantValue.typeInPartnerSignInRequest;
			let extraPrams={
				userAgent:request.headers["user-agent"] || "",
				platform:request.headers["platform"] || ""
			};
			const deviceLoginData = await loginInfoByDeviceIdService.initDeviceIdLoginDetails( input, result.data, result.data.email, result.data.mobile, result.data.countryCode ,constantValue.DeviceIdLoginDetailsStatus.ACTIVATE,{},extraPrams);
			if(!constantValue.BLOCK_DEVICEID_LLR.includes(_.get( deviceLoginData, "deviceId" ))){
				loginInfoByDeviceIdService.updateOneDeviceIdLoginDetails( { deviceId: _.get( deviceLoginData, "deviceId" ),uid:_.get( deviceLoginData, "uid" ) }, deviceLoginData, { upsert: true } ).catch( ( err => console.error( "Error while updating the record of deviceLoginDetails", deviceLoginData.deviceId, err ) ) );
			}
		}
		return response.status(200).send(result);
	} catch (error) {
		console.log("Error", JSON.stringify(error));
		if (error.https) {
			return response.status(error.https).send(error.error);
		} else {
			console.error(new Error(`${request.url} failed.`));
			console.log("response of api ",error);
			return response.status(500).send(error);
		}
	}
}

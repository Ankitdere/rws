"use strict";
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const refreshKsModel = require("../models").refreshKs;
const refreshKsBusiness = require("../business").refreshKs;
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");
const mixPanelConfig = require("../config/mixPanelConfig");

module.exports = refreshKs;

async function refreshKs(request, response) {
	let input = request.body;
	const headers = {
		accessToken: request.header("accessToken"),
		buildNumber: request.header("buildNumber"),
		deviceInfo: request.header("deviceInfo"),
		uid: request.header("uid"),
		deviceId: request.header("deviceId")
	};
	try {
		console.log("input: ", JSON.stringify(input, null, 2), "\n::: headers details ::: ", JSON.stringify(headers, null, 2));

		const { error } = refreshKsModel(request.header("accessToken"), input);

		if (error) {
			console.log("\n Error in refreshKs/validation \n",error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error),0,mixPanelConfig.refreshKs+mixPanelConfig.clientValidation_Error, {headers:headers,input:input},_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID"))));
		} else {
			const result = await refreshKsBusiness(input, request.tokenInfo, _.get(headers, "deviceId"));
			const output = commonUtils.responseFormatter(result);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData,null,200,mixPanelConfig.refreshKs+mixPanelConfig.success, input,_.get(request.userToken,"email",_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID")))));
		}
	} catch (error) {
		console.log("\n Error in refreshKs/catch \n",error);
		//TODO: Only send product-approved messages to the end-user
		if (error == errorConfig.invalidkToken.description)
			return response.status(400).send(apiResponse.error(errorConfig.invalidkToken.description, errorConfig.invalidkToken.code,mixPanelConfig.refreshKs+mixPanelConfig.serverValidation_Error, {headers:headers,input:input},_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID")),400));

		if (error == errorConfig.invalidkTokenId.description)
			return response.status(400).send(apiResponse.error(errorConfig.invalidkTokenId.description, errorConfig.invalidkTokenId.code,mixPanelConfig.refreshKs+mixPanelConfig.serverValidation_Error, {headers:headers,input:input},_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID"))));
		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData,null,output.httpCode,mixPanelConfig.refreshKs+mixPanelConfig.serverValidation_Error, {headers:headers,input:input},_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID"))));
		}
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(errorConfig.requestFailed,500,mixPanelConfig.refreshKs+mixPanelConfig.internalServerError, {headers:headers,input:input,error:_.get(error,"stack")},_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID"))));
	}
}
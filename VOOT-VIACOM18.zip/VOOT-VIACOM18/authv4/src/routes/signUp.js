
"use strict";
const signUpBusiness = require("../business").signUp;
const signUpModel = require("../models").signUp;
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const errorConfig = require("../config").errorConfig;
const config = require("../config").configuration;
const _ = require("lodash");
const requestIp = require("request-ip");
const iplocation = require("geoip-lite");
const mixpanelConfig = require("../config/mixPanelConfig");
const loginInfoByDeviceIdService = require( "../services" ).loginInfoByDeviceIdService;
const constant = require("../utils/constant/generic");
const { ipService } = require("../services");

module.exports = signUp;

async function signUp(request, response) {
	const input = request.body;
	try {
		console.log("Sign Up Request Received with input", JSON.stringify(input, null, 2));
		_.set(input, "type", _.toLower(_.get(input, "type", "")));
		if(_.has(input,"data.email"))_.set(input, "data.email", _.toLower(_.get(input, "data.email")));
		if (!_.includes(commonUtils.signUpTypes, input.type)) {
			console.error("\n Error in signUp(typeMissing.description, typeMissing.code) \n");
			_.unset(input,"password");
			return response.status(400).send(apiResponse.error(errorConfig.typeMissing.description, errorConfig.typeMissing.code,mixpanelConfig.signup+_.get(input, "type", "")+mixpanelConfig.clientValidation_Error,input,_.get(input.data,"email",_.get(input.data,"mobile")),400));
		}
		//block social account signup
		if (commonUtils.blockByProvider(input.type) && commonUtils.blockByPlatform(request.headers["user-agent"] || "")) {
			let provider=(input.type=="traditional")?"email":input.type;
			let blockMsg=commonUtils.notallowedSignupMethod(provider);
			return response.status(400).send(apiResponse.error(blockMsg.description, blockMsg.code.code,mixpanelConfig.signup+_.get(input, "type", "")+mixpanelConfig.clientValidation_Error,input,_.get(input.data,"email",_.get(input.data,"mobile")),400));
		}
		const ipAddress = requestIp.getClientIp(request);
		let countryCode = _.get(iplocation.lookup(ipAddress), "country", "NA");
		_.set(input, "countryCode", countryCode);
		const { error } = signUpModel(input);
		if (error){
			console.error("\n Error in signUp/validation \n",error,error.stack);
			_.unset(input,"password");
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error),0,mixpanelConfig.signup+_.get(input, "type", "")+mixpanelConfig.clientValidation_Error,input,_.get(input.data,"email",_.get(input.data,"mobile")),400));
		}
		const languagelist = _.get(input, "data.languages");
		for (const index in languagelist) {
			if (!config.DefaultLanguages.includes(languagelist[index])) {
				return response.status(400).send(apiResponse.error(errorConfig.invalidLanguage.description, errorConfig.invalidLanguage.code,mixpanelConfig.signup+_.get(input, "type", "")+mixpanelConfig.clientValidation_Error,input,_.get(input.data,"email",_.get(input.data,"mobile")),400));
			}
		}
		
		const { region, country } = await ipService.getCountryAndRegionDetails(request);
		_.set(input, "regionInfo", { region, country });
		
		const result = await signUpBusiness(input);
		const output =  commonUtils.responseFormatter(result);
		if ( result && result.data && result.data.uId ) {
			let extraPrams={
				userAgent:request.headers["user-agent"] || "",
				platform:request.headers["platform"] || ""
			};
			const deviceLoginData = await loginInfoByDeviceIdService.initDeviceIdLoginDetails( input, result.data, result.data.email, result.data.mobile, result.data.countryCode, constant.DeviceIdLoginDetailsStatus.ACTIVATE,{},extraPrams );
			if(!constant.BLOCK_DEVICEID_LLR.includes(_.get( deviceLoginData, "deviceId" ))){
				loginInfoByDeviceIdService.updateOneDeviceIdLoginDetails( { deviceId: _.get( deviceLoginData, "deviceId" ), uid:_.get( deviceLoginData, "uid" ) }, deviceLoginData, { upsert: true } ).catch( ( err => console.error( "Error while updating the record of deviceLoginDetails", deviceLoginData.deviceId, err ) ) );
			}
		}
		// Send mixpanel Event 
		let eventName = mixpanelConfig.signup+_.get(input, "type", "")+mixpanelConfig.success ;
		if(output.httpCode && output.httpCode  != 200){
			eventName = mixpanelConfig.signup+_.get(input, "type", "")+mixpanelConfig.serverValidation_Error; 
		}
		return response.status(output.httpCode).send(apiResponse.success(output.responseData,output.responseData,output.httpCode,eventName, {distinct_id: _.get(input.data,"email",_.get(input.data,"mobile")),UID: _.get(output.responseData.data,"uId"),email: _.get(input.data,"email"), mobile:_.get(input.data,"mobile"), input:input},_.get(input.data,"email",_.get(input.data,"mobile"))));
	} catch (error) {
		console.error("\n Error in signUp/catch \n",JSON.stringify(error),error.stack);
		if(error.message == errorConfig.emailAlreadyRegistered.code){
			return response.status(400).send(apiResponse.error(errorConfig.emailAlreadyRegistered.description, errorConfig.emailAlreadyRegistered.code,mixpanelConfig.signup+_.get(input, "type", "")+mixpanelConfig.serverValidation_Error,input,_.get(input.data,"email",_.get(input.data,"mobile")),400));
		}
		let responseCode = (_.get(error, "status.code") ? _.get(error, "status.code") : 500);
		// Send mixpanel Event
		try{
			// let eventProps = {userInput: input,input, error: error, httpCode: 500, distinct_id:_.get(input,'email')}
			apiResponse.error({message:_.get(error,"stack",error)},null,mixpanelConfig.signup+_.get(input, "type", "")+mixpanelConfig.internalServerError,input,_.get(input.data,"email",_.get(input.data,"mobile")),500);
			// mixpanelService(mixpanelConfig.signup+_.get(input, 'type', '')+mixpanelConfig.serverValidation_Error,eventProps,_.get(input.data,'email'))
		}catch(err){
			console.error("Error in sending mixpanel Event",err);
		}
		if (responseCode != 500)
			responseCode = 400;
		return response.status(responseCode).send(apiResponse.error(error));
	}
}
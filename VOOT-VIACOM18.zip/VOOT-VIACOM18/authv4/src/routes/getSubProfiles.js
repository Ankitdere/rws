
"use strict";

const _ = require("lodash");
const { getSubProfiles: getSubProfilesBusiness } = require("../business");
const { getSubProfiles: getSubProfilesModel } = require("../models");
const {
	common: commonUtils,
	apiResponse
} = require("../utils");
const {
	mixpanelEvent: mixPanelConfig,
} = require("../config");

module.exports = getSubProfiles;

/**
 * 
 * @param {Object} request 
 * @param {Object} response 
 * @returns {Object}
 */
async function getSubProfiles(request, response) {
	try {
		const headers = {
			accessToken: request.header("accessToken")
		};
		console.log(
			"\n::: headers details ::: ", JSON.stringify(headers, null, 2)
		);
		const { error } = getSubProfilesModel(headers);

		if (error) {
			console.error("\n Error in getSubProfiles/validation \n", error);
			const mpModelErrEventName = mixPanelConfig.getSubProfiles + mixPanelConfig.clientValidation_Error;
			return response
				.status(400)
				.send(
					apiResponse.error(
						commonUtils.formatValidationErrors(error),
						400,
						mpModelErrEventName,
						null,
						request.userToken.uid,
						400)
				);
		}

		const result = await getSubProfilesBusiness(request);
		const output = commonUtils.responseFormatter(result);
		const mpSuccessEventName = mixPanelConfig.getSubProfiles + mixPanelConfig.success;
		return response
			.status(output.httpCode)
			.send(
				apiResponse.success(
					output.responseData ,
					null,
					200,
					mpSuccessEventName,
					null,
					request.userToken.uid)
			);
	} catch (error) {
		console.error("\n Error in getSubProfiles Route/catch \n", error);
		if (error.status && error.status.code && error.status.code != 400) {
			return response.status(400).send(error);
		}
		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response
				.status(output.httpCode)
				.send(
					apiResponse.success(null, output.responseData)
				);
		}
		const mpInternalServerErrEventName = mixPanelConfig.getSubProfiles + mixPanelConfig.internalServerError;
		return response
			.status(500)
			.send(
				apiResponse.error(
					error.message, 
					500, 
					mpInternalServerErrEventName, 
					request.userToken, 
					request.userToken.uid, 
					500)
			);
	}
}

const anonymousTokenModel = require("../models/index").anonymousTokenModel;
const commonUtils = require("../utils").common;
const anonymousTokenBusiness = require("../business").anonymousTokenBusiness;
const { apiResponse } = require("../utils");
const Config = require("../config").configuration;
const errorUtilities = require("../config").errorConfig;
const mixPanelConfig = require("../config/mixPanelConfig");
const _ = require("lodash");

async function createAndValidateToken(request, response) {
	let eventBaseName = "";
	if (_.get(request, "path") === "/token") eventBaseName = mixPanelConfig.token;
	else if (_.get(request, "path") === "/token/verify") eventBaseName = mixPanelConfig.tokenVerify;
	else if (_.get(request, "path") === "/token/refresh") eventBaseName = mixPanelConfig.tokenRefresh;
	try {
		const input = request.body;
		let result;
		let headers = request.headers;
		let grantTypeRequest = "";
		console.debug(`X-Voot-Origin: ${ request.headers["x-voot-origin"] || request.headers["X-Voot-Origin"] }`);
		if(request.url == "/token/refresh"){
			grantTypeRequest = request.body.grantType;
			input.grantType = "refresh_token";
		}
		const { error } = anonymousTokenModel.validateCreateToken(input);
		if (error) {
			console.error("\n Error in login/validation \n", error);
			if (grantTypeRequest!="") input.grantType = grantTypeRequest;
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error),0,eventBaseName+mixPanelConfig.clientValidation_Error,input,input.clientId,400));
		}
		if (input.partnerName && input.partnerName != Config.AnonymousTokenClientAndPartnerMap[input.clientId]) {
			console.error(`Invaliad Partner Name is provided: partnerName ${ input.partnerName } and ClientId ${ input.clientId }`);
			if (grantTypeRequest != "") input.grantType = grantTypeRequest;
			return response.status(400).send(apiResponse.error(errorUtilities.invalidAnonymosTokenPartnerName.description,errorUtilities.invalidAnonymosTokenPartnerName.code,eventBaseName+mixPanelConfig.clientValidation_Error,input,input.clientId,400));
		}
		console.debug("Anonymous create And Refresh Token Request Received with input", JSON.stringify(input, null, 2));
		if(request.url == "/token/refresh"){
			input.grantTypeRequest = grantTypeRequest;
			// input.grantType = 'refresh_token';
		}
		result = await anonymousTokenBusiness.createAccessAndRefreshToken(input,headers.accesstoken);
		// console.log(apiResponse.success(result));
		return response.status(200).send(apiResponse.success({ data: result },null,200,eventBaseName+mixPanelConfig.success,input,input.clientId));
	} catch (err) {
		console.error("Error while creating anonymousToken", err);
		// return response.status(400).send(err);
		if (err.status && err.status.code && err.status.code != 400) {
			return response.status(400).send(err);
		} else {
			console.log("response of api ",err);
			return response.status(500).send(err);
		}
	}
}
async function verifyToken(request, response) {
	let headers = request.headers;
	const input = request.body;
	try {
		if (!headers.accesstoken) {
			console.error("Anonymous verifyToken()::Access token not available in header");
			return response.status(400).send(apiResponse.error(errorUtilities.verifyApiAccessTokenRequired.description,errorUtilities.verifyApiAccessTokenRequired.code,mixPanelConfig.tokenVerify+mixPanelConfig.clientValidation_Error,input,input.clientId,400));
		}
		let accessToke = headers.accesstoken;
		if (!Config.AnonymousTokenClientId.includes(input.clientId)) {
			console.error("\n Invalid partner in Anonymous verifyToken \n");
			return response.status(400).send(apiResponse.error(errorUtilities.invalidAnonymosTokenClientId.description, errorUtilities.invalidAnonymosTokenClientId.code,mixPanelConfig.tokenVerify+mixPanelConfig.clientValidation_Error,input,input.clientId,400));
		}
		const decodedToken=await anonymousTokenBusiness.verifyToken(accessToke,input.clientId, input.grantType,false,mixPanelConfig.tokenVerify);
		if (Config.AnonymousGrantTypeCheckDisable.includes(input.clientId) || decodedToken.grantType == input.grantType) {
			apiResponse.success(decodedToken.userData,null,200,mixPanelConfig.tokenRefresh+mixPanelConfig.success,input,input.clientId);
			return response.status(200).send(decodedToken.userData);
		}
		return response.status(400).send(apiResponse.error(errorUtilities.invalidGrantTypeInVerify.description,errorUtilities.invalidGrantTypeInVerify.code,mixPanelConfig.tokenRefresh+mixPanelConfig.serverValidation_Error,input,input.clientId,400));
	}
	catch (err) {
		console.error("Error in AnonymousTokenService.verifyToken()", err);
		// return response.status(400).send(err);
		if (err.status && err.status.code && err.status.code != 400) {
			return response.status(400).send(err);
		} else {
			console.log("response of api ",err);
			return response.status(500).send(err);
		}
	}
}

module.exports = {
	createAndValidateToken,
	verifyToken,
};
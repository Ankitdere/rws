"use strict";

const resetPasswordWithLoginBusiness = require("../business").resetPasswordWithLogin;
const resetPasswordWithLoginModel = require("../models").resetPasswordWithLogin;
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");
const mixPanelConfig = require("../config/mixPanelConfig");

module.exports = resetPasswordWithLogin;

async function resetPasswordWithLogin(request, response){
	console.debug("Inside Reset Password With Login");  
	const input = request.body;
	const tokenInfo=request.tokenInfo;
	const distinctId = _.get(tokenInfo,"email",_.get(tokenInfo,"uid","No_UID"));
	try {
		console.log("Reset Password With Login Request Received", JSON.stringify(input, null, 2));
		const headers={
			forgotpasswordtoken:request.headers.forgotpasswordtoken
		};
		const { error } =resetPasswordWithLoginModel(input,headers );
		if (error) {
			console.error("\n Error in resendPassword/validation \n", error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error),400,mixPanelConfig.resetPasswordWithLogin+mixPanelConfig.clientValidation_Error,input,distinctId));
		}
		const result = await resetPasswordWithLoginBusiness(input,tokenInfo);
		const output = commonUtils.responseFormatter(result);
		return response.status(output.httpCode).send(apiResponse.success(output.responseData,null,200,mixPanelConfig.resetPasswordWithLogin+mixPanelConfig.success,input,distinctId));
	} catch (error) {
		console.log("\n Error in resendPassword/validation\n", error);

		if(error.message == errorConfig.invalidDeviceBrand.code){
			return response.status(400).send(apiResponse.error(errorConfig.invalidDeviceBrand.description, errorConfig.invalidDeviceBrand.code,mixPanelConfig.resetPasswordWithLogin+mixPanelConfig.serverValidation_Error,input,distinctId));
		}
		if (error.message == errorConfig.invalidPassword.description)
			throw new Error(apiResponse.error(errorConfig.invalidPassword.description, errorConfig.invalidPassword.code,mixPanelConfig.resetPasswordWithLogin+mixPanelConfig.serverValidation_Error,input,distinctId,400));
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(errorConfig.requestFailed,500,mixPanelConfig.resetPasswordWithLogin+mixPanelConfig.internalServerError,{input:input,tokenInfo: tokenInfo, error:_.get(error, "stack")},distinctId,500));
	}
}
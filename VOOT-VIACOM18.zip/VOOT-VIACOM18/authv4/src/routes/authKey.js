"use strict";
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const authKeyModel = require("../models").authKey;
const authKeyBusiness = require("../business").authKey;
const _ =  require("lodash");
const mixPanelConfig = require("../config/mixPanelConfig");
module.exports = authKey;

async function authKey(request, response) {
	console.log("Reached Profiles Handler");
	const headers = {
		accessToken: request.header("accessToken"),
		buildNumber: request.header("buildNumber"),
		deviceInfo: request.header("deviceInfo"),
		uid: request.header("uid"),
		lastLoginProvider: request.header("lastLoginProvider"),
		profileId: request.header("profileId")
	};
	try {
		console.log("::: headers details ::: ", JSON.stringify(headers, null, 2));
		const { error } = authKeyModel({ accessToken: headers["accessToken"], lastLoginProvider: headers["lastLoginProvider"], profileId: headers["profileId"]});

		// check the error and return if error exist
		if (error) {
			console.log("\n Error in getAuthKey/validation \n",error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error),0,mixPanelConfig.getAuthKey+mixPanelConfig.clientValidation_Error, headers,_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID"))));
		}
		//update the value of lastLoginProvider VOOTDESK-1297
		if(_.isEmpty(headers["lastLoginProvider"])){
			console.log("update the value of headers['lastLoginProvider'] to NA");
			headers["lastLoginProvider"] = "NA";
		}

		// Get data from firebase createAccessTokenForScreenz
		const result = await authKeyBusiness(headers["lastLoginProvider"], headers["profileId"], request.tokenInfo, request.userToken);
		const output = commonUtils.responseFormatter(result);
		return response.status(output.httpCode).send(apiResponse.success(output.responseData,null,200,mixPanelConfig.getAuthKey+mixPanelConfig.success,headers,_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID"))));

	} catch (error) {
		console.log("\n Error in getAuthKey/catch \n",error);
		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData,null,output.httpCode,mixPanelConfig.getAuthKey+mixPanelConfig.serverValidation_Error,headers,_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID"))));
		}
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(error,500,mixPanelConfig.getAuthKey+mixPanelConfig.internalServerError,{headers:headers, error:_.get(error,"stack")},_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID")))); //TODO: Only send product-approved messages to the end-user
	}
}
"use strict";
const _ = require("lodash");
const checkEmailBusiness = require("../business").checkEmail;
const { checkEmail: checkEmailModel } = require("../models");
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;

/**
 * @param {object} request request.body contains email
 * @param {object} response 
 * @returns {object} apiResponse in case of success or failure 
 */
async function checkEmail(request, response) {
	try {
		const input = request.body;
		if (_.has(input, "email")) _.set(input, "email", _.toLower(_.get(input, "email")));
		const {
			error
		} = checkEmailModel(input);
		if (error === null) {
			const result = await checkEmailBusiness(input.email);
			const output = commonUtils.responseFormatter(result);
			return response.status(output.httpCode)
				.send(
					apiResponse.success(output.responseData)
				);
		}
		console.log("\n Error in checkEmail/validation \n", error);
		return response.status(400)
			.send(apiResponse.error(commonUtils.formatValidationErrors(error)));
	} catch (error) {
		console.log("\n Error in checkEmail/catch \n", error);
		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode)
				.send(
					apiResponse.success(output.responseData)
				);
		}
		return response.send(apiResponse.error(error));
	}
}

module.exports = checkEmail;
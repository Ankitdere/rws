
"use strict";
const { setAppleUnverifiedUserData}  = require("../business").appleRedirect;
const appleRedirectModel = require("../models").appleRedirect;
const { apiResponse } = require("../utils");
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");
const requestIp = require("request-ip");
const iplocation = require("geoip-lite");
const configurations = require("../config/configuration");

module.exports = appleRedirect;

async function appleRedirect(request, response) {
	try {
        
		let input = request.body;
		console.log("Login Request Received with input", JSON.stringify(input, null, 2));
		console.log("URL:",request.originalUrl);
		// Validate User Data
		const ipAddress = requestIp.getClientIp(request);
		let countryCode = _.get(iplocation.lookup(ipAddress), "country", "NA");
		_.set(input, "countryCode", countryCode);
		const { error } = appleRedirectModel(input);
		if (error){
			console.log("\n Error in appleRedirect/validation \n",error);
			if(request.originalUrl === "/usersV3/v3/appleRedirect-app"){
				return response.redirect(303, configurations.ApppleSignIn.redirectUrl);
			}else{
				return response.redirect(303, configurations.ApppleSignIn.redirectUrlApple);
			} 
		}
		let user = _.get(input,"user");
		let newUser ;
		if(user){
			newUser = JSON.parse(user);
		}
		let requestUrl  = request.originalUrl;
		const  unverifiedUserData = {
			state : _.get(input,"state",""),
			code : _.get(input,"code",""),
			id_token : _.get(input,"id_token",""),
			firstName :  _.get(newUser, "name.firstName",""),
			lastName :  _.get(newUser, "name.lastName",""),
			email :  _.get(newUser, "email",""),
			originalUrl: requestUrl 
		};
		console.log(unverifiedUserData);
		// Store User's data as apple-unverified-users'
		await setAppleUnverifiedUserData(unverifiedUserData);
		response.header("id_token",_.get(input,"id_token",""));
		if(request.originalUrl === "/usersV3/v3/appleRedirect-app"){
			return response.redirect(303, configurations.ApppleSignIn.redirectUrl+JSON.stringify(input.id_token));
		}else{
			if(unverifiedUserData.state == "web"){
				return response.redirect(303, configurations.ApppleSignIn.redirectUrlWeb+JSON.stringify(input.id_token));
			}
			return response.redirect(303, configurations.ApppleSignIn.redirectUrlApple+JSON.stringify(input.id_token));
		}   

	} catch (error) {
		console.log("\n Error in login/catch \n", error);
		// handlle kaltur errors
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(errorConfig.requestFailed));
	}
}
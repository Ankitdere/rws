"use strict";

const changePasswordWithLoginBusiness = require("../business").changePasswordWithLogin;
const changePasswordWithLoginModel = require("../models").changePasswordWithLogin;
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");
const requestIp = require("request-ip");
const mixPanelConfig = require("../config/mixPanelConfig");

module.exports = changePasswordWithLogin;

async function changePasswordWithLogin(request, response){
	console.debug("Inside Change Password With Login Code");
	let input = request.body;
	let tokenInfo =request.tokenInfo;
	const headers = {
		accessToken : request.header("accessToken"), 
	};
	const distinctId = _.get(tokenInfo,"email",_.get(tokenInfo,"uid","No_UID"));
	try {
		console.log("Inside Change Password With Login Code input: ", JSON.stringify(input, null, 2), "\n::: headers details ::: ", JSON.stringify(headers, null, 2));
		const { error } = changePasswordWithLoginModel(request.header("accessToken"),input);
		if (error) {
			console.error("\n Error in verifyCode/validation \n", error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error),0,mixPanelConfig.changePasswordWithLogin+mixPanelConfig.clientValidation_Error,input,distinctId,400));
		}
		const ipAddress = requestIp.getClientIp(request);
		const  methodType = request.method;
		let auditObj={
			ipAddress:ipAddress,
			methodType:methodType
		};
		const result = await changePasswordWithLoginBusiness(input,tokenInfo,auditObj);
		const output = commonUtils.responseFormatter(result);
		return response.status(output.httpCode).send(apiResponse.success(output.responseData,null,200,mixPanelConfig.changePasswordWithLogin+mixPanelConfig.success,input,distinctId));
	} catch (error) {
		console.log("\n Error in changePasswordWithLogin/catch \n", error);
		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData,null,200,mixPanelConfig.changePasswordWithLogin+mixPanelConfig.success,input,distinctId));
		}
		if(error.message == errorConfig.invalidDeviceBrand.code){
			return response.status(400).send(apiResponse.error(errorConfig.invalidDeviceBrand.description, errorConfig.invalidDeviceBrand.code,mixPanelConfig.changePasswordWithLogin+mixPanelConfig.serverValidation_Error,input,distinctId,400));
		}
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(errorConfig.requestFailed,500,mixPanelConfig.changePasswordWithLogin+mixPanelConfig.internalServerError,{input:input, error:_.get(error,"stack")},distinctId,500));
	}
}
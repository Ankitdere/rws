
"use strict";

const _ = require("lodash");
const { getSubProfilesAccessToken: getSubProfilesAccessTokenBusiness } = require("../business");
const { getSubProfilesAccessToken: getSubProfilesAccessTokenModel } = require("../models");
const {
	common: commonUtils,
	apiResponse
} = require("../utils");
const {
	errorConfig,
	mixpanelEvent: mixPanelConfig,
} = require("../config");

/**
 * @param {Object} request 
 * @param {Object} response 
 * @returns {Object}
 */
async function getSubProfileAccessToken(request, response) {
	const input = request.body;
	try {
		const headers = {
			accessToken: request.header("accessToken"),
			platform:request.header("platform"),
			device: request.header("device"),
		};
	
		console.log(
			"Input Request in getSubProfileAccessToken", JSON.stringify(input, null, 2),
			"\n::: headers details ::: ", JSON.stringify(headers, null, 2)
		);
		const { error } = getSubProfilesAccessTokenModel(headers, input);
		if (error) {
			console.error("\n Error in getSubProfileAccessToken/validation \n", error);
			const mpModelErrEventName = mixPanelConfig.getSubProfilesAccessToken + mixPanelConfig.clientValidation_Error;
			return response
				.status(400)
				.send(
					apiResponse.error(
						commonUtils.formatValidationErrors(error),
						400,
						mpModelErrEventName,
						input,
						request.userToken.uid,
						400
					)
				);
		}
		
		const result = await getSubProfilesAccessTokenBusiness(input, request);
		const output = commonUtils.responseFormatter(result);
		const mpSuccessEventName = mixPanelConfig.getSubProfilesAccessToken + mixPanelConfig.success;
		return response
			.status(output.httpCode)
			.send(
				apiResponse.success(
					{ "data": output.responseData },
					null,
					200,
					mpSuccessEventName,
					input,
					request.userToken.uid
				)
			);
	} catch (error) {
		console.error("\n Error in getSubProfileAccessToken Route/catch \n", error);
		const mpServerErrEventName = mixPanelConfig.subProfileDoesNotExist + mixPanelConfig.serverValidation_Error;

		if (error && error.message == errorConfig.subProfileDoesNotExist.description) {
			const { description, code } = errorConfig.subProfileDoesNotExist;
			return response
				.status(400)
				.send(
					apiResponse.error(
						description, 
						code, 
						mpServerErrEventName, 
						input, 
						request.userToken.uid, 
						400)
				);
		}

		if (error && error.message == errorConfig.getSubProfilesAccessToken.description) {
			const { description, code } = errorConfig.getSubProfilesAccessToken;
			return response
				.status(400)
				.send(
					apiResponse.error(
						description, 
						code, 
						mpServerErrEventName, 
						input, 
						request.userToken.uid, 
						400)
				);
		}
		if (error && error.message == errorConfig.parentPinError.description) {
			const mpServerErrEventName = mixPanelConfig.parentPinError + mixPanelConfig.serverValidation_Error;
			const { description, code } = errorConfig.parentPinError;
			return response
				.status(400)
				.send(
					apiResponse.error(
						description, 
						code, 
						mpServerErrEventName, 
						input, 
						request.userToken.uid, 
						400)
				);
		}

		if (error && error.message == errorConfig.parentPinModeError.description) {
			const mpServerErrEventName = mixPanelConfig.parentPinModeError + mixPanelConfig.serverValidation_Error;
			const { description, code } = errorConfig.parentPinModeError;
			return response
				.status(400)
				.send(
					apiResponse.error(
						description, 
						code, 
						mpServerErrEventName, 
						input, 
						request.userToken.uid, 
						400)
				);
		}
		if (error && error.message == errorConfig.invalidDeviceAndPlatformMissMatch.description) {
			const { description, code } = errorConfig.invalidDeviceAndPlatformMissMatch;
			return response
				.status(400)
				.send(
					apiResponse.error(
						description, 
						code, 
						null,
						input, 
						request.userToken.uid, 
						400)
				);
		}

		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response
				.status(output.httpCode)
				.send(
					apiResponse.success(null, output.responseData)
				);
		}

		const mpInternalServerErrEventName = mixPanelConfig.getSubProfilesAccessToken + mixPanelConfig.internalServerError;
		return response
			.status(500)
			.send(
				apiResponse.error(
					error.message, 
					500, 
					mpInternalServerErrEventName, 
					input, 
					request.userToken.uid, 
					500)
			);
	}
}
module.exports = getSubProfileAccessToken;
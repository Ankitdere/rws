
"use strict";

const getUserProfileBusiness = require("../business").getUserProfile;
const getProfileModel = require("../models").getProfile;
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");
const mixPanelConfig  = require("../config/mixPanelConfig");
const { ipService } = require("../services");

module.exports = getUserProfile;

async function getUserProfile(request, response) {
	const headers = {
		accessToken: request.header("accessToken"),
		apiVersion:request.header("apiVersion"),
		profiletype:request.header("profile-type"),
		deviceId:request.header("deviceId"),
		device:request.header("device"),
		platform:request.header("platform"),
	};
	try {
		console.debug("Reached get-profile Handler");
		console.log( "\n::: headers details for get-profile ::: ", JSON.stringify(headers, null, 2));
		let { DeviceList, PlatformList } = await commonUtils.returnDeviceAndPlatformsList();
		let  { error } =  getProfileModel(headers,DeviceList,PlatformList);
		if (error) {
			console.log("\n Error in getProfileModel/validation \n",error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error),0,mixPanelConfig.getProfile+mixPanelConfig.clientValidation_Error, headers,_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID"))));
		}
		if (headers && headers.apiVersion && headers.apiVersion=="v2") {
			await  commonUtils.customKsmDevicePlatformValidator(headers);  
		}  
		let endpoint = {};
		endpoint.path =  request.path;
		const { region, country } = await ipService.getCountryAndRegionDetails(request);
		endpoint.region = region;
		headers.region = region;
		headers.country=country;
		const result = await getUserProfileBusiness(request.userToken,headers,endpoint);
		const output = commonUtils.responseFormatter(result);
		return response.status(output.httpCode).send(apiResponse.success(output.responseData,null,200,mixPanelConfig.getProfile+mixPanelConfig.success,headers,_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID"))));
	} catch (error) {
		console.error("\n Error in getUserProfile/catch \n",error.stack);
		if(error.message == errorConfig.userDoesNotExist.code){
			return response.status(400).send(apiResponse.error(errorConfig.userDoesNotExist.description, errorConfig.userDoesNotExist.code,mixPanelConfig.getProfile+mixPanelConfig.serverValidation_Error, headers,_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID")),400));
		}
		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData,null,output.httpCode,mixPanelConfig.getProfile+mixPanelConfig.serverValidation_Error,headers,_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID"))));
		}
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(error,0,mixPanelConfig.getProfile+mixPanelConfig.internalServerError,{headers:headers,error:_.get(error,"stack")},_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID"))));
	}
}
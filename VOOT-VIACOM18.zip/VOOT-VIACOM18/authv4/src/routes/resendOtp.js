"use strict";

const resendOtpBusiness = require("../business").resendOtp;
const resendOtpModel = require("../models").resendOtp;
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const errorConfig = require("../config").errorConfig;
const forgetPassword = require("../business").forgotPassword;
const _ = require("lodash");
const mixPanelConfig = require("../config/mixPanelConfig");

module.exports = resendOtp;

async function resendOtp(request, response) {
	let input = request.body;
	try {
		//console.log("Inside resendOtp  Code");
		if(_.has(input,"email"))_.set(input, "email", _.toLower(_.get(input, "email")));
		const { error } = resendOtpModel(input);
		if (error) {
			console.error("\n Error in verifyCode/validation \n", error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error),400,mixPanelConfig.resendOtp+mixPanelConfig.clientValidation_Error,input, _.get(input,"mobile")));
		}
		if (_.get(input, "action") === "forgotPasswordOtp") {
			console.debug("Transfer to forgotPassword Controller whhich again resend the otp", input);
			let res = await forgetPassword(input);
			let output = commonUtils.responseFormatter(res);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData,null,400,mixPanelConfig.resendOtp+mixPanelConfig.success,input,_.get(input,"mobile")));
		} else {
			let result = await resendOtpBusiness(input, "resendOtp");
			let output = commonUtils.responseFormatter(result);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData,null,400,mixPanelConfig.resendOtp+mixPanelConfig.success,input,_.get(input,"mobile")));
		}
	} catch (error) {
		console.error("\n Error in resendOtpModel/catch \n", error);
		if (_.has(error, "status.code")) {
			commonUtils.responseFormatter(error);
		}

		if (error.message == errorConfig.otpDataNotFound.description) {
			return response.status(400).send(apiResponse.error(errorConfig.otpDataNotFound.description, errorConfig.invalidDeviceBrand.code,400,mixPanelConfig.resendOtp+mixPanelConfig.serverValidation_Error,input, _.get(input,"mobile")));
		}
		if (error.message == errorConfig.otpExpired.description) {
			return response.status(400).send(apiResponse.error(errorConfig.otpExpired.description, errorConfig.otpExpired.code,400,mixPanelConfig.resendOtp+mixPanelConfig.serverValidation_Error,input, _.get(input,"mobile")));
		}
		if (error.message == errorConfig.otpVerificationFailed.description) {
			return response.status(400).send(apiResponse.error(errorConfig.otpVerificationFailed.description, errorConfig.otpVerificationFailed.code,400,mixPanelConfig.resendOtp+mixPanelConfig.serverValidation_Error,input, _.get(input,"mobile")));
		} if (error.message == errorConfig.emailNotRegistered.description) {
			return response.status(400).send(apiResponse.error(errorConfig.emailNotRegistered.description, errorConfig.emailNotRegistered.code,400,mixPanelConfig.resendOtp+mixPanelConfig.serverValidation_Error,input, _.get(input,"mobile")));
		}
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(error,500,mixPanelConfig.resendOtp+mixPanelConfig.internalServerError,{input:input,error:_.get(error,"stack")},500));
	}
}
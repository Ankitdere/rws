"use strict";

const activateCodeBusiness = require("../business").activateCode;
const activateCodeModel = require("../models").activateCode;
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const _ = require("lodash");
const errorConfig = require("../config").errorConfig;
const mixPanelConfig = require("../config/mixPanelConfig");
module.exports = activateCode;

async function activateCode(request, response) {
	const activationCode = {
		code: _.get(request, "query.code"),
		accessToken: request.header("accessToken")
	};
	let { email } = request.tokenInfo;
	try {
		const { error } = activateCodeModel(activationCode);
		if (error) {
			console.error("\n Error in activate/validation \n", error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error),0,mixPanelConfig.activate+mixPanelConfig.clientValidation_Error,activationCode,email,400));
		}

		const result = await activateCodeBusiness(activationCode, request.userToken);
		const output = commonUtils.responseFormatter(result);
		return response.status(output.httpCode).send(apiResponse.success(output.responseData,null,output.httpCode,mixPanelConfig.activate+mixPanelConfig.success,activateCode,email));

	} catch (error) {
		console.error("\n Error in activate/catch \n", error);
		if (error.message == errorConfig.expiredDeviceActivationCode.code) {
			return response.status(400).send(apiResponse.error(errorConfig.expiredDeviceActivationCode.description, errorConfig.expiredDeviceActivationCode.code,mixPanelConfig.activate+mixPanelConfig.serverValidation_Error,activationCode,email,400));
		}
		if (error.message == errorConfig.invalidDeviceActivationCode.code) {
			return response.status(400).send(apiResponse.error(errorConfig.invalidDeviceActivationCode.description, errorConfig.invalidDeviceActivationCode.code,mixPanelConfig.activate+mixPanelConfig.serverValidation_Error,activationCode,email,400));
		}
		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData,null,output.httpCode,mixPanelConfig.activate+mixPanelConfig.serverValidation_Error,activationCode,email,output.httpCode));
		}
		console.log("response of api ",error);
		return response.status(500).send(error);
	}
}
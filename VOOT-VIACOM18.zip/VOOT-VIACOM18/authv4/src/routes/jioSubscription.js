"use strict";

const jioSubscriptionBusiness = require("../business").jioSubscription;
const jioSubscriptionModel = require("../models").jioSubscription;
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const _ = require("lodash");
const errorConfig = require("../config").errorConfig;

module.exports = jioSubscription;

async function jioSubscription(request, response) {
	try {
		const headers = {
			ssoToken: request.header("sso-token"),
			buildNumber: request.header("buildNumber"),
			deviceId: request.header("deviceId"),
			deviceName: request.header("deviceName"),
			uid: request.header("uid"),
			subscriberId: _.get(request, "body.subscriberId"),
			accessToken: request.header("accessToken")
		};
		const { error } = jioSubscriptionModel(headers);
		if (error) {
			console.log("\n Error in activate/validation \n", error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error)));
		}

		const result = await jioSubscriptionBusiness(headers);
		const output = commonUtils.responseFormatter(result);
		return response.status(output.httpCode).send(apiResponse.success(output.responseData));

	} catch (error) {
		console.log("\n Error in activate/catch \n", error);
		if (error.message == errorConfig.wrongPassword.code) {
			return response.status(400).send(apiResponse.error(errorConfig.expiredDeviceActivationCode.description, errorConfig.expiredDeviceActivationCode.code));
		}
		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData));
		}
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(errorConfig.requestFailed));
	}
}

"use strict";
const sendMessageBusiness = require("../business").sendMessage;
const sendMessageModel = require("../models").sendMessageModel;
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const errorConfig = require("../config").errorConfig;
const config = require("../config/configuration");
const _ = require("lodash");
module.exports = sendMessage;
/**
 * route 
 * @param {*} request 
 * @param {*} response 
 * @returns 
 */
async function sendMessage(request, response) {
	try {
		const apiKey = request.header("apiKey");
		//validate API key
		if(!apiKey){
			return response.status(403).send(apiResponse.error(
				errorConfig.apiKeyDoesNotExist.description, errorConfig.apiKeyDoesNotExist.code));
		}
		if(apiKey !== config.SendMessageAPIKey ){
			return response.status(403).send(apiResponse.error(
				errorConfig.invalidApiKey.description, errorConfig.invalidApiKey.code));
		}
		const input = request.body;
		console.log("Send Message API ", JSON.stringify(input));
		const { error } = sendMessageModel(input);
		if (error) {
			console.error("\n Error in Send Message Data/validation \n", error,error.stack);
			return response.status(400).send(
				apiResponse.error(commonUtils.formatValidationErrors(error)));
		}
		const result = await sendMessageBusiness(input);
		const output = commonUtils.responseFormatter(result);
		return response.status(output.httpCode).send(apiResponse.success(output.responseData));
		
	} catch (error) {
		console.error("\n Error in Send Message API/catch \n", error);
		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData));
		}
		return response.send(apiResponse.error(error));
	}
}
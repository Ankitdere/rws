const { smsData: modelValidation } = require("../models");
const {
	apiResponse,
	dateTime,
	common: commonUtils,
} = require("../utils");
const { smsData: businessLogic } = require("../business");
const {
	errorConfig,
	configuration: config,
} = require("../config");

const DEFAULT_DATE_FORMAT = "DD-MM-YYYY";

/**
 * @param {String} apiKey 
 * @returns {{isValid: Boolean, reason: String}} success status and root cause if any
 */
const validateApiKey = function (apiKey) {
	if (typeof apiKey !== "string") {
		return {
			isValid: false,
			reason: "invalidApiKey",
		};
	}
	if (apiKey.length === 0) {
		return {
			isValid: false,
			reason: "apiKeyDoesNotExist",
		};
	}
	const { SmsDataAPIKeyList: apiKeyList = [] } = config;
	if (apiKeyList.includes(apiKey) === false) {
		return {
			isValid: false,
			reason: "invalidApiKey",
		};
	}
	return {
		isValid: true,
		reason: "",
	};
};

/**
 * @param {Object} request 
 * @param {Object} response 
 */
const smsData = async function (request, response) {
	try {
		const apiKey = request.header("apiKey");
		const { isValid, reason = "" } = validateApiKey(apiKey);
		if (isValid === false) {
			const { description, code } = errorConfig[reason];
			return response.status(403)
				.send(
					apiResponse.error(description, code)
				);
		}

		const { body: requestBody } = request;
		const { error } = modelValidation(requestBody);
		if (error) {
			console.error("\n Error in smsData Data/validation \n", error);
			return response.status(400)
				.send(
					apiResponse.error(commonUtils.formatValidationErrors(error))
				);
		}

		const dateOptions = {
			dateFormat: DEFAULT_DATE_FORMAT,
		};
		const { startDate, endDate } = requestBody;
		const invalidDateIndex = dateTime.getInvalidDateIndex(dateOptions, [startDate, endDate]);
		if (invalidDateIndex !== -1) {
			const causeList = ["invalidStartDateFormat", "invalidEndDateFormat"];
			const { description, code } = errorConfig[causeList[invalidDateIndex]];
			return response.status(400)
				.send(
					apiResponse.error(description, code)
				);
		}
		if (
			(startDate !== endDate) &&
			(!dateTime.isBefore(dateOptions, startDate, endDate))
		) {
			const { description, code } = errorConfig.invalidDateFormat;
			return response.status(400)
				.send(
					apiResponse.error(description, code)
				);
		}

		/**
		 * Converting dd-mm-yyyy to yyyy-mm-dd for ease of date functions
		 */
		const payload = {
			startDate: dateTime.reverseOrder(startDate),
			endDate: dateTime.reverseOrder(endDate),
		};
		const result = await businessLogic(payload);
		const output = commonUtils.responseFormatter(result);
		const { httpCode, responseData } = output;
		return response.status(httpCode)
			.send(
				apiResponse.success(responseData)
			);
	} catch (error) {
		console.error("\n Error in smsData API/catch \n", error, error.stack);
		if (error.hasOwnProperty("status") &&
			error.status.hasOwnProperty("code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode)
				.send(
					apiResponse.success(output.responseData)
				);
		}
		return response.send(apiResponse.error(error));
	}
};

module.exports = smsData;
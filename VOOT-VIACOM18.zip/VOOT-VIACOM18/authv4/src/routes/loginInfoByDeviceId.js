
"use strict";
const loginInfoByDeviceIdBusiness = require( "../business" ).loginInfoByDeviceIdBusiness;
const loginInfoByDeviceIdModel = require( "../models" ).loginInfoByDeviceId;
const commonUtils = require( "../utils" ).common;
const apiResponse = require( "../utils" ).apiResponse;
const responseFormat = require( "../format" ).responseFormat;
const _ = require( "lodash" );
module.exports = loginInfoByDeviceId;

async function loginInfoByDeviceId ( request, response ) {
	try {
		console.log( "Inside Get device/loginDetail" );
		let queryParamsData = {
			deviceId: _.get( request, "query.deviceId" )
		};
		const { error } = loginInfoByDeviceIdModel( queryParamsData );
		if ( error ) {
			console.log( "\n Error in device/loginDetail/validation \n", error );
			return response.status( 400 ).send( apiResponse.error( commonUtils.formatValidationErrors( error ) ) );
		}
		const result = await loginInfoByDeviceIdBusiness.getLoginInfoByDeviceId( queryParamsData.deviceId );
		const output = commonUtils.responseFormatter( responseFormat.responseGetLoginDetailsByDeviceId( result ) );
		return response.status( output.httpCode ).send( apiResponse.success( output.responseData ) );
	} catch ( error ) {
		console.log( "\n Error in device/loginDetail/catch \n", error );
		if ( _.has( error, "status.code" ) ) {
			const output = commonUtils.responseFormatter( error );
			return response.status( output.httpCode ).send( apiResponse.success( output.responseData ) );
		}
		return response.status( 500 ).send( apiResponse.error( error ) );
	}
}

"use strict";

const authsTokensBusiness = require("../business").authsTokens;
const authsTokensModel = require("../models").authsTokens;
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");
const requestIp = require("request-ip");
const mixPanelConfig = require("../config/mixPanelConfig");
module.exports = authsTokens;

async function authsTokens(request, response) {
	const input = request.body;
	try {
		console.log("input", input);
		const headers = {
			accessToken: request.header("accessToken"),
			platform: request.header("platform"),
			device: request.header("device"),
		};
		console.log("input: ", JSON.stringify(input, null, 2), "\n::: headers details ::: ", JSON.stringify(headers, null, 2));
		let { DeviceList, PlatformList } = await commonUtils.returnDeviceAndPlatformsList();
		const { error } = authsTokensModel(headers, input , DeviceList , PlatformList);
		if (error) {
			console.log("\n Error in auths/Tokens \n", error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error), 0, mixPanelConfig.authsTokens + mixPanelConfig.clientValidation_Error, input, _.get(request.userToken, "email", _.get(request.userToken, "uid", "No_UID"))));
		}
		await commonUtils.customKsmDevicePlatformValidator(headers);
		//prepare details for audit log
		//for audit data:
		const ipAddress = requestIp.getClientIp(request);
		const  methodType = request.method;
		let auditObj={
			ipAddress:ipAddress,
			methodType:methodType
		};  
		const result = await authsTokensBusiness(input, request.userToken, headers, auditObj);
		const output = commonUtils.responseFormatter(result);
		let eventName = mixPanelConfig.authsTokens+_.get(input, "type", "")+mixPanelConfig.success ;
		if(output.httpCode && output.httpCode  != 200){
			eventName = mixPanelConfig.authsTokens+_.get(input, "type", "")+mixPanelConfig.serverValidation_Error; 
		}
		return response.status(output.httpCode).send(apiResponse.success(output.responseData, null, output.httpCode, eventName, { input: input, distinct_id: _.get(request.userToken, "email", _.get(request.userToken, "uid", "No_UID")) }, _.get(request.userToken, "email", _.get(request.userToken, "uid", "No_UID"))));
	} catch (error) {
		console.log("\n Error in updateAccount/catch \n", error);
		if (error.message == errorConfig.userDoesNotExist.code) {
			return response.status(400).send(apiResponse.error(errorConfig.userDoesNotExist.description, errorConfig.userDoesNotExist.code, mixPanelConfig.authsTokens + mixPanelConfig.serverValidation_Error, input, _.get(request.userToken, "email", _.get(request.userToken, "uid", "No_UID")), 400));
		}
		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData));
		}
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(error, 0, 0, mixPanelConfig.authsTokens + mixPanelConfig.internalServerError, { input: input, error: _.get(error, "stack") }, _.get(request.userToken, "email", _.get(request.userToken, "uid", "No_UID")), 500));
	}
}
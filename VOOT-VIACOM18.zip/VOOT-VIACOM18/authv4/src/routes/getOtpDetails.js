"use strict";
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const getOtpDetailsModel = require("../models").getOtpDetailsModel;
const getOtpDetailsBusiness = require("../business").getOtpDetails;
const requestIp = require("request-ip");
const config = require("../config").configuration;
const errorConfig = require("../config").errorConfig;
const verifyToken = require("../services/AnonymousTokenService").verifyToken;
const _ = require("lodash");

module.exports = getOtpDetails;
async function getOtpDetails(request, response) {
	try {

		if (config.getOtpDetails.isRetrieveOtp) {
			const input = request.body;
			const ipAddress = requestIp.getClientIp(request);
            
			const accessToken = request.header("accessToken");
			let whitelistip = config.getOtpDetails.whitelistIpArray;
			// check accesstoken is empty
			if (!accessToken) {
				return response.status(403).send(apiResponse.error(errorConfig.verifyApiAccessTokenRequired.description, errorConfig.verifyApiAccessTokenRequired.code));
			}
         
			console.log("WhitelistIP calling "+ ipAddress);
			// Check for the whitelist ip
			if (!whitelistip.includes(ipAddress)) {
				return response.status(403).send(apiResponse.error(errorConfig.noAuthorizeforgetOtp.description, errorConfig.noAuthorizeforgetOtp.code));
			}
			// Verify accessToken using service
			console.log(accessToken+" access = "+config.getOtpDetails.jwt.secret.access);
           
			const { error1 } = await verifyToken(accessToken, config.getOtpDetails.jwt.secret.access,"QA team","RetrieveOtp");
         
			if (error1) {
				return response.status(400).send(apiResponse.error(errorConfig.expiredProfileToken.description, errorConfig.expiredProfileToken.code));
			}

			const { error } = getOtpDetailsModel(input);

			if (error) {
				return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error)));
			}

			if (error) {
				console.log("\n Error in forgotPassword/validation \n", error);
				return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error)));
			}
			const result = await getOtpDetailsBusiness(input);
			const output = commonUtils.responseFormatter(result);

			return response.status(output.httpCode).send(apiResponse.success(output.responseData));
		}
		return response.status(403).send(apiResponse.error(errorConfig.noAuthorizeforgetOtp.description, errorConfig.noAuthorizeforgetOtp.code));

	}
	catch (error) {
		console.error("\n Error in getOtptoken/catch \n", error);
		if (error.message == errorConfig.emailNotRegistered.code) {
			return response.status(400).send(apiResponse.error(errorConfig.emailNotRegistered.description, errorConfig.emailNotRegistered.code));
		}

		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData));
		}
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(errorConfig.requestFailed, 400));
	}
}

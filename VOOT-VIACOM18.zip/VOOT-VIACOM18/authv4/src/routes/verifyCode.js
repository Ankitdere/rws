"use strict";

const verifyCodeBusiness = require("../business").verifyCode;
const verifyCodeModel = require("../models").verifyCode;
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");
const mixPanelConfig = require("../config/mixPanelConfig");
const constantValue = require( "../utils/constant/generic" );
const loginInfoByDeviceIdService = require( "../services" ).loginInfoByDeviceIdService;
const { ipService } = require("../services");
module.exports = verifyCode;

async function verifyCode(request, response){
	console.debug("Inside Verify Login Code");
	const verifyCode = {
		deviceBrand: _.get(request, "query.deviceBrand"),
		deviceId: _.get(request, "query.deviceId"),
		code: _.get(request, "query.code")
	};
	try {
		const { error } = verifyCodeModel(verifyCode);
		if (error) {
			console.error("\n Error in verifyCode/validation \n", error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error),0,`${mixPanelConfig.verifyCode}${mixPanelConfig.clientValidation_Error}`,verifyCode,verifyCode.deviceId,400));
		}
		const { region, country } = await ipService.getCountryAndRegionDetails(request);
		_.set(verifyCode, "regionInfo", { region, country });

		const result = await verifyCodeBusiness(verifyCode);
		const output = commonUtils.responseFormatter(result);
		if ( result && result.data && result.data.uId ) {
			verifyCode.type = constantValue.typeInVerifyCode;
			let extraPrams={
				userAgent:request.headers["user-agent"] || "",
				platform:request.headers["platform"] || ""
			};
			const deviceLoginData = await loginInfoByDeviceIdService.initDeviceIdLoginDetails( verifyCode, result.data, result.data.email, result.data.mobile, result.data.countryCode, constantValue.DeviceIdLoginDetailsStatus.ACTIVATE,{}, extraPrams );
			if(!constantValue.BLOCK_DEVICEID_LLR.includes(_.get( deviceLoginData, "deviceId" ))){
				loginInfoByDeviceIdService.updateOneDeviceIdLoginDetails( { deviceId: _.get( deviceLoginData, "deviceId" ), uid:_.get( deviceLoginData, "uid" ) }, deviceLoginData, { upsert: true } ).catch( ( err => console.error( "Error while updating the record of deviceLoginDetails", deviceLoginData.deviceId, err ) ) );
			}
		}
		return response.status(output.httpCode).send(apiResponse.success(output.responseData,null,200,`${mixPanelConfig.verifyCode}${mixPanelConfig.success}`,verifyCode,verifyCode.deviceId));
	} catch (error) {
		console.error("\n Error in verifyCode/catch \n", error);

		if(error.message == errorConfig.invalidDeviceBrand.code){
			return response.status(400).send(apiResponse.error(errorConfig.invalidDeviceBrand.description, errorConfig.invalidDeviceBrand.code,mixPanelConfig.verifyCode+mixPanelConfig.serverValidation_Error,verifyCode,verifyCode.deviceId,400));
		}
		if(error.message == errorConfig.invalidDeviceId.code){
			return response.status(400).send(apiResponse.error(errorConfig.invalidDeviceId.description, errorConfig.invalidDeviceId.code,mixPanelConfig.verifyCode+mixPanelConfig.serverValidation_Error,verifyCode,verifyCode.deviceId,400));
		}
		if(error.message == errorConfig.invalidDeviceActivationCode.code){
			return response.status(400).send(apiResponse.error(errorConfig.invalidDeviceActivationCode.description, errorConfig.invalidDeviceActivationCode.code,mixPanelConfig.verifyCode+mixPanelConfig.serverValidation_Error,verifyCode,verifyCode.deviceId,400));
		}
		if(error.message == errorConfig.loginCodeDeviceActivationFailure.code){
			return response.status(400).send(apiResponse.error(errorConfig.loginCodeDeviceActivationFailure.description, errorConfig.loginCodeDeviceActivationFailure.code,mixPanelConfig.verifyCode+mixPanelConfig.serverValidation_Error,verifyCode,verifyCode.deviceId,400));
		}
		if(error.message == errorConfig.expiredDeviceActivationCode.code){
			return response.status(400).send(apiResponse.error(errorConfig.expiredDeviceActivationCode.description, errorConfig.expiredDeviceActivationCode.code,mixPanelConfig.verifyCode+mixPanelConfig.serverValidation_Error,verifyCode,verifyCode.deviceId,400));
		}
		if(error.message == errorConfig.invalidAccessToken.code){
			return response.status(400).send(apiResponse.error(errorConfig.invalidAccessToken.description, errorConfig.invalidAccessToken.code,mixPanelConfig.verifyCode+mixPanelConfig.clientValidation_Error,verifyCode,verifyCode.deviceId,400));
		}
		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData,0,mixPanelConfig.verifyCode+mixPanelConfig.serverValidation_Error,verifyCode,verifyCode.deviceId,output.httpCode));
		}
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(error,0,mixPanelConfig.verifyCode+mixPanelConfig.internalServerError,verifyCode,verifyCode.deviceId,500));
	}
}
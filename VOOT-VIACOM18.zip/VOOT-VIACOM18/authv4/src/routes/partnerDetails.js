
"use strict";
const partnerDetailsBuiness = require("../business");
const partnerDetailsModel = require("../models").partnerDetails;
const commonUtils = require("../utils").common;
const { apiResponse } = require("../utils");
const _ = require("lodash");

module.exports = partnerDetails;

async function partnerDetails(request, response) {
	try {
		const input = {
			partnerType: request.header("partnerType"),
			externalId: request.header("externalId"),
			uniqueId: request.header("uniqueId")
		};
		let pulled;
		if(input.partnerType==undefined){
			pulled=_.pullAt(input,"partnerType");
		} 
		if (input.uniqueId == undefined) {
			pulled = _.pullAt(input, "uniqueId");
		} else if (input.externalId == undefined) {
			pulled = _.pullAt(input, "externalId");
		}
		console.log("Header RequestInput", input,pulled);
		const { error } = partnerDetailsModel(input);

		if (error) {
			console.log("\n Error in updateProfile/validation \n", error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error)));
		}
		const result = await partnerDetailsBuiness.partnerDetails(input);
		//const result: any = await TataSkyRepo.getTskyCollectionDetails(_.get(input));
		const output = commonUtils.responseFormatter(result);
		return response.status(output.httpCode).send(apiResponse.success(output.responseData));
	} catch (error) {
		console.log("\n Error in partnerDetails/catch \n", error);
		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData));
		}
		if (error.https) {
			return response.status(error.https).send(error.error);
		}
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(error));
	}
}
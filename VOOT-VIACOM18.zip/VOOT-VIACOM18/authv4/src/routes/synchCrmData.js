"use strict";
const commonUtils = require( "../utils" ).common;
const apiResponse = require( "../utils" ).apiResponse;
const synchCrmDataModel = require( "../models/synchCrmDataModel" );
const synchCrmDataBusiness = require( "../business" ).synchCrmData;
const errorConfig = require( "../config" ).errorConfig;
const _ = require( "lodash" );

module.exports = synchCrmData;
async function synchCrmData ( request, response ) {
	try {
		const input = request.body;
		//if(_.has(input,'email'))_.set(input, 'email', _.toLower(_.get(input, 'email')));
		const { error } = synchCrmDataModel( input );
		if ( error ) {
			console.log( "\n Error in Sych Crm Data/validation \n", error );
			return response.status( 400 ).send( apiResponse.error( commonUtils.formatValidationErrors( error ) ) );
		}
		const result = await synchCrmDataBusiness( input );
		const output = commonUtils.responseFormatter( result );

		return response.status( output.httpCode ).send( apiResponse.success( output.responseData ) );
	}
	catch ( error ) {
		console.error( "\n Error in getOtptoken/catch \n", error );
		if ( error.message == errorConfig.emailNotRegistered.code ) {
			return response.status( 400 ).send( apiResponse.error( errorConfig.emailNotRegistered.description, errorConfig.emailNotRegistered.code ) );
		}

		if ( _.has( error, "status.code" ) ) {
			const output = commonUtils.responseFormatter( error );
			return response.status( output.httpCode ).send( apiResponse.success( output.responseData ) );
		}
		return response.status( 500 ).send( apiResponse.error( errorConfig.requestFailed, 400 ) );
	}
}

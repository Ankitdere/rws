"use strict";
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const refreshAccessTokenModel = require("../models").refreshAccessToken;
const refreshAccessTokenBusiness = require("../business").refreshAccessToken;
const errorConfig = require("../config").errorConfig;

module.exports = refreshAccessToken;

async function refreshAccessToken(request, response) {
	try {
		const headers = {
			accessToken: request.header("accessToken"),
			buildNumber: request.header("buildNumber"),
			deviceInfo: request.header("deviceInfo"),
			uid: request.header("uid"),
			deviceId: request.header("deviceId")
		};
		console.log("::: headers details ::: ", JSON.stringify(headers, null, 2));
		// Call to model for validate Schema
		const { error } = refreshAccessTokenModel(request.header("accessToken"));

		// check the error and return if error exist
		if (error) {
			console.log("\n Error in refreshAccessToken/validation \n", error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error), errorConfig.invalidProfileToken.code));
		}
		// Get data from firebase     
		const result = await refreshAccessTokenBusiness(request.header("accessToken"), request.header("deviceId"));
		const output = commonUtils.responseFormatter(result);
		return response.status(output.httpCode).send(apiResponse.success(output.responseData));
	} catch (error) {
		console.log("\n Error in refreshAccessToken/catch \n", error);
		if (error.message == errorConfig.expiredRefreshProfileToken.description)
			return response.status(401).send(apiResponse.error(errorConfig.expiredRefreshProfileToken.description, errorConfig.expiredRefreshProfileToken.code));
		return response.status(400).send(apiResponse.error(errorConfig.invalidAccessToken.description, errorConfig.invalidAccessToken.code));
	}
}
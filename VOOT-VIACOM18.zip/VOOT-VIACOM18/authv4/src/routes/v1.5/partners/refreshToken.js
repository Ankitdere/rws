const To = require("../../../utils/to");
const ModuleError = require("../../../errors/module");
const ParseUtil = require("../../../utils/parse");
const GenericValidationUtil = require("../../../utils/validate/generic");
const PartnerUserBusiness = require("../../../business/partnerUser");
const mixpanelService = require("../../../services/mixpanelService");
const _ = require("lodash");
const commonUtil = require("../../../utils").common;
const { ipService } = require("../../../services");

module.exports = refreshToken;

/**
 * Refresh Token
 */
async function refreshToken(request, response, next) {
	try {
		// Initialize
		let authUser = {};
		let error, partnerResult, result;

		console.log(JSON.stringify(request.headers));

		// Validate
		if (!request.headers["accesstoken"]) {
			throw new ModuleError(400, "Access token is missing.", null);
		}
		if (!request.headers["refreshtoken"]) {
			throw new ModuleError(400, "Refresh token is missing.", null);
		}

		// Retrieve partner details from query params
		[error, partnerResult] = await To(ParseUtil.fromStringifiedJsonToObject(request.query.partner));
		if (error) {
			throw new ModuleError(error.code, error.message, error.data);
		} else if (!partnerResult.data) {
			throw new ModuleError(500, "An error occured while retrieving partner details internally.", null);
		} else {
			authUser.partner = partnerResult.data;
		}

		// Populate
		authUser.accessToken = request.headers["accesstoken"];
		authUser.refreshToken = request.headers["refreshtoken"];
		const { region, country } = await ipService.getCountryAndRegionDetails(request);
		authUser.regionInfo = { region, country };
		// Refresh Token
		[error, result] = await To(PartnerUserBusiness.refreshOneToken(
			authUser,
			null,
			null,
			null
		));
		if (error) {
			throw new ModuleError(error.code, error.message, error.data);
		} else if (!GenericValidationUtil.isSuccessResponse(result)) {
			throw new ModuleError(500, "An error occured while processing your request. Please try again.", null);
		} else {
			request.query.result = JSON.stringify({ code: result.code, message: result.message, data: result.data });
		}

		next();
	} catch (error) {
		let eventName;
		if(error.code=="400"|| error.code=="403"){
			eventName = await commonUtil.preparePartnerEventName(request.method,request.path,false,true,false);
		}
		eventName = await commonUtil.preparePartnerEventName(request.method,request.path,true,false,false);
		let distinctId = _.get(request.headers,"uniqueid",_.get(request.body.user,"uniqueId",_.get(request.body.user,"mobile","NO_UID")));
		let eventProps = {userInput: request.headers,input:_.get(request,"headers"), Message: error.message, ErrorCode: _.get(error,"code"), distinct_id: distinctId, StatusCode :error.code};
		mixpanelService(eventName, eventProps, distinctId, _.get(request,"body",null), null,false); 
		if (error && error.code && error.message) {
			request.query.error = JSON.stringify({ code: error.code, message: error.message, data: error.data });
		} else {
			request.query.error = JSON.stringify({ code: 500, message: "An error occured while processing your request: " + error });
		}
		next();
	}
}
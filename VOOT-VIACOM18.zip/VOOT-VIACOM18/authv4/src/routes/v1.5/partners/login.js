const To = require("../../../utils/to");
const ModuleError = require("../../../errors/module");
const ParseUtil = require("../../../utils/parse");
const GenericValidationUtil = require("../../../utils/validate/generic");
const PartnerUserBusiness = require("../../../business/partnerUser");
const mixpanelService = require("../../../services/mixpanelService");
const _ = require("lodash");
const commonUtil = require("../../../utils").common;
const { ipService } = require("../../../services");
module.exports = login;

/**
 * Login
 */
async function login(request, response, next) {
	let eventName;
	try {
		// Initialize
		let authUser = {};
		let error, partnerResult, result;

		// Validate
		if (!request.body) {
			throw new ModuleError(400, "All the required fields are missing: device platform and uniqueId.", null);
		}
		if (GenericValidationUtil.isNonEmptyObject(request.body.device)) {
			if (!request.body.device.platform) {
				throw new ModuleError(400, "Device platform is either missing or invalid.", null);
			}
		}
		if (!request.body.user) {
			throw new ModuleError(400, "All user related fields are missing: uniqueId.", null);
		} else {
			if (!GenericValidationUtil.isAlphaNumericWithUnderscoreDash(request.body.user.uniqueId)) {
				throw new ModuleError(400, "Unique identifier is either missing or invalid. Only alphabets, numerics, underscore and dash are allowed.", null);
			}
		}

		// Retrieve partner details from query params
		[error, partnerResult] = await To(ParseUtil.fromStringifiedJsonToObject(request.query.partner));
		if (error) {
			throw new ModuleError(error.code, error.message, error.data);
		} else if (!partnerResult.data) {
			throw new ModuleError(500, "An error occured while retrieving partner details internally.", null);
		} else {
			authUser.partner = partnerResult.data;
		}
		const { region, country } = await ipService.getCountryAndRegionDetails(request);
		// Login
		[error, result] = await To(PartnerUserBusiness.loginOne(
			authUser,
			request.body,
			null,
			null,
			request.distinctId,
			{ region, country }

		));
        
		if (error) {
			throw new ModuleError(error.code, error.message, error.data);
		} else if (!GenericValidationUtil.isSuccessResponse(result)) {
			throw new ModuleError(500, "An error occured while processing your request. Please try again.", null);
		} else {
			request.query.result = JSON.stringify({ code: result.code, message: result.message, data: result.data });
		}

		next();
	} catch (error) {
		if (error.code == "400" || error.code == "403") {
			eventName = await commonUtil.preparePartnerEventName(request.method, request.path, false, true, false);
		} else {
			eventName = await commonUtil.preparePartnerEventName(request.method, request.path, true, false, false);
		}
		let eventProps = { userInput: request.headers, input: _.get(request, "body"), Message: error.message, ErrorCode: _.get(error, "code"), distinct_id: request.distinctId, StatusCode: error.code };
		mixpanelService(eventName, eventProps, request.distinctId, _.get(request, "body", null), null,false);
		if (error && error.code && error.message) {
			request.query.error = JSON.stringify({ code: error.code, message: error.message, data: error.data });
		} else {
			request.query.error = JSON.stringify({ code: 500, message: "An error occured while processing your request: " + error });
		}
		next();
	}
}
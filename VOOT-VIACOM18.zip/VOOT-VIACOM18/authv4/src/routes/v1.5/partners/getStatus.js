"use strict";

const To = require("../../../utils/to");
const ModuleError = require("../../../errors/module");
const ParseUtil = require("../../../utils/parse");
const Base64Util = require("../../../utils/base64");
const GenericValidationUtil = require("../../../utils/validate/generic");
const PartnerUserBusiness = require("../../../business/partnerUser");
const mixpanelService = require("../../../services/mixpanelService");
const _ = require("lodash");
const commonUtil = require("../../../utils").common;
module.exports = getStatus;

/**
 * Get Status
 */
async function getStatus(request, response, next) {
	let eventName;
	try {
		// Initialize
		let authUser = {};
		let user = {};
		let error, partnerResult, base64Result, result;
        
		// Validate
		if (!request.headers["uniqueid"] || !_.has(request.headers,"uniqueid")) {
			throw new ModuleError(400, "All the required fields are missing: uniqueId.", null);
		}
		if (!GenericValidationUtil.isBase64(request.headers["uniqueid"])) {
			throw new ModuleError(400, "Invalid uniqueId. It must be Base64 encoded.", null);
		}

		// Retrieve partner details from query params
		[error, partnerResult] = await To(ParseUtil.fromStringifiedJsonToObject(request.query.partner));
		if (error) {
			throw new ModuleError(error.code, error.message, error.data);
		} else if (!partnerResult.data) {
			throw new ModuleError(500, "An error occured while retrieving partner details internally.", null);
		} else {
			authUser.partner = partnerResult.data;
		}

		// Retrieve uniqueId
		[error, base64Result] = await To(Base64Util.decode(request.headers["uniqueid"]));
		if (error) {
			throw new ModuleError(error.code, error.message, error.data);
		} else if (!base64Result.data) {
			throw new ModuleError(500, "An error occured while decoding unique id.", null);
		} else {
			user.uniqueId = base64Result.data;

			if (!GenericValidationUtil.isAlphaNumericWithUnderscoreDash(user.uniqueId)) {
				throw new ModuleError(400, "Unique identifier is either missing or invalid. Only alphabets, numerics, underscore and dash are allowed.", null);
			}
		}

		// Get Status
		[error, result] = await To(PartnerUserBusiness.getStatusForOne(
			authUser,
			user,
			null,
			null
		));
		if (error) {
			throw new ModuleError(error.code, error.message, error.data);
		} else if (!GenericValidationUtil.isSuccessResponse(result)) {
			throw new ModuleError(500, "An error occured while processing your request. Please try again.", null);
		} else {
			request.query.result = JSON.stringify({ code: result.code, message: result.message, data: result.data });
		}

		next();
	} catch (error) {
        
		if(error.code=="400"|| error.code=="403"){
			eventName = await commonUtil.preparePartnerEventName(request.method,request.path,false,true,false);
		}
		eventName = await commonUtil.preparePartnerEventName(request.method,request.path,true,false,false);
		let eventProps = {userInput: request.headers,input:_.get(request,"headers"), Message: error.message, ErrorCode: _.get(error,"code"), distinct_id: request.distinctId, StatusCode :error.code};
		mixpanelService(eventName, eventProps, request.distinctId, _.get(request,"body",null), null, false); 
		if (error && error.code && error.message) {
			request.query.error = JSON.stringify({ code: error.code, message: error.message, data: error.data });
		} else {
			request.query.error = JSON.stringify({ code: 500, message: "An error occured while processing your request: " + error });
		}
		next();
	}
}
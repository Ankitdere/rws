const To = require("../../../utils/to");
const ModuleError = require("../../../errors/module");
const ParseUtil = require("../../../utils/parse");
const GenericValidationUtil = require("../../../utils/validate/generic");
const PartnerUserBusiness = require("../../../business/partnerUser");
const notificationService = require("../../../services/notificationService");
const kafkaService = require("../../../services/kafkaService");
const config = require("../../../config/configuration");
const mixpanelService = require("../../../services/mixpanelService");
const _ = require("lodash");
const commonUtil = require("../../../utils").common;

module.exports = purchase;

/**
 * Purchase
 */
async function purchase(request, response, next) {
	await notificationService.getInitialNotificationObj(request.body);
	let eventName;
	try {
		// Initialize
		let authUser = {};
		let error, partnerResult, result;

		// Validate
		if (!request.body) {
			throw new ModuleError(400, "All the required fields are missing: device id, device brand, uniqueId and packId.", null);
		}
		if (!request.body.device) {
			throw new ModuleError(400, "All device related fields are missing: device id, device brand.", null);
		} else {
			if (!GenericValidationUtil.isAlphaNumericWithUnderscoreDash(request.body.device.id)) {
				throw new ModuleError(400, "Device ID is either missing or invalid. Only alphabets, numerics, underscore and dash are allowed.", null);
			}
			if (request.body.device.brand && !GenericValidationUtil.isAlphaNumericWithUnderscoreDash(request.body.device.brand)) {
				throw new ModuleError(400, "Device brand is either missing or invalid. Only alphabets, numerics, underscore and dash are allowed.", null);
			}
		}
		if (!request.body.user) {
			throw new ModuleError(400, "All user related fields are missing: uniqueId.", null);
		} else {
			if (!GenericValidationUtil.isAlphaNumericWithUnderscoreDash(request.body.user.uniqueId)) {
				throw new ModuleError(400, "Unique identifier is either missing or invalid. Only alphabets, numerics, underscore and dash are allowed.", null);
			}
			if (!request.body.user.mobile && !request.body.user.email) {
				throw new ModuleError(400, "Either mobile or email is mandatory.", null);
			}
			if (request.body.user.mobile && !GenericValidationUtil.isValidPhoneNumber(request.body.user.mobile)) {
				throw new ModuleError(400, "Invalid mobile number.", null);
			}
			if (request.body.user.email && !GenericValidationUtil.isValidEmail(request.body.user.email)) {
				throw new ModuleError(400, "Invalid email.", null);
			}
		}
		if (!request.body.subscription) {
			throw new ModuleError(400, "All subscription related fields are missing: planCode.", null);
		} else {
			if (!GenericValidationUtil.isAlphaNumericWithFwdSlashUnderscore(request.body.subscription.planCode)) {
				throw new ModuleError(400, "Plan code is either missing or invalid. Only alphabets, numbers, forward slash and underscore are allowed.", null);
			}
		}

		// Retrieve partner details from query params
		[error, partnerResult] = await To(ParseUtil.fromStringifiedJsonToObject(request.query.partner));
		if (error) {
			throw new ModuleError(error.code, error.message, error.data);
		} else if (!partnerResult.data) {
			throw new ModuleError(500, "An error occured while retrieving partner details internally.", null);
		} else {
			authUser.partner = partnerResult.data;
		}

		// Populate
		if (!request.body.user.mobile && GenericValidationUtil.isValidPhoneNumber(request.body.user.uniqueId)) {
			request.body.user.mobile = request.body.user.uniqueId;
		}
		if (!request.body.user.email && GenericValidationUtil.isValidEmail(request.body.user.uniqueId)) {
			request.body.user.mobile = request.body.user.uniqueId;
		}

		if (config["YuppTvAsyncConfig"].ïsEnable) {
			[error, result] = await To(PartnerUserBusiness.createAsyncOne(
				authUser,
				request.body,
				null,
				null,
				request.distinctId,
				request
			));
			if (error) {
				throw new ModuleError(error.code, error.message, error.data);
			} else if (!GenericValidationUtil.isSuccessResponse(result)) {
				throw new ModuleError(500, "An error occured while processing your request. Please try again.", null);
			} else {
				let notificationObj = await notificationService.createNotificationObjectForYuppTV("create_and_register","yupptv",request.body);
				kafkaService.pushEventToKafka(config.kafkaConfig.topic.partnerNotification,notificationObj);
				request.query.result = JSON.stringify({ code: result.code, message: result.message, data: result.data });
			}   
		}
		// Purchase
		else{
			[error, result] = await To(PartnerUserBusiness.createOne(
				authUser,
				request.body,
				null,
				null,
				request.distinctId
			));
			if (error) {
				throw new ModuleError(error.code, error.message, error.data);
			} else if ( !GenericValidationUtil.isSuccessResponse( result ) ) {
				throw new ModuleError(500, "An error occured while processing your request. Please try again.", null);
			} else {
				request.query.result = JSON.stringify({ code: result.code, message: result.message, data: result.data });
			}
		}
		next();
	} catch (error) {
		console.log("Request Body in purchase route............", request.body);
		if (request.body.user) {
			_.unset(request.body.user, "subscription");
		}
		let notificationObj = await notificationService.getInitialNotificationObj(request.body);
		let basic = { partnerType: "", uniqueId: "", deviceId: "" };
		request.query.partner = JSON.parse(request.query.partner);
		if (request.query.partner.name) {
			basic.partnerType = request.query.partner.code;
			basic.uniqueId = request.body.user.uniqueId || request.body.externalId;
			basic.deviceId = (request.body.device) ? request.body.device.id : request.body.deviceId;
		}

		notificationObj = await notificationService.updateBasicInfo(notificationObj, basic);

		notificationObj = await notificationService.updateNotificationStage(notificationObj, true, "validation");

		let validationErrorData;

		if (error.code == "400" || error.code == "403") {
			eventName = await commonUtil.preparePartnerEventName(request.method, request.path, false, true, false);
		}
		eventName = await commonUtil.preparePartnerEventName(request.method, request.path, true, false, false);
		let distinctId = _.get(request.headers, "uniqueid", _.get(request.body.user, "uniqueId", _.get(request.body.user, "mobile", "NO_UID")));
		let eventProps = { userInput: request.headers, input: _.get(request, "body"), Message: error.message, ErrorCode: _.get(error, "code"), distinct_id: distinctId, StatusCode: error.code };
		mixpanelService(eventName, eventProps, distinctId, _.get(request, "body", ""), null, false);
		if (error && error.code && error.message) {
			validationErrorData = { code: error.code, message: error.message, data: error.data };
			request.query.error = JSON.stringify({ code: error.code, message: error.message, data: error.data });
		} else {
			validationErrorData = { code: 500, message: "An error occured while processing your request: " + error };
			request.query.error = JSON.stringify({ code: 500, message: "An error occured while processing your request: " + error });
		}
		notificationObj = await notificationService.updateNotificationStage(notificationObj, false, "subscription", validationErrorData, "error");
		if (config.kafkaConfig.enable.processNotification && config.kafkaConfig.enable.processNotificationError) {
			kafkaService.pushEventToKafka(config.kafkaConfig.topic.partnerNotification, notificationObj);
		}
		next();
	}
}
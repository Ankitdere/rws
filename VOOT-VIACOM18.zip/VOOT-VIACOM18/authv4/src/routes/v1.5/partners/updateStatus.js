const To = require("../../../utils/to");
const ModuleError = require("../../../errors/module");
const ParseUtil = require("../../../utils/parse");
const Base64Util = require("../../../utils/base64");
const GenericValidationUtil = require("../../../utils/validate/generic");
const PartnerUserBusiness = require("../../../business/partnerUser");
const notificationService = require("../../../services/notificationService");
const mixpanelService = require("../../../services/mixpanelService");
const _ = require("lodash");
const commonUtil = require("../../../utils").common;
const kafkaService = require("../../../services/kafkaService");
const config = require("../../../config/configuration");

module.exports = updateStatus;

/**
 * Update Status
 */
async function updateStatus(request, response, next) {
	let eventName;
	try {
		// Initialize
		let authUser = {};
		let user = {};
		let error, partnerResult, base64Result, result;

		// Validate
		if (!request.headers["uniqueid"] || !_.has(request.headers,"uniqueid")) {
			throw new ModuleError(400, "All the required fields are missing: uniqueId.", null);
		}
		if (!GenericValidationUtil.isBase64(request.headers["uniqueid"])) {
			throw new ModuleError(400, "Invalid uniqueId. It must be Base64 encoded.", null);
		}
		if (!request.body) {
			throw new ModuleError(400, "All the required fields are missing: subscription status.", null);
		} else {
			if (!request.body.subscription) {
				throw new ModuleError(400, "All the subscription related fields are missing: subscription status.", null);
			} else {
				if (!GenericValidationUtil.isValidSubscriptionStatus(request.body.subscription.status)) {
					throw new ModuleError(400, "Subscription status is either missing or invalid. Only alphabets, numbers, forward slash and underscore are allowed.", null);
				} else {
					if (!GenericValidationUtil.isAlphaNumericWithFwdSlashUnderscore(request.body.subscription.planCode)) {
						throw new ModuleError(400, "Plan code is either missing or invalid. Only alphabets, numbers, forward slash and underscore are allowed.", null);
					}
				}
			}
		}

		// Retrieve partner details from query params
		[error, partnerResult] = await To(ParseUtil.fromStringifiedJsonToObject(request.query.partner));
		if (error) {
			throw new ModuleError(error.code, error.message, error.data);
		} else if (!partnerResult.data) {
			throw new ModuleError(500, "An error occured while retrieving partner details internally.", null);
		} else {
			authUser.partner = partnerResult.data;
		}

		// Retrieve uniqueId
		[error, base64Result] = await To(Base64Util.decode(request.headers["uniqueid"]));
		if (error) {
			throw new ModuleError(error.code, error.message, error.data);
		} else if (!base64Result.data) {
			throw new ModuleError(500, "An error occured while decoding unique id.", null);
		} else {
			user.uniqueId = base64Result.data;
           
			if (!GenericValidationUtil.isAlphaNumericWithUnderscoreDash(user.uniqueId)) {
				throw new ModuleError(400, "Unique identifier is either missing or invalid. Only alphabets, numerics, underscore and dash are allowed.", null);
			}
		}
    
 
		// Assign
		user.subscription = request.body.subscription;
		if (config["YuppTvAsyncConfig"].ïsEnable) {
			request.body.user={};
			request.body.user.uniqueId = base64Result.data;
            
			[error, result] = await To(PartnerUserBusiness.updateAsyncStatusForOne(
				authUser,
				user,
				null,
				null,
				request.distinctId,
				request
			));
			if (error) {
				throw new ModuleError(error.code, error.message, error.data);
			} else if (!GenericValidationUtil.isSuccessResponse(result)) {
				throw new ModuleError(500, "An error occured while processing your request. Please try again.", null);
			} else {
				let notificationObj = await notificationService.createNotificationObjectForYuppTV("create_and_update_subscription","yupptv",request.body);
				kafkaService.pushEventToKafka(config.kafkaConfig.topic.partnerNotification,notificationObj);
				request.query.result = JSON.stringify({ code: result.code, message: result.message, data: result.data });
			}
        
		}
		else {
            
			// Update status
			[error, result] = await To(PartnerUserBusiness.updateStatusForOne(
				authUser,
				user,
				null,
				null,
				request.distinctId
			));
			if (error) {
				throw new ModuleError(error.code, error.message, error.data);
			} else if (!GenericValidationUtil.isSuccessResponse(result)) {
				throw new ModuleError(500, "An error occured while processing your request. Please try again.", null);
			} else {
				request.query.result = JSON.stringify({ code: result.code, message: result.message, data: result.data });
			}

          
		}
		next();
	} catch (error){
		//adding kafka 
		let notificationObj = await notificationService.getInitialNotificationObj(request.body);
		let basic = {partnerType:"", uniqueId:"",deviceId:"" };
		request.query.partner=JSON.parse(request.query.partner);
		if ( request.query.partner.name||request.body.device) {
			basic.partnerType = request.query.partner.code;
			basic.uniqueId =  request.distinctId ?request.distinctId:request.body.user.uniqueId;
			basic.deviceId =(request.body.device)? request.body.device.id:"";
		}
		notificationObj = await notificationService.updateBasicInfo(notificationObj, basic);
		notificationObj = await notificationService.updateNotificationStage(notificationObj, true, "validation");
		let validationErrorData;
		if(error.code=="400"|| error.code=="403"){
			eventName = await commonUtil.preparePartnerEventName(request.method,request.path,false,true,false);
		}else{
			eventName = await commonUtil.preparePartnerEventName(request.method,request.path,true,false,false);
		}
		let eventProps = {userInput: request.headers,input:_.get(request,"body"), Message: error.message, ErrorCode: _.get(error,"code"), distinct_id: request.distinctId, StatusCode :error.code};
		mixpanelService(eventName, eventProps, request.distinctId,  _.get(request,"body",null), null, false); 
		if (error && error.code && error.message) {
			validationErrorData = { code: error.code, message: error.message, data: error.data };
			request.query.error = JSON.stringify({ code: error.code, message: error.message, data: error.data });
		} else {
			validationErrorData={ code: 500, message: "An error occured while processing your request: " + error };
			request.query.error = JSON.stringify({ code: 500, message: "An error occured while processing your request: " + error });
		}
		notificationObj = await notificationService.updateNotificationStage(notificationObj, false, "subscription", validationErrorData,"error");
		if (config.kafkaConfig.enable.processedNotification && config.kafkaConfig.enable.processedNotificationError) {
			kafkaService.pushEventToKafka(config.kafkaConfig.topic.partnerNotification, notificationObj);
		}
		next();
	}
}
"use strict";
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const refreshAccessTokenModel = require("../models").refreshAccessToken;
const refreshAccessTokenBusiness = require("../business").refreshAccessToken;
const {checkSSOAndJioSub} = require("../services/jioSTBService");
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");
const mixPanelConfig = require("../config/mixPanelConfig");
const { ipService } = require("../services");
module.exports = refreshAccessToken;

async function refreshAccessToken(request, response) {
	const headers = {
		accessToken: request.header("refreshAccessToken"),
		buildNumber: request.header("buildNumber"),
		deviceInfo: request.header("deviceInfo"),
		uid: request.header("uid"),
		deviceId: request.header("deviceId"),
		ssoToken:request.header("ssoToken")
	};
	try {
		let pulled;
		if(headers.ssoToken==undefined){
			pulled=_.pullAt(headers,"ssoToken");
		}
		let partnerDetails =false; 
		if(_.has(headers,"ssoToken")){
			let input={};
			_.set(input,"data.token",headers.ssoToken);
			partnerDetails = await checkSSOAndJioSub(input);
		} 
		console.log("::: headers details ::: ", JSON.stringify(headers, null, 2),pulled);
		// Call to model for validate Schema
		const { error } = refreshAccessTokenModel(request.header("refreshAccessToken"));

		// check the error and return if error exist
		if (error) {
			console.log("\n Error in refreshAccessToken/validation \n", error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error), errorConfig.invalidProfileToken.code,mixPanelConfig.refreshAccessToken+mixPanelConfig.clientValidation_Error, headers,_.get(headers,"uid","No_Uid")));
		}
		const regionInfo = {};
		const { region, country } = await ipService.getCountryAndRegionDetails(request);
		regionInfo.region = region;
		regionInfo.country = country;
		const result = await refreshAccessTokenBusiness(request.header("refreshAccessToken"), request.header("deviceId"),_.get(partnerDetails,"partnerDetails",false),regionInfo);
		const output = commonUtils.responseFormatter(result);
		return response.status(output.httpCode).send(apiResponse.success(output.responseData,null,200,mixPanelConfig.refreshAccessToken+mixPanelConfig.success,headers,_.get(headers,"uid","No_Uid")));
	} catch (error) {
		console.log("\n Error in refreshAccessToken/catch \n", error,error.stack);
		if (_.has(error, "status.code")) {
			//const output: any = Utility.responseFormatter(error);
			return response.status(401).send(error);
		}
		if(error.code=="partner/user-plan-expired"){
			return response.status(401).send(apiResponse.error(errorConfig.partnerInvalidToken.description, errorConfig.partnerInvalidToken.code,
				mixPanelConfig.refreshAccessToken+mixPanelConfig.serverValidation_Error, headers,_.get(headers,"uid","No_Uid")));
		}
		if (error.message == errorConfig.expiredRefreshProfileToken.description)
			return response.status(401).send(apiResponse.error(errorConfig.expiredRefreshProfileToken.description, errorConfig.expiredRefreshProfileToken.code,mixPanelConfig.refreshAccessToken+mixPanelConfig.serverValidation_Error, headers,_.get(headers,"uid","No_Uid")));
		return response.status(400).send(apiResponse.error(errorConfig.invalidAccessToken.description, errorConfig.invalidAccessToken.code,mixPanelConfig.refreshAccessToken+mixPanelConfig.serverValidation_Error,{headers:headers, error:_.get(error,"stack")},_.get(headers,"uid","No_Uid")));
	}
}

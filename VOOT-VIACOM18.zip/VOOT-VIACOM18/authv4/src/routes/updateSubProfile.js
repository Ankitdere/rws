
"use strict";

const _ = require("lodash");
const { updateSubProfile: updateSubProfileBusiness } = require("../business");
const { updateSubProfile: updateSubProfileModel } = require("../models");
const {
	common: commonUtils,
	apiResponse
} = require("../utils");
const {
	errorConfig,
	mixpanelEvent: mixPanelConfig,
	configuration
} = require("../config");

module.exports = updateSubProfile;

/**
 * @param {Object} request 
 * @param {Object} response 
 * @returns {Object}
 */
async function updateSubProfile(request, response) {
	const input = request.body;
	try {
		const headers = {
			accessToken: request.header("accessToken")
		};
		console.log(
			"Input Request in update sub Profile", JSON.stringify(input, null, 2),
			"\n::: headers details ::: ", JSON.stringify(headers, null, 2)
		);
		const { error } = updateSubProfileModel(headers, input);

		if (error) {
			console.error("\n Error in updateSubProfile/validation \n", error);
			const mpModelErrEventName = mixPanelConfig.updateSubProfile + mixPanelConfig.clientValidation_Error;
			return response
				.status(400)
				.send(
					apiResponse.error(
						commonUtils.formatValidationErrors(error),
						400,
						mpModelErrEventName,
						input,
						request.userToken.uid,
						400
					)
				);
		}
		const languagelist = _.get(input, "languages");
		for (const index in languagelist) {
			if (!configuration.DefaultLanguages.includes(languagelist[index])) {
				return response.status(400).send(apiResponse.error(errorConfig.invalidLanguage.description, errorConfig.invalidLanguage.code));
			}
		}
		
		const result = await updateSubProfileBusiness(input, request);
		const output = commonUtils.responseFormatter(result);
		const mpSuccessEventName = mixPanelConfig.updateSubProfile + mixPanelConfig.success;
		return response
			.status(output.httpCode)
			.send(
				apiResponse.success(
					{ "data": output.responseData },
					null,
					200,
					mpSuccessEventName,
					input,
					request.userToken.uid
				)
			);
	} catch (error) {
		console.error("\n Error in updateSubProfile Route/catch \n", error);
		const mpServerErrEventName = mixPanelConfig.updateSubProfile + mixPanelConfig.serverValidation_Error;

		if (error && error.message == errorConfig.subProfileDoesNotExist.description) {
			const { description, code } = errorConfig.subProfileDoesNotExist;
			return response
				.status(400)
				.send(
					apiResponse.error(
						description, 
						code, 
						mpServerErrEventName, 
						input, 
						request.userToken.uid, 
						400)
				);
		}

		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response
				.status(output.httpCode)
				.send(
					apiResponse.success(null, output.responseData)
				);
		}

		const mpInternalServerErrEventName = mixPanelConfig.updateSubProfile + mixPanelConfig.internalServerError;
		return response
			.status(500)
			.send(
				apiResponse.error(
					error.message, 
					500, 
					mpInternalServerErrEventName, 
					input, 
					request.userToken.uid, 
					500)
			);
	}
}

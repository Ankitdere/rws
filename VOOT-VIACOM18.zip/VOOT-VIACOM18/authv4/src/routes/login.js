
"use strict";
const loginBusiness = require("../business").login;
const loginModel = require("../models").login;
const commonUtils = require("../utils").common;
const { apiResponse } = require("../utils");
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");
const requestIp = require("request-ip");
const iplocation = require("geoip-lite");
const mixpanelConfig = require("../config/mixPanelConfig");
module.exports = login;
const To = require("../utils/to");
const DeviceBusiness = require("../business/device");
const loginInfoByDeviceIdService = require( "../services" ).loginInfoByDeviceIdService;
const { ipService } = require("../services");
const constant = require("../utils/constant/generic");
const configuration = require("../config").configuration;
async function login(req, res) {
	const input = req.body;
	try {
		console.info("Login Request Received with input", JSON.stringify(input, null, 2));
		_.set(input, "type", _.toLower(_.get(input, "type", "")));
		if(_.has(input,"data.email"))_.set(input, "data.email", _.toLower(_.get(input, "data.email")));
		if (!_.includes(commonUtils.loginTypes, input.type)) {
			console.log("\n Error in login/validation typeMissing.description, typeMissing.code \n");
			return res.status(400).send(apiResponse.error(errorConfig.typeMissing.description, errorConfig.typeMissing.code,mixpanelConfig.login+_.get(input, "type", "")+mixpanelConfig.clientValidation_Error,input,_.get(input.data,"email",_.get(input.data,"mobile")),400));
		}
		const { error } = loginModel(input);
		if (error) {
			console.error("\n Error in login/validation \n", error);
			return res.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error),0,mixpanelConfig.login+_.get(input, "type", "")+mixpanelConfig.clientValidation_Error,input,_.get(input.data,"email",_.get(input.data,"mobile")),400));
		}
		const ipAddress = requestIp.getClientIp(req);
		const  methodType = req.method;
		let auditObj={
			ipAddress:ipAddress,
			methodType:methodType
		};
		let countryCode = _.get(iplocation.lookup(ipAddress), "country", "NA");
		_.set(input, "countryCode", countryCode);
		_.set(input, "userAgent", req.headers["user-agent"] || "");
		
		const { region, country } = await ipService.getCountryAndRegionDetails(req);
		_.set(input, "regionInfo", { region, country });
		
		const result = await loginBusiness(input,auditObj);
		if(_.has(result,"description") && _.has(result,"code") && (result.code == configuration.limitConfig.tvMsgCode || result.code == 9995)){
			//block social account signup
			return res.status(400).send(apiResponse.error(result.description, result.code,mixpanelConfig.login+_.get(input, "type", "")+mixpanelConfig.clientValidation_Error,input,_.get(input.data,"email",_.get(input.data,"mobile")),400));
		}
		const output = commonUtils.responseFormatter(result);

		if ( result && result.data && result.data.uId ) {
			let extraPrams={
				userAgent:req.headers["user-agent"] || "",
				platform:req.headers["platform"] || ""
			};
			const deviceLoginData = await loginInfoByDeviceIdService.initDeviceIdLoginDetails( input, result.data, result.data.email, result.data.mobile, result.data.countryCode, constant.DeviceIdLoginDetailsStatus.ACTIVATE,{},extraPrams );
			if(!constant.BLOCK_DEVICEID_LLR.includes(_.get( deviceLoginData, "deviceId" ))){
				const query = { deviceId: _.get( deviceLoginData, "deviceId" ), uid:_.get( deviceLoginData, "uid" ) };
				const flag = { upsert: true };
				loginInfoByDeviceIdService.updateOneDeviceIdLoginDetails(query, deviceLoginData, flag)
					.catch( ( err => console.error( "Error while updating the record of deviceLoginDetails", deviceLoginData.deviceId, err ) ) );
			}
		}

		let eventName = mixpanelConfig.login+_.get(input, "type", "")+mixpanelConfig.success ;
		if(output.httpCode && output.httpCode  != 200){
			if(output.httpCode == 500){
				eventName = mixpanelConfig.login+_.get(input, "type", "")+mixpanelConfig.internalServerError;     
			}else{
				eventName = mixpanelConfig.login+_.get(input, "type", "")+mixpanelConfig.serverValidation_Error; 
			}
		}else{
			//If loggin Successfull capture device details
			// eslint-disable-next-line no-unused-vars
			let extraPrams={
				userAgent:req.headers["user-agent"] || "",
				platform:req.headers["platform"] || ""
			};
			console.log("extra Prams",extraPrams);
			loginInfoByDeviceIdService.updateOneDeviceIdLoginDetails( { deviceId: _.get( input, "deviceId" ), uid:  _.get(output.responseData.data, "uId")}, extraPrams, { upsert: false } ).catch( ( err => console.error( "Error while updating the record of deviceLoginDetails in login routes.", input.deviceId, err ) ) );
			let [Deviceerror, Deviceresult] = await To(DeviceBusiness.createOne(
				{
					email: req.body.data.email,
					password: req.body.data.password,
					mobile: req.body.data.mobile,
					deviceId: req.body.deviceId,
					brand: req.body.deviceBrand,
					type: req.body.type,
					requestIp: ipAddress || req.true_client_ip
				},
				null,
				null
			)); 
			console.debug(Deviceerror, Deviceresult);
		}
		let distinct_Id;
		if(_.get(input,"type")=="amazon"){
			distinct_Id=_.get(output.responseData.data,"mobile");
		}else{
			distinct_Id= _.get(input.data, "email", _.get(input.data, "mobile", _.get(output.responseData.data, "email", _.get(input.data, "uid"))));
		}
		console.log("Distinct Id",distinct_Id);
		return res.status(output.httpCode).send(apiResponse.success(output.responseData, null, output.httpCode, eventName,
			{
				distinct_id: distinct_Id,
				UID: _.get(output.responseData.data, "uId"),
				email: _.get(input.data, "email"),
				mobile: _.get(input.data, "mobile"),
				input: input
			}, distinct_Id
		));
	} catch (error) {
		console.error("\n Error in login/catch \n", error,error.stack);
		if(error.message == errorConfig.wrongPassword.code){
			return res.status(400).send(apiResponse.error(errorConfig.wrongPassword.description, errorConfig.wrongPassword.code,mixpanelConfig.login+_.get(input, "type", "")+mixpanelConfig.serverValidation_Error,input,_.get(input.data,"email",_.get(input.data,"mobile")),400));
		}
		if(error.message == errorConfig.invalidFborGToken.code){
			return res.status(400).send(apiResponse.error(errorConfig.invalidFborGToken.description + " " + error.message, errorConfig.invalidFborGToken.code,mixpanelConfig.login+_.get(input, "type", "")+mixpanelConfig.serverValidation_Error,input,_.get(input.data,"email",_.get(input.data,"mobile")),400));
		}
		if(_.get(error, "code", "") == errorConfig.errorCodes.INSIDE_LOCK_TIME.code){
			return res.status(400).send(apiResponse.error(errorConfig.kalturaInsideLockTime.description, errorConfig.kalturaInsideLockTime.code,mixpanelConfig.login+_.get(input, "type", "")+mixpanelConfig.serverValidation_Error,input,_.get(input.data,"email",_.get(input.data,"mobile")),400));
		}
		// handlle kaltur errors
		console.log("response of api ",error);
		return res.status(500).send(apiResponse.error(errorConfig.requestFailed,0,mixpanelConfig.login+_.get(input, "type", "")+mixpanelConfig.internalServerError,{input: input,error:_.get(error,"stack",error) },_.get(input.data,"email",_.get(input.data,"mobile")),500));
	}
}
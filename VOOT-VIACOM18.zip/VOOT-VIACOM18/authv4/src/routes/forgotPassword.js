"use strict";
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const forgotPasswordModel = require("../models").forgotPassword;
const forgotPasswordBusiness = require("../business").forgotPassword;
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");
const mixpanelConfig = require("../config/mixPanelConfig");
const { ipService } = require("../services");

module.exports = forgotPassword;
async function forgotPassword(request, response){
	const input = request.body;
	let type = _.has(input,"mobile")? "Mobile": "Email";
	try {
		console.log("forgotPassword() with parameter input ", JSON.stringify(input, null, 2));
		if(_.has(input,"email"))_.set(input, "email", _.toLower(_.get(input, "email")));
		const { error } = forgotPasswordModel(input);
		if (error) {
			console.error("\n Error in forgotPassword/validation \n", error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error),0,mixpanelConfig.forgotPassword+type+mixpanelConfig.clientValidation_Error,input,_.get(input,"email",_.get(input,"mobile")),400));
		}
		const { region, country } = await ipService.getCountryAndRegionDetails(request);
		_.set(input, "regionInfo", { region, country });

		const result = await forgotPasswordBusiness(input);
		const output = commonUtils.responseFormatter(result);
		let eventName = mixpanelConfig.forgotPassword+type+mixpanelConfig.success;
		if(output.httpCode && output.httpCode  != 200){
			eventName = mixpanelConfig.forgotPassword+type+mixpanelConfig.serverValidation_Error; 
		}
		return response.status(output.httpCode).send(apiResponse.success(output.responseData,null,output.httpCode,eventName, {distinct_id: _.get(input,"mobile",_.get(input,"email")),email: _.get(input,"email"), mobile:_.get(input,"mobile"), input:input},_.get(input,"mobile",_.get(input,"email"))));
	}
	catch (error) {
		console.error("\n Error in forgotPassword/catch \n", error);
		if (error.message == errorConfig.emailNotRegistered.code) {
			return response.status(400).send(apiResponse.error(errorConfig.emailNotRegistered.description, errorConfig.emailNotRegistered.code));
		}
		if (error.message == errorConfig.otpLimitExceeded.description) {
			return response.status(400).send(apiResponse.error(errorConfig.otpLimitExceeded.description, errorConfig.otpLimitExceeded.code,mixpanelConfig.forgotPassword+type+mixpanelConfig.serverValidation_Error,input,_.get(input,"email",_.get(input,"mobile")),400));
		}
		if (error.message == errorConfig.userlocked.description) {
			return response.status(400).send(apiResponse.error(errorConfig.userlocked.description, errorConfig.userlocked.code));
		}
        
		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData,0,mixpanelConfig.forgotPassword+type+mixpanelConfig.serverValidation_Error,input,_.get(input,"email",_.get(input,"mobile")),400));
		}
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(errorConfig.requestFailed,400,mixpanelConfig.forgotPassword+type+mixpanelConfig.internalServerError,{input:input,error:_.get(error,"stack")},_.get(input,"email",_.get(input,"mobile")),500));
	}
}

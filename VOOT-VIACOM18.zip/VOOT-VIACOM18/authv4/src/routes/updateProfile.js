
"use strict";

const updateProfileBusiness = require("../business").updateProfile;
const updateProfileModel = require("../models").updateProfile;
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");
const requestIp = require("request-ip");
const mixPanelConfig = require("../config/mixPanelConfig");
module.exports = updateProfile;

async function updateProfile(request, response) {
	const input = request.body;
	try {
		//for audit data:
		const ipAddress = requestIp.getClientIp(request);
		const  methodType = request.method;
		let auditObj={
			ipAddress:ipAddress,
			methodType:methodType
		};
		//console.log("input",input)
		const headers = {
			accessToken: request.header("accessToken"),
			apiVersion:request.header("apiVersion"),
			platform:request.header("platform"),
			device:request.header("device"),
		};
		console.log("Input Request in update Profile", JSON.stringify(input, null, 2), "\n::: headers details ::: ", JSON.stringify(headers, null, 2));
		let { DeviceList, PlatformList } = await commonUtils.returnDeviceAndPlatformsList();
		const { error } = updateProfileModel(headers, input, DeviceList,PlatformList);
         
		if (_.has(error, "status.code")){
			console.error("\n Error in updateAccount/validation \n",error);
			return response.status(400).send(error);
		}

		if (error) {
			console.error("\n Error in updateAccount/validation \n",error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error),0,mixPanelConfig.updateProfile+mixPanelConfig.clientValidation_Error, input,_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID"))));
		}
		const result = await updateProfileBusiness.updateProfile(input, request.userToken,headers,auditObj);
		const output = commonUtils.responseFormatter(result);
		return response.status(output.httpCode).send(apiResponse.success(output.responseData,null,200,mixPanelConfig.updateProfile+mixPanelConfig.success, {input:input, distinct_id:_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID"))},_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID"))));
	} catch (error) {
		console.error("\n Error in updateAccount/catch \n",error);
		if(error.message == errorConfig.userDoesNotExist.code){
			return response.status(400).send(apiResponse.error(errorConfig.userDoesNotExist.description, errorConfig.userDoesNotExist.code,mixPanelConfig.updateProfile+mixPanelConfig.serverValidation_Error, input,_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID")),400));
		}
		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData));
		}
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(error,0,0,mixPanelConfig.updateProfile+mixPanelConfig.internalServerError, {input:input, error:_.get(error,"stack")},_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID")),500));
	}
}
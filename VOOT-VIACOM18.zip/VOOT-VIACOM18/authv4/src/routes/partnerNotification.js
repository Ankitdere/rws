"use strict";

const partnerNotificationBusiness = require("../business").partnerNotification;
const partnerNotificationModel = require("../models").partnerNotification;
const partnerNotificationM2MIT = require("../models").partnerNotificationM2MIT;
const partnerNotificationDateValidator = require("../models").partnerNotificationDateValidator;
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const config = require("../config").configuration;
const mixpanelConfig=require("../config").mixpanelEvent;
const mixpanelEvent=require("../services/mixpanelService");
const _ = require("lodash");
const notificationService = require("../services/notificationService");
const kafkaService = require("../services/kafkaService");

module.exports = partnerNotification;

async function partnerNotification(request, response) {
	const input = request.body;
	console.info({ input });
	input.partnerToken = request.header("x-partner-token");
	console.debug("UniqueId", _.get(input.data,"uniqueId",""));
	console.debug("Action", _.get(input,"action",""));
	let notificationObj = await notificationService.getInitialNotificationObj(input);
	let asyncFunctionPartnerName = _.get(input,"partnerName")=="Tata-Sky"?"TataSky":_.get(input,"partnerName");
	try {
       
		switch (input.partnerName) {
		case (config.tSkyDetails.partnerType):
		{
			let { error } = partnerNotificationModel(input);
			if (error) {
                    
				if (config[`${asyncFunctionPartnerName}AsyncConfig`].ïsEnable) {
					notificationObj = await notificationService.updateNotificationStage(notificationObj, false,"validation",commonUtils.formatValidationForPartnerErrors(error));
					kafkaService.pushEventToKafka(config.kafkaConfig.topic.partnerNotification,notificationObj);
				}
				return response.status(400).send(apiResponse.error(commonUtils.formatValidationForPartnerErrors(error),0,
					mixpanelConfig.partnerNotification+_.get(input,"partnerName")+mixpanelConfig.clientValidation_Error,
					input,
					_.get(input.data,"uniqueId",""),
					400,
					false));
			}
			await partnerNotificationDateValidator(input);

			break;
		}
		case (config.M2MITDetails.partnerName):
		{
			let { error } = partnerNotificationM2MIT(input);
			if (error) {
				if (config[`${asyncFunctionPartnerName}AsyncConfig`].ïsEnable) {
					notificationObj = await notificationService.updateNotificationStage(notificationObj, false,"validation",commonUtils.formatValidationForPartnerErrors(error));
					kafkaService.pushEventToKafka(config.kafkaConfig.topic.partnerNotification,notificationObj);
				}
				return response.status(400).send(apiResponse.error(commonUtils.formatValidationForPartnerErrors(error),0,
					mixpanelConfig.partnerNotification+_.get(input,"partnerName","")+mixpanelConfig.clientValidation_Error
					,input
					, _.get(input.data,"uniqueId",""),
					400,
					false));
			}
			break;
		}
		}

		const result = await partnerNotificationBusiness(input);
		const output = commonUtils.responseFormatter(result);
		return response.status(output.httpCode).send(apiResponse.success(output.responseData));
	} catch (error) {
       
		if (error.https) {
			console.error("Custom Created Error Handler", error, error.stack);
			let eventProps = {userInput: request.body, Message: _.get(error.error.status,"message"), ErrorCode: _.get(error.error.status,"code"), distinct_id: _.get(request.body.data,"uniqueId"), StatusCode :error.https};
			console.log("My Event Props",eventProps);
			if (config[`${asyncFunctionPartnerName}AsyncConfig`].ïsEnable) {
				notificationObj = await notificationService.updateNotificationStage(notificationObj, false,"validation",{message: _.get(error.error.status,"message"), code: _.get(error.error.status,"code")});
				kafkaService.pushEventToKafka(config.kafkaConfig.topic.partnerNotification,notificationObj);
			}
			mixpanelEvent(mixpanelConfig.partnerNotification+_.get(request.body,"partnerName")+mixpanelConfig.clientValidation_Error
				,eventProps
				, _.get(request.body.data,"uniqueId")
				,_.get(request.body.data,"uniqueId")
				,null
				,false
			);
			return response.status(error.https).send(error.error);
		} else {
			console.error(new Error(`${request.url} failed.`), error);
			return response.status(400).send(error);
		}
	}
}

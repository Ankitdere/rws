
"use strict";

const jioEntitlementBusiness = require("../business").jioEntitlement;
const jioEntitlementModel = require("../models").jioEntitlement;
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const _ = require("lodash");

module.exports = jioEntitlement;

async function jioEntitlement(request, response) {
	try {
		console.log("Inside JIO subscription API");
		const headers = {
			ssoToken: request.header("sso-token"),
			buildNumber: request.header("buildNumber"),
			deviceId: request.header("deviceId"),
			deviceName: request.header("deviceName"),
			uid: request.header("uid"),
			ks: request.header("ks"),
			accessToken: request.header("accessToken")
		};
		const { error } = jioEntitlementModel(headers);
		if (error) {
			console.log("\n Error in activate/validation \n", error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error)));
		}

		const result = await jioEntitlementBusiness(headers.ks, headers.ssoToken, request.tokenInfo, request.userToken);
		const output = commonUtils.responseFormatter(result);
		return response.status(output.httpCode).send(apiResponse.success(output.responseData));

	} catch (error) {
		console.log("\n Error in jioEntitlement/catch \n", error);
		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData));
		}
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(error));
	}
}
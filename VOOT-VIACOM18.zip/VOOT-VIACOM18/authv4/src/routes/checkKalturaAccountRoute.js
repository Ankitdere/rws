"use strict";
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const checkKalturaModel = require("../models").checkKalturaAccountModel;
const checkKalturaBusiness = require("../business").checkKalturaBusiness;
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");

module.exports = kalturaAccount;
async function kalturaAccount(request, response) {
	try {
		const input = request.body;
		//if(_.has(input,'email'))_.set(input, 'email', _.toLower(_.get(input, 'email')));
		const { error } = checkKalturaModel(input);
		if (error) {
			console.log("\n Error in Check Kaltura Data/validation \n", error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error)));
		}
		const result = await checkKalturaBusiness(input);
		const output = commonUtils.responseFormatter(result);

		return response.status(output.httpCode).send(apiResponse.success(output.responseData));
	}
	catch (error) {
		console.error("\n Error in checkKalturaAccount/catch \n", error);
		if (_.has(error, "code") && error.code == errorConfig.errorCodes.USER_DOES_NOT_EXIST.code) {
			return response.status(400).send(apiResponse.error(errorConfig.kalturaUserDoesNotExist.description, errorConfig.kalturaUserDoesNotExist.code));
		}
		if (_.has(error, "status.code") && error.status.code == "1701") {
			return response.status(400).send(apiResponse.error(error.status.message, error.status.code));
		}
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(errorConfig.requestFailed, 400));
	}
}

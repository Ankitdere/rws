const apiResponse = require("../utils").apiResponse;
const errorConfig = require("../config").errorConfig;
const commonUtils = require("../utils").common;
const deleteProfileBusiness = require("../business").deleteProfile;

async function deleteProfile(request, response){
	const user = request.userToken;
	try{
		const result = await deleteProfileBusiness(user);
		const output = commonUtils.responseFormatter(result);
		return response.status(output.httpCode)
			.send(apiResponse.success(output.responseData,null,200));
	}catch(error){
		console.error("Delete profile error: "+ error );
		const { description, code } = errorConfig.deleteProfileFailed;
		return response.status(500)
			.send(apiResponse.error(description, code));
	}
}

module.exports = deleteProfile;
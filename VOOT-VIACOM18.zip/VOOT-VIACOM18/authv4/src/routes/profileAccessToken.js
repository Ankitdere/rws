"use strict";

const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const profileAccessTokenModel = require("../models").profileAccessToken;
const profileAccessTokenBusiness = require("../business").profileAccessToken;
const mixPanelConfig = require("../config/mixPanelConfig");
const _ = require("lodash");

module.exports = profileAccessToken;

async function profileAccessToken(request, response) {
	console.log("Reached Profiles Handler");
	const headers = {
		accessToken: request.header("accessToken"),
		buildNumber: request.header("buildNumber"),
		deviceInfo: request.header("deviceInfo"),
		uid: request.header("uid")
	};
	try {
		console.log("::: headers details ::: ", JSON.stringify(headers, null, 2));
		// Call to model for validate Schema
		const { error } = profileAccessTokenModel(headers.accessToken);

		// check the error and return if error exist
		if (error) {
			console.log("\n Error in getProfileByAccessToken/validation \n", error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error),0,mixPanelConfig.profilesAccessToken+mixPanelConfig.clientValidation_Error, headers,_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID"))));
		}

		// Get data from firebase
		const result = await profileAccessTokenBusiness(request.userToken);

		const output = commonUtils.responseFormatter(result);
		return response.status(output.httpCode).send(apiResponse.success(output.responseData,null,200,mixPanelConfig.profilesAccessToken+mixPanelConfig.success,{input:headers}, _.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID"))));

	} catch (error) {
		console.log("\n Error in getProfileByAccessToken/catch \n", error);
		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData,null,400,mixPanelConfig.profilesAccessToken+mixPanelConfig.serverValidation_Error,headers,_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID"))));
		}
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(error,0,mixPanelConfig.profilesAccessToken+mixPanelConfig.internalServerError, headers,_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID"))));
	}
}
"use strict";
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const kalturaBuildModel = require("../models").kalturaBuildModel;
const kalturaBuildBusiness = require("../business").kalturaBuildBusiness;
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");

module.exports = kalturaBuild;
async function kalturaBuild(request, response) {
	try {
		const input = request.body;
		//if(_.has(input,'email'))_.set(input, 'email', _.toLower(_.get(input, 'email')));
		const { error } = kalturaBuildModel(input);
		if (error) {
			console.log("\n Error in Check Kaltura Build Data/validation \n", error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error)));
		}
		const result = await kalturaBuildBusiness(input);
		const output = commonUtils.responseFormatter(result._doc);
		return response.status(output.httpCode).send(apiResponse.success(output.responseData));
	}
	catch (error) {
		console.error("\n Error in kalturaBuild data/catch \n", error);
		if (error.message == errorConfig.kalturaBuildAlreadyExist.code) {
			return response.status(400).send(apiResponse.error(errorConfig.kalturaBuildAlreadyExist.description, errorConfig.kalturaBuildAlreadyExist.code, 400));
		}
		let responseCode = (_.get(error, "status.code") ? _.get(error, "status.code") : 500);
		if (responseCode != 500)
			responseCode = 400;
		return response.status(responseCode).send(apiResponse.error(error));
	}
}

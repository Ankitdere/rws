
"use strict";

const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");
const Joi = require("joi");
const deltaMigrationBusiness = require("../business").deltaMigration;

module.exports = deltaMigration;

async function deltaMigration(request, response) {
	try {
		const input = request.body;
		console.log("Delta Migragtion API ", JSON.stringify(input));
		const schema = Joi.object().keys({
			email: Joi.string().email({ minDomainAtoms: 2 }).required().label(errorConfig.validationError.email),
			uid: Joi.string().required().label(errorConfig.validationError.uid),
			data: Joi.object().optional().label(errorConfig.validationError.data),
			apiName: Joi.string().required().label(errorConfig.validationError.apiName)
		});
		// Return result.
		const { error } = Joi.validate(input, schema, { abortEarly: false });
		if (error === null) {
			let { apiName, email, uid, data } = input;
			switch (apiName) {
			case "sign-up":
				await deltaMigrationBusiness.importOrUpdateAuth(data.userAuth, data.userProfile, data.password);
				break;
			case "login":
				if (_.get(data, "password")) {
					await deltaMigrationBusiness.importOrUpdateAuth(data.userAuth, data.userProfile, data.password);
				} else {
					await deltaMigrationBusiness.importSocailAuth(data.userAuth, data.userProfile);
				}
				break;
			case "update-account":
				if(!_.get(data, "userProfile.uid")){
					_.set(data, "userProfile.uid", uid);
				}
				if(!_.get(data, "userProfile.email")){
					_.set(data, "userProfile.email", email);
				}
				await deltaMigrationBusiness.importOrUpdateAccountData(data.uid, data.userProfile, data.password);
				break;
			case "forgot-password":
				await deltaMigrationBusiness.updateUserSystemData(uid, data.systemData);
				break;
			case "password-change":
				await deltaMigrationBusiness.updateAuthPassword(data.userAuth, data.systemData);
				break;
			default: break;
			}
			// eslint-disable-next-line no-undef
			const result = await insertOrUpdateDeltaUser(input);
			const output = commonUtils.responseFormatter(result);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData));
		} else {
			console.log("\n Error in checkEmail/validation \n", error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error)));
		}
	} catch (error) {
		console.log("\n Error in checkEmail/catch \n", error);
		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData));
		}
		return response.send(apiResponse.error(error));
	}
}

"use strict";

const _ = require("lodash");
const { deleteSubProfile: deleteSubProfileBusiness } = require("../business");
const { deleteSubProfile: deleteSubProfileModel } = require("../models");
const {
	common: commonUtils,
	apiResponse
} = require("../utils");
const {
	errorConfig,
	mixpanelEvent: mixPanelConfig,
} = require("../config");

module.exports = deleteSubProfile;

/**
 * @param {Object} request 
 * @param {Object} response 
 * @returns {Object}
 */
async function deleteSubProfile(request, response) {
	const input = request.body;
	try {
		const headers = {
			accessToken: request.header("accessToken")
		};
		console.log(
			"Input Request in delete sub Profile", JSON.stringify(input, null, 2),
			"\n::: headers details ::: ", JSON.stringify(headers, null, 2)
		);
		const { error } = deleteSubProfileModel(headers, input);

		if (error) {
			console.error("\n Error in deleteSubProfile/validation \n", error);
			const mpModelErrEventName = mixPanelConfig.deleteSubProfile + mixPanelConfig.clientValidation_Error;
			return response
				.status(400)
				.send(
					apiResponse.error(
						commonUtils.formatValidationErrors(error),
						400,
						mpModelErrEventName,
						input,
						request.userToken.uid,
						400
					)
				);
		}

		const result = await deleteSubProfileBusiness(input,request);
		const output = commonUtils.responseFormatter(result);
		
		const mpSuccessEventName = mixPanelConfig.deleteSubProfile + mixPanelConfig.success;
		
		return response
			.status(output.httpCode)
			.send(
				apiResponse.success(
					output.responseData,
					null,
					200,
					mpSuccessEventName,
					input,
					request.userToken.uid
				)
			);
	} catch (error) {
		console.error("\n Error in deleteSubProfile Route/catch \n", error);
		const mpServerErrEventName = mixPanelConfig.parentProfileCantBeDeleted + mixPanelConfig.serverValidation_Error;
		if(error && error.message === errorConfig.parentProfileCantBeDeleted.description)
		{
			const { description, code } = errorConfig.parentProfileCantBeDeleted;
			return response
				.status(400)
				.send(
					apiResponse.error(
						description, 
						code, 
						mpServerErrEventName, 
						input, 
						request.userToken.uid, 
						400)
				);
		}
		if (error && error.message == errorConfig.deleteSubProfile.description) {
			const { description, code } = errorConfig.deleteSubProfile;
			return response
				.status(400)
				.send(
					apiResponse.error(
						description, 
						code, 
						mpServerErrEventName, 
						input, 
						request.userToken.uid, 
						400)
				);
		}
		if (error && error.message == errorConfig.subProfileAlreadyDeleted.description) {
			const { description, code } = errorConfig.subProfileAlreadyDeleted;
			return response
				.status(400)
				.send(
					apiResponse.error(
						description, 
						code, 
						mpServerErrEventName, 
						input, 
						request.userToken.uid, 
						400)
				);
		}
		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response
				.status(output.httpCode)
				.send(
					apiResponse.success(null, output.responseData)
				);
		}

		const mpInternalServerErrEventName = mixPanelConfig.deleteSubProfile + mixPanelConfig.internalServerError;
		return response
			.status(500)
			.send(
				apiResponse.error(
					error.message, 
					500, 
					mpInternalServerErrEventName, 
					input, 
					request.userToken.uid, 
					500)
			);
	}
}

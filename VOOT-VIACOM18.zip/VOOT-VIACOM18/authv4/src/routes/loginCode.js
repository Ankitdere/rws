
"use strict";
const loginCodeBusiness = require("../business").loginCode;
const loginCodeModel = require("../models").loginCode;
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const _ = require("lodash");
module.exports = loginCode;

async function loginCode(request, response) {
	try {
		console.log("Inside Get Login Code");
		let loginCode = {
			deviceBrand: _.get(request, "query.deviceBrand"),
			deviceId: _.get(request, "query.deviceId")
		};
		const { error } = loginCodeModel(loginCode);
		if (error) {
			console.log("\n Error in loginCode/validation \n", error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error)));
		}
		const result = await loginCodeBusiness(loginCode.deviceId, loginCode.deviceBrand);
		const output = commonUtils.responseFormatter(result);
		return response.status(output.httpCode).send(apiResponse.success(output.responseData));
	} catch (error) {
		console.log("\n Error in loginCode/catch \n", error);
		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData));
		}
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(error));
	}
}
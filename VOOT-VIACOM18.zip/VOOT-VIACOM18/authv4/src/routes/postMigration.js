
"use strict";

const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");
const Joi = require("joi");
const mongoose = require("mongoose");
//Define a schema
const Schema = mongoose.Schema;

module.exports = postMigration;

async function postMigration(request, response) {
	try {
		const input = request.body;
		console.log("Post Migragtion API ", JSON.stringify(input));
		const schema = Joi.object().keys({
			payload: Joi.object().optional().label(errorConfig.validationError.data),
			apiName: Joi.string().required().label(errorConfig.validationError.apiName),
			accessToken: Joi.string().optional().label(errorConfig.validationError.accessToken)
		});
		// Return result.
		const { error } = Joi.validate(input, schema, { abortEarly: false });
		if (error === null) {
			_.set(input, "isUpdated", false);
			_.set(input, "createdAt", new Date().getTime());
			const result = await insertPostMigrationDeltaUser(input);
			const output = commonUtils.responseFormatter(result);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData));
		} else {
			console.log("\n Error in postMigration/validation \n", error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error)));
		}
	} catch (error) {
		console.log("\n Error in postMigration/catch \n", error);
		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData));
		}
		return response.send(apiResponse.error(error));
	}
}

async function insertPostMigrationDeltaUser(input) {
	// eslint-disable-next-line no-undef
	return new Promise((res, rej) => {
		const postMigrationSchema = new Schema(
			{
				apiName: String,
				paylod: Object,
				isUpdated: Boolean,
				createdAt: Number,
				updatedAt: Number,
				accessToken: String
			});
		const deltaUserSchema = mongoose.model("postMigration", postMigrationSchema);
		deltaUserSchema.create(input, function (err, data) {
			if (err)
				rej({ status: 1797, message: "Post Migration insertion failed" });
			else
				res(data);
		});
	});
}

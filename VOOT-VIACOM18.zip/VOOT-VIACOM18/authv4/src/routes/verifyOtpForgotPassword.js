"use strict";

const verifyOtpForgotPasswordBusiness = require("../business").verifyOtpForgotPassword;
const verifyOtpForgotPasswordModel = require("../models").verifyOtpForgotPassword;
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");
const mixPanelConfig = require("../config/mixPanelConfig");
const { ipService } = require("../services");

module.exports = verifyOtpForgotPassword;

async function verifyOtpForgotPassword(request, response){
	console.debug("Inside Verify Login Code");
	const input = request.body;
	const distinctId = _.get(input,"mobile",_.get(input,"email"));
	const inputType  = (input && _.isEmpty(input.email))? "mobile":"email";
	try {
		if(_.has(input,"email"))_.set(input, "email", _.toLower(_.get(input, "email")));
		const { error } = verifyOtpForgotPasswordModel(input);
		if (error) {
			console.log("\n Error in verifyCode/validation \n", error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error),400,mixPanelConfig.verifyOtpForgotPassword+inputType+mixPanelConfig.clientValidation_Error,input,distinctId,400));
		}
		const { region, country } = await ipService.getCountryAndRegionDetails(request);
		_.set(input, "regionInfo", { region, country });

		const result = await verifyOtpForgotPasswordBusiness(input);
		const output = commonUtils.responseFormatter(result);
		let eventName = mixPanelConfig.verifyOtpForgotPassword+inputType+mixPanelConfig.success;
		if(output.httpCode && output.httpCode  != 200){
			eventName = mixPanelConfig.verifyOtpForgotPassword+inputType+mixPanelConfig.clientValidation_Error;
		}
		return response.status(output.httpCode).send(apiResponse.success(output.responseData,null,output.httpCode,eventName,input,distinctId));
	} catch (error) {
		console.log("\n Error in verifyOtpForgotPassword/catch \n", error);
		if(error.message ==  errorConfig.otpDataNotFound.description){
			return response.status(400).send(apiResponse.error(errorConfig.otpDataNotFound.description, errorConfig.invalidDeviceBrand.code,mixPanelConfig.verifyOtpForgotPassword+inputType+mixPanelConfig.serverValidation_Error,input,distinctId,400));
		}
		if(error.message == errorConfig.otpExpired.description){
			return response.status(400).send(apiResponse.error(errorConfig.otpExpired.description, errorConfig.otpExpired.code,mixPanelConfig.verifyOtpForgotPassword+inputType+mixPanelConfig.serverValidation_Error,input,distinctId,400));
		}
		if(error.message == errorConfig.otpVerificationFailed.description){
			return response.status(400).send(apiResponse.error(errorConfig.otpVerificationFailed.description, errorConfig.otpVerificationFailed.code,mixPanelConfig.verifyOtpForgotPassword+inputType+mixPanelConfig.serverValidation_Error,input,distinctId,400));
		} if(error.message == errorConfig.emailNotRegistered.description){
			return response.status(400).send(apiResponse.error(errorConfig.emailNotRegistered.description, errorConfig.emailNotRegistered.code,mixPanelConfig.verifyOtpForgotPassword+inputType+mixPanelConfig.serverValidation_Error,input,distinctId,400));
		} 
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(error,500,mixPanelConfig.verifyOtpForgotPassword+inputType+mixPanelConfig.internalServerError,{input:input,error:_.get(error,"stack")},distinctId,500));
           
		// return response.status(500).send(apiResponse.error(error));
	}
}
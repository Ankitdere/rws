"use strict";
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const searchDetailsModel = require("../models").searchDetailsModel;
const searchDetailsBusiness = require("../business").searchDetailsBuisness;
const requestIp = require("request-ip");
const errorConfig = require("../config").errorConfig;
const _ = require("lodash");

module.exports = searchDetails;
async function searchDetails(request, response) {
	try {
		const input = request.body;
		const ipAddress = requestIp.getClientIp(request);
		const accessToken = request.header("accessToken");
		console.log("ACCESS TOKEN", accessToken);
		// const headers = request.header
		const headers = {
			accessToken: request.header("accessToken"),
			apiVersion: request.header("apiVersion")
		};
		console.log("HEADERS INSIDE ROUTES", headers);
		// check accesstoken is empty
		if (!accessToken) {
			return response.status(403).send(apiResponse.error(errorConfig.verifyApiAccessTokenRequired.description, errorConfig.verifyApiAccessTokenRequired.code));
		}
		console.log("WhitelistIP calling " + ipAddress);
		// Check for the whitelist ip
		// if (!whitelistip.includes(ipAddress)) {
		//     return response.status(403).send(apiResponse.error(errorConfig.noAuthorizeforgetOtp.description, errorConfig.noAuthorizeforgetOtp.code));
		// }
		// Verify requestBody using service
		try{
			await searchDetailsModel(input, headers);
		}catch(error) {
			console.log("\n Error in searchDetails/validation \n", error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error)));
		}
		console.log("AFTER ERROR IN ROUTES");
		const result = await searchDetailsBusiness(input.data);
		const output = commonUtils.responseFormatter(result);
		return response.status(output.httpCode).send(apiResponse.success({ "code": output.httpCode, "message": "Users retrieved successfully", "data": output.responseData.data, }));

	}
	catch (error) {
		console.error("\n Error in searchDetails/catch \n", error, error.stack);
		if (error.message == errorConfig.emailNotRegistered.code) {
			return response.status(400).send(apiResponse.error(errorConfig.emailNotRegistered.description, errorConfig.emailNotRegistered.code));
		}

		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData));
		}
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(errorConfig.requestFailed, 400));
	}
}

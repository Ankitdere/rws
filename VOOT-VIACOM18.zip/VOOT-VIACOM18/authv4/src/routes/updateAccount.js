
"use strict";

const updateAccountBusiness = require("../business").updateAccount;
const updateAccountModel = require("../models").updateAccount;
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const errorConfig = require("../config").errorConfig;
const config = require("../config").configuration;
const _ = require("lodash");
const mixPanelConfig = require("../config/mixPanelConfig");
const requestIp = require("request-ip");

async function updateAccount(request, response) {
	const input = request.body;
	const headers = {
		accessToken: request.header("accessToken"),
		apiVersion: request.header("apiVersion")
	};
	try {
		console.log("input: ", JSON.stringify(input, null, 2), "\n::: headers details ::: ", JSON.stringify(headers, null, 2));
		if(request.hasOwnProperty("body")==false)
			return response.status(400).send(apiResponse.error("Request body is empty, Please verify it"));
		if(request.headers.hasOwnProperty("uid")==false && request.headers.hasOwnProperty("accesstoken")==false)
			return response.status(400).send(apiResponse.error("Request header is empty, Please verify it"));

		const { error } = updateAccountModel(headers, input);
		const languagelist = input.languages;
		if (_.has(error, "status.code")){
			console.log("\n Error in updateAccount/validation \n",error);
			return response.status(400).send(error);
		}

		if (error) {
			console.log("\n Error in updateAccount/validation \n",error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error),0, mixPanelConfig.updateAccount+mixPanelConfig.clientValidation_Error, input,_.get(headers,"uid","No_Uid") ));
		}

		for (const index in languagelist) {
			if (!config.DefaultLanguages.includes(languagelist[index].trim())) {
				return response.status(400).send(apiResponse.error(errorConfig.invalidLanguage.description, errorConfig.invalidLanguage.code, mixPanelConfig.updateAccount + mixPanelConfig.clientValidation_Error, input, _.get(request.userToken, "uid", _.get(headers, "uid", "No_Uid"))));
			}
		}
		const ipAddress = requestIp.getClientIp(request);
		const  methodType = request.method;
		let auditObj={
			ipAddress:ipAddress,
			methodType:methodType
		};
		let options= {
			userToken : request.userToken,
			headers:request.headers
		};
		const result = await updateAccountBusiness(input, options, auditObj);
		const output = commonUtils.responseFormatter(result);
		return response.status(output.httpCode).send(apiResponse.success(output.responseData,null,200, mixPanelConfig.updateAccount+mixPanelConfig.success,{
			distinct_id:_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID")), input:input
		},_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID"))));
	} catch (error) {
		console.log("\n Error in updateAccount/catch \n",error);
		if(error.message == errorConfig.userDoesNotExist.code){
			return response.status(400).send(apiResponse.error(errorConfig.userDoesNotExist.description, errorConfig.userDoesNotExist.code,mixPanelConfig.updateAccount+mixPanelConfig.serverValidation_Error, _.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID")),400));
		}
		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData));
		}
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(error,null,mixPanelConfig.updateAccount+mixPanelConfig.internalServerError, input,_.get(request.userToken,"email",_.get(request.userToken,"uid","No_UID")),500));
	}
}
module.exports = updateAccount;
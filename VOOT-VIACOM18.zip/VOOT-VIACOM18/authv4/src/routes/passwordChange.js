"use strict";
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const passwordChangeModel = require("../models").passwordChange;
const passwordChangeBusiness = require("../business").passwordChange;
const requestIp = require("request-ip");

const _ = require("lodash");

module.exports = passwordChange;

async function passwordChange(request, response){
	try {
		let input = request.body;
		const headers = {
			accessToken : request.header("accessToken"),
			buildNumber : request.header("buildNumber"),
			deviceInfo : request.header("deviceInfo"),
			uid : request.header("uid")
		};
		console.log("input: ", JSON.stringify(input, null, 2), "\n::: headers details ::: ", JSON.stringify(headers, null, 2));
        
		const { error } = passwordChangeModel(request.header("accessToken"), input);
		if (error) 
		{
			console.log("\n Error in changePassword/validation \n",error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error)));
		}
		//for audit purpose
		const ipAddress = requestIp.getClientIp(request);
		const  methodType = request.method;
		let auditObj={
			ipAddress:ipAddress,
			methodType:methodType
		};
		const result = await passwordChangeBusiness(input, request.userToken,auditObj);
		const output = commonUtils.responseFormatter(result);
		return response.status(output.httpCode).send(apiResponse.success(output.responseData));
	} catch (error) {
		console.error("\n Error in changePassword/catch \n",error);
		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData));
		}
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(error));
	}
}

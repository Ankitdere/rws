
"use strict";
const checkUserBusiness = require("../business").checkUser;
const checkUserModel = require("../models").checkUser;
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const errorConfig = require("../config").errorConfig;
const mixpanelEvent =require("../config").mixpanelEvent;
const _ = require("lodash");

module.exports = checkUser;

async function checkUser(request, response) {
	const input = request.body;
	try {

		_.set(input, "type", _.toLower(_.get(input, "type", "")));
		if(_.has(input,"email"))_.set(input, "email", _.toLower(_.get(input, "email")));
		const typeArr = ["email", "mobile"];
		if (!_.includes(typeArr, input.type)) {
			console.error("\n Error in checkUser(typeMissing.description, typeMissing.code) \n");
			return response.status(400).send(apiResponse.error(errorConfig.typeMissing.description, errorConfig.typeMissing.code, mixpanelEvent.checkUser + _.get(input, "type", "") + mixpanelEvent.clientValidation_Error, input, _.get(input, "email",_.get(input,"mobile"))));
            
		}
		const { error } = checkUserModel(input, input.type);
		if (error) {
			console.error("\n Error in verifyUser/validation \n", error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error),0,mixpanelEvent.checkUser + _.get(input, "type", "") + mixpanelEvent.clientValidation_Error, input, _.get(input, "mobile",_.get(input,"email"))));
		}
		const result = await checkUserBusiness(input);
		const output = commonUtils.responseFormatter(result);
		return response.status(output.httpCode).send(apiResponse.success(output.responseData,null,output.httpCode,mixpanelEvent.checkUser + _.get(input,"type","") + mixpanelEvent.success,input,_.get(input, "mobile",_.get(input,"email"))));

	} catch (error) {
		console.error("\n Error in checkUser/catch \n", error);
		if (_.has(error, "status.code")) {
			const output = commonUtils.responseFormatter(error);
			return response.status(output.httpCode).send(apiResponse.success(output.responseData,null,output.httpCode,mixpanelEvent.checkUser+_.get(input, "type", "") + mixpanelEvent.serverValidation_Error,input,_.get(input, "email",_.get(input,"mobile"))));
		}
		return response.send(apiResponse.error(error,0,mixpanelEvent.getProfile+mixpanelEvent.internalServerError,{input:input,error:_.get(error,"stack")},_.get(input, "email",_.get(input,"mobile"))));
	}
}
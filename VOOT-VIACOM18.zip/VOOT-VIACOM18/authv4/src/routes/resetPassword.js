"use strict";

const resetPasswordBusiness = require("../business").resetPassword;
const resetPasswordModel = require("../models").resetPassword;
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const errorConfig = require("../config").errorConfig;

module.exports = resetPassword;

async function resetPassword(request, response){
	try {
		console.log("Inside Reset Password ");  
		const input = request.body;
		const tokenInfo=request.tokenInfo;
		const headers = {
			forgotpasswordtoken : request.header("forgotpasswordtoken"),
			buildNumber : request.header("buildNumber"),
			deviceInfo : request.header("deviceInfo"),
			uid : request.header("uid")
		};
		console.log("input: ", JSON.stringify(input, null, 2), "\n::: headers details ::: ", JSON.stringify(headers, null, 2));
		console.log("Reset Password ", JSON.stringify(input, null, 2));
		const { error } =resetPasswordModel(input,headers );
		if (error) {
			console.log("\n Error in resendPassword/validation \n", error);
			return response.status(400).send(apiResponse.error(commonUtils.formatValidationErrors(error)));
		}
		const result = await resetPasswordBusiness(input,tokenInfo);
		const output = commonUtils.responseFormatter(result);
		return response.status(output.httpCode).send(apiResponse.success(output.responseData));
	} catch (error) {
		console.log("\n Error in resetPassword/catch \n", error);

		if(error.message == errorConfig.invalidDeviceBrand.code){
			return response.status(400).send(apiResponse.error(errorConfig.invalidDeviceBrand.description, errorConfig.invalidDeviceBrand.code));
		}
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(error));
	}
}
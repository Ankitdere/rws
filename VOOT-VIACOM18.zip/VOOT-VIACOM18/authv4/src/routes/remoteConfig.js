"use strict";
const commonUtils = require("../utils").common;
const apiResponse = require("../utils").apiResponse;
const remoteConfigBusiness = require("../business").remoteConfig;
module.exports = remoteConfig;

async function remoteConfig(request, response) {
	try {
		console.log("Inside Get Remote Config");
		const result = await remoteConfigBusiness();
		const output = commonUtils.responseFormatter(result);
		return response.status(output.httpCode).send(apiResponse.success(output.responseData));
	} catch (error) {
		console.log("\n Error in getRemoteConfig/catch \n",error);
		console.log("response of api ",error);
		return response.status(500).send(apiResponse.error(error));
	}
}
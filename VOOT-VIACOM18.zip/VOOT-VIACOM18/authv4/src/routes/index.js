"use strict";

const login = require("./login");
const signUp = require("./signUp");
const updateAccount = require("./updateAccount");
const checkEmail = require("./checkEmail");
const loginCode = require("./loginCode");
const activateCode = require("./activateCode");
const verifyCode = require("./verifyCode");
const forgotPassword = require("./forgotPassword");
const passwordChange = require("./passwordChange");
const getOtpDetails = require("./getOtpDetails");
const profileAccessToken = require("./profileAccessToken");
const refreshAccessToken = require("./refreshAccessToken");
const refreshKs = require("./refreshKs");
const authKey = require("./authKey");
const jioEntitlement = require("./jioEntitlement");
const jioSubscription = require("./jioSubscription");
const deltaMigration = require("./deltaMigration");
const updateProfile = require("./updateProfile");
const getUserProfile = require("./getUserProfile");
const deleteProfile = require("./deleteProfile");
const postMigration = require("./postMigration");
const verifyOtpForgotPassword = require("./verifyOtpForgotPassword");
const changePasswordWithLogin = require("./changePasswordWithLogin");
const resetPasswordWithLogin = require("./resetPasswordWithLogin");
const appleRedirect = require("./appleRedirect");
const checkUser = require("./checkUser");
const resendOtp = require("./resendOtp");
const verifyOtp = require("./verifyOtp");
const resetPassword = require("./resetPassword");
const partnerSignIn = require("./partnerSignIn");
const partnerNotification = require("./partnerNotification");
const remoteConfig = require("./remoteConfig");
const getAccessToken = require("./getAccessToken");
const partnerDetails = require("./partnerDetails");
const anonymousTokeRoute = require("./AnonymousTokeRoute");
const authsTokensRoute = require("./authsTokens");
const searchDetails = require("./searchDetails");
const checkKalturaAccountRoute = require("./checkKalturaAccountRoute");
const kalturaBuildRoute = require("./kalturaBuildRoute");
// Partner v1.5
const V_1_5_PartnerLogin = require("./v1.5/partners/login");
const V_1_5_PartnerRefreshToken = require("./v1.5/partners/refreshToken");
const V_1_5_PartnerPurchase = require("./v1.5/partners/purchase");
const V_1_5_PartnerGetStatus = require("./v1.5/partners/getStatus");
const V_1_5_PartnerUpdateStatus = require("./v1.5/partners/updateStatus");
const loginInfoByDeviceId = require( "./loginInfoByDeviceId" );
const synchCrmData = require( "./synchCrmData" );
const createSubProfile = require( "./createSubProfile" );
const getSubProfiles = require( "./getSubProfiles" );
const getSubProfilesAccessToken = require( "./getSubProfilesAccessToken" );
const deleteSubProfile = require( "./deleteSubProfile" );
const updateSubProfile = require( "./updateSubProfile" );

const sendMessage = require("./sendMessage");
const smsData = require("./smsData");

module.exports = {
	login,
	signUp,
	updateAccount,
	checkEmail,
	loginCode,
	verifyCode,
	activateCode,
	forgotPassword,
	passwordChange,
	getOtpDetails,
	profileAccessToken,
	refreshAccessToken,
	refreshKs,
	authKey,
	deltaMigration,
	jioEntitlement,
	jioSubscription,
	updateProfile,
	getUserProfile,
	deleteProfile,
	postMigration,
	verifyOtpForgotPassword,
	changePasswordWithLogin,
	resetPasswordWithLogin,
	appleRedirect,
	checkUser,
	resendOtp,
	verifyOtp,
	resetPassword,
	partnerSignIn,
	partnerNotification,
	remoteConfig,
	getAccessToken,
	partnerDetails,
	// Partner V1.5
	V_1_5_PartnerLogin,
	V_1_5_PartnerRefreshToken,
	V_1_5_PartnerPurchase,
	V_1_5_PartnerGetStatus,
	V_1_5_PartnerUpdateStatus,
	anonymousTokeRoute,
	authsTokensRoute,
	searchDetails,
	loginInfoByDeviceId,
	checkKalturaAccountRoute,
	kalturaBuildRoute,
	synchCrmData,
	createSubProfile,
	getSubProfiles,
	getSubProfilesAccessToken,
	deleteSubProfile,
	updateSubProfile,
	sendMessage,
	smsData
};
